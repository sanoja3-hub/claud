import { InventoryItem } from '../types';

// Generator to produce a rich and balanced retail dataset matching real-world retail chains
const STORES = [
  'Tienda Centro (Flagship)',
  'Tienda Norte Mall',
  'Tienda Sur Outlet',
  'Tienda Este Plaza',
];

const BRANDS = ['NIKE', 'ADIDAS', 'PUMA', 'UNDER ARMOUR', 'NEW BALANCE', 'ASICS', 'REEBOK', 'ON RUNNING'];

const SHOE_SIZES_MEN = ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12'];
const SHOE_SIZES_WOMEN = ['5', '5.5', '6', '6.5', '7', '7.5', '8', '8.5', '9'];
const SHOE_SIZES_KIDS = ['1', '2', '3', '4', '5', '6'];
const TEXTILE_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const ACC_SIZES = ['U'];

interface ItemTemplate {
  ref: string;
  depto: 'CALZADO' | 'TEXTIL' | 'ACCESORIOS';
  seccion: string;
  familia: string;
  marca: string;
  precioBase: number;
  anomaly?: 'monotalla' | 'broken_core' | 'overstock' | 'normal';
}

const TEMPLATES: ItemTemplate[] = [
  // CALZADO HOMBRE
  { ref: 'NK-PEGASUS-40', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'NIKE', precioBase: 139.99, anomaly: 'normal' },
  { ref: 'NK-INVINCIBLE-3', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'NIKE', precioBase: 189.99, anomaly: 'broken_core' },
  { ref: 'AD-ULTRABOOST-LIGHT', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'ADIDAS', precioBase: 180.00, anomaly: 'normal' },
  { ref: 'AD-BOSTON-12', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'ADIDAS', precioBase: 160.00, anomaly: 'monotalla' },
  { ref: 'PU-DEVIATE-NITRO-2', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'PUMA', precioBase: 150.00, anomaly: 'normal' },
  { ref: 'AS-GEL-NIMBUS-26', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'ASICS', precioBase: 160.00, anomaly: 'broken_core' },
  { ref: 'NB-FRESHFOAM-1080', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'NEW BALANCE', precioBase: 165.00, anomaly: 'normal' },
  { ref: 'ON-CLOUDMONSTER-2', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'ON RUNNING', precioBase: 179.95, anomaly: 'normal' },

  { ref: 'NK-METCON-9', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'TRAINING', marca: 'NIKE', precioBase: 150.00, anomaly: 'overstock' },
  { ref: 'UA-PROJECT-ROCK-6', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'TRAINING', marca: 'UNDER ARMOUR', precioBase: 140.00, anomaly: 'normal' },
  { ref: 'RB-NANO-X4', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'TRAINING', marca: 'REEBOK', precioBase: 140.00, anomaly: 'monotalla' },

  { ref: 'NK-MERCURIAL-VAPOR', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'FUTBOL', marca: 'NIKE', precioBase: 110.00, anomaly: 'normal' },
  { ref: 'AD-PREDATOR-ELITE', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'FUTBOL', marca: 'ADIDAS', precioBase: 125.00, anomaly: 'broken_core' },
  { ref: 'PU-FUTURE-MATCH', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'FUTBOL', marca: 'PUMA', precioBase: 85.00, anomaly: 'normal' },

  { ref: 'NK-AIR-FORCE-1-07', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'NIKE', precioBase: 115.00, anomaly: 'overstock' },
  { ref: 'AD-SAMBA-OG', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'ADIDAS', precioBase: 100.00, anomaly: 'normal' },
  { ref: 'NB-550-VINTAGE', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'NEW BALANCE', precioBase: 120.00, anomaly: 'normal' },
  { ref: 'PU-SUEDE-CLASSIC', depto: 'CALZADO', seccion: 'HOMBRE (MENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'PUMA', precioBase: 75.00, anomaly: 'monotalla' },

  // CALZADO MUJER
  { ref: 'NK-INFINITYRN-4-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'RUNNING', marca: 'NIKE', precioBase: 160.00, anomaly: 'normal' },
  { ref: 'AD-ADIZERO-SL-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'RUNNING', marca: 'ADIDAS', precioBase: 120.00, anomaly: 'broken_core' },
  { ref: 'AS-GEL-KAYANO-30-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'RUNNING', marca: 'ASICS', precioBase: 160.00, anomaly: 'normal' },
  { ref: 'NK-SUPERREP-GO-3-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'TRAINING', marca: 'NIKE', precioBase: 100.00, anomaly: 'monotalla' },
  { ref: 'UA-TRIBASE-REIGN-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'TRAINING', marca: 'UNDER ARMOUR', precioBase: 130.00, anomaly: 'normal' },
  { ref: 'NK-DUNK-LOW-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'NIKE', precioBase: 115.00, anomaly: 'overstock' },
  { ref: 'AD-GAZELLE-BOLD-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'ADIDAS', precioBase: 120.00, anomaly: 'normal' },
  { ref: 'NB-327-HERITAGE-W', depto: 'CALZADO', seccion: 'MUJER (WOMENS)', familia: 'CASUAL / SPORTSWEAR', marca: 'NEW BALANCE', precioBase: 100.00, anomaly: 'normal' },

  // CALZADO NIÑOS
  { ref: 'NK-FLEX-RUNNER-2-K', depto: 'CALZADO', seccion: 'INFANTE / NIÑOS', familia: 'UNIFICADO', marca: 'NIKE', precioBase: 45.00, anomaly: 'normal' },
  { ref: 'AD-TENSAUR-SPORT-K', depto: 'CALZADO', seccion: 'INFANTE / NIÑOS', familia: 'UNIFICADO', marca: 'ADIDAS', precioBase: 38.00, anomaly: 'monotalla' },
  { ref: 'PU-SMASH-V2-K', depto: 'CALZADO', seccion: 'INFANTE / NIÑOS', familia: 'UNIFICADO', marca: 'PUMA', precioBase: 35.00, anomaly: 'normal' },

  // TEXTIL HOMBRE
  { ref: 'NK-DRIFIT-TEE-M', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'TRAINING', marca: 'NIKE', precioBase: 35.00, anomaly: 'normal' },
  { ref: 'UA-TECH-2-TEE-M', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'TRAINING', marca: 'UNDER ARMOUR', precioBase: 25.00, anomaly: 'overstock' },
  { ref: 'NK-MILER-RUN-M', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'NIKE', precioBase: 40.00, anomaly: 'normal' },
  { ref: 'AD-OWNTHERUN-JKT-M', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'RUNNING', marca: 'ADIDAS', precioBase: 65.00, anomaly: 'monotalla' },
  { ref: 'NK-CLUB-FLEECE-HD', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'SPORTSWEAR', marca: 'NIKE', precioBase: 65.00, anomaly: 'normal' },
  { ref: 'AD-ESSENTIALS-PANT', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'SPORTSWEAR', marca: 'ADIDAS', precioBase: 50.00, anomaly: 'overstock' },
  { ref: 'NK-ACADEMY-SHORT', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'FUTBOL', marca: 'NIKE', precioBase: 30.00, anomaly: 'normal' },
  { ref: 'AD-TIRO-23-TRACK', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'FUTBOL', marca: 'ADIDAS', precioBase: 55.00, anomaly: 'normal' },

  // TEXTIL MUJER
  { ref: 'NK-PRO-3INCH-SHORT-W', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'TRAINING', marca: 'NIKE', precioBase: 32.00, anomaly: 'normal' },
  { ref: 'UA-HEATGEAR-LEGGING-W', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'TRAINING', marca: 'UNDER ARMOUR', precioBase: 45.00, anomaly: 'overstock' },
  { ref: 'NK-SWOOSH-MED-BRA', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'TRAINING', marca: 'NIKE', precioBase: 38.00, anomaly: 'normal' },
  { ref: 'AD-FAST-LEGGING-W', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'RUNNING', marca: 'ADIDAS', precioBase: 55.00, anomaly: 'monotalla' },
  { ref: 'PU-RUN-FAVORITE-W', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'RUNNING', marca: 'PUMA', precioBase: 30.00, anomaly: 'normal' },
  { ref: 'NK-SPORTSWEAR-TEE-W', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'SPORTSWEAR', marca: 'NIKE', precioBase: 30.00, anomaly: 'normal' },
  { ref: 'AD-ORIGINALS-CROPHOOD', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'SPORTSWEAR', marca: 'ADIDAS', precioBase: 60.00, anomaly: 'normal' },

  // TEXTIL NIÑOS
  { ref: 'NK-CLUB-KIDS-SET', depto: 'TEXTIL', seccion: 'INFANTE / NIÑOS', familia: 'UNIFICADO', marca: 'NIKE', precioBase: 48.00, anomaly: 'normal' },
  { ref: 'AD-JUNIOR-TEE', depto: 'TEXTIL', seccion: 'INFANTE / NIÑOS', familia: 'UNIFICADO', marca: 'ADIDAS', precioBase: 22.00, anomaly: 'monotalla' },

  // ACCESORIOS HOMBRE (CABALLERO)
  { ref: 'NK-HERITAGE-CAP-M', depto: 'ACCESORIOS', seccion: 'HOMBRE (MENS)', familia: 'GORRAS / CAPS', marca: 'NIKE', precioBase: 24.00, anomaly: 'overstock' },
  { ref: 'AD-BASEBALL-CAP-M', depto: 'ACCESORIOS', seccion: 'HOMBRE (MENS)', familia: 'GORRAS / CAPS', marca: 'ADIDAS', precioBase: 20.00, anomaly: 'normal' },
  { ref: 'NK-BRASILIA-DUFFEL-M', depto: 'ACCESORIOS', seccion: 'HOMBRE (MENS)', familia: 'MOCHILAS / MALETINES', marca: 'NIKE', precioBase: 42.00, anomaly: 'normal' },
  { ref: 'UA-HUSTLE-BACKPACK-M', depto: 'ACCESORIOS', seccion: 'HOMBRE (MENS)', familia: 'MOCHILAS / MALETINES', marca: 'UNDER ARMOUR', precioBase: 55.00, anomaly: 'normal' },
  { ref: 'NK-EVERYDAY-CUSH-M', depto: 'TEXTIL', seccion: 'HOMBRE (MENS)', familia: 'CALCETINES / MEDIAS', marca: 'NIKE', precioBase: 18.00, anomaly: 'normal' },

  // ACCESORIOS MUJER (DAMA)
  { ref: 'NK-AEROBILL-VISOR-W', depto: 'ACCESORIOS', seccion: 'MUJER (WOMENS)', familia: 'GORRAS / VISERAS', marca: 'NIKE', precioBase: 26.00, anomaly: 'normal' },
  { ref: 'AD-TOTE-GYM-BAG-W', depto: 'ACCESORIOS', seccion: 'MUJER (WOMENS)', familia: 'BOLSOS / MOCHILAS', marca: 'ADIDAS', precioBase: 38.00, anomaly: 'overstock' },
  { ref: 'PU-SPORTS-BOTTLE-W', depto: 'ACCESORIOS', seccion: 'MUJER (WOMENS)', familia: 'BOLSOS / MOCHILAS', marca: 'PUMA', precioBase: 14.00, anomaly: 'monotalla' },
  { ref: 'UA-WOMENS-SOCK-3PK', depto: 'TEXTIL', seccion: 'MUJER (WOMENS)', familia: 'CALCETINES / MEDIAS', marca: 'UNDER ARMOUR', precioBase: 16.00, anomaly: 'normal' },

  // ACCESORIOS NIÑOS
  { ref: 'NK-KIDS-BACKPACK', depto: 'ACCESORIOS', seccion: 'INFANTE / NIÑOS', familia: 'MOCHILAS INFANTILES', marca: 'NIKE', precioBase: 30.00, anomaly: 'normal' },
  { ref: 'AD-KIDS-CAP', depto: 'ACCESORIOS', seccion: 'INFANTE / NIÑOS', familia: 'GORRAS INFANTILES', marca: 'ADIDAS', precioBase: 18.00, anomaly: 'normal' },
  { ref: 'PU-KIDS-SOCKS-3PK', depto: 'TEXTIL', seccion: 'INFANTE / NIÑOS', familia: 'CALCETINES', marca: 'PUMA', precioBase: 12.00, anomaly: 'monotalla' },
];

export function generateSampleInventory(): InventoryItem[] {
  const items: InventoryItem[] = [];

  STORES.forEach((tienda, storeIdx) => {
    // Generate items for each template across stores
    TEMPLATES.forEach((tmpl, tmplIdx) => {
      let sizeList: string[] = [];
      if (tmpl.depto === 'CALZADO') {
        if (tmpl.seccion.includes('HOMBRE')) sizeList = SHOE_SIZES_MEN;
        else if (tmpl.seccion.includes('MUJER')) sizeList = SHOE_SIZES_WOMEN;
        else sizeList = SHOE_SIZES_KIDS;
      } else if (tmpl.depto === 'TEXTIL') {
        sizeList = TEXTILE_SIZES;
      } else {
        sizeList = ACC_SIZES;
      }

      // Vary behavior by store and anomaly profile
      const isStoreOrigin = storeIdx === 0;
      const isStoreSurOutlet = storeIdx === 2;

      if (tmpl.anomaly === 'monotalla') {
        // Only 1 size, 1 or 2 units
        const singleSize = sizeList[tmplIdx % sizeList.length];
        const stockVal = (tmplIdx % 2) + 1; // 1 or 2
        items.push({
          Referencia: tmpl.ref,
          Departamento: tmpl.depto,
          Seccion: tmpl.seccion,
          Familia: tmpl.familia,
          Marca: tmpl.marca,
          Talla: singleSize,
          Stock: stockVal,
          Valoracion: Number((stockVal * tmpl.precioBase).toFixed(2)),
          Tienda: tienda,
          SKU_Talla: `${tmpl.ref} | ${singleSize}`,
        });
      } else if (tmpl.anomaly === 'broken_core' && tmpl.depto === 'CALZADO') {
        // Missing core sizes (8.5, 9, 9.5, 10), only has extreme sizes (7 or 12) with 2-3 units each
        const extremeSizes = [sizeList[0], sizeList[sizeList.length - 1]];
        extremeSizes.forEach((sz) => {
          const stockVal = 2 + (storeIdx % 2);
          items.push({
            Referencia: tmpl.ref,
            Departamento: tmpl.depto,
            Seccion: tmpl.seccion,
            Familia: tmpl.familia,
            Marca: tmpl.marca,
            Talla: sz,
            Stock: stockVal,
            Valoracion: Number((stockVal * tmpl.precioBase).toFixed(2)),
            Tienda: tienda,
            SKU_Talla: `${tmpl.ref} | ${sz}`,
          });
        });
      } else if (tmpl.anomaly === 'overstock') {
        // High stock across sizes (>28 units total for model)
        sizeList.forEach((sz, sIdx) => {
          const stockVal = isStoreSurOutlet ? 8 + sIdx : 5 + (sIdx % 4);
          items.push({
            Referencia: tmpl.ref,
            Departamento: tmpl.depto,
            Seccion: tmpl.seccion,
            Familia: tmpl.familia,
            Marca: tmpl.marca,
            Talla: sz,
            Stock: stockVal,
            Valoracion: Number((stockVal * tmpl.precioBase).toFixed(2)),
            Tienda: tienda,
            SKU_Talla: `${tmpl.ref} | ${sz}`,
          });
        });
      } else {
        // Normal healthy curve or slight variations
        sizeList.forEach((sz, sIdx) => {
          // If store 1 has excess and store 2 has zero, creates transfer opportunity!
          let stockVal = 3;
          if (isStoreOrigin) {
            stockVal = (sIdx >= 3 && sIdx <= 6) ? 5 : 2;
          } else if (isStoreSurOutlet) {
            stockVal = (sIdx % 3 === 0) ? 0 : 2;
          } else {
            stockVal = 2 + ((sIdx + storeIdx) % 3);
          }

          if (stockVal > 0) {
            items.push({
              Referencia: tmpl.ref,
              Departamento: tmpl.depto,
              Seccion: tmpl.seccion,
              Familia: tmpl.familia,
              Marca: tmpl.marca,
              Talla: sz,
              Stock: stockVal,
              Valoracion: Number((stockVal * tmpl.precioBase).toFixed(2)),
              Tienda: tienda,
              SKU_Talla: `${tmpl.ref} | ${sz}`,
            });
          }
        });
      }
    });

    // Expand dataset depth with additional realistic SKUs to populate full retail scale
    for (let i = 1; i <= 25; i++) {
      const brand = BRANDS[i % BRANDS.length];
      const dept: 'CALZADO' | 'TEXTIL' | 'ACCESORIOS' = i % 3 === 0 ? 'ACCESORIOS' : i % 2 === 0 ? 'TEXTIL' : 'CALZADO';
      const ref = `${brand.substring(0, 2)}-CORE-SERIES-${100 + i}`;
      const sec = dept === 'ACCESORIOS' ? 'UNISEX / GLOBAL' : (i % 2 === 0 ? 'HOMBRE (MENS)' : 'MUJER (WOMENS)');
      const fam = dept === 'CALZADO' ? 'RUNNING' : dept === 'TEXTIL' ? 'TRAINING' : 'UNIFICADO';
      const pBase = dept === 'CALZADO' ? 120 : dept === 'TEXTIL' ? 45 : 25;
      
      const sizes = dept === 'CALZADO' ? ['8', '8.5', '9', '9.5', '10', '10.5'] : dept === 'TEXTIL' ? ['S', 'M', 'L', 'XL'] : ['U'];
      sizes.forEach((sz, sIdx) => {
        const stockVal = 3 + ((i + sIdx + storeIdx) % 4);
        items.push({
          Referencia: ref,
          Departamento: dept,
          Seccion: sec,
          Familia: fam,
          Marca: brand,
          Talla: sz,
          Stock: stockVal,
          Valoracion: Number((stockVal * pBase).toFixed(2)),
          Tienda: tienda,
          SKU_Talla: `${ref} | ${sz}`,
        });
      });
    }
  });

  return items;
}
