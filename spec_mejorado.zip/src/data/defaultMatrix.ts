import { CapacityMatrixConfig, StoreDistance, StoreProfile, StoreType } from '../types';

export const STORE_FORMAT_INFO: Record<
  StoreType,
  {
    label: string;
    name: string;
    badge: string;
    description: string;
  }
> = {
  FLAGSHIP: {
    label: 'Flagship',
    name: 'Flagship (Gran Formato)',
    badge: 'Gran Formato',
    description: 'Tienda insignia de alta experiencia, amplio metraje y múltiples zonas de exhibición.',
  },
  LIVE: {
    label: 'Live',
    name: 'Live (Estándar Mall)',
    badge: 'Estándar Mall',
    description: 'Formato comercial estándar para centros comerciales y vías de alto tránsito.',
  },
  UNITE: {
    label: 'Unite',
    name: 'Unite (Outlet)',
    badge: 'Outlet',
    description: 'Formato de oportunidad, liquidación y alta densidad de percheros/estanterías.',
  },
  EXPRESS: {
    label: 'Express',
    name: 'Express (Compacto)',
    badge: 'Compacto',
    description: 'Formato ágil y compacto para estaciones, aeropuertos y conveniencia.',
  },
};

export function createBaseBrandMatrix(defaultDepth: number = 16): CapacityMatrixConfig {
  return {
    CALZADO: {
      activa: true,
      profundidad_target: defaultDepth,
      piezas_exhibicion_sku: 1,
      secciones: {
        'HOMBRE (MENS)': {
          RUNNING: 0,
          TRAINING: 0,
          FUTBOL: 0,
          'CASUAL / SPORTSWEAR': 0,
        },
        'MUJER (WOMENS)': {
          RUNNING: 0,
          TRAINING: 0,
          'CASUAL / SPORTSWEAR': 0,
        },
        'INFANTE / NIÑOS': {
          UNIFICADO: 0,
        },
      },
    },
    TEXTIL: {
      activa: true,
      profundidad_target: defaultDepth,
      piezas_exhibicion_sku: 6,
      secciones: {
        'HOMBRE (MENS)': {
          TRAINING: 0,
          RUNNING: 0,
          SPORTSWEAR: 0,
          FUTBOL: 0,
        },
        'MUJER (WOMENS)': {
          RUNNING: 0,
          TRAINING: 0,
          SPORTSWEAR: 0,
        },
        'INFANTE / NIÑOS': {
          UNIFICADO: 0,
        },
      },
    },
    ACCESORIOS: {
      activa: true,
      profundidad_target: Math.max(1, defaultDepth - 2),
      piezas_exhibicion_sku: 4,
      secciones: {
        'GENERAL': {
          'GORRAS / CAPS': 0,
          'MOCHILAS / MALETINES': 0,
          'CALCETINES / MEDIAS': 0,
          'BOLSOS / OTROS': 0,
        },
      },
    },
  };
}

export const DEFAULT_CAPACITY_MATRIX: CapacityMatrixConfig = createBaseBrandMatrix(16);

export function createGlobalBrandMatrix(defaultDepth: number = 16): CapacityMatrixConfig {
  return {
    CALZADO: {
      activa: true,
      profundidad_target: defaultDepth,
      piezas_exhibicion_sku: 1,
      secciones: {
        'HOMBRE (MENS)': { GLOBAL: 0 },
        'MUJER (WOMENS)': { GLOBAL: 0 },
        'INFANTE / NIÑOS': { GLOBAL: 0 },
      },
    },
    TEXTIL: {
      activa: true,
      profundidad_target: defaultDepth,
      piezas_exhibicion_sku: 6,
      secciones: {
        'HOMBRE (MENS)': { GLOBAL: 0 },
        'MUJER (WOMENS)': { GLOBAL: 0 },
        'INFANTE / NIÑOS': { GLOBAL: 0 },
      },
    },
    ACCESORIOS: {
      activa: true,
      profundidad_target: Math.max(1, defaultDepth - 2),
      piezas_exhibicion_sku: 4,
      secciones: {
        'GENERAL': { GLOBAL: 0 },
      },
    },
  };
}

// Matriz de distancias logísticas estándar entre tiendas (km)
export const DEFAULT_STORE_DISTANCES: StoreDistance = {};

// Catálogo de tiendas registradas (vacío por defecto, solo tiendas registradas oficialmente)
export const INITIAL_STORE_PROFILES: StoreProfile[] = [];

// Capacidades de tiendas por defecto (vacío por defecto)
export const INITIAL_STORE_CAPACITIES: Record<string, CapacityMatrixConfig> = {};

