export type Department = 'CALZADO' | 'TEXTIL' | 'ACCESORIOS' | string;

export interface InventoryItem {
  id?: string;
  Referencia: string;
  Departamento: Department;
  Seccion: string;
  Familia: string;
  Marca: string;
  Talla: string;
  Stock: number;
  Valoracion: number; // Siempre en Dólares ($ USD)
  ValorUnitario?: number; // Siempre en Dólares ($ USD)
  ValoracionBs?: number; // Valor original en Bolívares (VES)
  ValorUnitarioBs?: number; // Precio unitario original en Bolívares (VES)
  Tienda: string;
  SKU_Talla: string;
  FechaIngreso?: string;
  DiasAntiguedad?: number;
  ImagenUrl?: string;
  Temporada?: string;
  VentaSemanal?: number; // Ritmo de venta semanal promedio
  Venta30D?: number; // Unidades vendidas últimos 30 días
  WOS?: number; // Weeks of Supply (Semanas de Cobertura): Stock / VentaSemanal
}

export interface BcvRateConfig {
  rate: number;
  lastUpdated: string;
  source: string;
  isCustom?: boolean;
}

export interface ValuationHistoryPoint {
  date: string; // ISO or YYYY-MM-DD
  formattedDate: string; // e.g. "21 Sep"
  totalValuationUSD: number; // Siempre en Dólares ($ USD)
  totalValuationBs?: number; // En Bolívares (VES)
  totalPieces: number;
  bcvRateUsed: number;
  fileName?: string;
}

export interface SectionCapacity {
  [family: string]: number;
}

export interface DepartmentCapacity {
  activa?: boolean;
  profundidad_target: number;
  piezas_exhibicion_sku?: number;
  secciones: {
    [section: string]: SectionCapacity;
  };
}

export interface CapacityMatrixConfig {
  [dept: string]: DepartmentCapacity;
}

export interface CapacitySummaryRow {
  Departamento: string;
  ProfundidadTarget: number;
  SKUsIdeal: number;
  SKUsActual: number;
  DiferenciaSKUs: number;
  PiezasIdeal: number;
  PiezasActual: number;
  DiferenciaPiezas: number;
  PorcentajeOcupacion: number;
  ValoracionTotal: number;
}

export type GenderArea = 'CABALLERO' | 'DAMA' | 'NIÑOS' | 'GENERAL';

export interface AreaCapacitySummary {
  area: GenderArea | string;
  areaLabel: string;
  skusIdeal: number;
  skusActual: number;
  diferenciaSKUs: number;
  piezasIdeal: number;
  piezasActual: number;
  diferenciaPiezas: number;
  porcentajeOcupacion: number;
  valoracionTotal: number;
  estado: 'OPTIMO' | 'DEFICIT' | 'SATURACION';
}

export interface DepartmentModuleSummary {
  departamento: Department;
  profundidadTarget: number;
  skusIdeal: number;
  skusActual: number;
  diferenciaSKUs: number;
  piezasIdeal: number;
  piezasActual: number;
  diferenciaPiezas: number;
  porcentajeOcupacion: number;
  valoracionTotal: number;
  esGeneral?: boolean;
  areaGeneral?: AreaCapacitySummary;
  areas: {
    CABALLERO?: AreaCapacitySummary;
    DAMA?: AreaCapacitySummary;
    NIÑOS?: AreaCapacitySummary;
    GENERAL?: AreaCapacitySummary;
    [key: string]: AreaCapacitySummary | undefined;
  };
}

export type AlertPriority = 'CRÍTICA 🚨' | 'ALTA 🔴' | 'MEDIA 🟡' | 'BAJA 🟢';

export type AlertType = 
  | 'Talla Huérfana / Monotalla'
  | 'Quiebre de Tallas Core'
  | 'Sobrestock por Modelo'
  | 'Déficit de Profundidad'
  | 'Inventario Crítico / Aging'
  | 'Densidad Espacial Crítica'
  | 'Sobrestock por Cobertura (WOS)'
  | 'Riesgo de Quiebre por Demanda'
  | 'Inventario Inactivo sin Venta';

export type AlertStatus = 'PENDIENTE' | 'EN_GESTION' | 'APLICADA' | 'DESCARTADA';

export interface InventoryAlert {
  id: string;
  Prioridad: AlertPriority;
  TipoDeAlerta: AlertType;
  Referencia: string;
  Marca: string;
  Departamento: string;
  Tienda: string;
  Diagnostico: string;
  AccionCorrectiva: string;
  AccionSugerida?: string;
  Stock: number;
  TallasDisponibles: string[];
  ValorRiesgoMonetario?: number;
  status?: AlertStatus;
  statusNote?: string;
  statusUpdatedAt?: string;
}

export type TransferStatus = 'SUGERIDO' | 'APROBADO' | 'EN_REVISION' | 'VALIDADO' | 'EN_TRANSITO' | 'RECIBIDO';

export interface TransferSuggestion {
  id: string;
  Referencia: string;
  Marca: string;
  Departamento: string;
  Genero?: string;
  Seccion?: string;
  Talla: string;
  TiendaOrigen: string;
  StockOrigen: number;
  TiendaDestino: string;
  StockDestino: number;
  UnidadesSugeridas: number;
  DistanciaKm: number;
  Motivo: string;
  Prioridad: 'ALTA' | 'MEDIA' | 'NORMAL';
  CostoFleteEstimado?: number;
  Estado?: TransferStatus;
  FechaCreacion?: string;
  RevisadoPorAlmacen?: boolean;
  isGpsCalculated?: boolean;
  ValoracionUnitario?: number;
  UnidadesRealesDespachadas?: number;
  UnidadesRealesRecibidas?: number;
  NotasDiscrepancia?: string;
  CondicionFisica?: 'NUEVO' | 'USADO' | '';
}

export interface TransferManifestItem {
  id?: string;
  referencia: string;
  marca: string;
  genero?: string;
  departamento: string;
  talla: string;
  cantidad: number;
  condicion?: string;
  stockPrevioOrigen: number;
  stockPrevioDestino: number;
  valorUnitario?: number;
  observaciones?: string;
}

export interface TransferManifest {
  id: string;
  codigoManifiesto: string;
  tiendaOrigen: string;
  tiendaDestino: string;
  fechaEmision: string;
  autorizadoPor?: string;
  fechaEstimadaLlegada?: string;
  distanciaKm: number;
  costoFleteEstimado: number;
  estado: TransferStatus;
  items: TransferManifestItem[];
  totalPiezas: number;
  totalValoracion: number;
  validadorAlmacenOrigen?: string;
  validadorAlmacenDestino?: string;
  observaciones?: string;
}

export interface StoreDistance {
  [storeA: string]: Record<string, number> | number | any;
}

export type StoreType = 'FLAGSHIP' | 'LIVE' | 'UNITE' | 'EXPRESS';

export type StoreCluster = 'NORTE' | 'CENTRO' | 'SUR' | 'COSTA' | 'OCCIDENTE' | 'ESTANDAR';

export interface StoreProfile {
  id: string;
  nombre: string;
  ciudad: string;
  region?: string;
  direccion?: string;
  centroComercial?: string;
  lat?: number;
  lng?: number;
  placeId?: string;
  formattedAddress?: string;
  mapsUrl?: string;
  superficieM2?: number;
  tipo: StoreType;
  marcas?: string[];
  cluster?: StoreCluster;
  marcasCapacidad?: Record<string, CapacityMatrixConfig>;
  capacidadPersonalizada?: CapacityMatrixConfig;
  profundidadMediaTienda?: number;
  totalSkusFisicos?: number;
  totalPiezasFisicas?: number;
  fechaRegistro?: string;
}

export interface SizeCurveClusterTarget {
  cluster: StoreCluster;
  calzado: Record<string, number>;
  textil: Record<string, number>;
}

export interface AgingBucketSummary {
  rango0_30: { piezas: number; valor: number; pct: number };
  rango31_60: { piezas: number; valor: number; pct: number };
  rango61_90: { piezas: number; valor: number; pct: number };
  rangoMas90: { piezas: number; valor: number; pct: number };
  totalPiezas: number;
  totalValor: number;
}

export interface SpatialPerformanceMetric {
  tienda: string;
  superficieM2: number;
  formato: StoreType;
  piezasActuales: number;
  valoracionTotal: number;
  piezasPorM2: number;
  valorPorM2: number;
  densidadTargetMin: number;
  densidadTargetMax: number;
  estadoDensidad: 'OPTIMO' | 'SOBRECARGA' | 'SUBUTILIZADO';
}

export interface RuleEngineConfig {
  umbralSobrestockPorcentaje: number; // default 115%
  umbralSubstockPorcentaje: number; // default 75%
  umbralAgingCriticoDias: number; // default 90 days
  umbralMonotallaPiezas: number; // default 2
  costoFleteBasePorKm: number; // default $0.85 per km
  costoFleteBaseFijo: number; // default $15.00
  diasEstimadosQuiebreParaVentasPerdidas: number; // default 14 days
}

export interface FinancialRiskSummary {
  valorVentasPerdidasEstimadas: number;
  valorDeadStockCritico: number;
  valorCapitalInmovilizado: number;
  ahorroPorRebalanceoEstimado: number;
  piezasEnRiesgo: number;
}

export interface CapacitySnapshot {
  id: string;
  nombre: string;
  descripcion: string;
  fechaCreacion: string;
  tiendasCount: number;
  capacidades: Record<string, CapacityMatrixConfig>;
  perfiles: StoreProfile[];
}

export interface WhatIfSimulationConfig {
  horizonteSemanas: number;
  variacionSellThroughPct: number; // -50% to +50%
  incluirTraspasosEnTransito: boolean;
  departamentoFiltro?: string;
}

export interface WhatIfSimulationResult {
  tienda: string;
  stockActual: number;
  stockProyectado: number;
  ventasProyectadas: number;
  capacidadIdeal: number;
  ocupacionActualPct: number;
  ocupacionProyectadaPct: number;
  semanasCobertura: number;
  fechaQuiebreEstimada?: string;
  estadoRiesgo: 'QUIEBRE_PROMINENTE' | 'OPTIMO' | 'SATURACION_ALTA';
}


