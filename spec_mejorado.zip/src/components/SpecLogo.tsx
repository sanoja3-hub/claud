import React from 'react';

interface SpecLogoIconProps {
  className?: string;
  size?: number;
}

export const SpecLogoIcon: React.FC<SpecLogoIconProps> = ({ className = 'w-8 h-8', size }) => {
  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      aria-label="SPEC Logo"
    >
      <defs>
        {/* Lower curve gradient: emerald -> red/coral -> warm orange */}
        <linearGradient id="specLowerCurve" x1="25" y1="92" x2="60" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#10B981" />
          <stop offset="25%" stopColor="#F43F5E" />
          <stop offset="70%" stopColor="#EF4444" />
          <stop offset="100%" stopColor="#F97316" />
        </linearGradient>

        {/* Upper curve gradient: orange -> purple/indigo -> cyan -> coral */}
        <linearGradient id="specUpperCurve" x1="60" y1="56" x2="98" y2="28" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#F97316" />
          <stop offset="20%" stopColor="#8B5CF6" />
          <stop offset="50%" stopColor="#6366F1" />
          <stop offset="85%" stopColor="#06B6D4" />
          <stop offset="100%" stopColor="#EF4444" />
        </linearGradient>
      </defs>

      {/* Vertical Equalizer / Distribution Curve Pillars */}
      {/* Col 1: Far Left - Soft Gray Blue */}
      <rect x="18" y="48" width="7" height="28" rx="3.5" fill="#DDE5EE" />

      {/* Col 2: Pink background + Coral Red Pill at bottom */}
      <rect x="32" y="36" width="7" height="52" rx="3.5" fill="#FEE2E2" />
      <rect x="32" y="64" width="7" height="24" rx="3.5" fill="#EF4444" />

      {/* Col 3: Center Dominant Pillar - Deep Dark Slate */}
      <rect x="46" y="16" width="8" height="88" rx="4" fill="#0F172A" />

      {/* Col 4: Mint Green background + Emerald Pill at bottom */}
      <rect x="60" y="14" width="7" height="90" rx="3.5" fill="#DCFCE7" />
      <rect x="60" y="60" width="7" height="42" rx="3.5" fill="#10B981" />

      {/* Col 5: Lavender background + Royal Indigo Pill at bottom */}
      <rect x="74" y="22" width="7" height="72" rx="3.5" fill="#E0E7FF" />
      <rect x="74" y="52" width="7" height="38" rx="3.5" fill="#4F46E5" />

      {/* Col 6: Cream Peach background + Orange Pill at bottom */}
      <rect x="88" y="34" width="7" height="54" rx="3.5" fill="#FEF3C7" />
      <rect x="88" y="60" width="7" height="24" rx="3.5" fill="#F97316" />

      {/* Col 7: Far Right - Soft Gray Slate */}
      <rect x="102" y="48" width="7" height="28" rx="3.5" fill="#E2E8F0" />

      {/* "S" Dynamic Distribution Ribbon */}
      {/* Lower Loop: (25,92) -> loops down and sweeps up toward center (60,56) */}
      <path
        d="M 25 92 C 34 104, 52 108, 60 76 C 62 66, 60 58, 60 56"
        stroke="url(#specLowerCurve)"
        strokeWidth="6"
        strokeLinecap="round"
        fill="none"
      />

      {/* Upper Loop: (60,56) -> sweeps up and loops over toward (98,28) */}
      <path
        d="M 60 56 C 60 40, 68 18, 86 18 C 94 18, 97 22, 98 28"
        stroke="url(#specUpperCurve)"
        strokeWidth="6"
        strokeLinecap="round"
        fill="none"
      />

      {/* Terminal Node Left: Teal Dot */}
      <circle cx="25" cy="92" r="3.2" fill="#10B981" />

      {/* Terminal Node Right: Coral Red Dot */}
      <circle cx="98" cy="28" r="3.2" fill="#EF4444" />

      {/* Center Intersection Ring Node */}
      <circle cx="60" cy="56" r="5.5" fill="#F97316" />
      <circle cx="60" cy="56" r="2.5" fill="#FFFFFF" />
    </svg>
  );
};

interface SpecLogoProps {
  showSubtitle?: boolean;
  showTagline?: boolean;
  variant?: 'compact' | 'full' | 'stacked';
  className?: string;
  iconSize?: string;
}

export const SpecLogo: React.FC<SpecLogoProps> = ({
  showSubtitle = true,
  showTagline = false,
  variant = 'compact',
  className = '',
  iconSize = 'w-8 h-8',
}) => {
  if (variant === 'stacked') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`}>
        <SpecLogoIcon className="w-16 h-16 sm:w-20 sm:h-20" />
        <div className="mt-4 flex items-center justify-center">
          <span className="font-extrabold text-2xl sm:text-3xl text-zinc-900 tracking-[0.25em] pl-1 font-sans">
            SPEC
          </span>
          <span className="w-2.5 h-2.5 bg-[#F97316] ml-2 inline-block rounded-[1px] shadow-xs" />
        </div>
        {showSubtitle && (
          <p className="mt-2 text-[10px] sm:text-xs font-bold text-zinc-600 tracking-[0.22em] uppercase font-sans">
            Distribution Curve &amp; Rebalance
          </p>
        )}
        {showTagline && (
          <p className="mt-1 text-[8px] sm:text-[9px] font-mono text-zinc-400 tracking-[0.18em] uppercase">
            Compatible ERP Connector • Multi-Store Engine
          </p>
        )}
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2.5 min-w-0 ${className}`}>
      {/* Logo Mark Container */}
      <div className="relative flex items-center justify-center shrink-0">
        <SpecLogoIcon className={iconSize} />
      </div>

      {/* Typography */}
      <div className="min-w-0 flex flex-col justify-center">
        <div className="flex items-center leading-none">
          <span className="text-xs sm:text-sm font-black tracking-[0.22em] text-zinc-900 uppercase font-sans">
            SPEC
          </span>
          <span className="w-1.5 h-1.5 bg-[#F97316] ml-1 inline-block rounded-[1px] shrink-0" />
        </div>
        {showSubtitle && (
          <p className="text-[9px] sm:text-[10px] font-bold text-zinc-500 tracking-[0.16em] uppercase truncate mt-0.5 leading-tight font-sans">
            Distribution Curve &amp; Rebalance
          </p>
        )}
        {showTagline && (
          <p className="text-[8px] font-mono text-zinc-400 tracking-[0.12em] uppercase truncate mt-0.5 leading-none">
            Compatible ERP Connector
          </p>
        )}
      </div>
    </div>
  );
};
