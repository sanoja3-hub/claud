import React, { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  Clock,
  Download,
  Filter,
  Grid,
  HelpCircle,
  Search,
  ShieldAlert,
  ShoppingBag,
  X,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertStatus, InventoryAlert, InventoryItem } from '../types';
import { SizeCurveTab } from './SizeCurveTab';
import {
  generarSugeridoCompraInteligente,
} from '../utils/purchaseSuggester';
import { PurchasePlanModal } from './PurchasePlanModal';
import { CardInfoButton } from './CardInfoButton';

interface AlertsTabProps {
  alerts: InventoryAlert[];
  selectedStore: string;
  inventory?: InventoryItem[];
  customImageUrls?: Record<string, string>;
  onUpdateProductImageUrl?: (referencia: string, imageUrl: string) => void;
  selectedSku?: string | null;
  onSelectSku?: (sku: string) => void;
  onUpdateAlertStatus?: (alertId: string, status: AlertStatus, note?: string) => void;
}

export const AlertsTab: React.FC<AlertsTabProps> = ({
  alerts = [],
  selectedStore = 'TODAS',
  inventory = [],
  customImageUrls,
  onUpdateProductImageUrl,
  selectedSku,
  onSelectSku,
  onUpdateAlertStatus,
}) => {
  // Active detail group unfolded below the cards: 'TODAS' | 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA' | null
  const [activeDetailGroup, setActiveDetailGroup] = useState<'TODAS' | 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA' | null>(null);
  const [selectedType, setSelectedType] = useState<string>('TODAS');
  const [selectedStatus, setSelectedStatus] = useState<string>('TODAS');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [internalSelectedSku, setInternalSelectedSku] = useState<string | null>(selectedSku || null);
  const [isPurchasePlanModalOpen, setIsPurchasePlanModalOpen] = useState<boolean>(false);

  // Unique stores for filter
  const uniqueStores = useMemo(() => {
    const s = new Set<string>();
    (inventory || []).forEach((i) => {
      if (i && i.Tienda) s.add(i.Tienda);
    });
    return Array.from(s).sort();
  }, [inventory]);

  // Global purchase plan result in units
  const purchasePlanResult = useMemo(() => {
    return generarSugeridoCompraInteligente(alerts, inventory, selectedStore);
  }, [alerts, inventory, selectedStore]);

  // Metric counts
  const criticasAlerts = useMemo(
    () => alerts.filter((a) => a.Prioridad.toUpperCase().includes('CRÍTICA') || a.Prioridad.toUpperCase().includes('CRITICA')),
    [alerts]
  );
  const altasAlerts = useMemo(
    () => alerts.filter((a) => a.Prioridad.toUpperCase().includes('ALTA') && !a.Prioridad.toUpperCase().includes('CRÍTICA')),
    [alerts]
  );
  const mediasAlerts = useMemo(
    () => alerts.filter((a) => a.Prioridad.toUpperCase().includes('MEDIA')),
    [alerts]
  );
  const bajasAlerts = useMemo(
    () =>
      alerts.filter(
        (a) =>
          a.Prioridad.toUpperCase().includes('BAJA') ||
          (!a.Prioridad.toUpperCase().includes('CRÍTICA') &&
            !a.Prioridad.toUpperCase().includes('CRITICA') &&
            !a.Prioridad.toUpperCase().includes('ALTA') &&
            !a.Prioridad.toUpperCase().includes('MEDIA'))
      ),
    [alerts]
  );

  const alertTypes = useMemo(() => Array.from(new Set(alerts.map((a) => a.TipoDeAlerta))), [alerts]);

  const statusCounts = useMemo(() => {
    const counts = { PENDIENTE: 0, EN_GESTION: 0, APLICADA: 0, DESCARTADA: 0 };
    (alerts || []).forEach((a) => {
      if (!a) return;
      const st = a.status || 'PENDIENTE';
      if (counts[st] !== undefined) counts[st]++;
      else counts.PENDIENTE++;
    });
    return counts;
  }, [alerts]);

  // Filter helper for alert listings
  const filterList = (list: InventoryAlert[]) => {
    return list.filter((a) => {
      if (selectedType !== 'TODAS' && a.TipoDeAlerta !== selectedType) return false;
      const st = a.status || 'PENDIENTE';
      if (selectedStatus !== 'TODAS' && st !== selectedStatus) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const match =
          a.Referencia.toLowerCase().includes(q) ||
          a.Marca.toLowerCase().includes(q) ||
          a.Departamento.toLowerCase().includes(q) ||
          a.Diagnostico.toLowerCase().includes(q) ||
          a.Tienda.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  };

  const filteredCriticas = useMemo(() => filterList(criticasAlerts), [criticasAlerts, selectedType, selectedStatus, searchQuery]);
  const filteredAltas = useMemo(() => filterList(altasAlerts), [altasAlerts, selectedType, selectedStatus, searchQuery]);
  const filteredMedias = useMemo(() => filterList(mediasAlerts), [mediasAlerts, selectedType, selectedStatus, searchQuery]);
  const filteredBajas = useMemo(() => filterList(bajasAlerts), [bajasAlerts, selectedType, selectedStatus, searchQuery]);
  const filteredTodas = useMemo(() => filterList(alerts), [alerts, selectedType, selectedStatus, searchQuery]);

  // Handle Export Sugerido de Compra Inteligente -> Abre el modal estructurado de compra
  const handleExportPurchasePlan = () => {
    setIsPurchasePlanModalOpen(true);
  };

  // Toggle card detail selection
  const handleToggleCard = (group: 'TODAS' | 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAJA') => {
    if (activeDetailGroup === group) {
      setActiveDetailGroup(null);
    } else {
      setActiveDetailGroup(group);
      setTimeout(() => {
        const el = document.getElementById('detalle-alertas-seleccionadas');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }, 60);
    }
  };

  // Scroll to Size Curve Section
  const handleInspectSkuCurve = (sku: string) => {
    setInternalSelectedSku(sku);
    if (onSelectSku) {
      onSelectSku(sku);
    }
    setTimeout(() => {
      const el = document.getElementById('zona-curvas-talla');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 80);
  };

  const currentActiveSku = selectedSku || internalSelectedSku;

  // Configuration for unfolded detail panel based on active card
  const activeGroupInfo = useMemo(() => {
    switch (activeDetailGroup) {
      case 'CRITICA':
        return {
          title: 'Severidad Crítica // Quiebre de Curvas Centrales',
          badgeText: 'URGENTE',
          badgeClass: 'bg-rose-100 text-rose-800 border-rose-300',
          dotClass: 'bg-rose-600 animate-pulse',
          headerBg: 'bg-rose-50/70 border-rose-200 text-rose-950',
          borderClass: 'border-rose-300',
          macroAction:
            'Reabastecer con urgencia tallas centrales desde almacén central (CEDI) o rebalancear entre tiendas donantes. Si no hay reposición inmediata, retirar el frente de exhibición para evitar frustración de compra.',
          items: filteredCriticas,
          totalCount: criticasAlerts.length,
        };
      case 'ALTA':
        return {
          title: 'Severidad Alta // Picos (Tallas Huérfanas)',
          badgeText: 'PRIORIDAD ALTA',
          badgeClass: 'bg-amber-100 text-amber-800 border-amber-300',
          dotClass: 'bg-amber-500',
          headerBg: 'bg-amber-50/70 border-amber-200 text-amber-950',
          borderClass: 'border-amber-300',
          macroAction:
            'Consolidar inventario en la tienda insignia (flagship) de mayor tráfico o aplicar acción comercial/descuento en punto de venta para liquidar el pico remanente y liberar espacio en exhibición.',
          items: filteredAltas,
          totalCount: altasAlerts.length,
        };
      case 'MEDIA':
        return {
          title: 'Severidad Media // Stock Mínimo Operacional',
          badgeText: 'PREVENTIVO',
          badgeClass: 'bg-blue-100 text-blue-800 border-blue-300',
          dotClass: 'bg-blue-500',
          headerBg: 'bg-blue-50/70 border-blue-200 text-blue-950',
          borderClass: 'border-blue-300',
          macroAction:
            'Programar reposición en el ciclo regular de compras/despacho antes de que el SKU cruce el umbral de monotalla en el punto de venta.',
          items: filteredMedias,
          totalCount: mediasAlerts.length,
        };
      case 'BAJA':
        return {
          title: 'Severidad Baja // Tallas Extremas & Sobre-stock Marginal',
          badgeText: 'MONITOREO',
          badgeClass: 'bg-zinc-100 text-zinc-800 border-zinc-300',
          dotClass: 'bg-zinc-600',
          headerBg: 'bg-zinc-50 border-zinc-200 text-zinc-900',
          borderClass: 'border-zinc-300',
          macroAction:
            'Pausar envíos adicionales de tallas extremas y vigilar rotación natural de la referencia sin alterar la exhibición principal.',
          items: filteredBajas,
          totalCount: bajasAlerts.length,
        };
      case 'TODAS':
      default:
        return {
          title: 'Auditoría Integral // Todas las Anomalías Detectadas',
          badgeText: 'TODAS LAS ALERTAS',
          badgeClass: 'bg-zinc-100 text-zinc-800 border-zinc-300',
          dotClass: 'bg-zinc-700',
          headerBg: 'bg-zinc-50 border-zinc-200 text-zinc-900',
          borderClass: 'border-zinc-300',
          macroAction:
            'Auditoría y diagnóstico global de salud de inventario en la red comercial. Priorizar acciones correctivas sobre anomalías de severidad Crítica y Alta.',
          items: filteredTodas,
          totalCount: alerts.length,
        };
    }
  }, [
    activeDetailGroup,
    filteredCriticas,
    filteredAltas,
    filteredMedias,
    filteredBajas,
    filteredTodas,
    criticasAlerts.length,
    altasAlerts.length,
    mediasAlerts.length,
    bajasAlerts.length,
    alerts.length,
  ]);

  return (
    <div className="space-y-6">
      {/* ========================================================= */}
      {/* 1. SECCIÓN SUPERIOR UNIFICADA: ENCABEZADO Y TARJETAS SIMÉTRICAS */}
      {/* ========================================================= */}
      <div className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs space-y-4">
        {/* Encabezado Principal y Acciones */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-4 border-b border-zinc-100">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white shrink-0 shadow-xs">
                <Grid className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight flex items-center gap-2">
                  <span>Curvas de Tallas & Modelos</span>
                  <span className="text-xs font-normal text-zinc-400">|</span>
                  <span className="text-xs font-semibold text-zinc-600">Alertas Operativas</span>
                  <span className="text-[10px] font-mono font-normal uppercase bg-zinc-100 text-zinc-600 border border-zinc-200 px-2 py-0.5 rounded ml-1">
                    Vista: {selectedStore}
                  </span>
                </h1>
                <p className="text-xs text-zinc-500">
                  Mapeo de distribución de stock en tiempo real, detección de quiebres de curva y sugerido de compra inteligente
                </p>
              </div>
            </div>
          </div>

          {/* Top Action Buttons and Workflow Status Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="hidden sm:flex items-center gap-1.5 mr-2 bg-zinc-50 border border-zinc-200/80 px-2.5 py-1 rounded-lg">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Flujo:</span>
              <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200" title="Alertas pendientes de gestionar">
                {statusCounts.PENDIENTE} Pend.
              </span>
              <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200" title="Alertas en proceso de resolución">
                {statusCounts.EN_GESTION} En Gestión
              </span>
              <span className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200" title="Alertas resueltas o aplicadas">
                {statusCounts.APLICADA} Aplicadas
              </span>
            </div>

            <button
              type="button"
              onClick={handleExportPurchasePlan}
              className="inline-flex items-center gap-2 h-9 px-3.5 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Descargar reporte agrupado por Marca y Tienda con cálculo determinista de compra sugerida"
            >
              <Download className="w-3.5 h-3.5 text-zinc-300" />
              <span>Sugerido de Compra Inteligente</span>
            </button>

            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('zona-curvas-talla');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
              className="inline-flex items-center gap-1.5 h-9 px-3 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <ArrowDown className="w-3.5 h-3.5 text-zinc-500" />
              <span>Ver Curvas</span>
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* TARJETAS DE MÉTRICAS SEGMENTADAS (PRESERVANDO ESTILO/TAMAÑO) */}
        {/* ========================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
          {/* Card 1: Total Anomalías */}
          <div
            onClick={() => handleToggleCard('TODAS')}
            className={`bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group ${
              activeDetailGroup === 'TODAS'
                ? 'border-zinc-900 ring-2 ring-zinc-900/15 shadow-sm'
                : 'border-zinc-200/90 hover:border-zinc-400'
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Total Anomalías</span>
              <div className="flex items-center gap-1.5">
                <span className="text-zinc-700 bg-zinc-100 border border-zinc-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                  {alerts.length} SKUS
                </span>
                <CardInfoButton
                  title="Auditoría Integral de Anomalías"
                  description="Total de referencias y tallas que presentan desbalances respecto a la curvatura comercial ideal o saturación física."
                  formula="Total = Σ (Curvas Rotas + Monotallas + Picos + Sobrestock)"
                />
              </div>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-zinc-900 tabular-nums font-mono">
                {alerts.length.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Inventario activo auditado contra la matriz de curvatura teórica.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className={activeDetailGroup === 'TODAS' ? 'text-zinc-900 font-bold' : 'text-zinc-400 group-hover:text-zinc-600'}>
                {activeDetailGroup === 'TODAS' ? '▲ Ocultar detalle' : '▼ Ver detalle'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${activeDetailGroup === 'TODAS' ? 'rotate-180 text-zinc-900' : 'text-zinc-400'}`} />
            </div>
          </div>

          {/* Card 2: Crítica: Curva Rota */}
          <div
            onClick={() => handleToggleCard('CRITICA')}
            className={`bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group ${
              activeDetailGroup === 'CRITICA'
                ? 'border-rose-600 ring-2 ring-rose-500/20 shadow-sm'
                : 'border-zinc-200/90 hover:border-rose-300'
            }`}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1 text-rose-700">
                <span className="text-[10px] font-bold uppercase tracking-wider">Crítica: Curva Rota</span>
                <CardInfoButton
                  title="Curva Rota (Broken Core)"
                  description="Agotamiento (0 uds) en tallas centrales de alta demanda (ej. 38-41 o M-L) existiendo únicamente stock en tallas extremas."
                  operationalImpact="Genera pérdida directa de venta; el cliente desiste de la compra al no encontrar su talla."
                />
              </div>
              <span className="text-rose-700 bg-rose-50 border border-rose-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                URGENTE
              </span>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-rose-600 tabular-nums font-mono">
                {criticasAlerts.length.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Falta de tallas centrales de alta demanda; genera pérdida directa de venta.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className={activeDetailGroup === 'CRITICA' ? 'text-rose-700 font-bold' : 'text-zinc-400 group-hover:text-rose-600'}>
                {activeDetailGroup === 'CRITICA' ? '▲ Ocultar detalle' : '▼ Ver detalle'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${activeDetailGroup === 'CRITICA' ? 'rotate-180 text-rose-700' : 'text-zinc-400'}`} />
            </div>
          </div>

          {/* Card 3: Alta: Pico / Talla Huérfana */}
          <div
            onClick={() => handleToggleCard('ALTA')}
            className={`bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group ${
              activeDetailGroup === 'ALTA'
                ? 'border-amber-600 ring-2 ring-amber-500/20 shadow-sm'
                : 'border-zinc-200/90 hover:border-amber-300'
            }`}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1 text-amber-700">
                <span className="text-[10px] font-bold uppercase tracking-wider">Alta: Pico</span>
                <CardInfoButton
                  title="Pico / Talla Huérfana (≤ 2 uds)"
                  description="SKU con 1 o 2 piezas remanentes en una sola talla huérfana. Bloquea un espacio de exhibición sin masa crítica comercial."
                  operationalImpact="Candidato prioritario para consolidar en tienda Outlet/Flagship o liquidar."
                />
              </div>
              <span className="text-amber-700 bg-amber-50 border border-amber-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                ≤ 2 UDS
              </span>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-amber-600 tabular-nums font-mono">
                {altasAlerts.length.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Unidades aisladas (picos) bloqueando capacidad física de exhibición.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className={activeDetailGroup === 'ALTA' ? 'text-amber-700 font-bold' : 'text-zinc-400 group-hover:text-amber-600'}>
                {activeDetailGroup === 'ALTA' ? '▲ Ocultar detalle' : '▼ Ver detalle'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${activeDetailGroup === 'ALTA' ? 'rotate-180 text-amber-700' : 'text-zinc-400'}`} />
            </div>
          </div>

          {/* Card 4: Media: Stock Mínimo */}
          <div
            onClick={() => handleToggleCard('MEDIA')}
            className={`bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group ${
              activeDetailGroup === 'MEDIA'
                ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-sm'
                : 'border-zinc-200/90 hover:border-blue-300'
            }`}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1 text-blue-700">
                <span className="text-[10px] font-bold uppercase tracking-wider">Media: Stock Mínimo</span>
                <CardInfoButton
                  title="Stock Mínimo Preventivo"
                  description="Stock total en tienda menor o igual al umbral de seguridad operacional. Riesgo inminente de quiebre en los próximos días."
                  operationalImpact="Programar despacho de rebalanceo antes del fin de semana."
                />
              </div>
              <span className="text-blue-700 bg-blue-50 border border-blue-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                PREVENTIVO
              </span>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-blue-600 tabular-nums font-mono">
                {mediasAlerts.length.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Frentes con inventario bajo que requieren reposición en próximo ciclo.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className={activeDetailGroup === 'MEDIA' ? 'text-blue-700 font-bold' : 'text-zinc-400 group-hover:text-blue-600'}>
                {activeDetailGroup === 'MEDIA' ? '▲ Ocultar detalle' : '▼ Ver detalle'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${activeDetailGroup === 'MEDIA' ? 'rotate-180 text-blue-700' : 'text-zinc-400'}`} />
            </div>
          </div>

          {/* Card 5: Baja: Tallas Extremas */}
          <div
            onClick={() => handleToggleCard('BAJA')}
            className={`bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group ${
              activeDetailGroup === 'BAJA'
                ? 'border-zinc-700 ring-2 ring-zinc-700/20 shadow-sm'
                : 'border-zinc-200/90 hover:border-zinc-400'
            }`}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1 text-zinc-700">
                <span className="text-[10px] font-bold uppercase tracking-wider">Baja: Tallas Extremas</span>
                <CardInfoButton
                  title="Tallas Extremas & Desbalance Marginal"
                  description="Sobrecarga en tallas marginales (XS, XXL o 35, 45) con rotación lenta sin afectar los frentes principales."
                  operationalImpact="Monitoreo pasivo; no requiere rebalanceo de emergencia."
                />
              </div>
              <span className="text-zinc-600 bg-zinc-100 border border-zinc-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                MARG.
              </span>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-zinc-700 tabular-nums font-mono">
                {bajasAlerts.length.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Excedente en extremos de curvatura; monitoreo pasivo de rotación.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className={activeDetailGroup === 'BAJA' ? 'text-zinc-800 font-bold' : 'text-zinc-400 group-hover:text-zinc-600'}>
                {activeDetailGroup === 'BAJA' ? '▲ Ocultar detalle' : '▼ Ver detalle'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform ${activeDetailGroup === 'BAJA' ? 'rotate-180 text-zinc-800' : 'text-zinc-400'}`} />
            </div>
          </div>

          {/* Card 6: Sugerido Global de Compra (Uds) */}
          <div
            onClick={() => setIsPurchasePlanModalOpen(true)}
            className="bg-white border rounded-xl p-3.5 flex flex-col justify-between shadow-xs transition-all cursor-pointer relative group border-zinc-200/90 hover:border-emerald-500 hover:ring-2 hover:ring-emerald-500/15"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1 text-emerald-800">
                <span className="text-[10px] font-bold uppercase tracking-wider">Sugerido Compra</span>
                <CardInfoButton
                  title="Sugerido Inteligente de Compra"
                  description="Cálculo determinista de las piezas que se deben adquirir a proveedores cuando el déficit no puede cubrirse con traslados entre tiendas."
                  formula="Compra = Déficit por Curva Rota - Excedente Disponible en Red"
                />
              </div>
              <span className="text-emerald-800 bg-emerald-50 border border-emerald-200 text-[9px] px-1.5 py-0.5 rounded font-bold font-mono">
                UDS
              </span>
            </div>
            <div className="my-2">
              <div className="text-2xl font-bold text-emerald-700 tabular-nums font-mono">
                {purchasePlanResult.totalUnidades.toLocaleString()}
              </div>
            </div>
            <div className="text-[11px] text-zinc-500 leading-snug">
              Reposición neta calculada por velocidad de venta y curvas.
            </div>
            <div className="mt-2.5 pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] font-mono">
              <span className="text-emerald-700 font-bold group-hover:underline flex items-center gap-1">
                <span>▲ Ver Plan / Exportar</span>
              </span>
              <ShoppingBag className="w-3 h-3 text-emerald-600" />
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 2. DETALLE DESPLEGABLE AL FINAL DE LAS TARJETAS           */}
      {/* ========================================================= */}
      <AnimatePresence>
        {activeDetailGroup && (
          <motion.div
            id="detalle-alertas-seleccionadas"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.15 }}
            className={`bg-white border rounded-xl overflow-hidden shadow-xs ${activeGroupInfo.borderClass}`}
          >
              {/* Header del Detalle Desplegado */}
              <div
                className={`p-4 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${activeGroupInfo.headerBg}`}
              >
                <div className="flex items-start sm:items-center gap-3">
                  <span className={`w-3 h-3 rounded-full shrink-0 mt-0.5 sm:mt-0 ${activeGroupInfo.dotClass}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xs font-bold font-mono uppercase tracking-wider">
                        {activeGroupInfo.title}
                      </h3>
                      <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${activeGroupInfo.badgeClass}`}>
                        {activeGroupInfo.badgeText}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/90 text-zinc-800 border border-zinc-200">
                        {activeGroupInfo.items.length} SKUs encontrados
                      </span>
                    </div>
                    <p className="text-xs mt-1 leading-relaxed opacity-95">
                      <strong>Plan de Acción Macro:</strong> {activeGroupInfo.macroAction}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setActiveDetailGroup(null)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-white hover:bg-zinc-100 border border-zinc-200 text-zinc-700 transition-colors cursor-pointer shadow-2xs"
                  >
                    <X className="w-3.5 h-3.5 text-zinc-500" />
                    <span>Cerrar detalle</span>
                  </button>
                </div>
              </div>

              {/* Barra de Filtros Internos del Detalle */}
              <div className="p-3 bg-zinc-50/80 border-b border-zinc-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider flex items-center gap-1">
                      <Filter className="w-3 h-3 text-zinc-400" /> Tipo:
                    </span>
                    <select
                      value={selectedType}
                      onChange={(e) => setSelectedType(e.target.value)}
                      className="h-8 bg-white border border-zinc-200 rounded-lg px-2.5 text-xs text-zinc-800 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer"
                    >
                      <option value="TODAS">Todos los tipos de anomalía</option>
                      {alertTypes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider flex items-center gap-1">
                      <Clock className="w-3 h-3 text-zinc-400" /> Estado:
                    </span>
                    <select
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value)}
                      className="h-8 bg-white border border-zinc-200 rounded-lg px-2.5 text-xs text-zinc-800 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer font-medium"
                    >
                      <option value="TODAS">Todos los estados</option>
                      <option value="PENDIENTE">🔵 Pendientes ({statusCounts.PENDIENTE})</option>
                      <option value="EN_GESTION">🟡 En Gestión ({statusCounts.EN_GESTION})</option>
                      <option value="APLICADA">🟢 Aplicadas ({statusCounts.APLICADA})</option>
                      <option value="DESCARTADA">⚪ Descartadas ({statusCounts.DESCARTADA})</option>
                    </select>
                  </div>
                </div>

                <div className="relative w-full sm:w-72">
                  <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Filtrar por SKU, Marca, Departamento..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full h-8 bg-white border border-zinc-200 rounded-lg pl-8 pr-3 text-xs text-zinc-900 placeholder-zinc-400 shadow-2xs focus:outline-none focus:border-zinc-400 transition-colors"
                  />
                </div>
              </div>

              {/* Tabla de SKUs */}
              <div className="overflow-x-auto max-h-[500px]">
                {activeGroupInfo.items.length === 0 ? (
                  <div className="p-6 text-center text-xs text-zinc-500">
                    No se encontraron SKUs para este nivel de severidad con los filtros actuales.
                  </div>
                ) : (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-zinc-50 text-zinc-500 text-[10px] uppercase font-mono font-bold tracking-wider border-b border-zinc-200 sticky top-0 bg-zinc-50 z-10">
                      <tr>
                        <th className="px-4 py-2.5">Tienda</th>
                        <th className="px-4 py-2.5">SKU / Referencia</th>
                        <th className="px-4 py-2.5">Marca / Depto</th>
                        {activeDetailGroup === 'TODAS' && (
                          <th className="px-4 py-2.5">Severidad</th>
                        )}
                        <th className="px-4 py-2.5">Diagnóstico Específico</th>
                        <th className="px-4 py-2.5">Acción Correctiva Sugerida</th>
                        <th className="px-4 py-2.5">Estado Operativo</th>
                        <th className="px-4 py-2.5 text-right">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100 font-mono text-zinc-700">
                      {activeGroupInfo.items.map((a) => (
                        <tr key={a.id} className="hover:bg-zinc-50 transition-colors">
                          <td className="px-4 py-2.5 font-bold text-zinc-900 whitespace-nowrap">
                            {a.Tienda}
                          </td>
                          <td className="px-4 py-2.5 font-bold text-zinc-900 whitespace-nowrap">
                            {a.Referencia}
                          </td>
                          <td className="px-4 py-2.5 text-zinc-600 font-sans whitespace-nowrap">
                            {a.Marca} • {a.Departamento}
                          </td>
                          {activeDetailGroup === 'TODAS' && (
                            <td className="px-4 py-2.5 whitespace-nowrap">
                              <span
                                className={`text-[10px] font-bold font-mono px-1.5 py-0.5 rounded border ${
                                  a.Prioridad.includes('CRÍTICA')
                                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                                    : a.Prioridad.includes('ALTA')
                                    ? 'bg-amber-50 text-amber-700 border-amber-200'
                                    : a.Prioridad.includes('MEDIA')
                                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                                    : 'bg-zinc-50 text-zinc-700 border-zinc-200'
                                }`}
                              >
                                {a.Prioridad}
                              </span>
                            </td>
                          )}
                          <td className="px-4 py-2.5 text-zinc-800 font-sans max-w-xs">
                            {a.Diagnostico}
                          </td>
                          <td className="px-4 py-2.5 text-zinc-700 font-sans text-[11px] max-w-sm">
                            {a.AccionSugerida || a.AccionCorrectiva}
                          </td>
                          <td className="px-4 py-2.5 whitespace-nowrap">
                            <select
                              value={a.status || 'PENDIENTE'}
                              onChange={(e) => onUpdateAlertStatus?.(a.id, e.target.value as AlertStatus)}
                              className={`text-[11px] font-bold font-mono px-2 py-1 rounded-md border cursor-pointer focus:outline-none transition-colors ${
                                (a.status === 'APLICADA')
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                  : (a.status === 'EN_GESTION')
                                  ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                                  : (a.status === 'DESCARTADA')
                                  ? 'bg-zinc-100 text-zinc-600 border-zinc-300 hover:bg-zinc-200'
                                  : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                              }`}
                              title="Cambiar estado operacional de la alerta"
                            >
                              <option value="PENDIENTE">🔵 Pendiente</option>
                              <option value="EN_GESTION">🟡 En Gestión</option>
                              <option value="APLICADA">🟢 Aplicada</option>
                              <option value="DESCARTADA">⚪ Descartada</option>
                            </select>
                          </td>
                          <td className="px-4 py-2.5 text-right whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleInspectSkuCurve(a.Referencia)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-zinc-100 text-zinc-800 border border-zinc-200 rounded text-[11px] font-bold font-mono cursor-pointer transition-colors shadow-2xs"
                              title={`Inspeccionar curva Gaussiana para ${a.Referencia}`}
                            >
                              <span>Inspeccionar</span>
                              <ArrowRight className="w-3 h-3 text-zinc-500" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      {/* ========================================================= */}
      {/* 3. CURVAS DE TALLAS & MODELOS DIRECTO (SIN CABECERA DUPLICADA) */}
      {/* ========================================================= */}
      <div id="zona-curvas-talla" className="pt-2">
        <SizeCurveTab
          inventory={inventory}
          customImageUrls={customImageUrls}
          onUpdateProductImageUrl={onUpdateProductImageUrl}
          selectedSku={currentActiveSku}
          onSelectSku={(sku) => {
            setInternalSelectedSku(sku);
            if (onSelectSku) onSelectSku(sku);
          }}
          embedded={true}
        />
      </div>

      {/* Modal de Sugerido de Compra Inteligente en Unidades */}
      <PurchasePlanModal
        isOpen={isPurchasePlanModalOpen}
        onClose={() => setIsPurchasePlanModalOpen(false)}
        alerts={alerts}
        inventory={inventory}
        initialStore={selectedStore}
        stores={uniqueStores}
      />
    </div>
  );
};
