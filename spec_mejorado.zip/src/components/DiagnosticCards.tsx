import React from 'react';
import { DollarSign, Clock, Building2 } from 'lucide-react';
import { motion } from 'motion/react';
import { CardInfoButton } from './CardInfoButton';
import {
  FinancialRiskSummary,
  AgingBucketSummary,
  SpatialPerformanceMetric,
} from '../types';

interface DiagnosticCardsProps {
  financialRisk?: FinancialRiskSummary;
  agingSummary?: AgingBucketSummary;
  currentSpatial?: SpatialPerformanceMetric;
  totalValuation: number;
}

export const DiagnosticCards: React.FC<DiagnosticCardsProps> = ({
  financialRisk,
  agingSummary,
  currentSpatial,
  totalValuation = 0,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* Card 1: Cuantificación Financiera de Riesgo */}
      {(() => {
        const lostSales = financialRisk?.valorVentasPerdidasEstimadas || 0;
        const deadStock = financialRisk?.valorDeadStockCritico || 0;
        const savings = financialRisk?.ahorroPorRebalanceoEstimado || 0;
        const totalRisk = lostSales + deadStock;
        const riskRatio =
          totalValuation > 0
            ? Math.min(100, Math.round((totalRisk / totalValuation) * 100))
            : totalRisk > 0
            ? 100
            : 0;

        const radius = 35;
        const circ = 2 * Math.PI * radius;
        const strokeOffset = circ * (1 - Math.min(100, riskRatio) / 100);

        return (
          <motion.div
            id="card-financial-risk"
            whileHover={{ y: -1 }}
            className="bg-white border border-zinc-200/90 rounded-xl p-4 shadow-xs space-y-3 relative flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-rose-500" />
                <span>RIESGO FINANCIERO</span>
              </span>
              <CardInfoButton
                title="Cuantificación Financiera de Riesgo"
                description="Calcula el valor en riesgo por ventas perdidas debido a tallas centrales agotadas, y el capital inmovilizado en inventario crítico (>90 días)."
                formula="Ventas Perdidas = Frecuencia Quiebre * Velocidad de Ventas Teórica * Valor Unitario"
              />
            </div>

            <div className="flex items-center gap-4 py-1">
              <div className="relative w-[84px] h-[84px] shrink-0 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 84 84">
                  <circle
                    cx="42"
                    cy="42"
                    r={radius}
                    className="stroke-zinc-100"
                    strokeWidth="6.5"
                    fill="none"
                  />
                  <circle
                    cx="42"
                    cy="42"
                    r={radius}
                    stroke="#f43f5e"
                    strokeWidth="6.5"
                    fill="none"
                    strokeDasharray={circ}
                    strokeDashoffset={strokeOffset}
                    strokeLinecap="round"
                    className="transition-all duration-700 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-sm font-bold text-rose-600 font-mono leading-none">
                    {riskRatio}%
                  </span>
                  <span className="text-[8px] font-mono text-zinc-400 uppercase mt-0.5 leading-none">
                    Expuesto
                  </span>
                </div>
              </div>

              <div className="flex-1 space-y-1.5 min-w-0">
                <div className="flex justify-between items-center bg-zinc-50 px-2.5 py-1.5 rounded-lg border border-zinc-200/80">
                  <span className="text-[11px] text-zinc-600 truncate">Ventas Perdidas:</span>
                  <span className="text-xs font-bold font-mono text-rose-600 shrink-0 ml-1">
                    ${lostSales.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center bg-zinc-50 px-2.5 py-1.5 rounded-lg border border-zinc-200/80">
                  <span className="text-[11px] text-zinc-600 truncate">Dead Stock (&gt;90d):</span>
                  <span className="text-xs font-bold font-mono text-amber-600 shrink-0 ml-1">
                    ${deadStock.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-zinc-100 flex items-center justify-between text-[11px]">
              <span className="text-zinc-500 font-mono">Ahorro Rebalanceo:</span>
              <span className="font-mono font-bold text-emerald-600">
                +${savings.toLocaleString()}
              </span>
            </div>
          </motion.div>
        );
      })()}

      {/* Card 2: Antigüedad del Inventario */}
      {(() => {
        const p1 = agingSummary?.rango0_30?.pct || 0;
        const p2 = agingSummary?.rango31_60?.pct || 0;
        const p3 = agingSummary?.rango61_90?.pct || 0;
        const p4 = agingSummary?.rangoMas90?.pct || 0;

        const radius = 35;
        const circ = 2 * Math.PI * radius;

        const arc1Offset = 0;
        const arc2Offset = -(p1 / 100) * circ;
        const arc3Offset = -((p1 + p2) / 100) * circ;
        const arc4Offset = -((p1 + p2 + p3) / 100) * circ;

        return (
          <motion.div
            id="card-stock-aging"
            whileHover={{ y: -1 }}
            className="bg-white border border-zinc-200/90 rounded-xl p-4 shadow-xs space-y-3 relative flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-500" />
                <span>ANTIGÜEDAD & TEMPORADA</span>
              </span>
              <CardInfoButton
                title="Antigüedad del Inventario & Temporada"
                description="Segmenta las unidades físicas según los días transcurridos desde su corte/recepción y ciclo de temporada comercial."
                formula="0-30d (Novedad), 31-60d (Regular), 61-90d (Riesgo), >90d (Crítico / Sin Rotación)"
                operationalImpact="El porcentaje actual se calcula por fecha de corte cronológica del dataset y se vinculará por Temporada (FW/SS/Carry-over) al incluirse el campo."
              />
            </div>

            {agingSummary ? (
              <div className="flex items-center gap-4 py-1">
                <div className="relative w-[84px] h-[84px] shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 84 84">
                    <circle
                      cx="42"
                      cy="42"
                      r={radius}
                      className="stroke-zinc-100"
                      strokeWidth="6.5"
                      fill="none"
                    />
                    {p1 > 0 && (
                      <circle
                        cx="42"
                        cy="42"
                        r={radius}
                        stroke="#10b981"
                        strokeWidth="6.5"
                        fill="none"
                        strokeDasharray={`${(p1 / 100) * circ} ${circ}`}
                        strokeDashoffset={arc1Offset}
                        className="transition-all duration-500"
                      />
                    )}
                    {p2 > 0 && (
                      <circle
                        cx="42"
                        cy="42"
                        r={radius}
                        stroke="#94a3b8"
                        strokeWidth="6.5"
                        fill="none"
                        strokeDasharray={`${(p2 / 100) * circ} ${circ}`}
                        strokeDashoffset={arc2Offset}
                        className="transition-all duration-500"
                      />
                    )}
                    {p3 > 0 && (
                      <circle
                        cx="42"
                        cy="42"
                        r={radius}
                        stroke="#f59e0b"
                        strokeWidth="6.5"
                        fill="none"
                        strokeDasharray={`${(p3 / 100) * circ} ${circ}`}
                        strokeDashoffset={arc3Offset}
                        className="transition-all duration-500"
                      />
                    )}
                    {p4 > 0 && (
                      <circle
                        cx="42"
                        cy="42"
                        r={radius}
                        stroke="#f43f5e"
                        strokeWidth="6.5"
                        fill="none"
                        strokeDasharray={`${(p4 / 100) * circ} ${circ}`}
                        strokeDashoffset={arc4Offset}
                        className="transition-all duration-500"
                      />
                    )}
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-sm font-bold text-zinc-900 font-mono leading-none">
                      {p1 + p2}%
                    </span>
                    <span className="text-[8px] font-mono text-zinc-400 uppercase mt-0.5 leading-none">
                      Activo
                    </span>
                  </div>
                </div>

                <div className="flex-1 space-y-1 text-[11px] min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-zinc-600 truncate">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                      <span>0-30d:</span>
                    </span>
                    <span className="font-mono font-semibold text-emerald-600">{p1}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-zinc-600 truncate">
                      <span className="w-2 h-2 rounded-full bg-slate-400 shrink-0"></span>
                      <span>31-60d:</span>
                    </span>
                    <span className="font-mono font-semibold text-zinc-700">{p2}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-zinc-600 truncate">
                      <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                      <span>61-90d:</span>
                    </span>
                    <span className="font-mono font-semibold text-amber-600">{p3}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-zinc-600 truncate">
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
                      <span>&gt;90d:</span>
                    </span>
                    <span className="font-mono font-semibold text-rose-600">{p4}%</span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-zinc-400 py-3">Sin datos de antigüedad calculados.</p>
            )}

            <div className="pt-2 border-t border-zinc-100 flex items-center justify-between text-[11px] font-mono">
              <span className="text-zinc-500">Total Unidades:</span>
              <span className="text-zinc-800 font-semibold">
                {(agingSummary?.totalPiezas || 0).toLocaleString()} uds
              </span>
            </div>
          </motion.div>
        );
      })()}

      {/* Card 3: Rendimiento Espacial */}
      {(() => {
        const piezasPorM2 = currentSpatial?.piezasPorM2 || 0;
        const targetMax = currentSpatial?.densidadTargetMax || 35;
        const status = currentSpatial?.estadoDensidad || 'OPTIMO';

        const spatialPct = Math.min(100, Math.max(0, Math.round((piezasPorM2 / (targetMax || 35)) * 100)));
        const radius = 35;
        const circ = 2 * Math.PI * radius;
        const strokeOffset = circ * (1 - spatialPct / 100);

        const ringColor =
          status === 'OPTIMO' ? '#10b981' : status === 'SUBUTILIZADO' ? '#f59e0b' : '#f43f5e';

        return (
          <motion.div
            id="card-spatial-performance"
            whileHover={{ y: -1 }}
            className="bg-white border border-zinc-200/90 rounded-xl p-4 shadow-xs space-y-3 relative flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-zinc-600" />
                <span>RENDIMIENTO ESPACIAL</span>
              </span>
              <CardInfoButton
                title="Densidad Espacial por Metro Cuadrado (m²)"
                description="Evalúa la carga física y monetaria por metro cuadrado comercial de la tienda según los estándares de su formato."
                formula="Densidad = Piezas Actuales / Metraje Comercial (m²)"
              />
            </div>

            {currentSpatial ? (
              <div className="flex items-center gap-4 py-1">
                <div className="relative w-[84px] h-[84px] shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 84 84">
                    <circle
                      cx="42"
                      cy="42"
                      r={radius}
                      className="stroke-zinc-100"
                      strokeWidth="6.5"
                      fill="none"
                    />
                    <circle
                      cx="42"
                      cy="42"
                      r={radius}
                      stroke={ringColor}
                      strokeWidth="6.5"
                      fill="none"
                      strokeDasharray={circ}
                      strokeDashoffset={strokeOffset}
                      strokeLinecap="round"
                      className="transition-all duration-700 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-base font-bold text-zinc-900 font-mono leading-none">
                      {piezasPorM2}
                    </span>
                    <span className="text-[8px] font-mono text-zinc-400 uppercase mt-0.5 leading-none">
                      pzs/m²
                    </span>
                  </div>
                </div>

                <div className="flex-1 space-y-1.5 min-w-0">
                  <div className="flex justify-between items-center bg-zinc-50 px-2.5 py-1.5 rounded-lg border border-zinc-200/80">
                    <span className="text-[11px] text-zinc-600 truncate" title={currentSpatial.tienda ? `Tienda / Ámbito: ${currentSpatial.tienda}` : undefined}>
                      Superficie:
                    </span>
                    <span className="text-xs font-semibold font-mono text-zinc-900 shrink-0 ml-1">
                      {currentSpatial.superficieM2.toLocaleString()} m²
                    </span>
                  </div>
                  <div className="flex justify-between items-center bg-zinc-50 px-2.5 py-1.5 rounded-lg border border-zinc-200/80">
                    <span className="text-[11px] text-zinc-600 truncate">Valor / m²:</span>
                    <span className="text-xs font-semibold font-mono text-emerald-600 shrink-0 ml-1">
                      ${currentSpatial.valorPorM2}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-zinc-400 py-3">Sin datos espaciales calculados.</p>
            )}

            <div className="pt-2 border-t border-zinc-100 flex items-center justify-between text-[11px] font-mono">
              <span className="text-zinc-500">Estado Densidad:</span>
              <span
                className={`font-semibold ${
                  status === 'OPTIMO'
                    ? 'text-emerald-600'
                    : status === 'SUBUTILIZADO'
                    ? 'text-amber-600'
                    : 'text-rose-600'
                }`}
              >
                {status}
              </span>
            </div>
          </motion.div>
        );
      })()}
    </div>
  );
};
