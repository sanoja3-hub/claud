import React, { useMemo, useState, useEffect } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Check,
  CheckCircle2,
  ChevronDown,
  Download,
  ExternalLink,
  Flame,
  Globe,
  Grid,
  Image as ImageIcon,
  Layers,
  Link as LinkIcon,
  Loader2,
  RefreshCw,
  Search,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Store,
  Tag,
  Truck,
  X,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { InventoryItem } from '../types';
import { TechnicalSneakerGraphic } from './TechnicalSneakerGraphic';
import {
  resolveProductImage,
  getGoogleImagesSearchUrl,
} from '../utils/productImageResolver';
import {
  searchRealProductImages,
  WebImageResult,
} from '../utils/webImageSearchService';
import { generarPivotCurvas } from '../utils/analysisEngine';

interface SizeCurveTabProps {
  inventory: InventoryItem[];
  customImageUrls?: Record<string, string>;
  onUpdateProductImageUrl?: (referencia: string, imageUrl: string) => void;
  selectedSku?: string | null;
  onSelectSku?: (sku: string) => void;
  onBack?: () => void;
  backLabel?: string;
  embedded?: boolean;
}

export interface ProductUnitInfo {
  isCalzado: boolean;
  isTextil: boolean;
  isAccesorios: boolean;
  categoryName: string;
  unitPlural: string; // 'pares' | 'piezas' | 'unidades'
  unitSingular: string; // 'par' | 'pieza' | 'unidad'
  unitShort: string; // 'par' | 'pza' | 'ud'
  unitPluralWithPieces: string; // 'pares' | 'piezas' | 'unidades (piezas)'
  formatQty: (count: number) => string;
  formatRate: () => string;
  formatRateShort: () => string;
}

export function getProductUnitInfo(
  prod?: { departamento?: string; familia?: string; seccion?: string } | null
): ProductUnitInfo {
  const rawDepto = (prod?.departamento || '').trim().toUpperCase();
  const rawFam = (prod?.familia || '').trim().toUpperCase();
  const rawSec = (prod?.seccion || '').trim().toUpperCase();
  const combined = `${rawDepto} ${rawFam} ${rawSec}`;

  let isTextil = false;
  let isCalzado = false;
  let isAccesorios = false;

  // 1. Strict priority to explicit product department
  if (
    rawDepto === 'TEXTIL' ||
    rawDepto.includes('TEXTIL') ||
    rawDepto.includes('ROPA') ||
    rawDepto.includes('APPAREL') ||
    rawDepto.includes('CONFECCION') ||
    rawDepto.includes('INDUMENTARIA')
  ) {
    isTextil = true;
  } else if (
    rawDepto === 'CALZADO' ||
    rawDepto.includes('CALZAD') ||
    rawDepto.includes('FOOTWEAR') ||
    rawDepto.includes('ZAPAT')
  ) {
    isCalzado = true;
  } else if (
    rawDepto === 'ACCESORIOS' ||
    rawDepto.includes('ACCESORI') ||
    rawDepto.includes('ACCESSOR')
  ) {
    isAccesorios = true;
  } else {
    // 2. Semantic fallback if department is empty
    isTextil =
      combined.includes('TEXTIL') ||
      combined.includes('ROPA') ||
      combined.includes('APPAREL') ||
      combined.includes('CONFECCION') ||
      combined.includes('CAMIS') ||
      combined.includes('PANTALON') ||
      combined.includes('SHIRT') ||
      combined.includes('TEE') ||
      combined.includes('HOODIE') ||
      combined.includes('SUDADERA') ||
      combined.includes('SHORT') ||
      combined.includes('LEGGING') ||
      combined.includes('MEDIAS') ||
      combined.includes('SOCKS') ||
      combined.includes('CALCETIN') ||
      combined.includes('CAPUCHA') ||
      combined.includes('CAPRI');

    if (!isTextil) {
      isAccesorios =
        combined.includes('ACCESORIO') ||
        combined.includes('COMPLEMENTO') ||
        combined.includes('MOCHILA') ||
        combined.includes('BACKPACK') ||
        combined.includes('GORRA') ||
        combined.includes('BOLSO') ||
        /\b(CAP|CAPS|HAT|BAG|BAGS)\b/.test(combined);
    }

    if (!isTextil && !isAccesorios) {
      isCalzado = true;
    }
  }

  const categoryName = isCalzado ? 'Calzado' : isTextil ? 'Textil' : 'Accesorios';
  const unitPlural = isCalzado ? 'pares' : isTextil ? 'piezas' : 'unidades';
  const unitSingular = isCalzado ? 'par' : isTextil ? 'pieza' : 'unidad';
  const unitShort = isCalzado ? 'par' : isTextil ? 'pza' : 'ud';
  const unitPluralWithPieces = isCalzado ? 'pares' : isTextil ? 'piezas' : 'unidades (piezas)';

  return {
    isCalzado,
    isTextil,
    isAccesorios,
    categoryName,
    unitPlural,
    unitSingular,
    unitShort,
    unitPluralWithPieces,
    formatQty: (count: number) => {
      const abs = Math.abs(count);
      if (isCalzado) return `${count} ${abs === 1 ? 'par' : 'pares'}`;
      if (isTextil) return `${count} ${abs === 1 ? 'pieza' : 'piezas'}`;
      return `${count} ${abs === 1 ? 'unidad' : 'unidades'}`;
    },
    formatRate: () => {
      if (isCalzado) return 'pares / talla';
      if (isTextil) return 'piezas / talla';
      return 'unidades / talla';
    },
    formatRateShort: () => {
      if (isCalzado) return 'pares/talla';
      if (isTextil) return 'piezas/talla';
      return 'uds/talla';
    },
  };
}

interface ProductSummary {
  referencia: string;
  marca: string;
  departamento: string;
  seccion: string;
  familia: string;
  imagenUrl?: string;
  totalStock: number;
  totalValuation: number;
  avgPrice: number;
  storesCount: number;
  hasBrokenCore: boolean;
  criticalSize?: string;
  sizeQuantities: Record<string, number>;
  sizesList: string[];
}

export const SizeCurveTab: React.FC<SizeCurveTabProps> = ({
  inventory = [],
  customImageUrls: externalCustomImageUrls,
  onUpdateProductImageUrl,
  selectedSku,
  onSelectSku,
  onBack,
  backLabel = 'Volver al Detalle',
  embedded = false,
}) => {
  // Mode: 'stitch' (Single Product Detail View) vs 'matrix' (Consolidated Multi-SKU Matrix)
  const [viewMode, setViewMode] = useState<'stitch' | 'matrix'>('stitch');

  // Selected Reference for Stitch view
  const [selectedRef, setSelectedRef] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedStoreFilter, setSelectedStoreFilter] = useState<string>('TODAS');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('TODAS');
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  // Custom Image URL Override (session memory and persistent state)
  const [localCustomImageUrls, setLocalCustomImageUrls] = useState<Record<string, string>>({});
  const customImageUrls = useMemo(() => ({
    ...externalCustomImageUrls,
    ...localCustomImageUrls,
  }), [externalCustomImageUrls, localCustomImageUrls]);

  const [isImageUrlModalOpen, setIsImageUrlModalOpen] = useState<boolean>(false);
  const [tempImageUrl, setTempImageUrl] = useState<string>('');
  const [imageLoadError, setImageLoadError] = useState<boolean>(false);

  // Web Query & Image Linker States
  const [isSearchingWebImages, setIsSearchingWebImages] = useState<boolean>(false);
  const [webSearchResults, setWebSearchResults] = useState<WebImageResult[]>([]);
  const [webSearchError, setWebSearchError] = useState<string | null>(null);
  const [hasSearchedWeb, setHasSearchedWeb] = useState<boolean>(false);

  // Transfer simulation state for selected product
  const [isTransferModalOpen, setIsTransferModalOpen] = useState<boolean>(false);
  const [transferSuccessNotice, setTransferSuccessNotice] = useState<string | null>(null);

  // Selected cell inspector state
  const [inspectedCell, setInspectedCell] = useState<{
    store: string;
    size: string;
    stock: number;
  } | null>(null);

  // Matrix view filters (when viewMode === 'matrix')
  const [matrixDept, setMatrixDept] = useState<string>('CALZADO');
  const [matrixBrand, setMatrixBrand] = useState<string>('TODAS');

  // 1. Group inventory into products
  const productSummaries = useMemo<ProductSummary[]>(() => {
    if (!inventory || inventory.length === 0) return [];

    const map = new Map<string, {
      items: InventoryItem[];
      referencia: string;
      marca: string;
      departamento: string;
      seccion: string;
      familia: string;
      imagenUrl?: string;
      totalStock: number;
      totalValuation: number;
      stores: Set<string>;
      sizeQuantities: Record<string, number>;
    }>();

    inventory.forEach((item) => {
      const ref = (item.Referencia || 'SIN-REF').trim();
      if (!map.has(ref)) {
        map.set(ref, {
          items: [],
          referencia: ref,
          marca: item.Marca || 'MARCA',
          departamento: (item.Departamento || '').trim() || 'CALZADO',
          seccion: item.Seccion || '',
          familia: item.Familia || '',
          imagenUrl: item.ImagenUrl || undefined,
          totalStock: 0,
          totalValuation: 0,
          stores: new Set<string>(),
          sizeQuantities: {},
        });
      }

      const entry = map.get(ref)!;
      // If the entry didn't have a valid department yet, grab it from any row of this SKU that has it
      if ((!entry.departamento || entry.departamento === 'CALZADO') && item.Departamento) {
        entry.departamento = item.Departamento.trim();
      }
      if (!entry.imagenUrl && item.ImagenUrl) {
        entry.imagenUrl = item.ImagenUrl;
      }
      entry.items.push(item);
      entry.totalStock += Number(item.Stock || 0);
      entry.totalValuation += Number(item.Valoracion || 0);
      entry.stores.add(item.Tienda);

      const size = String(item.Talla || '').trim();
      if (size) {
        entry.sizeQuantities[size] = (entry.sizeQuantities[size] || 0) + Number(item.Stock || 0);
      }
    });

    const list: ProductSummary[] = [];

    map.forEach((data, ref) => {
      const sizesList = Object.keys(data.sizeQuantities).sort((a, b) => {
        const numA = parseFloat(a);
        const numB = parseFloat(b);
        if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
        return a.localeCompare(b);
      });

      // Detect broken core sizes (e.g. 8.5, 9, 9.5, 10 for Calzado with 0 or 1 stock)
      const coreCandidates = ['8.5', '9', '9.5', '10', '41', '42', '43', 'M', 'L'];
      let criticalSize: string | undefined;
      let hasBrokenCore = false;

      for (const cs of coreCandidates) {
        if (sizesList.includes(cs)) {
          const qty = data.sizeQuantities[cs] || 0;
          if (qty <= 2) {
            hasBrokenCore = true;
            criticalSize = cs;
            break;
          }
        }
      }

      // If no candidate matched, find the lowest non-zero or zero size
      if (!criticalSize && sizesList.length > 0) {
        const sortedByQty = [...sizesList].sort(
          (a, b) => (data.sizeQuantities[a] || 0) - (data.sizeQuantities[b] || 0)
        );
        if ((data.sizeQuantities[sortedByQty[0]] || 0) <= 2) {
          criticalSize = sortedByQty[0];
          hasBrokenCore = true;
        }
      }

      const avgPrice = data.totalStock > 0 ? data.totalValuation / data.totalStock : 120;

      list.push({
        referencia: ref,
        marca: data.marca,
        departamento: data.departamento,
        seccion: data.seccion,
        familia: data.familia,
        imagenUrl: data.imagenUrl,
        totalStock: data.totalStock,
        totalValuation: data.totalValuation,
        avgPrice: Math.round(avgPrice * 100) / 100,
        storesCount: data.stores.size,
        hasBrokenCore,
        criticalSize,
        sizeQuantities: data.sizeQuantities,
        sizesList,
      });
    });

    // Sort: items with broken core first, then by highest total stock
    return list.sort((a, b) => {
      if (a.hasBrokenCore && !b.hasBrokenCore) return -1;
      if (!a.hasBrokenCore && b.hasBrokenCore) return 1;
      return b.totalStock - a.totalStock;
    });
  }, [inventory]);

  // Set default selected product on first load or when inventory updates / selectedSku prop changes
  useEffect(() => {
    if (selectedSku) {
      setSelectedRef(selectedSku);
      return;
    }
    if (productSummaries.length > 0 && !selectedRef) {
      // Pick first broken core or first item
      const broken = productSummaries.find((p) => p.hasBrokenCore);
      setSelectedRef(broken ? broken.referencia : productSummaries[0].referencia);
    }
  }, [productSummaries, selectedRef, selectedSku]);

  // Active Selected Product Details
  const activeProduct = useMemo(() => {
    return (
      productSummaries.find((p) => p.referencia === selectedRef) ||
      productSummaries[0] ||
      null
    );
  }, [productSummaries, selectedRef]);

  // Reset image error and search state on ref change
  useEffect(() => {
    setImageLoadError(false);
    setWebSearchResults([]);
    setWebSearchError(null);
    setHasSearchedWeb(false);
  }, [selectedRef]);

  // Stores available in the dataset
  const allStores = useMemo(() => {
    const set = new Set(inventory.map((it) => it.Tienda));
    return Array.from(set).sort();
  }, [inventory]);

  // Filtered products list for search autocomplete and carousel
  const filteredProducts = useMemo(() => {
    let list = productSummaries;
    if (selectedDeptFilter !== 'TODAS' && selectedDeptFilter !== 'TODOS') {
      list = list.filter((p) => {
        const d = (p.departamento || '').toUpperCase();
        return d.includes(selectedDeptFilter);
      });
    }
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter(
      (p) =>
        p.referencia.toLowerCase().includes(q) ||
        p.marca.toLowerCase().includes(q) ||
        p.familia.toLowerCase().includes(q) ||
        p.seccion.toLowerCase().includes(q)
    );
  }, [productSummaries, searchQuery, selectedDeptFilter]);

  // If department filter changes and current product is not in the filtered department, switch to first match
  useEffect(() => {
    if (selectedDeptFilter === 'TODAS' || selectedDeptFilter === 'TODOS') return;
    if (
      activeProduct &&
      !(activeProduct.departamento || '').toUpperCase().includes(selectedDeptFilter)
    ) {
      const match = productSummaries.find((p) =>
        (p.departamento || '').toUpperCase().includes(selectedDeptFilter)
      );
      if (match) {
        setSelectedRef(match.referencia);
      }
    }
  }, [selectedDeptFilter, activeProduct, productSummaries]);

  // Build Store vs Size Matrix for the Active Product
  const { storeMatrixRows, productSizes } = useMemo(() => {
    if (!activeProduct) return { storeMatrixRows: [], productSizes: [] };

    const sizes = activeProduct.sizesList;

    // Filter items belonging to this reference
    const itemsForRef = inventory.filter(
      (it) => it.Referencia === activeProduct.referencia
    );

    // Get all stores that have inventory or are active
    const storesToShow =
      selectedStoreFilter === 'TODAS'
        ? allStores
        : allStores.filter((st) => st === selectedStoreFilter);

    const rows = storesToShow.map((storeName) => {
      const storeItems = itemsForRef.filter((it) => it && it.Tienda === storeName);
      const sizeCounts: Record<string, number> = {};

      (sizes || []).forEach((s) => {
        const match = storeItems.find((it) => String(it.Talla).trim() === s);
        sizeCounts[s] = match ? Number(match.Stock) : 0;
      });

      const totalStoreUnits = Object.values(sizeCounts).reduce((a, b) => a + b, 0);

      // Determine store category / type
      const lower = storeName.toLowerCase();
      let storeType = 'REGULAR';
      if (lower.includes('flagship') || lower.includes('centro')) storeType = 'FLAGSHIP';
      else if (lower.includes('outlet')) storeType = 'OUTLET';
      else if (lower.includes('hub') || lower.includes('almacen') || lower.includes('norte')) storeType = 'HUB';

      return {
        storeName,
        storeType,
        sizes: sizeCounts,
        totalUnits: totalStoreUnits,
      };
    });

    return { storeMatrixRows: rows, productSizes: sizes };
  }, [activeProduct, inventory, allStores, selectedStoreFilter]);

  // Calculate size category (Orphan, Optimal, Overstock) for Aggregate bar
  const sizeClassifications = useMemo(() => {
    if (!activeProduct || !productSizes || productSizes.length === 0) return {};

    const total = activeProduct.totalStock || 1;
    const result: Record<string, { status: 'orphan' | 'optimal' | 'overstock'; pct: number }> = {};

    (productSizes || []).forEach((s) => {
      const count = activeProduct.sizeQuantities?.[s] || 0;
      const pct = (count / total) * 100;

      // Deficit condition
      if (count <= 2 || (s === activeProduct.criticalSize && count <= 4)) {
        result[s] = { status: 'orphan', pct };
      } else if (pct > 32 || count > 35) {
        result[s] = { status: 'overstock', pct };
      } else {
        result[s] = { status: 'optimal', pct };
      }
    });

    return result;
  }, [activeProduct, productSizes]);

  // Dynamic Image URL (Custom override > Item ImagenUrl > Curated resolver)
  const resolvedImageUrl = useMemo(() => {
    if (!activeProduct) return '';
    if (customImageUrls[activeProduct.referencia]) {
      return customImageUrls[activeProduct.referencia];
    }
    if (activeProduct.imagenUrl) {
      return activeProduct.imagenUrl;
    }
    return resolveProductImage(
      activeProduct.referencia,
      activeProduct.marca,
      activeProduct.departamento
    );
  }, [activeProduct, customImageUrls]);

  // Google Images Search Link for this reference
  const googleImagesUrl = useMemo(() => {
    if (!activeProduct) return '';
    return getGoogleImagesSearchUrl(
      activeProduct.marca,
      activeProduct.referencia,
      activeProduct.departamento
    );
  }, [activeProduct]);

  // Trigger Automatic Web Image Query
  const handleTriggerWebSearch = async (overrideRef?: string) => {
    if (!activeProduct) return;
    setIsSearchingWebImages(true);
    setWebSearchError(null);
    setHasSearchedWeb(true);

    try {
      const results = await searchRealProductImages(
        activeProduct.marca,
        overrideRef || activeProduct.referencia,
        activeProduct.familia,
        activeProduct.departamento
      );

      setWebSearchResults(results);
      if (results.length === 0) {
        setWebSearchError('No se encontraron imágenes directas en la consulta web. Puedes pegar la URL de la foto o buscar en Google Imágenes.');
      }
    } catch (err: any) {
      setWebSearchError('Error al consultar los repositorios web. Intenta nuevamente o pega el enlace manual.');
    } finally {
      setIsSearchingWebImages(false);
    }
  };

  // Select and persist an image found from web search
  const handleSelectWebImage = (url: string) => {
    if (!activeProduct || !url) return;
    const ref = activeProduct.referencia;
    
    // Save to local state
    setLocalCustomImageUrls((prev) => ({
      ...prev,
      [ref]: url,
    }));

    // Trigger parent persistence callback to save in IndexedDB
    if (onUpdateProductImageUrl) {
      onUpdateProductImageUrl(ref, url);
    }

    setImageLoadError(false);
    setIsImageUrlModalOpen(false);
  };

  // Save manually input URL
  const handleSaveManualImageUrl = () => {
    if (!activeProduct || !tempImageUrl.trim()) {
      setIsImageUrlModalOpen(false);
      return;
    }
    const cleanUrl = tempImageUrl.trim();
    const ref = activeProduct.referencia;

    setLocalCustomImageUrls((prev) => ({
      ...prev,
      [ref]: cleanUrl,
    }));

    if (onUpdateProductImageUrl) {
      onUpdateProductImageUrl(ref, cleanUrl);
    }

    setImageLoadError(false);
    setIsImageUrlModalOpen(false);
  };

  // Curve health status & deficit diagnosis (Red: Alerta real, Yellow: Curva baja/falta talla, Green: Óptima, Blue: Sobre stock)
  const criticalDeficitData = useMemo(() => {
    if (!activeProduct) return null;

    const criticalSize = activeProduct.criticalSize || productSizes[0] || '9.5';
    const totalStock = activeProduct.totalStock ?? 0;
    const sizesCount = productSizes.length || 1;
    const avgUnitsPerSize = sizesCount > 0 ? totalStock / sizesCount : 0;

    // Tallas faltantes (stock = 0 en toda la red)
    const missingSizes = productSizes.filter((s) => (activeProduct.sizeQuantities[s] || 0) === 0);

    // Tallas con stock bajo (1 o 2 unidades en total en toda la red)
    const lowStockSizes = productSizes.filter((s) => {
      const q = activeProduct.sizeQuantities[s] || 0;
      return q > 0 && q <= 2;
    });

    // Tiendas con stock activo de este producto
    const activeStoresForProduct = storeMatrixRows.filter((r) => r.totalUnits > 0);
    const deficientStores: string[] = [];
    const excessStores: { store: string; stock: number }[] = [];

    (storeMatrixRows || []).forEach((r) => {
      const count = r.sizes?.[criticalSize] || 0;
      if (r.totalUnits > 0 && count <= 1) {
        deficientStores.push(r.storeName);
      } else if (count >= 4) {
        excessStores.push({ store: r.storeName, stock: count });
      }
    });

    const lostWeeklyUnits = deficientStores.length * 4;
    const estLostSales = Math.round(lostWeeklyUnits * (activeProduct.avgPrice || 100));

    // Stock de la talla crítica/core en toda la red
    const criticalSizeStock = activeProduct.sizeQuantities[criticalSize] || 0;

    // 1. ROJO: "se coloque de color rojo solo si hay una alerta real del producto señalado"
    // Solo cuando hay una rotura crítica real comprobada:
    // - Stock total = 0 (quiebre completo del producto)
    // - O la talla core tiene 0 pares globales en la red
    // - O más del 40% de las tiendas activas que comercializan el modelo tienen quiebre en la talla core (y la talla core tiene <= 2 pares totales)
    // - O más del 35% de las tallas de la curva están en 0 en un modelo con demanda
    const isRealCriticalAlert =
      totalStock === 0 ||
      criticalSizeStock === 0 ||
      (activeStoresForProduct.length >= 2 && deficientStores.length >= Math.ceil(activeStoresForProduct.length * 0.4) && criticalSizeStock <= 2) ||
      (sizesCount >= 4 && missingSizes.length >= Math.ceil(sizesCount * 0.35));

    // 2. AZUL: "azul para cuando esta en sobre stock"
    // Cuando el inventario total o el promedio por talla está en niveles de exceso sin quiebres críticos
    const isOverstock =
      !isRealCriticalAlert &&
      (avgUnitsPerSize >= 9 || (totalStock >= 45 && missingSizes.length === 0 && avgUnitsPerSize >= 7.5));

    // 3. AMARILLO: "de color amarillos si el estado de la curva esta bajo o si hace falta una tallas de la curva"
    // Falta al menos una talla en la curva (missingSizes.length > 0) O el promedio por talla es bajo (< 3.5) O muchas tallas con stock bajo (<= 2)
    const isLowOrMissing =
      !isRealCriticalAlert &&
      !isOverstock &&
      (missingSizes.length > 0 || avgUnitsPerSize < 3.5 || lowStockSizes.length >= Math.ceil(sizesCount * 0.4));

    // 4. VERDE: "verde si la curva completa es optima"
    // Curva completa con todas las tallas cubiertas, sin quiebres ni sobrestock
    let status: 'critical' | 'low' | 'optimal' | 'overstock' = 'optimal';
    if (isRealCriticalAlert) {
      status = 'critical';
    } else if (isOverstock) {
      status = 'overstock';
    } else if (isLowOrMissing) {
      status = 'low';
    } else {
      status = 'optimal';
    }

    return {
      status,
      size: criticalSize,
      criticalSizeStock,
      totalStock,
      avgUnitsPerSize,
      missingSizes,
      lowStockSizes,
      deficientStores,
      excessStores: excessStores.sort((a, b) => b.stock - a.stock),
      estLostSales,
      hasDeficit: deficientStores.length > 0,
    };
  }, [activeProduct, productSizes, storeMatrixRows]);

  // Product unit information (Calzado -> pares, Textil -> piezas, Accesorios -> unidades)
  const unitInfo = useMemo(() => getProductUnitInfo(activeProduct), [activeProduct]);

  // Handle Export CSV
  const handleExportCSV = () => {
    if (!activeProduct) return;

    const headers = ['Referencia', 'Marca', 'Tienda', 'Tipo_Tienda', ...productSizes, 'Total_Pares'];
    const rows = storeMatrixRows.map((st) => {
      return [
        activeProduct.referencia,
        activeProduct.marca,
        `"${st.storeName}"`,
        st.storeType,
        ...productSizes.map((s) => st.sizes[s] || 0),
        st.totalUnits,
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Curva_Tallas_${activeProduct.referencia}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Handle Sync Data button
  const handleSyncData = () => {
    setIsSyncing(true);
    setSyncNotice(null);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncNotice('Datos sincronizados con éxito desde el inventario activo.');
      setTimeout(() => setSyncNotice(null), 4000);
    }, 600);
  };

  // Helper for matrix cell density styling
  const getCellDensityStyle = (count: number, isCriticalSize: boolean) => {
    if (count === 0) {
      return isCriticalSize
        ? 'bg-rose-50 border border-rose-200 text-rose-700 font-bold shadow-xs'
        : 'bg-[#F8F7FC] text-zinc-400 font-normal border border-zinc-200/80';
    }
    if (count <= 2) {
      return 'bg-amber-50 border border-amber-200 text-amber-800 font-medium';
    }
    if (count >= 3 && count <= 9) {
      return 'bg-emerald-50 border border-emerald-200 text-emerald-800 font-semibold';
    }
    // Overstock (10+)
    return 'bg-blue-50 border border-blue-200 text-blue-800 font-bold';
  };

  // Pivot data for Multi-SKU Matrix view
  const { rows: multiSkuRows, allSizes: multiSkuSizes } = useMemo(() => {
    if (viewMode !== 'matrix') return { rows: [], allSizes: [] };
    return generarPivotCurvas(
      inventory,
      matrixDept,
      matrixBrand,
      selectedStoreFilter,
      searchQuery
    );
  }, [inventory, matrixDept, matrixBrand, selectedStoreFilter, searchQuery, viewMode]);

  return (
    <div className="space-y-6 select-none">
      {/* Top Action & Search Header */}
      {!embedded ? (
        <div className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Title & Status */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white shrink-0 shadow-xs">
              <Grid className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight font-sans">
                  Curvas de Tallas & Modelos
                </h2>
              </div>
              <p className="text-xs text-zinc-500 font-sans">
                Mapeo de distribución de stock en tiempo real por modelo, talla y tienda.
              </p>
            </div>
          </div>

          {/* Action Controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle */}
            <div className="bg-zinc-100 border border-zinc-200 rounded-lg p-0.5 flex items-center gap-0.5 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('stitch')}
                className={`h-7 px-2.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'stitch'
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Ficha Modelo
              </button>
              <button
                type="button"
                onClick={() => setViewMode('matrix')}
                className={`h-7 px-2.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'matrix'
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Matriz Consolidada
              </button>
            </div>

            {/* Department Filter (Calzado, Textil, Accesorios) */}
            <div className="bg-zinc-100 border border-zinc-200 rounded-lg p-0.5 flex items-center gap-0.5 text-xs">
              {[
                { id: 'TODAS', label: 'Todos', icon: '🌐' },
                { id: 'CALZADO', label: 'Calzado', icon: '👟' },
                { id: 'TEXTIL', label: 'Textil', icon: '👕' },
                { id: 'ACCESORIOS', label: 'Accesorios', icon: '🎒' },
              ].map((dept) => (
                <button
                  key={dept.id}
                  type="button"
                  onClick={() => {
                    setSelectedDeptFilter(dept.id);
                    setMatrixDept(dept.id);
                  }}
                  className={`h-7 px-2 rounded-md font-medium transition-colors flex items-center gap-1 cursor-pointer ${
                    selectedDeptFilter === dept.id
                      ? 'bg-white text-zinc-900 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <span>{dept.icon}</span>
                  <span>{dept.label}</span>
                </button>
              ))}
            </div>

            {/* Store Filter */}
            <select
              value={selectedStoreFilter}
              onChange={(e) => setSelectedStoreFilter(e.target.value)}
              className="h-8 bg-white border border-zinc-200/90 text-xs text-zinc-900 rounded-lg px-2.5 shadow-xs focus:outline-none focus:border-zinc-400 cursor-pointer"
            >
              <option value="TODAS">🌐 Todas las Tiendas</option>
              {allStores.map((st) => (
                <option key={st} value={st}>
                  🏬 {st}
                </option>
              ))}
            </select>

            {/* Export CSV */}
            <button
              type="button"
              onClick={handleExportCSV}
              disabled={!activeProduct}
              className="h-8 flex items-center gap-1.5 px-3 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/90 text-xs font-medium text-zinc-700 hover:text-zinc-900 transition-colors shadow-xs disabled:opacity-40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-zinc-500" />
              <span>Exportar CSV</span>
            </button>

            {/* Sync Data */}
            <button
              type="button"
              onClick={handleSyncData}
              disabled={isSyncing}
              className="h-8 flex items-center gap-1.5 px-3 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/90 text-xs font-medium text-zinc-700 hover:text-zinc-900 transition-colors shadow-xs cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-zinc-500 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Sincronizando...' : 'Sincronizar'}</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-zinc-200/90 rounded-xl p-3 sm:p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3">
          {/* View Mode Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-zinc-500 font-sans hidden sm:inline">Vista:</span>
            <div className="bg-zinc-100 border border-zinc-200 rounded-lg p-0.5 flex items-center gap-0.5 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('stitch')}
                className={`h-7 px-2.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'stitch'
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Ficha Modelo
              </button>
              <button
                type="button"
                onClick={() => setViewMode('matrix')}
                className={`h-7 px-2.5 rounded-md font-medium transition-colors cursor-pointer ${
                  viewMode === 'matrix'
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                Matriz Consolidada
              </button>
            </div>
          </div>

          {/* Department Filter (Calzado, Textil, Accesorios) */}
          <div className="bg-zinc-100 border border-zinc-200 rounded-lg p-0.5 flex items-center gap-0.5 text-xs">
            {[
              { id: 'TODAS', label: 'Todos', icon: '🌐' },
              { id: 'CALZADO', label: 'Calzado', icon: '👟' },
              { id: 'TEXTIL', label: 'Textil', icon: '👕' },
              { id: 'ACCESORIOS', label: 'Accesorios', icon: '🎒' },
            ].map((dept) => (
              <button
                key={dept.id}
                type="button"
                onClick={() => {
                  setSelectedDeptFilter(dept.id);
                  setMatrixDept(dept.id);
                }}
                className={`h-7 px-2 rounded-md font-medium transition-colors flex items-center gap-1 cursor-pointer ${
                  selectedDeptFilter === dept.id
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                <span>{dept.icon}</span>
                <span>{dept.label}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {/* Store Filter */}
            <select
              value={selectedStoreFilter}
              onChange={(e) => setSelectedStoreFilter(e.target.value)}
              className="h-7 bg-white border border-zinc-200/90 text-xs text-zinc-900 rounded-lg px-2.5 shadow-xs focus:outline-none focus:border-zinc-400 cursor-pointer"
            >
              <option value="TODAS">🌐 Todas las Tiendas</option>
              {allStores.map((st) => (
                <option key={st} value={st}>
                  🏬 {st}
                </option>
              ))}
            </select>

            {/* Export CSV */}
            <button
              type="button"
              onClick={handleExportCSV}
              disabled={!activeProduct}
              className="h-7 flex items-center gap-1.5 px-2.5 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/90 text-xs font-medium text-zinc-700 hover:text-zinc-900 transition-colors shadow-xs disabled:opacity-40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-zinc-500" />
              <span>CSV</span>
            </button>

            {/* Sync Data */}
            <button
              type="button"
              onClick={handleSyncData}
              disabled={isSyncing}
              className="h-7 flex items-center gap-1.5 px-2.5 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/90 text-xs font-medium text-zinc-700 hover:text-zinc-900 transition-colors shadow-xs cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-zinc-500 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? '...' : 'Sincronizar'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Sync Notification Banner */}
      {syncNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-4 py-2 rounded-xl flex items-center gap-2 font-mono">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{syncNotice}</span>
        </div>
      )}

      {/* Product Selector / Search Carousel */}
      <div className="bg-white border border-zinc-200/90 rounded-xl p-3.5 sm:p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-zinc-400" />
            <span>Seleccionar Producto / Referencia ({filteredProducts.length} Modelos {selectedDeptFilter !== 'TODAS' ? `en ${selectedDeptFilter}` : 'Totales'}):</span>
          </label>
          <span className="text-xs text-zinc-500">
            Mostrando modelo activo: <strong className="text-zinc-900 font-semibold">{activeProduct?.referencia || 'N/A'}</strong>
          </span>
        </div>

        {/* Search input + scannable product pills */}
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative sm:w-80 shrink-0">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Buscar SKU, Marca o Modelo..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-8 bg-white border border-zinc-200/90 rounded-lg pl-8 pr-3 text-xs text-zinc-900 placeholder-zinc-400 shadow-xs focus:outline-none focus:border-zinc-400 transition-colors"
            />
          </div>

          {/* Quick pills for products in dataset */}
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {filteredProducts.length === 0 ? (
              <span className="text-xs text-zinc-400 italic py-1 px-2">
                No hay productos en {selectedDeptFilter} para esta búsqueda
              </span>
            ) : (
              filteredProducts.map((prod) => {
                const isSelected = prod.referencia === selectedRef;
                const deptIcon = prod.departamento?.toUpperCase().includes('TEXTIL')
                  ? '👕'
                  : prod.departamento?.toUpperCase().includes('ACCESORIO')
                  ? '🎒'
                  : '👟';
                return (
                  <button
                    key={prod.referencia}
                    type="button"
                    onClick={() => setSelectedRef(prod.referencia)}
                    className={`h-8 flex items-center gap-1.5 px-3 rounded-lg text-xs shrink-0 transition-colors border cursor-pointer shadow-xs ${
                      isSelected
                        ? 'bg-zinc-900 text-white font-medium border-zinc-900'
                        : 'bg-white border-zinc-200/90 text-zinc-700 hover:bg-zinc-50 hover:text-zinc-900'
                    }`}
                  >
                    <span className="text-xs">{deptIcon}</span>
                    <span className="font-medium">{prod.referencia}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded font-medium tabular-nums ${
                        isSelected
                          ? 'bg-zinc-800 text-zinc-200'
                          : 'bg-zinc-100 text-zinc-600 border border-zinc-200'
                      }`}
                    >
                      {prod.totalStock}p
                    </span>
                    {prod.hasBrokenCore && (
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" title="Quiebre detectado" />
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: Ficha y Diagnóstico de Modelo */}
      {viewMode === 'stitch' && activeProduct && (
        <div className="space-y-6">
          {/* SECCIÓN SUPERIOR: FICHA DE PRODUCTO CON DIAGNÓSTICO INTEGRADO */}
          <div
            id="product-card-container"
            className="bg-white border border-zinc-200/80 rounded-xl p-4 sm:p-5 shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden"
          >
            {/* Back button directly above the image */}
            {onBack && (
              <div className="flex items-center justify-between pb-3 border-b border-zinc-100 mb-4">
                <button
                  type="button"
                  id="btn-back-to-table"
                  onClick={onBack}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-700 hover:text-zinc-950 bg-zinc-100 hover:bg-zinc-200/80 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer group"
                  title="Volver a la tabla de atención en el Cuadro de Mando"
                >
                  <ArrowLeft className="w-3.5 h-3.5 text-zinc-500 group-hover:text-zinc-900 group-hover:-translate-x-0.5 transition-transform" />
                  <span>{backLabel}</span>
                </button>
                <span className="inline-flex items-center gap-1 text-[11px] font-mono font-medium px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200/70">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  Auditoría SKU
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
              {/* COLUMNA IZQUIERDA: FOTO DEL PRODUCTO */}
              <div className="lg:col-span-4 xl:col-span-4 flex flex-col">
                {/* Product Photo Canvas */}
                <div
                  id="product-photo-canvas"
                  className="relative group bg-[#F8F7FC] border border-zinc-200/80 rounded-xl p-3 flex flex-col items-center justify-center h-full min-h-[200px] overflow-hidden"
                >
                  {!imageLoadError && resolvedImageUrl ? (
                    <img
                      src={resolvedImageUrl}
                      alt={activeProduct.referencia}
                      onError={() => setImageLoadError(true)}
                      className="w-full h-44 object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <TechnicalSneakerGraphic
                      className="w-full h-44"
                      departamento={activeProduct.departamento}
                    />
                  )}

                  {/* Floating Image Actions Toolbar */}
                  <div className="absolute bottom-2 right-2 flex items-center gap-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      id="btn-search-photo-web"
                      onClick={() => {
                        setTempImageUrl(customImageUrls[activeProduct.referencia] || '');
                        setIsImageUrlModalOpen(true);
                        handleTriggerWebSearch();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-zinc-100 text-[11px] font-semibold text-zinc-800 border border-zinc-200/90 shadow-xs backdrop-blur-md transition-all cursor-pointer font-mono"
                      title="Buscar foto real del producto en la web automáticamente"
                    >
                      <Globe className="w-3 h-3 text-zinc-500" />
                      <span>Buscar Foto</span>
                    </button>
                    <a
                      href={googleImagesUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 px-2 py-1 rounded-lg bg-white/95 hover:bg-zinc-100 text-[11px] font-medium text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 shadow-xs backdrop-blur-md transition-all font-mono"
                      title="Abrir búsqueda en Google Imágenes en una pestaña nueva"
                    >
                      <ExternalLink className="w-3 h-3 text-zinc-400" />
                      <span>Google</span>
                    </a>
                    <button
                      type="button"
                      id="btn-custom-image-url"
                      onClick={() => {
                        setTempImageUrl(customImageUrls[activeProduct.referencia] || '');
                        setIsImageUrlModalOpen(true);
                      }}
                      className="p-1.5 rounded-lg bg-white/95 hover:bg-zinc-100 text-zinc-600 hover:text-zinc-900 border border-zinc-200/90 shadow-xs backdrop-blur-md transition-all cursor-pointer"
                      title="Ingresar enlace o URL personalizada de la foto"
                    >
                      <LinkIcon className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* COLUMNA DERECHA: IDENTIDAD, DIAGNÓSTICO INTEGRADO Y KPIS */}
              <div className="lg:col-span-8 xl:col-span-8 flex flex-col justify-between space-y-3.5">
                {/* Product Identity */}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-zinc-800 uppercase">
                      {activeProduct.marca}
                    </span>
                    <span className="text-zinc-300">•</span>
                    <span className="text-xs text-zinc-500 font-mono">
                      {activeProduct.familia || activeProduct.seccion || 'SPORT'}
                    </span>
                    <span className="text-zinc-300">•</span>
                    <span className="text-xs text-zinc-500 font-mono">
                      SKU: {activeProduct.referencia}
                    </span>
                    <span className="text-zinc-300">•</span>
                    <span className="text-xs font-semibold text-zinc-700 uppercase tracking-wide">
                      {activeProduct.departamento}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-zinc-900 tracking-tight mt-1 font-sans">
                    {activeProduct.referencia}
                  </h3>

                  {/* Diagnóstico Compacto y Métricas directamente aquí */}
                  {criticalDeficitData && (
                    <div
                      id="integrated-curve-diagnosis-card"
                      className={`mt-2 rounded-xl p-3 border transition-all space-y-2 ${
                        criticalDeficitData.status === 'critical'
                          ? 'border-rose-200 bg-rose-50/40 text-rose-950'
                          : criticalDeficitData.status === 'low'
                          ? 'border-amber-200 bg-amber-50/40 text-amber-950'
                          : criticalDeficitData.status === 'overstock'
                          ? 'border-blue-200 bg-blue-50/40 text-blue-950'
                          : 'border-emerald-200 bg-emerald-50/40 text-emerald-950'
                      }`}
                    >
                      {/* Cabecera compacta: Título de diagnóstico + Métrica y Acción */}
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              criticalDeficitData.status === 'critical'
                                ? 'bg-rose-500 animate-pulse'
                                : criticalDeficitData.status === 'low'
                                ? 'bg-amber-500'
                                : criticalDeficitData.status === 'overstock'
                                ? 'bg-blue-500'
                                : 'bg-emerald-500'
                            }`}
                          />
                          <span className="text-xs font-bold text-zinc-900 tracking-tight font-sans">
                            {criticalDeficitData.status === 'critical' &&
                              `Déficit Crítico: Talla ${criticalDeficitData.size}`}
                            {criticalDeficitData.status === 'low' &&
                              (criticalDeficitData.missingSizes.length > 0
                                ? `Curva Incompleta: Faltan ${criticalDeficitData.missingSizes.length} Talla(s)`
                                : 'Curva con Poca Profundidad')}
                            {criticalDeficitData.status === 'overstock' &&
                              'Alta Concentración de Inventario'}
                            {criticalDeficitData.status === 'optimal' &&
                              'Curva Completa y Equilibrada'}
                          </span>
                        </div>

                        {/* Métrica compacta & Botón de acción */}
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1.5 font-mono">
                            <span className="text-[10px] uppercase font-bold text-zinc-500 tracking-wider">
                              {criticalDeficitData.status === 'critical' && 'Ventas Perdidas Est. / Sem:'}
                              {criticalDeficitData.status === 'low' && 'Disponibilidad:'}
                              {criticalDeficitData.status === 'overstock' && 'Densidad:'}
                              {criticalDeficitData.status === 'optimal' && 'Salud:'}
                            </span>
                            <span
                              className={`text-xs font-bold ${
                                criticalDeficitData.status === 'critical'
                                  ? 'text-rose-600'
                                  : criticalDeficitData.status === 'low'
                                  ? 'text-amber-700'
                                  : criticalDeficitData.status === 'overstock'
                                  ? 'text-blue-700'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {criticalDeficitData.status === 'critical' &&
                                `$${(criticalDeficitData.estLostSales ?? 0).toLocaleString()}`}
                              {criticalDeficitData.status === 'low' &&
                                `${productSizes.length - criticalDeficitData.missingSizes.length}/${productSizes.length} Tallas`}
                              {criticalDeficitData.status === 'overstock' &&
                                `${criticalDeficitData.avgUnitsPerSize.toFixed(1)} ${unitInfo.unitShort}/talla`}
                              {criticalDeficitData.status === 'optimal' && '100% Óptima'}
                            </span>
                          </div>

                          {criticalDeficitData.status === 'critical' && (
                            <button
                              type="button"
                              id="btn-diagnosis-action-transfer"
                              onClick={() => setIsTransferModalOpen(true)}
                              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition-all shadow-xs cursor-pointer font-mono"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              TRASLADO
                            </button>
                          )}
                          {criticalDeficitData.status === 'low' && (
                            <button
                              type="button"
                              id="btn-diagnosis-action-restock"
                              onClick={() => setIsTransferModalOpen(true)}
                              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold transition-all shadow-xs cursor-pointer font-mono"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              REPOSICIÓN
                            </button>
                          )}
                          {criticalDeficitData.status === 'overstock' && (
                            <button
                              type="button"
                              id="btn-diagnosis-action-rebalance"
                              onClick={() => setIsTransferModalOpen(true)}
                              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold transition-all shadow-xs cursor-pointer font-mono"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              REBALANCEO
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Explicación en texto pequeño */}
                      <p className="text-xs text-zinc-600 leading-relaxed">
                        {criticalDeficitData.status === 'critical' && (
                          <>
                            La talla core <strong className="text-zinc-900 font-bold">{criticalDeficitData.size}</strong> presenta rotura real en{' '}
                            <strong className="text-rose-600 font-semibold">{criticalDeficitData.deficientStores.length} tienda(s)</strong> ({unitInfo.formatQty(criticalDeficitData.criticalSizeStock)} globales).
                            Riesgo directo de venta perdida en la curva central del producto.
                          </>
                        )}
                        {criticalDeficitData.status === 'low' && (
                          criticalDeficitData.missingSizes.length > 0 ? (
                            <>
                              La curva presenta <strong className="text-amber-800 font-bold">{criticalDeficitData.missingSizes.length} talla(s) agotada(s)</strong> ({criticalDeficitData.missingSizes.join(', ')}).
                              Promedio de <strong className="text-zinc-900 font-bold">{criticalDeficitData.avgUnitsPerSize.toFixed(1)} {unitInfo.formatRateShort()}</strong>. Se recomienda programar reposición para recuperar la serie comercial completa.
                            </>
                          ) : (
                            <>
                              La serie cuenta con profundidad reducida (<strong className="text-amber-800 font-bold">{criticalDeficitData.lowStockSizes.length} tallas</strong> con stock ≤ 2 {unitInfo.unitPlural}, prom. <strong className="text-zinc-900 font-bold">{criticalDeficitData.avgUnitsPerSize.toFixed(1)} {unitInfo.formatRateShort()}</strong>).
                              Riesgo latente de quiebres inmediatos.
                            </>
                          )
                        )}
                        {criticalDeficitData.status === 'overstock' && (
                          <>
                            El producto acumula volumen por encima del rango operativo (<strong className="text-blue-800 font-bold">{unitInfo.formatQty(criticalDeficitData.totalStock)} totales</strong>, prom. <strong className="text-zinc-900 font-bold">{criticalDeficitData.avgUnitsPerSize.toFixed(1)} {unitInfo.formatRateShort()}</strong>).
                            Sin riesgo de rotura; se sugiere rebalancear a tiendas con mayor rotación o diseñar campañas de salida.
                          </>
                        )}
                        {criticalDeficitData.status === 'optimal' && (
                          <>
                            Todas las <strong className="text-zinc-900 font-bold">{productSizes.length} tallas</strong> de la curva cuentan con cobertura adecuada (promedio de <strong className="text-emerald-700 font-bold">{criticalDeficitData.avgUnitsPerSize.toFixed(1)} {unitInfo.formatRateShort()}</strong>).
                            Disponibilidad comercial balanceada sin quiebres de curva ni sobrecostos de almacenamiento.
                          </>
                        )}
                      </p>
                    </div>
                  )}
                </div>

                {/* Symmetrical 3-Metric KPI Grid */}
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-zinc-100">
                  <div className="bg-[#F8F7FC] border border-zinc-200/80 rounded-xl p-2 text-center">
                    <span className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-mono">
                      PRECIO PROM.
                    </span>
                    <span className="text-sm sm:text-base font-mono font-bold text-zinc-900 mt-0.5 block">
                      €{(activeProduct.avgPrice ?? 0).toFixed(2)}
                    </span>
                  </div>
                  <div className="bg-[#F8F7FC] border border-zinc-200/80 rounded-xl p-2 text-center">
                    <span className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-mono">
                      STOCK TOTAL
                    </span>
                    <span className="text-sm sm:text-base font-mono font-bold text-zinc-900 mt-0.5 block">
                      {(activeProduct.totalStock ?? 0).toLocaleString()} <span className="text-[10px] text-zinc-500 font-normal">{unitInfo.unitShort}</span>
                    </span>
                  </div>
                  <div className="bg-[#F8F7FC] border border-zinc-200/80 rounded-xl p-2 text-center">
                    <span className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-mono">
                      TIENDAS
                    </span>
                    <span className="text-sm sm:text-base font-mono font-bold text-zinc-900 mt-0.5 block">
                      {activeProduct.storesCount}/{allStores.length}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SECCIÓN INFERIOR: MATRIZ GEOGRÁFICA TIENDA VS. TALLA A ANCHO COMPLETO */}
          <div className="bg-white border border-zinc-200/80 rounded-xl p-4 sm:p-5 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-zinc-900 tracking-tight flex items-center gap-2 font-sans">
                  <Store className="w-4 h-4 text-zinc-500" />
                  Matriz Geográfica: Tienda vs. Talla
                </h3>
                <p className="text-xs text-zinc-500 mt-0.5 font-sans">
                  Distribución y densidad de unidades en cada tienda física de la red para el modelo {activeProduct.referencia}
                </p>
              </div>

              {/* Density Scale Legend */}
              <div className="flex items-center gap-2 text-[10px] font-mono bg-[#F8F7FC] px-3 py-1.5 rounded-lg border border-zinc-200">
                <span className="text-zinc-500 uppercase font-bold">DENSIDAD:</span>
                <span className="px-1.5 py-0.5 rounded bg-rose-50 border border-rose-200 text-rose-700 font-bold">
                  0-1 Quiebre
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold">
                  2-9 Óptimo
                </span>
                <span className="px-1.5 py-0.5 rounded bg-blue-50 border border-blue-200 text-blue-700 font-bold">
                  10+ Exceso
                </span>
              </div>
            </div>

            {/* Interactive Matrix Table */}
            <div className="overflow-x-auto rounded-xl border border-zinc-200/80 bg-white">
              <table className="w-full text-left text-xs text-zinc-700 border-collapse">
                <thead>
                  <tr className="bg-[#F4F2FD] text-[10px] font-mono text-zinc-500 uppercase tracking-wider border-b border-zinc-200">
                    <th className="py-2.5 px-4 font-bold tracking-wider sticky left-0 bg-[#F4F2FD] z-10 font-mono">
                      TIENDA / UBICACIÓN
                    </th>
                    {productSizes.map((s) => (
                      <th
                        key={s}
                        className={`py-2.5 px-3 text-center font-bold font-mono ${
                          s === activeProduct.criticalSize ? 'text-rose-700 bg-rose-50' : ''
                        }`}
                      >
                        {s}
                      </th>
                    ))}
                    <th className="py-2.5 px-4 text-right font-bold uppercase font-mono">
                      TOTAL
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200/60 font-mono">
                  {storeMatrixRows.map((row) => (
                    <tr key={row.storeName} className="hover:bg-[#F8F7FC] transition-colors">
                      <td className="py-2.5 px-4 font-sans font-medium text-zinc-900 sticky left-0 bg-white z-10 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span>{row.storeName}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#F4F2FD] text-zinc-600 border border-zinc-200">
                            {row.storeType}
                          </span>
                        </div>
                      </td>
                      {productSizes.map((s) => {
                        const count = row.sizes[s] || 0;
                        const isCriticalSize = s === activeProduct.criticalSize;
                        const cellClass = getCellDensityStyle(count, isCriticalSize);

                        return (
                          <td key={s} className="py-2 px-1 text-center">
                            <button
                              type="button"
                              onClick={() =>
                                setInspectedCell({
                                  store: row.storeName,
                                  size: s,
                                  stock: count,
                                })
                              }
                              className={`w-8 h-8 rounded-lg text-xs font-mono inline-flex items-center justify-center transition-all hover:scale-105 cursor-pointer ${cellClass}`}
                              title={`${row.storeName} - Talla ${s}: ${count} ${unitInfo.unitPlural}`}
                            >
                              {count}
                            </button>
                          </td>
                        );
                      })}
                      <td className="py-2.5 px-4 text-right font-bold text-zinc-900 font-mono">
                        {row.totalUnits} <span className="text-[10px] text-zinc-500 font-normal">{unitInfo.unitShort}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                {/* Totals Row */}
                <tfoot>
                  <tr className="bg-[#F4F2FD] font-bold border-t border-zinc-200 text-zinc-900">
                    <td className="py-2.5 px-4 uppercase text-[10px] tracking-wider sticky left-0 bg-[#F4F2FD] z-10 font-mono">
                      TOTAL RED COMPLETA
                    </td>
                    {productSizes.map((s) => (
                      <td
                        key={s}
                        className={`py-2.5 px-3 text-center font-mono ${
                          s === activeProduct.criticalSize ? 'text-rose-700' : 'text-zinc-800'
                        }`}
                      >
                        {activeProduct.sizeQuantities[s] || 0}
                      </td>
                    ))}
                    <td className="py-2.5 px-4 text-right font-mono text-zinc-900 font-bold">
                      {activeProduct.totalStock} <span className="text-[10px] text-zinc-500 font-normal">{unitInfo.unitShort}</span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW MODE 2: Multi-SKU Consolidated Matrix Pivot */}
      {viewMode === 'matrix' && (
        <div className="bg-white rounded-xl border border-zinc-200/80 p-4 sm:p-5 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2 font-sans">
                <Layers className="w-4 h-4 text-zinc-500" />
                Matriz Consolidada de Curvas de Talla (Multi-SKU)
              </h3>
              <p className="text-xs text-zinc-500 mt-0.5 font-sans">
                Vista de tabla dinámica pivotada por modelo y talla para todo el inventario
              </p>
            </div>

            {/* Matrix Filters */}
            <div className="flex items-center gap-2">
              <select
                value={matrixDept}
                onChange={(e) => setMatrixDept(e.target.value)}
                className="bg-[#F8F7FC] border border-zinc-200 text-xs text-zinc-800 rounded-lg px-3 py-1.5 focus:outline-none focus:border-zinc-400 cursor-pointer font-mono"
              >
                <option value="TODAS">Todos los Deptos</option>
                <option value="CALZADO">CALZADO</option>
                <option value="TEXTIL">TEXTIL</option>
                <option value="ACCESORIOS">ACCESORIOS</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-zinc-200/80 bg-white">
            <table className="w-full text-left text-xs text-zinc-700 border-collapse">
              <thead>
                <tr className="bg-[#F4F2FD] text-[10px] font-mono text-zinc-500 border-b border-zinc-200">
                  <th className="py-2.5 px-4 font-bold tracking-wider font-mono">REFERENCIA</th>
                  <th className="py-2.5 px-3 font-bold tracking-wider font-mono">MARCA</th>
                  <th className="py-2.5 px-3 font-bold tracking-wider font-mono">TIENDA</th>
                  {multiSkuSizes.map((s) => (
                    <th key={s} className="py-2.5 px-2 text-center font-bold font-mono">
                      {s}
                    </th>
                  ))}
                  <th className="py-2.5 px-4 text-right font-bold tracking-wider font-mono">TOTAL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200/60 font-mono">
                {multiSkuRows.slice(0, 50).map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#F8F7FC] transition-colors">
                    <td className="py-2 px-4 font-bold text-zinc-900">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedRef(row.Referencia);
                          setViewMode('stitch');
                        }}
                        className="text-zinc-900 hover:text-zinc-600 hover:underline font-bold cursor-pointer"
                      >
                        {row.Referencia}
                      </button>
                    </td>
                    <td className="py-2 px-3 text-zinc-600">{row.Marca}</td>
                    <td className="py-2 px-3 text-zinc-600">{row.Tienda}</td>
                    {multiSkuSizes.map((s) => {
                      const count = row.Tallas[s] || 0;
                      return (
                        <td
                          key={s}
                          className={`py-2 px-2 text-center font-mono ${
                            count === 0 ? 'text-zinc-300' : 'text-emerald-700 font-bold'
                          }`}
                        >
                          {count > 0 ? count : '-'}
                        </td>
                      );
                    })}
                    <td className="py-2 px-4 text-right font-bold text-zinc-900 font-mono">{row.Total}p</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: Búsqueda y Vinculación Directa de Fotos Reales */}
      {isImageUrlModalOpen && activeProduct && (
        <div className="fixed inset-0 z-50 bg-zinc-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-zinc-200 rounded-xl max-w-xl w-full p-5 sm:p-6 space-y-4 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-zinc-200">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-white shadow-xs">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-zinc-900 tracking-wide font-sans">
                    Vincular Foto del Producto
                  </h3>
                  <p className="text-[11px] text-zinc-500 font-mono">
                    {activeProduct.marca} • {activeProduct.referencia}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsImageUrlModalOpen(false)}
                className="text-zinc-400 hover:text-zinc-700 p-1 rounded-lg hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 overflow-y-auto pr-1 flex-1">
              {/* Automatic Web Query Action */}
              <div className="bg-[#F8F7FC] border border-zinc-200 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-800 flex items-center gap-1.5 font-sans">
                    <Sparkles className="w-3.5 h-3.5 text-zinc-500" />
                    Consulta Web Automática (Wikimedia / Catálogos)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleTriggerWebSearch()}
                    disabled={isSearchingWebImages}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-zinc-100 text-zinc-800 font-semibold text-xs border border-zinc-200 shadow-xs transition-all disabled:opacity-50 cursor-pointer font-mono"
                  >
                    {isSearchingWebImages ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-zinc-500" />
                        <span>Buscando...</span>
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 text-zinc-500" />
                        <span>Re-consultar</span>
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-zinc-500">
                  El sistema consulta repositorios públicos para sugerir la imagen de referencia.
                </p>

                {/* Results or Loading State */}
                {isSearchingWebImages && (
                  <div className="py-6 flex flex-col items-center justify-center gap-2 text-zinc-500">
                    <Loader2 className="w-6 h-6 animate-spin text-zinc-500" />
                    <span className="text-xs font-mono">Consultando imágenes para {activeProduct.referencia}...</span>
                  </div>
                )}

                {/* Web Search Error message */}
                {webSearchError && !isSearchingWebImages && (
                  <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-2.5 font-mono">
                    {webSearchError}
                  </p>
                )}

                {/* Web Search Photo Gallery */}
                {!isSearchingWebImages && webSearchResults.length > 0 && (
                  <div className="space-y-2 pt-1">
                    <span className="text-[11px] font-mono text-zinc-700 uppercase font-bold">
                      Selecciona una foto para vincularla a este SKU:
                    </span>
                    <div className="grid grid-cols-3 gap-2.5">
                      {webSearchResults.map((res, i) => {
                        const isCurrent = resolvedImageUrl === res.url;
                        return (
                          <div
                            key={i}
                            onClick={() => handleSelectWebImage(res.url)}
                            className={`group relative rounded-lg border p-2 cursor-pointer transition-all overflow-hidden flex flex-col items-center bg-white ${
                              isCurrent
                                ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/40'
                                : 'border-zinc-200 hover:border-zinc-300 hover:bg-[#F8F7FC]'
                            }`}
                          >
                            <img
                              src={res.url}
                              alt={res.title}
                              referrerPolicy="no-referrer"
                              className="w-full h-24 object-contain rounded-md transition-transform duration-200 group-hover:scale-105"
                            />
                            <div className="mt-1.5 w-full text-center">
                              <p className="text-[10px] text-zinc-800 font-medium truncate" title={res.title}>
                                {res.title}
                              </p>
                              <span className="text-[9px] text-zinc-500 font-mono block truncate">
                                {res.source}
                              </span>
                            </div>
                            {isCurrent && (
                              <div className="absolute top-1 right-1 bg-emerald-600 text-white p-0.5 rounded-full shadow-xs">
                                <Check className="w-3 h-3 stroke-[3]" />
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Manual URL Linker Option */}
              <div className="space-y-2 pt-1">
                <label className="text-xs font-semibold text-zinc-700 block font-sans">
                  O pega directamente la URL de la imagen:
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/... o enlace directo (.jpg, .png)"
                    value={tempImageUrl}
                    onChange={(e) => setTempImageUrl(e.target.value)}
                    className="flex-1 bg-white border border-zinc-200 rounded-lg px-3 py-2 text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleSaveManualImageUrl}
                    disabled={!tempImageUrl.trim()}
                    className="px-4 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-xs border border-zinc-900 shadow-xs disabled:opacity-40 transition-colors cursor-pointer font-mono"
                  >
                    Vincular
                  </button>
                </div>
              </div>
            </div>

            {/* Footer with External Search Shortcut */}
            <div className="pt-3 border-t border-zinc-200 flex items-center justify-between">
              <a
                href={googleImagesUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-zinc-600 hover:text-zinc-900 hover:underline flex items-center gap-1.5 font-sans"
              >
                <ExternalLink className="w-3.5 h-3.5 text-zinc-400" />
                <span>Explorar en Google Imágenes ({activeProduct.referencia})</span>
              </a>
              <button
                type="button"
                onClick={() => setIsImageUrlModalOpen(false)}
                className="px-4 py-1.5 rounded-lg bg-[#F8F7FC] hover:bg-zinc-100 text-xs text-zinc-700 font-medium border border-zinc-200 transition-colors cursor-pointer font-mono"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Rebalanceo / Transferencia para Déficit Crítico */}
      {isTransferModalOpen && criticalDeficitData && activeProduct && (
        <div className="fixed inset-0 z-50 bg-zinc-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-zinc-200 rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div
                className={`flex items-center gap-2 ${
                  criticalDeficitData.status === 'overstock'
                    ? 'text-blue-700'
                    : criticalDeficitData.status === 'low'
                    ? 'text-amber-700'
                    : 'text-rose-700'
                }`}
              >
                <Truck className="w-5 h-5" />
                <h3 className="text-sm font-bold text-zinc-900 font-sans">
                  {criticalDeficitData.status === 'overstock'
                    ? `Rebalanceo de Inventario por Exceso (${activeProduct.referencia})`
                    : criticalDeficitData.status === 'low'
                    ? `Rebalanceo / Reposición de Curva (${activeProduct.referencia})`
                    : `Orden de Traslado para Talla ${criticalDeficitData.size}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsTransferModalOpen(false)}
                className="text-zinc-400 hover:text-zinc-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-zinc-600 font-sans">
              Propuesta automática de rebalanceo para el modelo{' '}
              <strong className="text-zinc-900 font-mono">{activeProduct.referencia}</strong>:
            </p>

            {/* Transfer Route */}
            <div className="bg-[#F8F7FC] border border-zinc-200 rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-500 font-mono">Origen (Tienda con Exceso):</span>
                <strong className="text-emerald-700 font-mono font-bold">
                  {criticalDeficitData.excessStores[0]?.store || 'Almacén Central / Hub'}
                </strong>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-500 font-mono">Destino (Tienda con Quiebre):</span>
                <strong className="text-rose-700 font-mono font-bold">
                  {criticalDeficitData.deficientStores[0] || 'Tienda Flagship'}
                </strong>
              </div>
              <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-200">
                <span className="text-zinc-500 font-mono">Cantidad recomendada:</span>
                <strong className="text-zinc-900 font-mono font-bold">+8 {unitInfo.unitPlural}</strong>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsTransferModalOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-[#F8F7FC] hover:bg-zinc-100 border border-zinc-200 text-xs text-zinc-700 font-semibold cursor-pointer font-mono"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsTransferModalOpen(false);
                  setTransferSuccessNotice(
                    `Orden generada: 8 ${unitInfo.unitPlural} de la talla ${criticalDeficitData.size} despachados.`
                  );
                  setTimeout(() => setTransferSuccessNotice(null), 4000);
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-xs cursor-pointer font-mono"
              >
                Confirmar y Despachar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inspected Cell Toast / Inspector */}
      {inspectedCell && (
        <div className="fixed bottom-6 right-6 z-40 bg-white border border-zinc-200 rounded-xl p-4 shadow-xl text-xs space-y-1 max-w-xs animate-in fade-in slide-in-from-bottom-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-zinc-900 font-sans">{inspectedCell.store}</span>
            <button
              type="button"
              onClick={() => setInspectedCell(null)}
              className="text-zinc-400 hover:text-zinc-700 ml-2 cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <p className="text-zinc-700 font-sans">
            Talla <strong className="text-zinc-900 font-mono">{inspectedCell.size}</strong>: {inspectedCell.stock} {unitInfo.unitPlural} en stock
          </p>
          <p className="text-[11px] text-zinc-500 font-mono">
            {inspectedCell.stock <= 1
              ? '⚠️ Estado: Quiebre de talla comercial'
              : inspectedCell.stock >= 10
              ? '📦 Estado: Acumulación alta / Sobrestock'
              : '✅ Estado: Nivel de profundidad óptimo'}
          </p>
        </div>
      )}

      {/* Transfer success toast */}
      {transferSuccessNotice && (
        <div className="fixed bottom-6 left-6 z-40 bg-white border border-emerald-300 rounded-xl p-3 shadow-xl text-xs text-emerald-800 flex items-center gap-2 font-mono">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{transferSuccessNotice}</span>
        </div>
      )}
    </div>
  );
};
