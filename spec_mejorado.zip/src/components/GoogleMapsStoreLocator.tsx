import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  useMapsLibrary,
  useMap,
} from '@vis.gl/react-google-maps';
import {
  Search,
  MapPin,
  Building2,
  Navigation,
  Check,
  RotateCcw,
  Truck,
  Sparkles,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  ChevronDown,
  Store,
  Compass,
} from 'lucide-react';
import {
  parseGooglePlaceDetails,
  ExtractedPlaceDetails,
  calculateGeoDistanceKm,
} from '../utils/geoDistance';
import { StoreProfile } from '../types';
import { calcularCostoFlete } from '../utils/analysisEngine';

// La clave se lee solo desde VITE_GOOGLE_MAPS_API_KEY (nunca hardcodeada en el código).
// Restríngela por HTTP referrer y por API (Maps JS, Places, Geocoding) en Google Cloud Console.
const GOOGLE_MAPS_API_KEY: string = (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY || '';

export interface GoogleMapsStoreLocatorProps {
  initialLat?: number;
  initialLng?: number;
  initialAddress?: string;
  initialCity?: string;
  initialRegion?: string;
  initialMall?: string;
  initialLocation?: {
    lat?: number;
    lng?: number;
    ciudad?: string;
    region?: string;
    direccion?: string;
    centroComercial?: string;
    formattedAddress?: string;
    placeId?: string;
  };
  existingStores?: StoreProfile[];
  selectedStoreName?: string;
  onSelectStoreToGeolocate?: (storeName: string) => void;
  onApplyLocation?: (data: ExtractedPlaceDetails) => void;
  onLocationSelected?: (data: ExtractedPlaceDetails) => void;
}

// Inner component with access to Google Maps JS instances
const MapContent: React.FC<{
  currentPos: { lat: number; lng: number };
  onPosChange: (pos: { lat: number; lng: number }) => void;
  onPlaceSelected: (details: ExtractedPlaceDetails) => void;
  existingStores?: StoreProfile[];
}> = ({ currentPos, onPosChange, onPlaceSelected, existingStores = [] }) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');
  const geocodingLib = useMapsLibrary('geocoding');

  const inputRef = useRef<HTMLInputElement | null>(null);
  const autocompleteRef = useRef<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchFeedback, setSearchFeedback] = useState<string | null>(null);
  const sessionTokenRef = useRef<any>(null);

  // Initialize Places Autocomplete directly on inputRef
  useEffect(() => {
    if (!placesLib?.Autocomplete || !inputRef.current) return;

    try {
      const autocomplete = new placesLib.Autocomplete(inputRef.current, {
        fields: [
          'address_components',
          'formatted_address',
          'geometry',
          'name',
          'place_id',
          'types',
        ],
      });
      autocompleteRef.current = autocomplete;

      const listener = autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (!place) return;

        let lat = 0;
        let lng = 0;
        const geomLoc = place.geometry?.location;
        const anyPlace = place as any;
        if (geomLoc) {
          lat = typeof geomLoc.lat === 'function' ? geomLoc.lat() : Number(geomLoc.lat);
          lng = typeof geomLoc.lng === 'function' ? geomLoc.lng() : Number(geomLoc.lng);
        } else if (anyPlace.location) {
          lat = typeof anyPlace.location.lat === 'function' ? anyPlace.location.lat() : Number(anyPlace.location.lat);
          lng = typeof anyPlace.location.lng === 'function' ? anyPlace.location.lng() : Number(anyPlace.location.lng);
        }

        if (lat && lng) {
          const newPos = { lat, lng };
          onPosChange(newPos);
          if (map) {
            map.panTo(newPos);
            map.setZoom(16);
          }

          const parsed = parseGooglePlaceDetails({
            ...place,
            location: { lat: () => lat, lng: () => lng },
          });

          if (parsed) {
            onPlaceSelected(parsed);
            setSearchQuery(parsed.formattedAddress || parsed.direccion);
            setShowDropdown(false);
            setSearchFeedback(`Ubicación seleccionada: ${parsed.centroComercial || parsed.ciudad}`);
            setTimeout(() => setSearchFeedback(null), 4000);
          }
        }
      });

      return () => {
        if (listener && window.google?.maps?.event?.removeListener) {
          google.maps.event.removeListener(listener);
        }
      };
    } catch (err) {
      console.warn('Google Places Autocomplete instantiation notice:', err);
    }
  }, [placesLib, map, onPosChange, onPlaceSelected]);

  // Initialize or reset session token for Places API
  useEffect(() => {
    if (placesLib?.AutocompleteSessionToken && !sessionTokenRef.current) {
      sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
    }
  }, [placesLib]);

  // Autocomplete suggestions as user types
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 2 || !placesLib) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setIsSearching(true);
        if (placesLib.AutocompleteSuggestion) {
          const request = {
            input: searchQuery,
            sessionToken: sessionTokenRef.current,
          };
          const res = await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions(request);
          if (res?.suggestions && res.suggestions.length > 0) {
            setSuggestions(res.suggestions);
            setShowDropdown(true);
          }
        } else if (placesLib.AutocompleteService) {
          const service = new placesLib.AutocompleteService();
          service.getPlacePredictions(
            {
              input: searchQuery,
              sessionToken: sessionTokenRef.current,
            },
            (predictions, status) => {
              if (status === google.maps.places.PlacesServiceStatus.OK && predictions) {
                setSuggestions(predictions);
                setShowDropdown(true);
              }
            }
          );
        }
      } catch (err) {
        console.warn('Autocomplete fetch note:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery, placesLib]);

  // Robust Direct Search (via Enter key or Search button)
  const handleDirectSearch = useCallback(
    (queryToSearch?: string) => {
      const q = (queryToSearch || searchQuery).trim();
      if (!q) return;

      setIsSearching(true);
      setShowDropdown(false);
      setSearchFeedback(null);

      // 1. Try Geocoder first (most reliable for addresses, malls, cities, POIs)
      if (geocodingLib?.Geocoder) {
        const geocoder = new geocodingLib.Geocoder();
        geocoder.geocode({ address: q }, (results, status) => {
          setIsSearching(false);
          if (status === 'OK' && results && results.length > 0) {
            const first = results[0];
            const lat = first.geometry.location.lat();
            const lng = first.geometry.location.lng();
            const newPos = { lat, lng };

            onPosChange(newPos);
            if (map) {
              map.panTo(newPos);
              map.setZoom(16);
            }

            const parsed = parseGooglePlaceDetails({
              ...first,
              location: { lat: () => lat, lng: () => lng },
            });

            if (parsed) {
              onPlaceSelected(parsed);
              setSearchFeedback(`Ubicación localizada: ${parsed.centroComercial || parsed.ciudad}`);
              setTimeout(() => setSearchFeedback(null), 4000);
            }
            return;
          }

          // Fallback: If geocoder failed, try PlacesService findPlaceFromQuery
          if (placesLib?.PlacesService && map) {
            const service = new placesLib.PlacesService(map);
            service.findPlaceFromQuery(
              {
                query: q,
                fields: ['name', 'geometry', 'formatted_address', 'place_id', 'types'],
              },
              (pResults, pStatus) => {
                if (pStatus === google.maps.places.PlacesServiceStatus.OK && pResults && pResults[0]) {
                  const place = pResults[0];
                  if (place.geometry?.location) {
                    const lat = place.geometry.location.lat();
                    const lng = place.geometry.location.lng();
                    const newPos = { lat, lng };

                    onPosChange(newPos);
                    map.panTo(newPos);
                    map.setZoom(16);

                    const parsed = parseGooglePlaceDetails({
                      ...place,
                      location: { lat: () => lat, lng: () => lng },
                    });
                    if (parsed) {
                      onPlaceSelected(parsed);
                      setSearchFeedback(`Lugar encontrado: ${parsed.centroComercial || parsed.direccion}`);
                      setTimeout(() => setSearchFeedback(null), 4000);
                    }
                  }
                } else {
                  setSearchFeedback('No se encontró el lugar. Puedes hacer clic en el mapa para marcarlo.');
                  setTimeout(() => setSearchFeedback(null), 4000);
                }
              }
            );
          } else {
            setSearchFeedback('No se encontró el lugar. Puedes hacer clic en el mapa para marcarlo.');
            setTimeout(() => setSearchFeedback(null), 4000);
          }
        });
      } else {
        setIsSearching(false);
      }
    },
    [searchQuery, geocodingLib, placesLib, map, onPosChange, onPlaceSelected]
  );

  // Handle selection from autocomplete dropdown
  const handleSelectSuggestion = async (suggestion: any) => {
    setShowDropdown(false);
    const label =
      suggestion.placePrediction?.text?.toString() ||
      suggestion.description ||
      suggestion.text ||
      '';
    setSearchQuery(label);

    try {
      if (suggestion.fetchPlace) {
        const place = await suggestion.fetchPlace();
        await place.fetchFields({
          fields: [
            'displayName',
            'formattedAddress',
            'addressComponents',
            'location',
            'types',
            'id',
          ],
        });

        const parsed = parseGooglePlaceDetails(place);
        if (parsed) {
          onPosChange({ lat: parsed.lat, lng: parsed.lng });
          onPlaceSelected(parsed);
          if (map) {
            map.panTo({ lat: parsed.lat, lng: parsed.lng });
            map.setZoom(16);
          }
          setSearchFeedback(`Seleccionado: ${parsed.centroComercial || parsed.ciudad}`);
          setTimeout(() => setSearchFeedback(null), 3000);
        }
      } else if (suggestion.place_id && placesLib) {
        const dummyDiv = document.createElement('div');
        const service = new placesLib.PlacesService(dummyDiv);
        service.getDetails(
          {
            placeId: suggestion.place_id,
            fields: ['name', 'formatted_address', 'address_components', 'geometry', 'types', 'place_id'],
            sessionToken: sessionTokenRef.current,
          },
          (place, status) => {
            if (status === google.maps.places.PlacesServiceStatus.OK && place?.geometry?.location) {
              const lat = place.geometry.location.lat();
              const lng = place.geometry.location.lng();
              const parsed = parseGooglePlaceDetails({
                ...place,
                location: { lat: () => lat, lng: () => lng },
              });
              if (parsed) {
                onPosChange({ lat, lng });
                onPlaceSelected(parsed);
                if (map) {
                  map.panTo({ lat, lng });
                  map.setZoom(16);
                }
                setSearchFeedback(`Seleccionado: ${parsed.centroComercial || parsed.ciudad}`);
                setTimeout(() => setSearchFeedback(null), 3000);
              }
            }
          }
        );
      } else {
        // Fallback to direct search with the text
        handleDirectSearch(label);
      }

      if (placesLib?.AutocompleteSessionToken) {
        sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
      }
    } catch (err) {
      console.error('Error fetching place details, fallback to direct search:', err);
      handleDirectSearch(label);
    }
  };

  // Reverse geocode when dragging marker
  const handleMarkerDragEnd = useCallback(
    (e: google.maps.MapMouseEvent) => {
      if (!e.latLng) return;
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();
      onPosChange({ lat, lng });

      if (geocodingLib?.Geocoder) {
        const geocoder = new geocodingLib.Geocoder();
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
          if (status === 'OK' && results && results[0]) {
            const parsed = parseGooglePlaceDetails({
              ...results[0],
              location: { lat: () => lat, lng: () => lng },
            });
            if (parsed) {
              onPlaceSelected(parsed);
              setSearchFeedback(`Punto fijado: ${parsed.ciudad} (${parsed.direccion.slice(0, 35)}...)`);
              setTimeout(() => setSearchFeedback(null), 3500);
            }
          }
        });
      }
    },
    [geocodingLib, onPosChange, onPlaceSelected]
  );

  // Reverse geocode when clicking anywhere on the map
  const handleMapClick = useCallback(
    (e: any) => {
      if (!e.detail?.latLng) return;
      const lat = e.detail.latLng.lat;
      const lng = e.detail.latLng.lng;
      const newPos = { lat, lng };

      onPosChange(newPos);
      if (map) {
        map.panTo(newPos);
      }

      if (geocodingLib?.Geocoder) {
        const geocoder = new geocodingLib.Geocoder();
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
          if (status === 'OK' && results && results[0]) {
            const parsed = parseGooglePlaceDetails({
              ...results[0],
              location: { lat: () => lat, lng: () => lng },
            });
            if (parsed) {
              onPlaceSelected(parsed);
              setSearchFeedback(`Marcado en mapa: ${parsed.centroComercial || parsed.ciudad}`);
              setTimeout(() => setSearchFeedback(null), 3500);
            }
          }
        });
      }
    },
    [geocodingLib, map, onPosChange, onPlaceSelected]
  );

  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Top Floating Search & Action Bar */}
      <div className="absolute top-3 left-3 right-3 z-20">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleDirectSearch();
          }}
          className="relative bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-zinc-200/90 overflow-hidden"
        >
          <div className="flex items-center px-3 py-2 gap-2">
            <Search className="w-4 h-4 text-zinc-400 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleDirectSearch();
                }
              }}
              onFocus={() => {
                if (suggestions.length > 0) setShowDropdown(true);
              }}
              placeholder="Buscar dirección, Centro Comercial, Mall o Ciudad (Places Autocomplete)..."
              className="w-full bg-transparent text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none font-medium"
            />
            {isSearching && (
              <div className="w-4 h-4 border-2 border-zinc-300 border-t-zinc-700 rounded-full animate-spin shrink-0" />
            )}
            {searchQuery && !isSearching && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSuggestions([]);
                  setShowDropdown(false);
                }}
                className="text-zinc-400 hover:text-zinc-700 p-0.5 cursor-pointer"
                title="Limpiar búsqueda"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              type="submit"
              disabled={!searchQuery.trim() || isSearching}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 text-white rounded-lg text-[11px] font-semibold tracking-tight transition-colors shrink-0 cursor-pointer shadow-xs"
            >
              <span>Buscar</span>
            </button>
          </div>

          {/* Search Feedback / Notification Pill */}
          {searchFeedback && (
            <div className="px-3 py-1.5 bg-emerald-50 border-t border-emerald-100 text-[11px] text-emerald-800 flex items-center gap-1.5 font-medium">
              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">{searchFeedback}</span>
            </div>
          )}

          {/* Autocomplete Suggestions Dropdown */}
          {showDropdown && suggestions.length > 0 && (
            <div className="border-t border-zinc-100 max-h-56 overflow-y-auto divide-y divide-zinc-50 bg-white shadow-xl">
              {suggestions.map((item, idx) => {
                const primaryText =
                  item.placePrediction?.mainText?.toString() ||
                  item.structured_formatting?.main_text ||
                  item.text?.toString() ||
                  item.description ||
                  'Lugar';
                const secondaryText =
                  item.placePrediction?.secondaryText?.toString() ||
                  item.structured_formatting?.secondary_text ||
                  '';

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectSuggestion(item)}
                    className="w-full text-left px-3 py-2.5 hover:bg-zinc-50 flex items-start gap-2.5 transition-colors cursor-pointer"
                  >
                    <MapPin className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-zinc-900 truncate">
                        {primaryText}
                      </p>
                      {secondaryText && (
                        <p className="text-[10px] text-zinc-500 truncate">
                          {secondaryText}
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </form>
      </div>

      {/* Google Map View: Free Panning & Zooming (NO controlled center prop) */}
      <div className="flex-1 w-full min-h-[320px] rounded-xl overflow-hidden border border-zinc-200 relative">
        <Map
          defaultCenter={currentPos}
          defaultZoom={14}
          mapId="49ae42fed52588c3"
          gestureHandling="greedy"
          disableDefaultUI={false}
          className="w-full h-full cursor-crosshair"
          onClick={handleMapClick}
        >
          {/* Main Pin for the Store being registered/geolocated */}
          <AdvancedMarker
            position={currentPos}
            draggable={true}
            onDragEnd={handleMarkerDragEnd}
            title="Arrastra este pin o haz clic en cualquier lugar para ubicar la tienda"
          >
            <Pin
              background="#0f172a"
              borderColor="#ffffff"
              glyphColor="#ffffff"
              scale={1.25}
            />
          </AdvancedMarker>

          {/* Existing network stores markers */}
          {existingStores.map((st) => {
            if (typeof st.lat !== 'number' || typeof st.lng !== 'number') return null;
            return (
              <AdvancedMarker
                key={st.id || st.nombre}
                position={{ lat: st.lat, lng: st.lng }}
                title={`🏬 ${st.nombre} - ${st.ciudad} (${st.centroComercial || 'Independiente'})`}
              >
                <Pin
                  background="#4338ca"
                  borderColor="#ffffff"
                  glyphColor="#ffffff"
                  scale={0.9}
                />
              </AdvancedMarker>
            );
          })}
        </Map>

        {/* Quick Instructions Badge */}
        <div className="absolute bottom-2.5 left-2.5 z-10 pointer-events-none">
          <span className="bg-zinc-900/80 backdrop-blur-md text-white text-[10px] font-medium px-2.5 py-1 rounded-md shadow-md flex items-center gap-1.5">
            <Compass className="w-3 h-3 text-emerald-400" />
            Haz clic en el mapa o arrastra el marcador negro para ajustar la posición
          </span>
        </div>
      </div>
    </div>
  );
};

export const GoogleMapsStoreLocator: React.FC<GoogleMapsStoreLocatorProps> = ({
  initialLat,
  initialLng,
  initialAddress = '',
  initialCity = '',
  initialRegion = '',
  initialMall = '',
  initialLocation,
  existingStores = [],
  selectedStoreName,
  onSelectStoreToGeolocate,
  onApplyLocation,
  onLocationSelected,
}) => {
  // Resolve initial coordinates from either initialLocation or individual props
  const resolvedLat = initialLocation?.lat ?? initialLat ?? 10.4806;
  const resolvedLng = initialLocation?.lng ?? initialLng ?? -66.9036;
  const resolvedCity = initialLocation?.ciudad ?? initialCity ?? 'Caracas';
  const resolvedRegion = initialLocation?.region ?? initialRegion ?? '';
  const resolvedAddress = initialLocation?.direccion ?? initialAddress ?? '';
  const resolvedMall = initialLocation?.centroComercial ?? initialMall ?? '';
  const resolvedPlaceId = initialLocation?.placeId ?? '';

  const [pos, setPos] = useState({ lat: resolvedLat, lng: resolvedLng });
  const [detectedDetails, setDetectedDetails] = useState<ExtractedPlaceDetails>({
    lat: resolvedLat,
    lng: resolvedLng,
    ciudad: resolvedCity,
    region: resolvedRegion || undefined,
    direccion: resolvedAddress,
    formattedAddress: resolvedAddress,
    centroComercial: resolvedMall || undefined,
    placeId: resolvedPlaceId,
  });

  const [isApplied, setIsApplied] = useState(false);

  // Sync if initialLocation updates externally
  useEffect(() => {
    if (initialLocation?.lat && initialLocation?.lng) {
      setPos({ lat: initialLocation.lat, lng: initialLocation.lng });
      setDetectedDetails({
        lat: initialLocation.lat,
        lng: initialLocation.lng,
        ciudad: initialLocation.ciudad || 'Caracas',
        region: initialLocation.region || undefined,
        direccion: initialLocation.direccion || '',
        formattedAddress: initialLocation.formattedAddress || initialLocation.direccion || '',
        centroComercial: initialLocation.centroComercial || undefined,
        placeId: initialLocation.placeId || '',
      });
    }
  }, [initialLocation]);

  // When place is selected from Autocomplete, direct search, or map click
  const handlePlaceSelected = useCallback(
    (details: ExtractedPlaceDetails) => {
      setDetectedDetails(details);
      setIsApplied(false);
      // Auto-notify parent immediately so no information is lost
      if (onLocationSelected) {
        onLocationSelected(details);
      }
    },
    [onLocationSelected]
  );

  // Calculated distance with other network stores
  const storeDistancesPreview = existingStores
    .filter((st) => typeof st.lat === 'number' && typeof st.lng === 'number')
    .map((st) => {
      const km = calculateGeoDistanceKm(pos.lat, pos.lng, st.lat!, st.lng!);
      const estimatedCost = calcularCostoFlete(km, 20); // sample 20 units
      return {
        storeName: st.nombre,
        city: st.ciudad,
        km,
        estimatedCost,
      };
    })
    .sort((a, b) => a.km - b.km);

  // Apply location handler (explicit button click)
  const handleApply = () => {
    const fullPayload: ExtractedPlaceDetails = {
      ...detectedDetails,
      lat: pos.lat,
      lng: pos.lng,
    };

    if (onApplyLocation) {
      onApplyLocation(fullPayload);
    }
    if (onLocationSelected) {
      onLocationSelected(fullPayload);
    }

    setIsApplied(true);
    setTimeout(() => setIsApplied(false), 3000);
  };

  return (
    <div className="bg-zinc-50 border border-zinc-200/90 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xs">
      {/* Header with Google Maps Branding & Store Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-zinc-200/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-600 shrink-0">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-zinc-900 tracking-tight">
                Geolocalización & Dirección en Google Maps
              </h4>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Google Maps Conectado
              </span>
            </div>
            <p className="text-xs text-zinc-500 mt-0.5">
              Identifica automáticamente Centro Comercial, Ciudad y coordenadas exactas para calcular distancias y flete.
            </p>
          </div>
        </div>

        {/* Store Assignment Dropdown & Action Button */}
        <div className="flex items-center gap-2.5 shrink-0 flex-wrap sm:flex-nowrap">
          {existingStores.length > 0 && onSelectStoreToGeolocate && (
            <div className="relative inline-flex items-center shrink-0">
              <div className="absolute left-2.5 pointer-events-none text-zinc-400 flex items-center">
                <Store className="w-3.5 h-3.5" />
              </div>
              <select
                value={selectedStoreName || ''}
                onChange={(e) => onSelectStoreToGeolocate(e.target.value)}
                className="h-9 pl-8 pr-7 bg-white border border-zinc-300 hover:border-zinc-400 rounded-xl text-xs font-semibold text-zinc-800 shadow-xs focus:outline-none focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-400 cursor-pointer transition-colors max-w-[200px] sm:max-w-[240px] truncate appearance-none"
                title="Selecciona la tienda que deseas geolocalizar"
              >
                <option value="">🏬 Nueva Tienda</option>
                {existingStores.map((st) => (
                  <option key={st.id || st.nombre} value={st.nombre}>
                    🏬 {st.nombre} ({st.ciudad})
                  </option>
                ))}
              </select>
              <div className="absolute right-2 pointer-events-none text-zinc-400 flex items-center">
                <ChevronDown className="w-3.5 h-3.5" />
              </div>
            </div>
          )}

          <button
            type="button"
            onClick={handleApply}
            className={`inline-flex items-center justify-center gap-2 h-9 px-4 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 shadow-xs transition-all cursor-pointer select-none active:scale-[0.98] ${
              isApplied
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600'
                : 'bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-900'
            }`}
            title="Asignar la ubicación seleccionada a los datos de la tienda"
          >
            {isApplied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-100 shrink-0" />
                <span className="whitespace-nowrap font-bold">Ubicación Asignada</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="whitespace-nowrap font-bold">Asignar Ubicación</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Map & Search Container */}
      <div className="h-80 w-full rounded-xl overflow-hidden relative shadow-inner">
        {GOOGLE_MAPS_API_KEY ? (
          <APIProvider apiKey={GOOGLE_MAPS_API_KEY} libraries={['places', 'marker', 'geocoding']}>
            <MapContent
              currentPos={pos}
              onPosChange={setPos}
              onPlaceSelected={handlePlaceSelected}
              existingStores={existingStores}
            />
          </APIProvider>
        ) : (
          <div className="h-full w-full flex flex-col items-center justify-center gap-1 bg-zinc-50 text-center px-6">
            <span className="text-sm font-bold text-zinc-700">Mapa no disponible</span>
            <span className="text-xs text-zinc-500">
              Falta configurar VITE_GOOGLE_MAPS_API_KEY en el archivo .env.local (ver .env.example).
            </span>
          </div>
        )}
      </div>

      {/* Extracted Metadata Grid (Zero Manual Typing - Autopopulates City, Region, Coordinates) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Ciudad Oficial */}
        <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
              <Navigation className="w-3 h-3 text-blue-600" />
              Ciudad Oficial
            </span>
            <span className="text-[9px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
              Auto-rellenado
            </span>
          </div>
          <p className="text-xs font-bold text-zinc-900 mt-1 truncate">
            {detectedDetails.ciudad || 'Por determinar'}
          </p>
          <span className="text-[10px] text-zinc-400 block mt-0.5">
            Localidad administrativa
          </span>
        </div>

        {/* Región / Estado / Provincia */}
        <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
              <Compass className="w-3 h-3 text-indigo-600" />
              Región / Estado
            </span>
            <span className="text-[9px] font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200">
              Auto-rellenado
            </span>
          </div>
          <p className="text-xs font-bold text-zinc-900 mt-1 truncate">
            {detectedDetails.region || detectedDetails.ciudad || 'Por determinar'}
          </p>
          <span className="text-[10px] text-zinc-400 block mt-0.5">
            Área nivel 1 / Estado
          </span>
        </div>

        {/* Coordenadas GPS */}
        <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
              <MapPin className="w-3 h-3 text-emerald-600" />
              Coordenadas GPS
            </span>
            <span className="text-[9px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 font-mono">
              Alta Precisión
            </span>
          </div>
          <p className="text-xs font-bold text-zinc-900 mt-1 font-mono">
            {pos.lat.toFixed(5)}, {pos.lng.toFixed(5)}
          </p>
          <span className="text-[10px] text-zinc-400 block mt-0.5">
            Ajustable con marcador
          </span>
        </div>

        {/* Mall / Centro Comercial */}
        <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
              <Building2 className="w-3 h-3 text-purple-600" />
              Centro Comercial / Mall
            </span>
            {detectedDetails.centroComercial ? (
              <span className="text-[9px] font-semibold text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded border border-purple-200">
                Detectado
              </span>
            ) : (
              <span className="text-[9px] font-medium text-zinc-400">
                A pie de calle
              </span>
            )}
          </div>
          <p className="text-xs font-bold text-zinc-900 mt-1 truncate">
            {detectedDetails.centroComercial || 'A pie de calle / Independiente'}
          </p>
          <span className="text-[10px] text-zinc-400 block mt-0.5">
            {detectedDetails.centroComercial ? 'Complejo comercial' : 'Ubicación exterior'}
          </span>
        </div>
      </div>

      {/* Full Normalized Address Display */}
      <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="min-w-0">
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
            <MapPin className="w-3 h-3 text-zinc-500" />
            Dirección Completa Normalizada (Google Places)
          </span>
          <p className="text-xs font-medium text-zinc-800 mt-0.5 truncate">
            {detectedDetails.direccion || detectedDetails.formattedAddress || 'Selecciona una dirección en el buscador superior'}
          </p>
        </div>
        {detectedDetails.placeId && (
          <span className="text-[10px] text-zinc-400 font-mono shrink-0 bg-zinc-100 px-2 py-0.5 rounded">
            ID: {detectedDetails.placeId.slice(0, 14)}...
          </span>
        )}
      </div>

      {/* Network Distances & Rebalancing Cost Impact */}
      {storeDistancesPreview.length > 0 && (
        <div className="bg-white p-3 rounded-xl border border-zinc-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-zinc-600" />
              Distancias GPS Reales & Costo Estimado de Rebalanceo con la Red
            </span>
            <span className="text-[10px] font-semibold text-zinc-600 font-mono">
              {storeDistancesPreview.length} tienda(s) conectadas
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-1">
            {storeDistancesPreview.slice(0, 3).map((st, idx) => (
              <div
                key={idx}
                className="bg-zinc-50 p-2.5 rounded-lg border border-zinc-200 text-xs flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-zinc-800 block truncate">
                    {st.storeName}
                  </span>
                  <span className="text-[10px] text-zinc-500">
                    {st.city}
                  </span>
                </div>
                <div className="text-right pl-2 shrink-0">
                  <span className="font-mono font-bold text-emerald-700 text-[11px] block">
                    {st.km} km
                  </span>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    Flete est: ${st.estimatedCost.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
