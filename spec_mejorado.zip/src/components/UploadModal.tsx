import React, { useRef, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Building2,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Database,
  Eye,
  FileSpreadsheet,
  FileType,
  Filter,
  Layers,
  Loader2,
  Plus,
  RefreshCw,
  Sliders,
  Sparkles,
  Store,
  Tag,
  Trash2,
  Upload,
  Download,
  X,
} from 'lucide-react';
import { downloadOfficialSpecTemplate } from '../utils/specTemplateGenerator';
import { fetchOfficialBcvRate, getStoredBcvRate } from '../utils/bcvService';
import { CapacityMatrixConfig, InventoryItem, StoreProfile, StoreType } from '../types';
import {
  DEFAULT_CAPACITY_MATRIX,
  STORE_FORMAT_INFO,
  createBaseBrandMatrix,
} from '../data/defaultMatrix';
import {
  ColumnMappingConfig,
  ParsedFileResult,
  parseInventoryFile,
} from '../utils/fileParser';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingStores: string[];
  storeProfiles: StoreProfile[];
  onDataLoaded: (
    items: InventoryItem[],
    filenames: string[],
    newStoreProfiles: StoreProfile[],
    newStoreCapacities: Record<string, CapacityMatrixConfig>,
    replaceExisting: boolean,
    bcvRateUsed?: number
  ) => void;
  bcvRate?: number;
  onUpdateBcvRate?: (newRate: number) => void;
}

interface StagedFileEntry {
  file: File;
  parsed: ParsedFileResult;
  assignedStore: string;
  isNewStore: boolean;
  storeType: StoreType;
  surfaceM2: number;
  customMapping: ColumnMappingConfig;
  showColumnMapping: boolean;
  showPreviewTable: boolean;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  existingStores = [],
  storeProfiles = [],
  onDataLoaded,
  bcvRate: propBcvRate,
  onUpdateBcvRate,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [replaceExisting, setReplaceExisting] = useState(true);

  // BCV Exchange Rate State
  const [currentBcvRate, setCurrentBcvRate] = useState<number>(() => propBcvRate || getStoredBcvRate().rate);
  const [isFetchingBcv, setIsFetchingBcv] = useState(false);
  const [bcvFetchNotice, setBcvFetchNotice] = useState<string | null>(null);

  // Automatically check/update official BCV rate on modal open
  React.useEffect(() => {
    if (isOpen) {
      let isMounted = true;
      setIsFetchingBcv(true);
      fetchOfficialBcvRate()
        .then((data) => {
          if (isMounted && data.rate > 0) {
            setCurrentBcvRate(data.rate);
            if (onUpdateBcvRate) onUpdateBcvRate(data.rate);
            setBcvFetchNotice(`Tasa oficial BCV actualizada: ${data.rate} Bs./USD`);
            setTimeout(() => {
              if (isMounted) setBcvFetchNotice(null);
            }, 4000);
          }
        })
        .catch(() => {})
        .finally(() => {
          if (isMounted) setIsFetchingBcv(false);
        });
      return () => {
        isMounted = false;
      };
    }
  }, [isOpen]);

  // Staged files waiting for confirmation
  const [stagedFiles, setStagedFiles] = useState<StagedFileEntry[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleManualBcvRateChange = (newRate: number) => {
    if (!newRate || newRate <= 0) return;
    setCurrentBcvRate(newRate);
    if (onUpdateBcvRate) onUpdateBcvRate(newRate);

    // Recalculate staged files with new rate
    setStagedFiles((prev) =>
      prev.map((entry) => {
        const updatedItems = entry.parsed.items.map((it) => {
          const valBs = it.ValoracionBs !== undefined ? it.ValoracionBs : it.Valoracion * currentBcvRate;
          const valUSD = Math.round((valBs / newRate) * 100) / 100;
          const unitValUSD = it.Stock > 0 ? Math.round((valUSD / it.Stock) * 100) / 100 : 0;
          return {
            ...it,
            Valoracion: valUSD,
            ValorUnitario: unitValUSD,
            ValoracionBs: valBs,
          };
        });
        const totalValuation = updatedItems.reduce((acc, it) => acc + it.Valoracion, 0);
        return {
          ...entry,
          parsed: {
            ...entry.parsed,
            items: updatedItems,
            totalValuation,
            bcvRateUsed: newRate,
          },
        };
      })
    );
  };

  const handleRefreshBcvRate = async () => {
    setIsFetchingBcv(true);
    try {
      const data = await fetchOfficialBcvRate();
      handleManualBcvRateChange(data.rate);
      setBcvFetchNotice(`Tasa sincronizada con BCV: ${data.rate} Bs./USD`);
      setTimeout(() => setBcvFetchNotice(null), 4000);
    } catch {
      setBcvFetchNotice('No se pudo conectar con el BCV. Ajusta la tasa manualmente.');
      setTimeout(() => setBcvFetchNotice(null), 4000);
    } finally {
      setIsFetchingBcv(false);
    }
  };

  const handleFiles = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    setIsProcessing(true);
    setErrorMsg(null);

    const newStaged: StagedFileEntry[] = [...stagedFiles];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.name.match(/\.(xlsx|xls|csv)$/i)) {
          throw new Error(`El archivo "${file.name}" no tiene extensión válida (.xlsx, .xls o .csv)`);
        }

        // Avoid adding duplicate file
        if (newStaged.some((st) => st.file.name === file.name)) {
          continue;
        }

        const res = await parseInventoryFile(file, undefined, existingStores, undefined, currentBcvRate);

        if (res.items.length === 0) {
          throw new Error(`El archivo "${file.name}" no contiene filas de inventario válidas.`);
        }

        const detectedName = res.detectedStore.detectedStoreName;
        const isAlreadyRegistered = existingStores.some(
          (s) => s.toLowerCase() === detectedName.toLowerCase()
        );

        let initialType: StoreType = 'LIVE';
        let initialM2 = 520;
        const lowerName = detectedName.toLowerCase();
        if (lowerName.includes('flagship') || lowerName.includes('rise')) {
          initialType = 'FLAGSHIP';
          initialM2 = 850;
        } else if (lowerName.includes('outlet') || lowerName.includes('unite')) {
          initialType = 'UNITE';
          initialM2 = 680;
        } else if (lowerName.includes('express') || lowerName.includes('compact') || lowerName.includes('airport')) {
          initialType = 'EXPRESS';
          initialM2 = 250;
        }

        const isCriticalMissing = !res.appliedMapping.Referencia || !res.appliedMapping.Talla || !res.appliedMapping.Stock;

        newStaged.push({
          file,
          parsed: res,
          assignedStore: detectedName,
          isNewStore: !isAlreadyRegistered,
          storeType: initialType,
          surfaceM2: initialM2,
          customMapping: res.appliedMapping,
          showColumnMapping: isCriticalMissing,
          showPreviewTable: false,
        });
      }

      setStagedFiles(newStaged);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Ocurrió un error al procesar los archivos.');
    } finally {
      setIsProcessing(false);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleUpdateAssignedStore = (index: number, newStoreName: string) => {
    setStagedFiles((prev) => {
      const next = [...prev];
      const entry = next[index];
      if (!entry) return prev;

      const isRegistered = existingStores.some(
        (s) => s.toLowerCase() === newStoreName.trim().toLowerCase()
      );

      next[index] = {
        ...entry,
        assignedStore: newStoreName,
        isNewStore: !isRegistered,
      };
      return next;
    });
  };

  const handleUpdateStoreType = (index: number, newType: StoreType) => {
    setStagedFiles((prev) => {
      const next = [...prev];
      const entry = next[index];
      if (!entry) return prev;

      next[index] = {
        ...entry,
        storeType: newType,
      };
      return next;
    });
  };

  const handleUpdateColumnMapping = async (
    index: number,
    field: keyof ColumnMappingConfig,
    headerName: string
  ) => {
    const entry = stagedFiles[index];
    if (!entry) return;

    const newMapping: ColumnMappingConfig = {
      ...entry.customMapping,
      [field]: headerName === '__NONE__' ? undefined : headerName,
    };

    try {
      const reParsed = await parseInventoryFile(
        entry.file,
        entry.assignedStore,
        existingStores,
        newMapping,
        currentBcvRate
      );

      setStagedFiles((prev) => {
        const next = [...prev];
        next[index] = {
          ...entry,
          parsed: reParsed,
          customMapping: newMapping,
        };
        return next;
      });
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error al remapear columnas');
    }
  };

  const handleToggleColumnMapping = (index: number) => {
    setStagedFiles((prev) =>
      prev.map((item, i) =>
        i === index ? { ...item, showColumnMapping: !item.showColumnMapping } : item
      )
    );
  };

  const handleTogglePreviewTable = (index: number) => {
    setStagedFiles((prev) =>
      prev.map((item, i) =>
        i === index ? { ...item, showPreviewTable: !item.showPreviewTable } : item
      )
    );
  };

  const handleRemoveStagedFile = (index: number) => {
    setStagedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleConfirmImport = () => {
    if (stagedFiles.length === 0) return;

    const allItems: InventoryItem[] = [];
    const fileNames: string[] = [];
    const newProfiles: StoreProfile[] = [];
    const newCapacities: Record<string, CapacityMatrixConfig> = {};

    stagedFiles.forEach((staged) => {
      const storeName = staged.assignedStore.trim() || staged.parsed.detectedStore.detectedStoreName;
      fileNames.push(staged.file.name);

      // Reassign all items from this file to the confirmed store name with globally unique IDs
      const fileUid = Math.random().toString(36).slice(2, 7);
      const storeItems = staged.parsed.items.map((it, idx) => ({
        ...it,
        Tienda: storeName,
        id: `${storeName}-${it.Referencia}-${it.Talla}-${fileUid}-${idx}`,
      }));

      allItems.push(...storeItems);

      // If store is not registered in system, generate its store profile and capacity
      const isAlreadyInProfiles = (storeProfiles || []).some(
        (p) => p && p.nombre && p.nombre.toLowerCase() === storeName.toLowerCase()
      );
      const isAlreadyInNew = newProfiles.some(
        (p) => p && p.nombre && p.nombre.toLowerCase() === storeName.toLowerCase()
      );

      if (!isAlreadyInProfiles && !isAlreadyInNew) {
        let defaultDepth = 16;
        if (staged.storeType === 'FLAGSHIP') defaultDepth = 18;
        else if (staged.storeType === 'UNITE') defaultDepth = 20;
        else if (staged.storeType === 'EXPRESS') defaultDepth = 14;

        const baseMatrix = createBaseBrandMatrix(defaultDepth);

        // Detect unique brands from the uploaded items
        const fileBrands: string[] = Array.from(new Set(storeItems.map((it) => it.Marca || 'GENERAL')));
        const marcasCap: Record<string, CapacityMatrixConfig> = {};
        if (fileBrands.length > 0) {
          (fileBrands || []).forEach((b: string) => {
            marcasCap[b] = createBaseBrandMatrix(defaultDepth);
          });
        } else {
          marcasCap['GENERAL'] = baseMatrix;
        }

        const newProf: StoreProfile = {
          id: `store-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          nombre: storeName,
          ciudad: 'Ciudad Principal',
          direccion: 'Ubicación Comercial',
          superficieM2: staged.surfaceM2 || 500,
          tipo: staged.storeType,
          marcasCapacidad: marcasCap,
          profundidadMediaTienda: defaultDepth,
          fechaRegistro: new Date().toISOString().split('T')[0],
        };

        newProfiles.push(newProf);
        newCapacities[storeName] = baseMatrix;
      }
    });

    onDataLoaded(allItems, fileNames, newProfiles, newCapacities, replaceExisting, currentBcvRate);
    if (onUpdateBcvRate) onUpdateBcvRate(currentBcvRate);
    onClose();
  };

  const totalStagedRows = stagedFiles.reduce((acc, f) => acc + f.parsed.rowCount, 0);
  const totalStagedSkus = new Set(
    stagedFiles.flatMap((f) => f.parsed.items.map((it) => `${it.Referencia}-${it.Tienda}`))
  ).size;
  const uniqueStoresDetected = Array.from(new Set(stagedFiles.map((f) => f.assignedStore.trim())));

  const targetMappingFields: { key: keyof ColumnMappingConfig; label: string; desc: string }[] = [
    { key: 'Referencia', label: 'SKU / Referencia *', desc: 'Código de estilo o producto (Requerido)' },
    { key: 'Talla', label: 'Talla *', desc: 'Talla numérica o alfabética (Requerido)' },
    { key: 'Stock', label: 'Stock / Cantidad *', desc: 'Unidades físicas disponibles (Requerido)' },
    { key: 'Marca', label: 'Marca', desc: 'Fabricante o marca comercial' },
    { key: 'Genero', label: 'Género / Sexo', desc: 'Hombre, Mujer, Niños, Unisex' },
    { key: 'Categoria', label: 'Categoría', desc: 'Calzado, Textil, Accesorios, etc.' },
    { key: 'Familia', label: 'Familia / Silueta', desc: 'Running, Training, Sportswear, etc.' },
    { key: 'Seccion', label: 'Sección', desc: 'Zona o sección comercial' },
    { key: 'Departamento', label: 'Departamento', desc: 'Depto mayor (Calzado, Textil, Accesorios)' },
    { key: 'Valoracion', label: 'Valoración / Precio', desc: 'Costo o PVP total' },
    { key: 'Tienda', label: 'Tienda / Sucursal', desc: 'Nombre de la tienda en el archivo' },
    { key: 'VentaSemanal', label: 'Venta Semanal (Ritmo)', desc: 'Ritmo semanal promedio para WOS' },
    { key: 'Venta30D', label: 'Venta 30 Días (Uds)', desc: 'Venta mensual para WOS' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border border-zinc-200 rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden text-zinc-800 flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-200 bg-[#F8F7FC]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-900 tracking-tight flex items-center gap-2">
                <span>Cargar Inventario Excel / CSV</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 uppercase font-mono">
                  Reconocimiento Inteligente
                </span>
              </h2>
              <p className="text-xs text-zinc-500">
                Extracción automática de Géneros, Categorías, Familias, Secciones y Marcas sin KeyError
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-800 rounded-xl hover:bg-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* Download Official SPEC Template Callout */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-emerald-50/70 border border-emerald-200/90 rounded-xl">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <span>¿Deseas probar la plataforma de inmediato?</span>
                  <span className="text-[10px] bg-emerald-200/70 text-emerald-900 font-mono px-1.5 py-0.2 rounded font-semibold">
                    OFICIAL SPEC
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800/90 truncate">
                  Descarga la plantilla con 50 referencias de prueba preparadas para rebalanceo.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                downloadOfficialSpecTemplate();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Descargar Plantilla .xlsx</span>
            </button>
          </div>

          {/* Tasa Oficial BCV para Conversión Monetaria */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-zinc-50 border border-zinc-200/90 rounded-xl">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 text-white flex items-center justify-center shrink-0 font-mono text-xs font-bold shadow-2xs">
                BCV
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-zinc-900">
                    Conversión Oficial BCV (Bolívares → Dólares)
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-semibold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    ACTIVA
                  </span>
                </div>
                <p className="text-[11px] text-zinc-500">
                  Los valores del archivo en Bolívares (Bs.) se convierten automáticamente a Dólares ($ USD).
                </p>
                {bcvFetchNotice && (
                  <p className="text-[10px] text-emerald-700 font-mono mt-0.5 font-medium">
                    ✓ {bcvFetchNotice}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center bg-white border border-zinc-200 rounded-lg px-2.5 py-1 shadow-2xs">
                <span className="text-[11px] text-zinc-500 mr-1.5 font-mono">1 USD =</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={currentBcvRate}
                  onChange={(e) => {
                    const r = parseFloat(e.target.value);
                    if (!isNaN(r) && r > 0) {
                      handleManualBcvRateChange(r);
                    }
                  }}
                  className="w-20 text-xs font-bold font-mono text-zinc-900 focus:outline-none text-right"
                  title="Puedes ajustar manualmente la tasa de conversión si lo deseas"
                />
                <span className="text-[11px] font-mono text-zinc-500 ml-1">Bs.</span>
              </div>
              <button
                type="button"
                onClick={handleRefreshBcvRate}
                disabled={isFetchingBcv}
                className="p-1.5 rounded-lg border border-zinc-200 hover:bg-zinc-100 text-zinc-600 transition-colors cursor-pointer"
                title="Actualizar cotización oficial directamente desde el BCV"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isFetchingBcv ? 'animate-spin text-blue-600' : ''}`} />
              </button>
            </div>
          </div>

          {/* Dropzone */}
          <div
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-blue-500 bg-blue-50/50 scale-[0.99]'
                : 'border-zinc-300 hover:border-zinc-400 bg-[#F8F7FC] hover:bg-zinc-50'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) handleFiles(e.target.files);
              }}
            />
            {isProcessing ? (
              <div className="flex flex-col items-center justify-center space-y-3 py-3">
                <Loader2 className="w-9 h-9 text-blue-600 animate-spin" />
                <p className="text-sm font-semibold text-zinc-800">
                  Analizando estructura y mapeando géneros, categorías, familias y marcas...
                </p>
                <p className="text-xs text-zinc-500 font-mono">Lectura inteligente de columnas activa</p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center space-y-2.5">
                <div className="w-11 h-11 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-zinc-800">
                    Arrastra aquí tus archivos Excel (.xlsx, .xls o .csv), o haz clic para seleccionarlos
                  </p>
                  <p className="text-xs text-zinc-500 mt-1">
                    Detecta automáticamente Género, Categoría, Familia, Sección, Marca, Talla y Stock.
                  </p>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-zinc-200 text-[11px] text-zinc-600 shadow-2xs">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>
                    Compatible con columnas en español e inglés (SKU, GÉNERO, CATEGORÍA, FAMILIA, SECCIÓN, MARCA, etc.)
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Error display */}
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-rose-800 flex items-start gap-3 text-xs animate-fadeIn">
              <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-rose-900">Error al procesar archivo</p>
                <p className="mt-1 text-rose-700">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* Staged files cards list */}
          {stagedFiles.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-2">
                  <Store className="w-4 h-4 text-blue-600" />
                  <span>Archivos Procesados Listos para Integrar ({stagedFiles.length})</span>
                </h3>
                <span className="text-[11px] text-zinc-500">
                  Revisa la asignación de columnas y la muestra de datos
                </span>
              </div>

              <div className="space-y-4">
                {stagedFiles.map((staged, idx) => (
                  <div
                    key={`${staged.file.name}-${idx}`}
                    className="bg-white border border-zinc-200 hover:border-zinc-300 rounded-2xl p-4 transition-colors space-y-3.5 shadow-2xs"
                  >
                    {/* Header info row */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-100 pb-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-xl bg-zinc-100 text-zinc-700 flex-shrink-0">
                          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                        </div>
                        <div className="truncate">
                          <div className="text-xs font-bold text-zinc-900 truncate font-mono">
                            {staged.file.name}
                          </div>
                          <div className="text-[10px] text-zinc-500 flex items-center gap-2 mt-0.5 flex-wrap font-mono">
                            <span className="text-zinc-700 font-semibold">{staged.parsed.rowCount.toLocaleString()} filas</span>
                            <span>•</span>
                            <span className="text-emerald-700 font-semibold">{staged.parsed.uniqueSkus} SKUs</span>
                            <span>•</span>
                            <span className="text-blue-700 font-semibold">{staged.parsed.totalPieces.toLocaleString()} piezas</span>
                            <span>•</span>
                            <span className="text-emerald-700 font-semibold font-mono" title={staged.parsed.totalValuationBs ? `En Bolívares: Bs. ${staged.parsed.totalValuationBs.toLocaleString('es-VE')}` : undefined}>
                              ${staged.parsed.totalValuation.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                            </span>
                            {staged.parsed.detectedBrand && staged.parsed.detectedBrand !== 'GENERAL' && (
                              <>
                                <span>•</span>
                                <span className="text-amber-800 font-bold">Marca: {staged.parsed.detectedBrand}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {staged.isNewStore ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1 font-mono">
                            <Sparkles className="w-3 h-3" /> Nueva Tienda
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1 font-mono">
                            <Check className="w-3 h-3" /> Tienda Existente
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveStagedFile(idx)}
                          className="p-1 text-zinc-400 hover:text-rose-600 rounded-lg hover:bg-zinc-100 transition-colors cursor-pointer"
                          title="Eliminar de la lista"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Detected breakdown badges */}
                    <div className="flex flex-wrap gap-2 text-[10px]">
                      <div className="flex items-center gap-1 bg-[#F8F7FC] px-2.5 py-1 rounded-lg border border-zinc-200 text-zinc-700">
                        <span className="text-zinc-500 font-bold uppercase">Deptos:</span>
                        <span className="font-semibold text-zinc-900">
                          {Object.keys(staged.parsed.deptBreakdown).join(', ') || 'General'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 bg-[#F8F7FC] px-2.5 py-1 rounded-lg border border-zinc-200 text-zinc-700">
                        <span className="text-zinc-500 font-bold uppercase">Géneros:</span>
                        <span className="font-semibold text-emerald-700">
                          {Object.keys(staged.parsed.genderBreakdown).join(', ') || 'Unisex'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 bg-[#F8F7FC] px-2.5 py-1 rounded-lg border border-zinc-200 text-zinc-700">
                        <span className="text-zinc-500 font-bold uppercase">Marcas:</span>
                        <span className="font-semibold text-blue-700">
                          {Object.keys(staged.parsed.brandBreakdown).join(', ') || 'General'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 bg-[#F8F7FC] px-2.5 py-1 rounded-lg border border-zinc-200 text-zinc-700">
                        <span className="text-zinc-500 font-bold uppercase">Familias:</span>
                        <span className="font-semibold text-amber-800">
                          {Object.keys(staged.parsed.familyBreakdown).slice(0, 4).join(', ') || 'General'}
                          {Object.keys(staged.parsed.familyBreakdown).length > 4 ? '...' : ''}
                        </span>
                      </div>
                    </div>

                    {/* Diagnostic warning: check for numeric sizes in textile */}
                    {(() => {
                      const textileNumAnomalies = staged.parsed.items.filter(
                        (it) =>
                          it.Departamento === 'TEXTIL' &&
                          /^\d+(\.0+)?$/.test(String(it.Talla || '').trim())
                      );
                      if (textileNumAnomalies.length === 0) return null;
                      return (
                        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2 text-xs text-amber-900 animate-fadeIn">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <div className="space-y-0.5">
                            <span className="font-bold">
                              Aviso: {textileNumAnomalies.length} fila(s) de Textil tienen talla numérica (ej: "{textileNumAnomalies[0].Talla}" en ref {textileNumAnomalies[0].Referencia}).
                            </span>
                            <p className="text-[11px] text-amber-700 leading-tight">
                              Si tu archivo de textil usa tallas XS, S, M, L, revisa en <strong>Mapeo de Columnas</strong> que la columna <em>Talla</em> esté asignada a la columna de tallas de tu Excel (y no a una columna numérica de cantidad, pasillo o caja).
                            </p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Store assignment and format controls */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-zinc-600 mb-1">
                          Tienda Asignada
                        </label>
                        <div className="relative">
                          <Store className="w-3.5 h-3.5 text-blue-600 absolute left-3 top-2.5" />
                          <input
                            type="text"
                            value={staged.assignedStore}
                            onChange={(e) => handleUpdateAssignedStore(idx, e.target.value)}
                            placeholder="Nombre de la tienda..."
                            className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-xl pl-9 pr-3 py-1.5 text-xs font-bold text-zinc-900 focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>

                      {staged.isNewStore ? (
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-zinc-600 mb-1">
                            Formato de Tienda
                          </label>
                          <select
                            value={staged.storeType}
                            onChange={(e) => handleUpdateStoreType(idx, e.target.value as StoreType)}
                            className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-xl px-3 py-1.5 text-xs text-zinc-900 focus:outline-none focus:border-blue-500 cursor-pointer"
                          >
                            <option value="FLAGSHIP">⭐ Flagship (Gran Formato)</option>
                            <option value="LIVE">🏬 Live (Estándar Mall)</option>
                            <option value="UNITE">🏷️ Unite (Outlet)</option>
                            <option value="EXPRESS">⚡ Express (Compacto)</option>
                          </select>
                        </div>
                      ) : (
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-zinc-600 mb-1">
                            Perfil en el Sistema
                          </label>
                          <div className="bg-[#F8F7FC] border border-zinc-200 rounded-xl px-3 py-1.5 text-xs text-zinc-700 flex items-center justify-between">
                            <span>🏬 Registrada en CommandCenter</span>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Column Mapping & Preview action buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-zinc-100">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleToggleColumnMapping(idx)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer border ${
                            staged.showColumnMapping
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-[#F8F7FC] text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100 border-zinc-200'
                          }`}
                        >
                          <Sliders className="w-3.5 h-3.5" />
                          <span>Mapeo de Columnas</span>
                          {staged.showColumnMapping ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleTogglePreviewTable(idx)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer border ${
                            staged.showPreviewTable
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-[#F8F7FC] text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100 border-zinc-200'
                          }`}
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Ver Muestra de Filas (5)</span>
                          {staged.showPreviewTable ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Mapping health pill */}
                      {(() => {
                        const missing: string[] = [];
                        if (!staged.customMapping.Referencia) missing.push('SKU');
                        if (!staged.customMapping.Talla) missing.push('Talla');
                        if (!staged.customMapping.Stock) missing.push('Stock');
                        const mappedCount = Object.values(staged.customMapping).filter(Boolean).length;

                        if (missing.length > 0) {
                          return (
                            <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 border border-amber-300 inline-flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                              Falta asignar: {missing.join(', ')}
                            </span>
                          );
                        }
                        return (
                          <span className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 inline-flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            {mappedCount} campos mapeados
                          </span>
                        );
                      })()}
                    </div>

                    {/* Expandable Column Mapping Panel */}
                    {staged.showColumnMapping && (
                      <div className="bg-[#F8F7FC] p-4 rounded-2xl border border-zinc-200 space-y-3 animate-fadeIn">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
                            <Sliders className="w-3.5 h-3.5 text-blue-600" />
                            Ajustar Mapeo de Columnas de Excel
                          </span>
                          <span className="text-[10px] text-zinc-500 font-mono">
                            {staged.parsed.rawHeaders.length} Columnas encontradas en el archivo
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-500 leading-tight">
                          Si alguna columna de tu Excel no se detectó automáticamente, selecciónala aquí para remapearla al campo correspondiente:
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
                          {targetMappingFields.map((f) => {
                            const currentMappedHeader = staged.customMapping[f.key] || '';
                            return (
                              <div key={f.key} className="bg-white p-2.5 rounded-xl border border-zinc-200 shadow-2xs">
                                <div className="flex items-center justify-between mb-1">
                                  <label className="text-[10px] font-bold text-zinc-700 uppercase tracking-tight">
                                    {f.label}
                                  </label>
                                  {currentMappedHeader && (
                                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200">
                                      Mapeado
                                    </span>
                                  )}
                                </div>
                                <select
                                  value={currentMappedHeader || '__NONE__'}
                                  onChange={(e) => handleUpdateColumnMapping(idx, f.key, e.target.value)}
                                  className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-lg px-2 py-1 text-xs text-zinc-900 focus:outline-none focus:border-blue-500 cursor-pointer"
                                >
                                  <option value="__NONE__">— Sin Asignar —</option>
                                  {staged.parsed.rawHeaders.map((hdr) => (
                                    <option key={hdr} value={hdr}>
                                      {hdr}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Expandable Live Sample Data Preview Table */}
                    {staged.showPreviewTable && (
                      <div className="bg-[#F8F7FC] rounded-2xl border border-zinc-200 overflow-hidden space-y-2 p-3 animate-fadeIn">
                        <div className="flex items-center justify-between px-1">
                          <span className="text-xs font-bold text-zinc-900 flex items-center gap-1.5">
                            <Eye className="w-3.5 h-3.5 text-emerald-600" />
                            Vista Previa de Datos Normalizados (Primeras 5 Filas)
                          </span>
                          <span className="text-[10px] text-emerald-700 font-mono font-bold">
                            Total: {staged.parsed.items.length.toLocaleString()} items
                          </span>
                        </div>

                        <div className="overflow-x-auto border border-zinc-200 rounded-xl bg-white">
                          <table className="w-full text-left text-[11px]">
                            <thead className="bg-[#F4F2FD] text-zinc-500 border-b border-zinc-200 text-[10px] uppercase font-mono font-bold tracking-wider">
                              <tr>
                                <th className="px-2.5 py-2">SKU / Ref</th>
                                <th className="px-2.5 py-2">Marca</th>
                                <th className="px-2.5 py-2">Depto</th>
                                <th className="px-2.5 py-2">Sección / Género</th>
                                <th className="px-2.5 py-2">Familia</th>
                                <th className="px-2.5 py-2 text-center">Talla</th>
                                <th className="px-2.5 py-2 text-right">Stock</th>
                                 <th className="px-2.5 py-2 text-right">Valoración ($ USD)</th>
                                {staged.parsed.items.slice(0, 5).some((it) => it.VentaSemanal !== undefined || it.WOS !== undefined) && (
                                  <th className="px-2.5 py-2 text-right">Venta / WOS</th>
                                )}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-zinc-100 text-zinc-800">
                              {staged.parsed.items.slice(0, 5).map((it, sampleIdx) => {
                                const hasSampleSales = staged.parsed.items.slice(0, 5).some((s) => s.VentaSemanal !== undefined || s.WOS !== undefined);
                                return (
                                  <tr key={sampleIdx} className="hover:bg-[#F8F7FC]">
                                    <td className="px-2.5 py-1.5 font-mono font-bold text-blue-700 whitespace-nowrap">
                                      {it.Referencia}
                                    </td>
                                    <td className="px-2.5 py-1.5 font-semibold text-zinc-900 whitespace-nowrap">
                                      {it.Marca}
                                    </td>
                                    <td className="px-2.5 py-1.5 whitespace-nowrap">{it.Departamento}</td>
                                    <td className="px-2.5 py-1.5 text-emerald-700 whitespace-nowrap">{it.Seccion}</td>
                                    <td className="px-2.5 py-1.5 text-amber-800 whitespace-nowrap">{it.Familia}</td>
                                    <td className="px-2.5 py-1.5 text-center font-mono font-bold text-zinc-800 whitespace-nowrap">
                                      {it.Talla}
                                    </td>
                                    <td className="px-2.5 py-1.5 text-right font-mono font-bold text-zinc-900 whitespace-nowrap">
                                      {it.Stock}
                                    </td>
                                    <td className="px-2.5 py-1.5 text-right font-mono text-emerald-700 whitespace-nowrap" title={it.ValoracionBs !== undefined ? `Original: Bs. ${it.ValoracionBs.toLocaleString()}` : undefined}>
                                      <div>${it.Valoracion.toFixed(2)}</div>
                                      {it.ValoracionBs !== undefined && (
                                        <div className="text-[9px] text-zinc-400 font-sans font-normal">
                                          Bs. {it.ValoracionBs.toLocaleString()}
                                        </div>
                                      )}
                                    </td>
                                    {hasSampleSales && (
                                      <td className="px-2.5 py-1.5 text-right font-mono whitespace-nowrap">
                                        {it.VentaSemanal !== undefined ? (
                                          <span className="font-bold text-zinc-800">{it.VentaSemanal} u/s</span>
                                        ) : (
                                          <span className="text-zinc-400">—</span>
                                        )}
                                        {it.WOS !== undefined && (
                                          <span className="ml-1 text-[10px] text-blue-700 font-semibold">
                                            ({it.WOS === 999 ? '∞' : it.WOS}s)
                                          </span>
                                        )}
                                      </td>
                                    )}
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Total Batch Summary */}
              <div className="bg-[#F8F7FC] p-4 rounded-2xl border border-zinc-200 grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-zinc-500">Total Filas</span>
                  <div className="text-base font-bold text-zinc-900 font-mono">{totalStagedRows.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-zinc-500">SKUs Únicos</span>
                  <div className="text-base font-bold text-emerald-700 font-mono">{totalStagedSkus.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-zinc-500">Tiendas Detectadas</span>
                  <div className="text-base font-bold text-blue-700 font-mono">{uniqueStoresDetected.length}</div>
                </div>
              </div>

              {/* Replacement mode toggle */}
              <div className="bg-[#F8F7FC] p-3.5 rounded-2xl border border-zinc-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-blue-600" />
                  <span className="text-zinc-700 font-medium">
                    Reemplazar inventario de estas tiendas (Recomendado)
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={replaceExisting}
                    onChange={(e) => setReplaceExisting(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-zinc-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-[#F8F7FC] border-t border-zinc-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60 rounded-xl transition-colors cursor-pointer"
          >
            Cancelar
          </button>

          <div className="flex items-center gap-2">
            {stagedFiles.length > 0 && (
              <button
                type="button"
                onClick={handleConfirmImport}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  Confirmar e Importar ({uniqueStoresDetected.length} Tienda{uniqueStoresDetected.length > 1 ? 's' : ''}, {totalStagedRows.toLocaleString()} Registros)
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
