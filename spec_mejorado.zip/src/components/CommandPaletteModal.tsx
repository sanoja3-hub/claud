import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertOctagon,
  ArrowRight,
  BarChart3,
  Boxes,
  Building2,
  Calendar,
  CheckCircle2,
  Command,
  CornerDownLeft,
  Crown,
  Database,
  Download,
  FileSpreadsheet,
  Grid,
  Search,
  Settings2,
  Sparkles,
  Tag,
  Truck,
  X,
} from 'lucide-react';
import { InventoryAlert, InventoryItem, StoreProfile } from '../types';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: InventoryItem[];
  stores?: string[];
  storeProfiles?: StoreProfile[];
  alerts?: InventoryAlert[];
  onNavigateTab?: (tabId: string) => void;
  onSelectStore?: (storeName: string) => void;
  onExportAudit?: () => void;
  onOpenUpload?: () => void;
  onOpenRegisterStore?: () => void;
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  inventory = [],
  stores = [],
  storeProfiles = [],
  alerts = [],
  onNavigateTab = (_tabId: string) => {},
  onSelectStore = (_storeName: string) => {},
  onExportAudit = () => {},
  onOpenUpload = () => {},
  onOpenRegisterStore = () => {},
}) => {
  const [query, setQuery] = useState<string>('');
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  // Close on Escape or open on Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Reset query on open
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Unique lists for instant search
  const uniqueReferences = useMemo(() => {
    const map = new Map<string, { ref: string; marca: string; depto: string; totalStock: number }>();
    (inventory || []).forEach((it) => {
      if (!it) return;
      if (!map.has(it.Referencia)) {
        map.set(it.Referencia, { ref: it.Referencia, marca: it.Marca, depto: it.Departamento, totalStock: 0 });
      }
      map.get(it.Referencia)!.totalStock += it.Stock;
    });
    return Array.from(map.values());
  }, [inventory]);

  const uniqueBrands = useMemo(() => {
    const map = new Map<string, number>();
    (inventory || []).forEach((it) => {
      if (!it || !it.Marca) return;
      map.set(it.Marca, (map.get(it.Marca) || 0) + it.Stock);
    });
    return Array.from(map.entries()).map(([marca, stock]) => ({ marca, stock }));
  }, [inventory]);

  // Filtered Results categorized
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list: {
      id: string;
      category: 'ACCIONES' | 'TIENDAS' | 'REFERENCIAS' | 'MARCAS' | 'ALERTAS';
      title: string;
      subtitle: string;
      icon: any;
      action: () => void;
    }[] = [];

    // 1. Quick Global System Actions
    const systemActions = [
      {
        id: 'act-dashboard',
        category: 'ACCIONES' as const,
        title: 'Ir a Cuadro de Mando & Capacidad',
        subtitle: 'Ver KPIs de ocupación y balance de stock',
        icon: BarChart3,
        action: () => {
          onNavigateTab('dashboard');
          onClose();
        },
      },
      {
        id: 'act-manager',
        category: 'ACCIONES' as const,
        title: 'Ir al Panel Ejecutivo de Manager',
        subtitle: 'Supervisión global multitienda y asignación',
        icon: Crown,
        action: () => {
          onNavigateTab('manager');
          onSelectStore('TODAS');
          onClose();
        },
      },
      {
        id: 'act-transfers',
        category: 'ACCIONES' as const,
        title: 'Ir a Rebalanceo Inter-Tienda & Lista de Empaque',
        subtitle: 'Ver sugerencias de transferencias y guías de despacho',
        icon: Truck,
        action: () => {
          onNavigateTab('traslados');
          onClose();
        },
      },
      {
        id: 'act-curves',
        category: 'ACCIONES' as const,
        title: 'Ver Curvas & Alertas Operativas',
        subtitle: 'Explorar distribución de tallas, Gauss y anomalías',
        icon: Grid,
        action: () => {
          onNavigateTab('alertas');
          onClose();
        },
      },
      {
        id: 'act-audit',
        category: 'ACCIONES' as const,
        title: 'Descargar Auditoría Ejecutiva Consolidada (.xlsx)',
        subtitle: 'Generar reporte completo de auditoría financiera y operativa',
        icon: FileSpreadsheet,
        action: () => {
          onExportAudit();
          onClose();
        },
      },
      {
        id: 'act-register-store',
        category: 'ACCIONES' as const,
        title: 'Registrar Nueva Sucursal / Tienda',
        subtitle: 'Configurar metraje m², ciudad, formato y capacidad',
        icon: Building2,
        action: () => {
          onOpenRegisterStore();
          onClose();
        },
      },
      {
        id: 'act-upload',
        category: 'ACCIONES' as const,
        title: 'Cargar Archivos de Inventario (Excel/CSV)',
        subtitle: 'Importar existencias y detectar columnas automáticamente',
        icon: Download,
        action: () => {
          onOpenUpload();
          onClose();
        },
      },
    ];

    (systemActions || []).forEach((sa) => {
      if (!q || sa.title.toLowerCase().includes(q) || sa.subtitle.toLowerCase().includes(q)) {
        list.push(sa);
      }
    });

    // 2. Stores Filter
    (stores || []).forEach((st) => {
      if (st === 'TODAS') return;
      if (!q || st.toLowerCase().includes(q)) {
        const prof = (storeProfiles || []).find((p) => p && p.nombre === st);
        list.push({
          id: `store-${st}`,
          category: 'TIENDAS',
          title: st,
          subtitle: `Formato: ${prof?.tipo || 'LIVE'} • Ciudad: ${prof?.ciudad || 'N/A'} • Cluster: ${prof?.cluster || 'ESTANDAR'}`,
          icon: Building2,
          action: () => {
            onSelectStore(st);
            onNavigateTab('dashboard');
            onClose();
          },
        });
      }
    });

    // 3. References / SKUs Filter
    (uniqueReferences || []).forEach((r) => {
      if (q && (r.ref.toLowerCase().includes(q) || r.marca.toLowerCase().includes(q) || r.depto.toLowerCase().includes(q))) {
        list.push({
          id: `ref-${r.ref}`,
          category: 'REFERENCIAS',
          title: r.ref,
          subtitle: `${r.marca} • ${r.depto} • Stock Total: ${r.totalStock} unidades`,
          icon: Tag,
          action: () => {
            onNavigateTab('alertas');
            onClose();
          },
        });
      }
    });

    // 4. Brands Filter
    (uniqueBrands || []).forEach((b) => {
      if (q && b.marca.toLowerCase().includes(q)) {
        list.push({
          id: `brand-${b.marca}`,
          category: 'MARCAS',
          title: b.marca,
          subtitle: `Inventario consolidado: ${b.stock.toLocaleString()} unidades`,
          icon: Boxes,
          action: () => {
            onNavigateTab('alertas');
            onClose();
          },
        });
      }
    });

    // 5. Critical Alerts Filter
    (alerts || []).forEach((a) => {
      if (!a) return;
      if (q && (a.Referencia?.toLowerCase().includes(q) || a.TipoDeAlerta?.toLowerCase().includes(q) || a.Tienda?.toLowerCase().includes(q))) {
        list.push({
          id: `alert-${a.id}`,
          category: 'ALERTAS',
          title: `${a.TipoDeAlerta}: ${a.Referencia}`,
          subtitle: `${a.Tienda} • ${a.Prioridad} • ${(a.Diagnostico || '').slice(0, 70)}...`,
          icon: AlertOctagon,
          action: () => {
            onSelectStore(a.Tienda);
            onNavigateTab('alertas');
            onClose();
          },
        });
      }
    });

    return list.slice(0, 20); // Cap to top 20 matches for ultra responsiveness
  }, [query, stores, storeProfiles, uniqueReferences, uniqueBrands, alerts, onNavigateTab, onSelectStore, onExportAudit, onOpenUpload, onOpenRegisterStore, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="w-full max-w-2xl bg-white border border-zinc-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Bar Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-zinc-200 bg-[#F8F7FC]">
          <Search className="w-5 h-5 text-blue-600 shrink-0" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Buscar SKU, referencia, tienda, marca, alerta o comando... (ej. Nike, Flagship, TR-1001)"
            className="w-full bg-transparent text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-200/60 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <div className="hidden sm:flex items-center gap-1 text-[11px] text-zinc-500 bg-zinc-200/60 px-2 py-0.5 rounded-md border border-zinc-300 font-mono">
            <span>ESC</span>
          </div>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-zinc-100">
          {results.length === 0 ? (
            <div className="p-10 text-center text-zinc-500 space-y-2">
              <Search className="w-8 h-8 mx-auto text-zinc-400 opacity-50" />
              <p className="text-sm font-medium">No se encontraron resultados para "{query}"</p>
              <p className="text-xs text-zinc-400">Prueba buscando por nombre de tienda, SKU, marca o comando del sistema.</p>
            </div>
          ) : (
            results.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={`${item.id}-${idx}`}
                  onClick={item.action}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-left transition-all cursor-pointer ${
                    isSelected ? 'bg-blue-50 border border-blue-200 text-zinc-900' : 'hover:bg-zinc-50 text-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-lg shrink-0 ${
                        item.category === 'ACCIONES'
                          ? 'bg-blue-100 text-blue-700'
                          : item.category === 'TIENDAS'
                          ? 'bg-emerald-100 text-emerald-700'
                          : item.category === 'ALERTAS'
                          ? 'bg-rose-100 text-rose-700'
                          : item.category === 'MARCAS'
                          ? 'bg-purple-100 text-purple-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold truncate text-zinc-900">{item.title}</span>
                        <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-zinc-100 text-zinc-600 border border-zinc-200 font-mono">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-500 truncate">{item.subtitle}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-zinc-400 shrink-0">
                    <CornerDownLeft className="w-3.5 h-3.5" />
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-[#F8F7FC] border-t border-zinc-200 flex items-center justify-between text-[11px] text-zinc-500">
          <div className="flex items-center gap-3">
            <span>Navega con <b>↑ ↓</b></span>
            <span>Selecciona con <b>ENTER</b></span>
          </div>
          <span>Atajo: <b>Cmd+K</b> o <b>Ctrl+K</b></span>
        </div>
      </div>
    </div>
  );
};
