import React, { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { HelpCircle, X } from 'lucide-react';

interface CardInfoButtonProps {
  title: string;
  description: string;
  formula?: string;
  dataSource?: string;
  operationalImpact?: string;
  className?: string;
}

export const CardInfoButton: React.FC<CardInfoButtonProps> = ({
  title,
  description,
  formula,
  dataSource,
  operationalImpact,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [coords, setCoords] = useState<{ top: number; left: number }>({ top: 0, left: 0 });

  const calculatePosition = useCallback(() => {
    if (!buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const popoverWidth = Math.min(384, window.innerWidth - 24);
    const popoverMaxHeight = 420;

    // Horizontal calculation: align right edge if near right margin, otherwise align left
    let left = rect.left;
    if (rect.left + popoverWidth > window.innerWidth - 16) {
      left = Math.max(12, rect.right - popoverWidth);
    } else {
      left = Math.max(12, rect.left);
    }

    // Vertical calculation: if near bottom edge, flip above the button
    let top = rect.bottom + 8;
    if (rect.bottom + popoverMaxHeight > window.innerHeight - 16 && rect.top > popoverMaxHeight + 16) {
      top = Math.max(12, rect.top - popoverMaxHeight - 8);
    }

    setCoords({ top, left });
  }, []);

  const handleOpen = (e: React.MouseEvent) => {
    e.stopPropagation();
    calculatePosition();
    setIsOpen((prev) => !prev);
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };

    const handleScrollOrResize = () => {
      calculatePosition();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('scroll', handleScrollOrResize, true);
    window.addEventListener('resize', handleScrollOrResize);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScrollOrResize, true);
      window.removeEventListener('resize', handleScrollOrResize);
    };
  }, [isOpen, calculatePosition]);

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <button
        ref={buttonRef}
        type="button"
        onClick={handleOpen}
        title={`Información técnica: ${title}`}
        className="p-1 rounded-md text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 transition-colors focus:outline-none cursor-pointer inline-flex items-center justify-center"
      >
        <HelpCircle className="w-3.5 h-3.5" />
      </button>

      {isOpen &&
        typeof document !== 'undefined' &&
        createPortal(
          <div className="fixed inset-0 z-[999999] pointer-events-auto">
            {/* Backdrop transparent/blur */}
            <div
              className="fixed inset-0 bg-zinc-950/20 backdrop-blur-[0.5px] transition-opacity animate-in fade-in duration-100"
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(false);
              }}
            />

            {/* Floating Popover Card - Guaranteed on top of any container, modal, table or overflow */}
            <div
              style={{
                position: 'fixed',
                top: `${coords.top}px`,
                left: `${coords.left}px`,
                maxWidth: 'calc(100vw - 24px)',
                width: '384px',
              }}
              className="rounded-xl bg-white border border-zinc-200/95 shadow-[0_20px_50px_rgba(0,0,0,0.2),0_10px_20px_rgba(0,0,0,0.1)] p-4 text-left text-xs select-none animate-in fade-in zoom-in-95 duration-150 z-[1000000] overflow-y-auto max-h-[82vh]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-zinc-100 mb-2.5">
                <div className="flex items-center gap-2 text-zinc-900 font-mono font-bold text-xs uppercase tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-blue-600 ring-2 ring-blue-100" />
                  <span className="truncate">{title}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1 rounded-md text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 cursor-pointer shrink-0 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <p className="text-zinc-600 leading-relaxed mb-3 font-sans text-[12px]">{description}</p>

              {formula && (
                <div className="mb-2.5 bg-[#F8F7FC] p-3 rounded-lg border border-zinc-200/80 font-mono text-[11px] text-zinc-800 shadow-[inset_0_1px_2px_rgba(0,0,0,0.03)] whitespace-pre-line leading-relaxed">
                  <span className="text-[9px] text-zinc-500 block uppercase tracking-widest font-mono mb-1.5 font-bold">
                    FÓRMULA // LÓGICA DE CÁLCULO:
                  </span>
                  <code>{formula}</code>
                </div>
              )}

              {dataSource && (
                <div className="mb-2 text-[11px] text-zinc-500 font-mono bg-zinc-50/70 p-2 rounded border border-zinc-100">
                  <span className="font-semibold text-zinc-700">ORIGEN DE DATOS // </span>
                  {dataSource}
                </div>
              )}

              {operationalImpact && (
                <div className="text-[11px] text-amber-950 bg-amber-50/80 p-2.5 rounded-lg border border-amber-200/80 font-sans leading-relaxed">
                  <span className="font-bold text-amber-900 block mb-1 text-[10px] font-mono uppercase tracking-wider">
                    IMPACTO EN LA OPERACIÓN //
                  </span>
                  {operationalImpact}
                </div>
              )}
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};
