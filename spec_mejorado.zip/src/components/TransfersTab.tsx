import React, { useState, useMemo } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Boxes,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  MapPin,
  RotateCcw,
  Route,
  ShieldCheck,
  Sparkles,
  Truck,
  UserCheck,
  Zap,
  ShoppingBag,
  Building2,
  Check,
  Package,
  Layers,
  Send,
  Inbox,
  AlertTriangle,
  Minus,
  Plus,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { InventoryAlert, StoreDistance, TransferSuggestion, TransferStatus } from '../types';
import { CardInfoButton } from './CardInfoButton';
import { PackingListModal } from './PackingListModal';
import { PurchasePlanModal } from './PurchasePlanModal';
import * as XLSX from 'xlsx';

interface TransfersTabProps {
  suggestions?: TransferSuggestion[];
  distances?: StoreDistance;
  stores?: string[];
  isSimulationActive?: boolean;
  onToggleSimulation?: (active: boolean) => void;
  onConfirmExecute?: () => void;
  onApplySingleTransfer?: (transfer: TransferSuggestion, units: number) => void;
  executedToast?: string | null;
  inventory?: any[];
  alerts?: InventoryAlert[];
}

export type OperationalStage = 'SUGERIDO' | 'APROBADO' | 'EN_TRANSITO' | 'RECIBIDO';

interface TransferRecordState {
  status: OperationalStage;
  condition: 'NUEVO' | 'USADO' | '';
  dispatchedUnits: number;
  receivedUnits: number;
  discrepancyNote?: string;
  updatedAt: string;
}

export const TransfersTab: React.FC<TransfersTabProps> = ({
  suggestions = [],
  distances = {},
  stores = [],
  isSimulationActive = false,
  onToggleSimulation = (_active: boolean) => {},
  onConfirmExecute = () => {},
  onApplySingleTransfer,
  executedToast = null,
  inventory = [],
  alerts = [],
}) => {
  // Perspective: Planner Central (Macro red) vs Operador de Tienda (Bodega / Despacho)
  const [perspective, setPerspective] = useState<'PLANNER' | 'OPERADOR_TIENDA'>('PLANNER');
  const [operatorStore, setOperatorStore] = useState<string>(() => stores[0] || 'TODAS');

  // View mode switcher: Pendientes vs Recibidos / Historial vs Todos
  const [activeViewMode, setActiveViewMode] = useState<'PENDIENTES' | 'RECIBIDOS' | 'TODOS'>('PENDIENTES');
  const [localToast, setLocalToast] = useState<string | null>(null);

  const [filterPriority, setFilterPriority] = useState<string>('TODAS');
  const [filterStage, setFilterStage] = useState<string>('TODAS');
  const [selectedSource, setSelectedSource] = useState<string>('TODAS');
  const [selectedTarget, setSelectedTarget] = useState<string>('TODAS');
  const [isPackingListOpen, setIsPackingListOpen] = useState<boolean>(false);
  const [isPurchasePlanOpen, setIsPurchasePlanOpen] = useState<boolean>(false);
  const [isListOpen, setIsListOpen] = useState<boolean>(true);

  // Workflow status, condition and discrepancy quantities persisted in localStorage
  const [workflowMap, setWorkflowMap] = useState<Record<string, TransferRecordState>>(() => {
    try {
      const saved = localStorage.getItem('spec_transfer_workflow_v2');
      if (saved) return JSON.parse(saved);
      // Fallback migration from previous version if exists
      const oldConditions = localStorage.getItem('rcc_transfer_conditions');
      const parsedOld = oldConditions ? JSON.parse(oldConditions) : {};
      const initial: Record<string, TransferRecordState> = {};
      Object.entries(parsedOld).forEach(([id, cond]) => {
        initial[id] = {
          status: 'SUGERIDO',
          condition: (cond as any) || '',
          dispatchedUnits: 0,
          receivedUnits: 0,
          updatedAt: new Date().toISOString(),
        };
      });
      return initial;
    } catch {
      return {};
    }
  });

  const saveWorkflow = (next: Record<string, TransferRecordState>) => {
    setWorkflowMap(next);
    try {
      localStorage.setItem('spec_transfer_workflow_v2', JSON.stringify(next));
    } catch {}
  };

  const getRecord = (t: TransferSuggestion): TransferRecordState => {
    return (
      workflowMap[t.id] || {
        status: (t.Estado as OperationalStage) || 'SUGERIDO',
        condition: '',
        dispatchedUnits: t.UnidadesSugeridas,
        receivedUnits: t.UnidadesSugeridas,
        updatedAt: new Date().toISOString(),
      }
    );
  };

  const handleUpdateStatus = (id: string, newStatus: OperationalStage) => {
    const target = suggestions.find((s) => s.id === id);
    const prevRec = target ? getRecord(target) : null;
    const defaultUnits = target?.UnidadesSugeridas || 1;
    const unitsToMove = prevRec?.receivedUnits ?? defaultUnits;

    saveWorkflow({
      ...workflowMap,
      [id]: {
        status: newStatus,
        condition: prevRec?.condition || '',
        dispatchedUnits: prevRec?.dispatchedUnits ?? defaultUnits,
        receivedUnits: unitsToMove,
        discrepancyNote: prevRec?.discrepancyNote,
        updatedAt: new Date().toISOString(),
      },
    });

    if (newStatus === 'RECIBIDO' && target && onApplySingleTransfer) {
      onApplySingleTransfer(target, unitsToMove);
      setLocalToast(`✓ Mercancía recibida: ${unitsToMove} uds de ${target.Referencia} transferidas a ${target.TiendaDestino}. Stock actualizado en inventario.`);
      setTimeout(() => setLocalToast(null), 4500);
    } else if (newStatus === 'APROBADO' && target) {
      setLocalToast(`✓ Orden aprobada: Mercancía lista para picking en bodega de ${target.TiendaOrigen}.`);
      setTimeout(() => setLocalToast(null), 3500);
    } else if (newStatus === 'EN_TRANSITO' && target) {
      setLocalToast(`🚚 Orden en tránsito: Mercancía despachada desde ${target.TiendaOrigen} en ruta hacia ${target.TiendaDestino}.`);
      setTimeout(() => setLocalToast(null), 3500);
    }
  };

  const handleToggleCondition = (id: string, cond: 'NUEVO' | 'USADO') => {
    const target = suggestions.find((s) => s.id === id);
    const rec = target ? getRecord(target) : null;
    const current = rec?.condition || '';
    const newCond = current === cond ? '' : cond;

    saveWorkflow({
      ...workflowMap,
      [id]: {
        ...(rec || {
          status: 'SUGERIDO',
          dispatchedUnits: target?.UnidadesSugeridas || 1,
          receivedUnits: target?.UnidadesSugeridas || 1,
          updatedAt: new Date().toISOString(),
        }),
        condition: newCond,
        updatedAt: new Date().toISOString(),
      },
    });
  };

  const handleUpdateUnits = (id: string, field: 'dispatched' | 'received', delta: number) => {
    const target = suggestions.find((s) => s.id === id);
    if (!target) return;
    const rec = getRecord(target);
    const currentVal = field === 'dispatched' ? rec.dispatchedUnits : rec.receivedUnits;
    const newVal = Math.max(0, currentVal + delta);

    saveWorkflow({
      ...workflowMap,
      [id]: {
        ...rec,
        [field === 'dispatched' ? 'dispatchedUnits' : 'receivedUnits']: newVal,
        updatedAt: new Date().toISOString(),
      },
    });
  };

  // Bulk workflow updates
  const handleBulkSetStatus = (newStatus: OperationalStage) => {
    const next = { ...workflowMap };
    filtered.forEach((t) => {
      const rec = getRecord(t);
      next[t.id] = {
        ...rec,
        status: newStatus,
        updatedAt: new Date().toISOString(),
      };
    });
    saveWorkflow(next);
  };

  // Filtered dataset for Planner
  const filtered = useMemo(() => {
    return suggestions.filter((s) => {
      const rec = getRecord(s);
      if (activeViewMode === 'PENDIENTES' && rec.status === 'RECIBIDO') return false;
      if (activeViewMode === 'RECIBIDOS' && rec.status !== 'RECIBIDO') return false;

      if (filterPriority !== 'TODAS' && s.Prioridad !== filterPriority) return false;
      if (selectedSource !== 'TODAS' && s.TiendaOrigen !== selectedSource) return false;
      if (selectedTarget !== 'TODAS' && s.TiendaDestino !== selectedTarget) return false;
      if (filterStage !== 'TODAS' && rec.status !== filterStage) return false;
      return true;
    });
  }, [suggestions, filterPriority, selectedSource, selectedTarget, filterStage, workflowMap, activeViewMode]);

  // Operator store data: Outgoing (Despacho / Salidas) & Incoming (Recepción / Entradas)
  const effectiveOperatorStore = operatorStore === 'TODAS' ? stores[0] || 'TODAS' : operatorStore;

  const outgoingTransfers = useMemo(() => {
    let list = suggestions;
    if (effectiveOperatorStore && effectiveOperatorStore !== 'TODAS') {
      list = suggestions.filter((s) => s.TiendaOrigen === effectiveOperatorStore);
    }
    if (activeViewMode === 'PENDIENTES') {
      list = list.filter((s) => getRecord(s).status !== 'RECIBIDO');
    } else if (activeViewMode === 'RECIBIDOS') {
      list = list.filter((s) => getRecord(s).status === 'RECIBIDO');
    }
    return list;
  }, [suggestions, effectiveOperatorStore, activeViewMode, workflowMap]);

  const incomingTransfers = useMemo(() => {
    if (!effectiveOperatorStore || effectiveOperatorStore === 'TODAS') return [];
    let list = suggestions.filter((s) => s.TiendaDestino === effectiveOperatorStore);
    if (activeViewMode === 'PENDIENTES') {
      list = list.filter((s) => getRecord(s).status !== 'RECIBIDO');
    } else if (activeViewMode === 'RECIBIDOS') {
      list = list.filter((s) => getRecord(s).status === 'RECIBIDO');
    }
    return list;
  }, [suggestions, effectiveOperatorStore, activeViewMode, workflowMap]);

  // Global KPIs
  const totalPiezas = suggestions.reduce((acc, s) => acc + s.UnidadesSugeridas, 0);

  const stats = useMemo(() => {
    let sugeridos = 0;
    let aprobados = 0;
    let enTransito = 0;
    let recibidos = 0;
    let nuevos = 0;
    let usados = 0;

    suggestions.forEach((t) => {
      const rec = getRecord(t);
      if (rec.status === 'SUGERIDO') sugeridos++;
      else if (rec.status === 'APROBADO') aprobados++;
      else if (rec.status === 'EN_TRANSITO') enTransito++;
      else if (rec.status === 'RECIBIDO') recibidos++;

      if (rec.condition === 'NUEVO') nuevos++;
      else if (rec.condition === 'USADO') usados++;
    });

    return { sugeridos, aprobados, enTransito, recibidos, nuevos, usados, totalVerificados: nuevos + usados };
  }, [suggestions, workflowMap]);

  // Export transfers to Excel
  const handleExportTransfers = () => {
    const wb = XLSX.utils.book_new();
    const rows = filtered.map((t) => {
      const rec = getRecord(t);
      return {
        'Estado Traslado': rec.status,
        'Prioridad': t.Prioridad,
        'Referencia / SKU': t.Referencia,
        'Marca': t.Marca,
        'Departamento': t.Departamento,
        'Talla': t.Talla,
        'Tienda Origen': t.TiendaOrigen,
        'Stock en Origen': t.StockOrigen,
        'Tienda Destino': t.TiendaDestino,
        'Stock en Destino': t.StockDestino,
        'Cantidad Sugerida': t.UnidadesSugeridas,
        'Cantidad Despachada Real': rec.dispatchedUnits,
        'Cantidad Recibida Real': rec.receivedUnits,
        'Discrepancia': rec.dispatchedUnits - t.UnidadesSugeridas,
        'Condición Física': rec.condition || 'SIN VERIFICAR',
        'Última Actualización': rec.updatedAt,
      };
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    ws['!cols'] = [
      { wch: 16 }, // Estado
      { wch: 12 }, // Prioridad
      { wch: 20 }, // SKU
      { wch: 15 }, // Marca
      { wch: 16 }, // Depto
      { wch: 10 }, // Talla
      { wch: 22 }, // Origen
      { wch: 14 }, // Stock Origen
      { wch: 22 }, // Destino
      { wch: 14 }, // Stock Destino
      { wch: 16 }, // Sugerida
      { wch: 22 }, // Despachada Real
      { wch: 22 }, // Recibida Real
      { wch: 14 }, // Discrepancia
      { wch: 18 }, // Condicion
      { wch: 24 }, // Fecha
    ];

    XLSX.utils.book_append_sheet(wb, ws, 'Rebalanceo_SPEC_Trazabilidad');
    XLSX.writeFile(wb, `SPEC_Traslados_Trazabilidad_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header Bento Banner */}
      <motion.div
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.15, ease: 'easeOut' }}
        className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-white p-4 sm:p-5 rounded-xl border border-zinc-200/90 shadow-xs"
      >
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-zinc-900" />
            <h2 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight">
              Motor de Rebalanceo Logístico &amp; Despacho Inter-Tienda
            </h2>
            <CardInfoButton
              title="Ciclo Operativo de Rebalanceo"
              description="Gestiona las órdenes desde su sugerencia matemática hasta la confirmación física en bodega: Sugerido ➔ Aprobado ➔ En Tránsito ➔ Recibido."
              formula="Prioridad = Quiebre en Destino & Excedente en Origen (sin vulnerar stock de seguridad)"
              operationalImpact="Permite auditar discrepancias entre unidades sugeridas, despachadas y recibidas en destino."
            />
          </div>
          <p className="text-xs text-zinc-500 mt-1">
            Optimización por DDI, curvas rotas, consolidación comercial y trazabilidad con verificación física
          </p>
        </div>

        {/* Action Controls & Mode Switcher */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Perspective Switcher: Planner vs Tienda */}
          <div className="bg-zinc-100 p-0.5 rounded-lg border border-zinc-200 flex items-center text-xs">
            <button
              type="button"
              onClick={() => setPerspective('PLANNER')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                perspective === 'PLANNER'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-zinc-700" />
              <span>Vista Planner Central</span>
            </button>
            <button
              type="button"
              onClick={() => setPerspective('OPERADOR_TIENDA')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                perspective === 'OPERADOR_TIENDA'
                  ? 'bg-white text-zinc-900 shadow-xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-zinc-700" />
              <span>Modo Operativo Tienda</span>
            </button>
          </div>

          {/* Simulation Controls */}
          {!isSimulationActive ? (
            <button
              type="button"
              onClick={() => onToggleSimulation(true)}
              disabled={suggestions.length === 0}
              className="inline-flex items-center gap-1.5 h-8 px-3 bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Simular impacto en inventario antes de aplicar definitivamente"
            >
              <Eye className="w-3.5 h-3.5 text-white" />
              <span>Simular Traslados</span>
            </button>
          ) : (
            <span className="inline-flex items-center gap-1.5 h-8 px-3 bg-purple-50 text-purple-800 border border-purple-200 text-xs font-semibold rounded-lg shadow-2xs">
              <Eye className="w-3.5 h-3.5 text-purple-700 animate-pulse" />
              <span>Simulación Activa</span>
            </span>
          )}

          {/* Packing List Modal */}
          <button
            type="button"
            onClick={() => setIsPackingListOpen(true)}
            disabled={filtered.length === 0}
            className="inline-flex items-center gap-1.5 h-8 px-3 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer disabled:opacity-40"
          >
            <FileText className="w-3.5 h-3.5 text-zinc-500" />
            <span>Guía Transferencia</span>
          </button>

          {/* Export button */}
          <button
            type="button"
            onClick={handleExportTransfers}
            disabled={filtered.length === 0}
            className="inline-flex items-center gap-1.5 h-8 px-3 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5 text-zinc-500" />
            <span>Exportar (.xlsx)</span>
          </button>

          {/* Purchase Suggester */}
          <button
            type="button"
            onClick={() => setIsPurchasePlanOpen(true)}
            className="inline-flex items-center gap-1.5 h-8 px-3 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Sugerido Compra</span>
          </button>
        </div>
      </motion.div>

      {/* Notification / Toast Banner */}
      {(executedToast || localToast) && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-medium flex items-center justify-between shadow-2xs"
        >
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{executedToast || localToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setLocalToast(null)}
            className="text-xs text-emerald-700 hover:text-emerald-950 font-bold ml-3 cursor-pointer"
          >
            ✕
          </button>
        </motion.div>
      )}

      {/* Single Consolidated Simulation Active Banner */}
      {isSimulationActive && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-purple-50 border border-purple-200 rounded-xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-lg bg-purple-100 text-purple-700 border border-purple-200 shrink-0">
              <Truck className="w-5 h-5 animate-pulse text-purple-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-800 bg-purple-100 px-3 py-0.5 rounded-full border border-purple-200 font-mono">
                  Modo Vista Previa de Traslados Activo
                </span>
                <span className="text-[11px] text-purple-700 font-mono font-bold">
                  {suggestions.length} Órdenes • {totalPiezas.toLocaleString()} Unidades
                </span>
              </div>
              <p className="text-xs text-purple-900 mt-1">
                Visualizando impacto proyectado en Cuadro de Mando, Curvas y Alertas. Al confirmar, las unidades se transferirán efectivamente al inventario real.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 w-full md:w-auto justify-end">
            <button
              type="button"
              onClick={() => onToggleSimulation(false)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-white hover:bg-zinc-50 text-zinc-700 text-xs font-bold rounded-lg border border-zinc-200 shadow-2xs transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-zinc-600" />
              <span>Restablecer Original</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onConfirmExecute();
                setActiveViewMode('RECIBIDOS');
              }}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 text-white" />
              <span>Confirmar y Aplicar al Inventario</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* 4 KPI Tiles with Descriptions & Info Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white p-4.5 rounded-xl border border-zinc-200/80 shadow-2xs flex flex-col justify-between relative">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider">
              Órdenes de Rebalanceo
            </span>
            <CardInfoButton
              title="Órdenes de Traslado"
              description="Pares de origen-destino detectados con viabilidad de rebalanceo sin vulnerar el stock de seguridad de la tienda donante."
            />
          </div>
          <div className="my-2.5">
            <div className="text-3xl font-bold text-zinc-900 tracking-tight tabular-nums font-mono">
              {suggestions.length}
            </div>
            <div className="w-full bg-[#F4F2FD] h-2 rounded-full mt-2.5 overflow-hidden">
              <div className="bg-indigo-600 h-full w-full rounded-full" />
            </div>
          </div>
          <p className="text-[11px] text-zinc-500">
            {stats.sugeridos} sugeridas • {stats.aprobados} aprobadas
          </p>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-4.5 rounded-xl border border-zinc-200/80 shadow-2xs flex flex-col justify-between relative">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">
              Unidades a Movilizar
            </span>
            <CardInfoButton
              title="Piezas a Rebalancear"
              description="Suma total de pares y prendas a transferir para recuperar curvas de tallas rotas en tiendas con alta demanda."
            />
          </div>
          <div className="my-2.5">
            <div className="text-3xl font-bold text-emerald-600 tracking-tight tabular-nums font-mono">
              {totalPiezas.toLocaleString()} <span className="text-xs text-zinc-400 font-normal">uds</span>
            </div>
            <div className="w-full bg-[#F4F2FD] h-2 rounded-full mt-2.5 overflow-hidden">
              <div className="bg-emerald-500 h-full w-4/5 rounded-full" />
            </div>
          </div>
          <p className="text-[11px] text-zinc-500">Recuperación de frentes comerciales</p>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-4.5 rounded-xl border border-zinc-200/80 shadow-2xs flex flex-col justify-between relative">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">
              Condición en Campo
            </span>
            <CardInfoButton
              title="Condición del Producto (Nuevo / Usado)"
              description="Prendas y pares recolectados cuya condición física ha sido verificada y tildada por el usuario en bodega."
            />
          </div>
          <div className="my-2.5">
            <div className="text-3xl font-bold text-amber-700 tracking-tight tabular-nums font-mono">
              {stats.totalVerificados} / {suggestions.length}
            </div>
            <div className="w-full bg-[#F4F2FD] h-2 rounded-full mt-2.5 overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full transition-all"
                style={{
                  width: `${Math.min(100, (stats.totalVerificados / Math.max(1, suggestions.length)) * 100)}%`,
                }}
              />
            </div>
          </div>
          <p className="text-[11px] text-zinc-500">{stats.nuevos} nuevos • {stats.usados} usados</p>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-4.5 rounded-xl border border-zinc-200/80 shadow-2xs flex flex-col justify-between relative">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider">
              En Tránsito / Recibidos
            </span>
            <CardInfoButton
              title="Trazabilidad y Despacho"
              description="Control de traslados que ya salieron de tienda donante (en tránsito) y completados exitosamente en destino."
            />
          </div>
          <div className="my-2.5">
            <div className="text-3xl font-bold text-indigo-600 tracking-tight tabular-nums font-mono">
              {stats.recibidos} <span className="text-xs text-zinc-400 font-normal">/ {suggestions.length}</span>
            </div>
            <div className="w-full bg-[#F4F2FD] h-2 rounded-full mt-2.5 overflow-hidden">
              <div
                className="bg-indigo-600 h-full rounded-full transition-all"
                style={{
                  width: `${Math.min(100, (stats.recibidos / Math.max(1, suggestions.length)) * 100)}%`,
                }}
              />
            </div>
          </div>
          <p className="text-[11px] text-zinc-500">{stats.enTransito} en camino • {stats.recibidos} recibidos</p>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VISTA 1: MODO OPERATIVO TIENDA / BODEGA (Enfocado por sucursal) */}
      {/* ========================================================================= */}
      {perspective === 'OPERADOR_TIENDA' && (
        <div className="bg-white border border-zinc-200/90 rounded-2xl p-5 shadow-xs space-y-6">
          {/* Store Selector for Store Staff */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-zinc-50 rounded-xl border border-zinc-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-zinc-900 text-white flex items-center justify-center shrink-0">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-zinc-500">
                  Panel de Campo // Operador
                </span>
                <h3 className="text-sm font-bold text-zinc-900">
                  Selecciona tu Tienda para Despachar o Recibir
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={operatorStore}
                onChange={(e) => setOperatorStore(e.target.value)}
                className="h-9 bg-white border border-zinc-300 text-xs font-semibold text-zinc-900 rounded-lg px-3 shadow-xs focus:outline-none focus:border-zinc-500 cursor-pointer"
              >
                {stores.map((st) => (
                  <option key={st} value={st}>
                    🏬 {st}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Two-Column Task Layout: Outgoing vs Incoming */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Column 1: Salidas por Despachar (Donante) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
                <div className="flex items-center gap-2 text-zinc-900 font-bold text-sm">
                  <Send className="w-4 h-4 text-amber-600" />
                  <span>1. Mercancía a Preparar &amp; Despachar (Salidas)</span>
                </div>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                  {outgoingTransfers.length} ítems
                </span>
              </div>

              {outgoingTransfers.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 bg-zinc-50 rounded-xl border border-dashed border-zinc-200 text-xs">
                  No hay mercancía asignada para despacho desde esta sucursal hoy.
                </div>
              ) : (
                <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1 custom-scrollbar">
                  {outgoingTransfers.map((t) => {
                    const rec = getRecord(t);
                    const isDispatched = rec.status === 'EN_TRANSITO' || rec.status === 'RECIBIDO';

                    return (
                      <div
                        key={t.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isDispatched
                            ? 'bg-zinc-50/80 border-zinc-200 opacity-60'
                            : 'bg-white border-zinc-200/90 shadow-2xs hover:border-zinc-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase">
                              {t.Marca} • {t.Departamento}
                            </span>
                            <div className="font-mono font-bold text-zinc-900 text-sm">{t.Referencia}</div>
                            <div className="text-xs text-zinc-600 mt-0.5">
                              Talla: <strong className="font-mono text-zinc-900">{t.Talla}</strong> | Destino: <strong className="text-emerald-700">{t.TiendaDestino}</strong>
                            </div>
                          </div>

                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${
                              rec.status === 'EN_TRANSITO'
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : rec.status === 'RECIBIDO'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-blue-50 text-blue-800 border-blue-200'
                            }`}
                          >
                            {rec.status}
                          </span>
                        </div>

                        {/* Condition Check & Units */}
                        <div className="mt-3 pt-3 border-t border-zinc-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                          {/* Nuevo / Usado */}
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] text-zinc-500">Condición:</span>
                            <button
                              type="button"
                              onClick={() => handleToggleCondition(t.id, 'NUEVO')}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer ${
                                rec.condition === 'NUEVO'
                                  ? 'bg-emerald-600 text-white border-emerald-600'
                                  : 'bg-white text-zinc-700 border-zinc-300'
                              }`}
                            >
                              Nuevo
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleCondition(t.id, 'USADO')}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer ${
                                rec.condition === 'USADO'
                                  ? 'bg-amber-600 text-white border-amber-600'
                                  : 'bg-white text-zinc-700 border-zinc-300'
                              }`}
                            >
                              Usado
                            </button>
                          </div>

                          {/* Unit counter with discrepancy adjustment */}
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] text-zinc-500">Despachar:</span>
                            <div className="inline-flex items-center border border-zinc-300 rounded-lg overflow-hidden bg-white shadow-2xs">
                              <button
                                type="button"
                                onClick={() => handleUpdateUnits(t.id, 'dispatched', -1)}
                                className="px-1.5 py-0.5 hover:bg-zinc-100 text-zinc-600 cursor-pointer"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-2 font-mono font-bold text-xs text-zinc-900">
                                {rec.dispatchedUnits}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUpdateUnits(t.id, 'dispatched', 1)}
                                className="px-1.5 py-0.5 hover:bg-zinc-100 text-zinc-600 cursor-pointer"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                            <span className="text-[10px] text-zinc-400 font-mono">/ {t.UnidadesSugeridas} sug</span>
                          </div>
                        </div>

                        {/* Action: Mark En Tránsito */}
                        {!isDispatched && (
                          <div className="mt-3">
                            <button
                              type="button"
                              onClick={() => handleUpdateStatus(t.id, 'EN_TRANSITO')}
                              className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                            >
                              <Truck className="w-3.5 h-3.5" />
                              <span>Marcar como Despachado (En Tránsito)</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Column 2: Entradas por Recibir (Destino) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
                <div className="flex items-center gap-2 text-zinc-900 font-bold text-sm">
                  <Inbox className="w-4 h-4 text-emerald-600" />
                  <span>2. Mercancía por Recibir en Tienda (Entradas)</span>
                </div>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                  {incomingTransfers.length} ítems
                </span>
              </div>

              {incomingTransfers.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 bg-zinc-50 rounded-xl border border-dashed border-zinc-200 text-xs">
                  No hay envíos programados hacia esta sucursal actualmente.
                </div>
              ) : (
                <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1 custom-scrollbar">
                  {incomingTransfers.map((t) => {
                    const rec = getRecord(t);
                    const isReceived = rec.status === 'RECIBIDO';

                    return (
                      <div
                        key={t.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isReceived
                            ? 'bg-emerald-50/50 border-emerald-200'
                            : 'bg-white border-zinc-200/90 shadow-2xs hover:border-zinc-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase">
                              Origen: {t.TiendaOrigen}
                            </span>
                            <div className="font-mono font-bold text-zinc-900 text-sm">{t.Referencia}</div>
                            <div className="text-xs text-zinc-600 mt-0.5">
                              Talla: <strong className="font-mono text-zinc-900">{t.Talla}</strong> | Esperado: <strong className="font-mono text-zinc-900">{rec.dispatchedUnits} uds</strong>
                            </div>
                          </div>

                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase border ${
                              isReceived
                                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                : rec.status === 'EN_TRANSITO'
                                ? 'bg-amber-50 text-amber-800 border-amber-200 animate-pulse'
                                : 'bg-zinc-100 text-zinc-700 border-zinc-200'
                            }`}
                          >
                            {isReceived ? '✓ RECIBIDO' : rec.status}
                          </span>
                        </div>

                        {/* Confirmation of Received Goods */}
                        <div className="mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
                          <div className="text-xs text-zinc-500">
                            Condición reportada: <strong className="text-zinc-800">{rec.condition || 'N/A'}</strong>
                          </div>

                          {!isReceived ? (
                            <button
                              type="button"
                              onClick={() => handleUpdateStatus(t.id, 'RECIBIDO')}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Confirmar Recepción</span>
                            </button>
                          ) : (
                            <span className="text-xs font-bold text-emerald-700 font-mono flex items-center gap-1">
                              <Check className="w-4 h-4" /> Ingresado al Stock
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VISTA 2: VISTA PLANNER CENTRAL (Tabla Maestra & Gestión Global) */}
      {/* ========================================================================= */}
      {perspective === 'PLANNER' && (
        <div className="space-y-4">
          {/* Filters & Bulk Operations Toolbar */}
          <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-zinc-200/90 shadow-xs space-y-3">
            {/* Top Toolbar Row: View Mode Switcher & Quick Legend */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-100">
              <div className="flex items-center gap-1.5 p-1 bg-zinc-100 rounded-lg border border-zinc-200 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveViewMode('PENDIENTES')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activeViewMode === 'PENDIENTES'
                      ? 'bg-white text-zinc-900 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>Órdenes Pendientes</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800">
                    {stats.sugeridos + stats.aprobados + stats.enTransito}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveViewMode('RECIBIDOS')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activeViewMode === 'RECIBIDOS'
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Historial Recibidos</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    {stats.recibidos}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveViewMode('TODOS')}
                  className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activeViewMode === 'TODOS'
                      ? 'bg-white text-zinc-900 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  <span>Todas</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-zinc-200 text-zinc-800">
                    {suggestions.length}
                  </span>
                </button>
              </div>

              {/* Status Explanation Pills */}
              <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-zinc-500">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> Aprobado: Reservado</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" /> En Tránsito: Despachado</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Recibido: Stock Transferido</span>
              </div>
            </div>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 flex-1">
              {/* Prioridad */}
              <div>
                <label className="block text-[10px] font-semibold text-zinc-500 mb-1 uppercase tracking-wider">
                  Prioridad
                </label>
                <select
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="w-full h-8 bg-zinc-50 border border-zinc-200 text-xs text-zinc-900 rounded-lg px-2 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer"
                >
                  <option value="TODAS">Todas</option>
                  <option value="ALTA">Alta</option>
                  <option value="MEDIA">Media</option>
                  <option value="NORMAL">Normal</option>
                </select>
              </div>

              {/* Estado de Flujo */}
              <div>
                <label className="block text-[10px] font-semibold text-zinc-500 mb-1 uppercase tracking-wider">
                  Estado
                </label>
                <select
                  value={filterStage}
                  onChange={(e) => setFilterStage(e.target.value)}
                  className="w-full h-8 bg-zinc-50 border border-zinc-200 text-xs text-zinc-900 rounded-lg px-2 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer"
                >
                  <option value="TODAS">Todos los Estados</option>
                  <option value="SUGERIDO">Sugerido</option>
                  <option value="APROBADO">Aprobado</option>
                  <option value="EN_TRANSITO">En Tránsito</option>
                  <option value="RECIBIDO">Recibido</option>
                </select>
              </div>

              {/* Tienda Origen */}
              <div>
                <label className="block text-[10px] font-semibold text-zinc-500 mb-1 uppercase tracking-wider">
                  Origen
                </label>
                <select
                  value={selectedSource}
                  onChange={(e) => setSelectedSource(e.target.value)}
                  className="w-full h-8 bg-zinc-50 border border-zinc-200 text-xs text-zinc-900 rounded-lg px-2 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer"
                >
                  <option value="TODAS">Todas las Tiendas</option>
                  {stores.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              {/* Tienda Destino */}
              <div>
                <label className="block text-[10px] font-semibold text-zinc-500 mb-1 uppercase tracking-wider">
                  Destino
                </label>
                <select
                  value={selectedTarget}
                  onChange={(e) => setSelectedTarget(e.target.value)}
                  className="w-full h-8 bg-zinc-50 border border-zinc-200 text-xs text-zinc-900 rounded-lg px-2 shadow-2xs focus:outline-none focus:border-zinc-400 cursor-pointer"
                >
                  <option value="TODAS">Todas las Tiendas</option>
                  {stores.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Bulk Stage Buttons */}
            <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-zinc-100">
              <span className="text-[10px] font-mono text-zinc-400 uppercase hidden sm:inline mr-1">
                Acciones Masivas:
              </span>
              <button
                type="button"
                onClick={() => handleBulkSetStatus('APROBADO')}
                className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-lg text-xs font-semibold cursor-pointer"
                title="Aprobar todas las órdenes mostradas para despacho"
              >
                Aprobar Todas
              </button>
              <button
                type="button"
                onClick={() => handleBulkSetStatus('EN_TRANSITO')}
                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-xs font-semibold cursor-pointer"
                title="Marcar todas las órdenes mostradas como despachadas"
              >
                Marcar En Tránsito
              </button>
              <button
                type="button"
                onClick={() => handleBulkSetStatus('RECIBIDO')}
                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold cursor-pointer"
                title="Confirmar recepción física de todas las órdenes mostradas"
              >
                Marcar Recibidas
              </button>
            </div>
          </div>
        </div>

          {/* Interactive Collapsible Table */}
          <div className="bg-white rounded-xl border border-zinc-200/90 shadow-xs overflow-hidden">
            <div
              onClick={() => setIsListOpen((prev) => !prev)}
              className={`px-4 sm:px-6 py-4 bg-[#F4F2FD] hover:bg-[#ECE8FB] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none ${
                isListOpen ? 'border-b border-zinc-200' : ''
              }`}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setIsListOpen((prev) => !prev);
                }
              }}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 border border-indigo-200 flex items-center justify-center shrink-0">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold font-mono text-zinc-900 uppercase tracking-wider">
                      📦 LISTADO DE TRASLADOS Y RECOLECCIÓN
                    </h3>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-white text-zinc-800 rounded-full border border-zinc-200 shadow-2xs">
                      {filtered.length} Órdenes
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-500 font-sans mt-0.5">
                    Trazabilidad por estado, condición física y ajuste de cantidades despachadas
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsListOpen((prev) => !prev);
                  }}
                  className="inline-flex items-center gap-1.5 h-8 px-3.5 bg-white hover:bg-zinc-50 text-zinc-800 border border-zinc-300 rounded-lg text-xs font-bold shadow-2xs transition-colors cursor-pointer"
                >
                  <span>{isListOpen ? 'Ocultar Listado' : 'Desplegar Listado'}</span>
                  {isListOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <AnimatePresence initial={false}>
              {isListOpen && (
                <motion.div
                  key="transfers-table-open"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2, ease: 'easeOut' }}
                  className="overflow-hidden"
                >
                  {filtered.length === 0 ? (
                    <div className="p-12 text-center text-zinc-500 space-y-3">
                      <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                      <p className="font-bold text-zinc-900 text-base">
                        {activeViewMode === 'PENDIENTES' && stats.recibidos > 0
                          ? '¡Todas las órdenes pendientes han sido procesadas!'
                          : 'No hay sugerencias de traslado con los filtros actuales'}
                      </p>
                      <p className="text-xs text-zinc-500 max-w-md mx-auto">
                        {activeViewMode === 'PENDIENTES' && stats.recibidos > 0
                          ? `Se completaron ${stats.recibidos} órdenes de traslado. El inventario real ya fue actualizado.`
                          : 'El stock entre sucursales se encuentra equilibrado o no hay donantes viables.'}
                      </p>
                      {activeViewMode === 'PENDIENTES' && stats.recibidos > 0 && (
                        <button
                          type="button"
                          onClick={() => setActiveViewMode('RECIBIDOS')}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Ver Historial de Recibidos ({stats.recibidos} órdenes)</span>
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#F4F2FD] text-zinc-600 text-[10px] font-bold font-mono uppercase tracking-wider border-b border-zinc-200">
                          <tr>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Estado Ciclo</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Prioridad</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Referencia / SKU</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Marca</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Talla</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Tienda Origen</th>
                            <th className="py-3 px-3 font-semibold whitespace-nowrap">Tienda Destino</th>
                            <th className="py-3 px-3 text-center font-semibold whitespace-nowrap">Sugerido</th>
                            <th className="py-3 px-3 text-center font-semibold whitespace-nowrap">Despachado Real</th>
                            <th className="py-3 px-3 text-center font-semibold whitespace-nowrap">Condición</th>
                            <th className="py-3 px-3 text-center font-semibold whitespace-nowrap">Acción Rápida</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-100 text-zinc-700">
                          {filtered.map((t) => {
                            const rec = getRecord(t);
                            const isAlta = t.Prioridad === 'ALTA';
                            const hasDiscrepancy = rec.dispatchedUnits !== t.UnidadesSugeridas;

                            return (
                              <tr
                                key={t.id}
                                className={`hover:bg-[#F8F7FC] transition-colors ${
                                  rec.status === 'RECIBIDO' ? 'bg-emerald-50/20' : ''
                                }`}
                              >
                                {/* Estado */}
                                <td className="py-3 px-3 whitespace-nowrap">
                                  <div className="flex flex-col gap-0.5">
                                    <select
                                      value={rec.status}
                                      onChange={(e) => handleUpdateStatus(t.id, e.target.value as OperationalStage)}
                                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase border cursor-pointer ${
                                        rec.status === 'RECIBIDO'
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-bold'
                                          : rec.status === 'EN_TRANSITO'
                                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                                          : rec.status === 'APROBADO'
                                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                                          : 'bg-zinc-100 text-zinc-700 border-zinc-200'
                                      }`}
                                    >
                                      <option value="SUGERIDO">Sugerido</option>
                                      <option value="APROBADO">Aprobado</option>
                                      <option value="EN_TRANSITO">En Tránsito</option>
                                      <option value="RECIBIDO">Recibido</option>
                                    </select>
                                    <span className="text-[9px] text-zinc-400 font-sans">
                                      {rec.status === 'SUGERIDO' && 'Sugerido'}
                                      {rec.status === 'APROBADO' && 'Reservado en tienda'}
                                      {rec.status === 'EN_TRANSITO' && 'En ruta'}
                                      {rec.status === 'RECIBIDO' && '✓ Stock ingresado'}
                                    </span>
                                  </div>
                                </td>

                                {/* Prioridad */}
                                <td className="py-3 px-3 whitespace-nowrap">
                                  <span
                                    className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase tracking-wider border ${
                                      isAlta
                                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                                        : 'bg-[#F4F2FD] text-zinc-700 border-zinc-200'
                                    }`}
                                  >
                                    {t.Prioridad}
                                  </span>
                                </td>

                                {/* Referencia */}
                                <td className="py-3 px-3 whitespace-nowrap font-mono font-bold text-zinc-900">
                                  {t.Referencia}
                                </td>

                                {/* Marca */}
                                <td className="py-3 px-3 whitespace-nowrap font-medium text-zinc-900">
                                  {t.Marca}
                                </td>

                                {/* Talla */}
                                <td className="py-3 px-3 whitespace-nowrap font-mono font-semibold text-zinc-800">
                                  {t.Talla}
                                </td>

                                {/* Tienda Origen */}
                                <td className="py-3 px-3 whitespace-nowrap font-medium text-zinc-800">
                                  {t.TiendaOrigen}
                                  <span className="text-[10px] text-zinc-400 font-mono ml-1">({t.StockOrigen} uds)</span>
                                </td>

                                {/* Tienda Destino */}
                                <td className="py-3 px-3 whitespace-nowrap font-medium text-emerald-800">
                                  {t.TiendaDestino}
                                  <span className="text-[10px] text-zinc-400 font-mono ml-1">({t.StockDestino} uds)</span>
                                </td>

                                {/* Cantidad Sugerida */}
                                <td className="py-3 px-3 text-center whitespace-nowrap font-mono font-bold text-zinc-700">
                                  {t.UnidadesSugeridas} uds
                                </td>

                                {/* Cantidad Despachada Real */}
                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  <div className="inline-flex items-center border border-zinc-200 rounded-md overflow-hidden bg-white">
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateUnits(t.id, 'dispatched', -1)}
                                      className="px-1 hover:bg-zinc-100 text-zinc-500 cursor-pointer"
                                    >
                                      <Minus className="w-2.5 h-2.5" />
                                    </button>
                                    <span
                                      className={`px-1.5 font-mono font-bold text-xs ${
                                        hasDiscrepancy ? 'text-amber-600 bg-amber-50' : 'text-zinc-900'
                                      }`}
                                    >
                                      {rec.dispatchedUnits}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateUnits(t.id, 'dispatched', 1)}
                                      className="px-1 hover:bg-zinc-100 text-zinc-500 cursor-pointer"
                                    >
                                      <Plus className="w-2.5 h-2.5" />
                                    </button>
                                  </div>
                                </td>

                                {/* Condición */}
                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  <div className="inline-flex items-center gap-1 p-0.5 bg-zinc-50 rounded border border-zinc-200">
                                    <button
                                      type="button"
                                      onClick={() => handleToggleCondition(t.id, 'NUEVO')}
                                      className={`px-1.5 py-0.2 rounded text-[10px] font-semibold cursor-pointer border ${
                                        rec.condition === 'NUEVO'
                                          ? 'bg-emerald-600 text-white border-emerald-600'
                                          : 'bg-white text-zinc-700 border-zinc-300'
                                      }`}
                                    >
                                      {rec.condition === 'NUEVO' ? '✓ ' : ''}Nuevo
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleToggleCondition(t.id, 'USADO')}
                                      className={`px-1.5 py-0.2 rounded text-[10px] font-semibold cursor-pointer border ${
                                        rec.condition === 'USADO'
                                          ? 'bg-amber-600 text-white border-amber-600'
                                          : 'bg-white text-zinc-700 border-zinc-300'
                                      }`}
                                    >
                                      {rec.condition === 'USADO' ? '✓ ' : ''}Usado
                                    </button>
                                  </div>
                                </td>

                                {/* Acción Rápida */}
                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  {rec.status === 'SUGERIDO' && (
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateStatus(t.id, 'APROBADO')}
                                      className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors shadow-2xs"
                                      title="Aprobar para preparación en bodega de tienda donante"
                                    >
                                      Aprobar
                                    </button>
                                  )}
                                  {rec.status === 'APROBADO' && (
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateStatus(t.id, 'EN_TRANSITO')}
                                      className="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors shadow-2xs"
                                      title="Marcar salida de bodega y viaje en camión"
                                    >
                                      Despachar
                                    </button>
                                  )}
                                  {rec.status === 'EN_TRANSITO' && (
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateStatus(t.id, 'RECIBIDO')}
                                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold cursor-pointer transition-colors shadow-2xs"
                                      title="Confirmar llegada física e ingresar unidades al inventario real"
                                    >
                                      Recibir
                                    </button>
                                  )}
                                  {rec.status === 'RECIBIDO' && (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-bold font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
                                      <Check className="w-3 h-3" /> En Destino
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Modals */}
      <PackingListModal
        isOpen={isPackingListOpen}
        onClose={() => setIsPackingListOpen(false)}
        transfers={filtered}
        suggestions={filtered}
        distances={distances}
        conditions={Object.fromEntries(
          Object.entries(workflowMap).map(([k, v]) => [k, (v as TransferRecordState)?.condition || ''])
        )}
      />

      <PurchasePlanModal
        isOpen={isPurchasePlanOpen}
        onClose={() => setIsPurchasePlanOpen(false)}
        alerts={alerts}
        inventory={inventory}
        selectedStore={selectedSource}
      />
    </div>
  );
};
