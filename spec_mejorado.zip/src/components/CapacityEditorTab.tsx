import React, { useState } from 'react';
import {
  Building2,
  CheckCircle2,
  Edit3,
  MapPin,
  Plus,
  Settings,
  Store,
  Trash2,
} from 'lucide-react';
import {
  CapacityMatrixConfig,
  StoreProfile,
} from '../types';
import {
  STORE_FORMAT_INFO,
} from '../data/defaultMatrix';
import {
  calcularTotalesMatriz,
  consolidarMatrizMarcas,
} from '../utils/analysisEngine';

interface CapacityEditorTabProps {
  config: CapacityMatrixConfig;
  onChangeConfig: (newConfig: CapacityMatrixConfig) => void;
  stores: string[];
  storeProfiles: StoreProfile[];
  storeCapacities: Record<string, CapacityMatrixConfig>;
  onUpdateStoreCapacity: (storeName: string, newConfig: CapacityMatrixConfig) => void;
  onUpdateStoreProfile?: (updatedProfile: StoreProfile) => void;
  onOpenRegisterModal: (storeToEdit?: StoreProfile | null) => void;
  onDeleteStore: (storeName: string) => void;
  selectedStore: string;
  onSelectStore: (storeName: string) => void;
}

export const CapacityEditorTab: React.FC<CapacityEditorTabProps> = ({
  config,
  onChangeConfig,
  stores = [],
  storeProfiles = [],
  storeCapacities = {},
  onOpenRegisterModal,
  onDeleteStore,
  selectedStore = 'TODAS',
  onSelectStore,
}) => {
  const [notification, setNotification] = useState<string | null>(null);
  const [storeToDelete, setStoreToDelete] = useState<string | null>(null);

  const handleConfirmDeleteStore = () => {
    if (!storeToDelete) return;
    onDeleteStore(storeToDelete);
    setNotification(`Tienda "${storeToDelete}" eliminada de la red.`);
    setTimeout(() => setNotification(null), 3000);
    setStoreToDelete(null);
  };

  // Calculate total network metrics
  let totalNetworkSkus = 0;
  let totalNetworkPieces = 0;
  stores.forEach((st) => {
    const p = storeProfiles.find((x) => x.nombre === st);
    if (p?.marcasCapacidad) {
      const c = consolidarMatrizMarcas(p.marcasCapacidad);
      const t = calcularTotalesMatriz(c);
      totalNetworkSkus += t.totalSkus;
      totalNetworkPieces += t.totalPieces;
    } else if (storeCapacities[st]) {
      const t = calcularTotalesMatriz(storeCapacities[st]);
      totalNetworkSkus += t.totalSkus;
      totalNetworkPieces += t.totalPieces;
    }
  });
  const avgNetworkDepth =
    totalNetworkSkus > 0 ? Math.round((totalNetworkPieces / totalNetworkSkus) * 10) / 10 : 0;

  return (
    <div className="space-y-6 font-sans select-none">
      {/* TOP INDUSTRIAL OVERVIEW PANEL */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-zinc-200/90 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0 text-white shadow-xs">
              <Store className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight">
                  Directorio y Matriz de Capacidad Física
                </h2>
                <span className="text-[10px] font-semibold text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200">
                  Red Centralizada
                </span>
              </div>
              <p className="text-xs text-zinc-500 mt-0.5">
                Gestión de sucursales, visual merchandising y capacidad de planta en la red
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onOpenRegisterModal(null)}
              className="h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-medium shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Registrar Nueva Tienda</span>
            </button>
          </div>
        </div>

        {notification && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>{notification}</span>
          </div>
        )}

        {/* Global Network Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-zinc-100">
          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/90">
            <span className="text-[10px] font-semibold text-zinc-500 uppercase">Tiendas de la Red</span>
            <div className="text-lg font-bold text-zinc-900 mt-0.5">{stores.length} sucursales</div>
          </div>
          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/90">
            <span className="text-[10px] font-semibold text-zinc-600 uppercase">Capacidad Red SKUs</span>
            <div className="text-lg font-bold text-zinc-900 mt-0.5">
              {totalNetworkSkus.toLocaleString()} <span className="text-xs text-zinc-400 font-normal">SKUs</span>
            </div>
          </div>
          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/90">
            <span className="text-[10px] font-semibold text-emerald-700 uppercase">Capacidad Red Piezas</span>
            <div className="text-lg font-bold text-emerald-700 mt-0.5">
              {totalNetworkPieces.toLocaleString()} <span className="text-xs text-emerald-600/70 font-normal">uds</span>
            </div>
          </div>
          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/90">
            <span className="text-[10px] font-semibold text-purple-700 uppercase">Profundidad Media Red</span>
            <div className="text-lg font-bold text-purple-800 mt-0.5">
              {avgNetworkDepth} <span className="text-xs text-purple-600/70 font-normal">uds/SKU</span>
            </div>
          </div>
        </div>
      </div>

      {/* DIRECTORY OF STORES - CLEAN SELECTOR LIST */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-2">
            <Store className="w-4 h-4 text-zinc-800" />
            Directorio de Tiendas de la Red ({stores.length})
          </span>
          <span className="text-xs text-zinc-400">
            Haz clic en «Configurar tienda» para calibrar marcas, departamentos y parámetros base
          </span>
        </div>

        {stores.length === 0 ? (
          <div className="bg-white border border-dashed border-zinc-300 rounded-2xl p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-xl bg-zinc-50 border border-zinc-200 flex items-center justify-center mx-auto text-zinc-500">
              <Store className="w-6 h-6 text-zinc-700" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-zinc-900">No hay tiendas registradas en la red</h4>
              <p className="text-xs text-zinc-500 max-w-md mx-auto mt-1">
                Registra la primera sucursal para definir marcas, capacidad y parámetros base de exhibición.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onOpenRegisterModal(null)}
              className="inline-flex items-center gap-2 h-9 px-4 bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Registrar Tienda Oficial</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {stores.map((stName) => {
              const p = storeProfiles.find((x) => x.nombre === stName);
              const fmt = p?.tipo || 'LIVE';
              const fmtInfo = STORE_FORMAT_INFO[fmt];
              const isSelectedInApp = selectedStore === stName;

              return (
                <div
                  key={stName}
                  className={`p-4 rounded-xl border bg-white transition-all flex flex-col justify-between shadow-xs ${
                    isSelectedInApp
                      ? 'border-zinc-900 ring-1 ring-zinc-900/10'
                      : 'border-zinc-200/90 hover:border-zinc-300'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-lg bg-zinc-100 border border-zinc-200 flex items-center justify-center text-base shrink-0">
                          🏬
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-bold text-zinc-900 truncate">
                            {stName}
                          </h4>
                          <span className="text-xs text-zinc-500 flex items-center gap-1 truncate">
                            <MapPin className="w-3 h-3 text-zinc-400 shrink-0" />
                            {p?.ciudad || 'Sucursal de la Red'}
                          </span>
                        </div>
                      </div>

                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-200 shrink-0">
                        {fmtInfo?.name || fmt}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-500">
                      <span>Superficie: <strong className="text-zinc-800">{p?.superficieM2 || 500} m²</strong></span>
                      {p?.direccion && (
                        <span className="truncate max-w-[140px] text-zinc-400 text-[11px]">{p.direccion}</span>
                      )}
                    </div>
                  </div>

                  {/* Actions: Configure Store & Delete */}
                  <div className="mt-4 pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenRegisterModal(p)}
                      className="h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Settings className="w-3.5 h-3.5" />
                      <span>Configurar tienda</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSelectStore(stName)}
                        title="Seleccionar esta tienda en la consola"
                        className="h-8 px-2.5 bg-white hover:bg-zinc-50 text-zinc-700 border border-zinc-200/90 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                      >
                        {isSelectedInApp ? 'Activa' : 'Seleccionar'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setStoreToDelete(stName)}
                        className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-rose-200"
                        title="Eliminar tienda de la red"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete Store Confirmation Modal */}
      {storeToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/60 backdrop-blur-sm animate-fadeIn select-none">
          <div className="bg-white border border-rose-300 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200">
                <Trash2 className="w-6 h-6 text-rose-600" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-900 uppercase">¿Eliminar Tienda?</h3>
                <p className="text-xs text-zinc-500">Esta acción removerá la sucursal de la red.</p>
              </div>
            </div>

            <p className="text-xs text-zinc-700 bg-zinc-50 p-3 rounded-xl border border-zinc-200">
              Confirmas la eliminación permanente de <strong>"{storeToDelete}"</strong>. Se borrará su configuración de capacidad, marcas e inventario asociado.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStoreToDelete(null)}
                className="h-9 px-4 bg-white hover:bg-zinc-50 border border-zinc-200/90 text-zinc-700 rounded-xl text-xs font-medium cursor-pointer shadow-xs"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteStore}
                className="h-9 px-4 bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white rounded-xl text-xs font-bold border border-rose-700 shadow-xs transition-colors cursor-pointer"
              >
                Confirmar Eliminación
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
