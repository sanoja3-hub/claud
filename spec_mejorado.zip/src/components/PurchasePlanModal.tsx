import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Download,
  FileSpreadsheet,
  Building2,
  Tag,
  Boxes,
  TrendingUp,
  Layers,
  ChevronRight,
  ChevronDown,
  ShoppingBag,
} from 'lucide-react';
import {
  generarSugeridoCompraInteligente,
  exportarSugeridoCompraExcel,
  exportarSugeridoCompraCSV,
  PurchaseHierarchyNode,
} from '../utils/purchaseSuggester';
import { InventoryAlert, InventoryItem } from '../types';

interface PurchasePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: InventoryAlert[];
  inventory: InventoryItem[];
  initialStore?: string;
  stores?: string[];
}

export const PurchasePlanModal: React.FC<PurchasePlanModalProps> = ({
  isOpen,
  onClose,
  alerts,
  inventory,
  initialStore = 'TODAS',
  stores = [],
}) => {
  const [selectedStore, setSelectedStore] = useState<string>(initialStore);
  const [selectedBrand, setSelectedBrand] = useState<string>('TODAS');
  const [selectedDept, setSelectedDept] = useState<string>('TODOS');
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());

  // Generar cálculo de sugerido de compra
  const calculationResult = useMemo(() => {
    return generarSugeridoCompraInteligente(alerts, inventory, selectedStore);
  }, [alerts, inventory, selectedStore]);

  // Lista de marcas disponibles
  const availableBrands = useMemo(() => {
    const set = new Set<string>();
    (calculationResult?.flatRows || []).forEach((r) => {
      if (r?.Marca) set.add(r.Marca);
    });
    return ['TODAS', ...Array.from(set).sort()];
  }, [calculationResult?.flatRows]);

  // Filtrar filas planas según filtros secundarios de la modal
  const filteredRows = useMemo(() => {
    return (calculationResult?.flatRows || []).filter((r) => {
      if (selectedBrand !== 'TODAS' && r.Marca !== selectedBrand) return false;
      if (selectedDept !== 'TODOS' && r.Departamento !== selectedDept) return false;
      return true;
    });
  }, [calculationResult.flatRows, selectedBrand, selectedDept]);

  // Totales filtrados
  const filteredTotalUnits = useMemo(() => {
    return filteredRows.reduce((acc, r) => acc + r.UnidadesSugeridas, 0);
  }, [filteredRows]);

  const filteredTotalStock = useMemo(() => {
    return filteredRows.reduce((acc, r) => acc + r.StockActual, 0);
  }, [filteredRows]);

  const filteredTotalSkus = useMemo(() => {
    return filteredRows.reduce((acc, r) => acc + (r.SkusCount || 0), 0);
  }, [filteredRows]);

  // Manejo de expansión de nodos del árbol
  const toggleNode = (nodeId: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) next.delete(nodeId);
      else next.add(nodeId);
      return next;
    });
  };

  const expandAll = () => {
    const all = new Set<string>();
    const recurse = (nodes?: PurchaseHierarchyNode[]) => {
      (nodes || []).forEach((n) => {
        if (!n) return;
        all.add(n.id);
        if (n.children && Array.isArray(n.children)) recurse(n.children);
      });
    };
    recurse(calculationResult?.hierarchyTree || []);
    setExpandedNodes(all);
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  // Exportar Excel
  const handleExportExcel = () => {
    const storeLabel = selectedStore !== 'TODAS' ? `_${selectedStore.replace(/\s+/g, '_')}` : '_Red_Total';
    const dateStr = new Date().toISOString().split('T')[0];
    exportarSugeridoCompraExcel(filteredRows, `Sugerido_Compra_Unidades${storeLabel}_${dateStr}.xlsx`);
  };

  // Exportar CSV
  const handleExportCSV = () => {
    const storeLabel = selectedStore !== 'TODAS' ? `_${selectedStore.replace(/\s+/g, '_')}` : '_Red_Total';
    const dateStr = new Date().toISOString().split('T')[0];
    exportarSugeridoCompraCSV(filteredRows, `Sugerido_Compra_Unidades${storeLabel}_${dateStr}.csv`);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-zinc-950/60 backdrop-blur-xs"
        />

        {/* Modal Dialog */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97, y: 10 }}
          transition={{ duration: 0.18, ease: 'easeOut' }}
          className="relative z-10 bg-white border border-zinc-200/90 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-zinc-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-zinc-50/50 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 text-white flex items-center justify-center shrink-0 shadow-xs">
                <ShoppingBag className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight">
                    Sugerido de Compra Inteligente (Unidades)
                  </h2>
                  <span className="text-[10px] font-mono font-bold uppercase bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full">
                    {filteredTotalUnits.toLocaleString()} UDS TOTALES
                  </span>
                  <span className="text-[10px] font-mono font-bold uppercase bg-indigo-50 text-indigo-800 border border-indigo-200 px-2 py-0.5 rounded-full">
                    {filteredTotalSkus.toLocaleString()} SKUS
                  </span>
                </div>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Matriz de compras y reposición a proveedores según velocidad de venta, temporada y balance de curvas
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                type="button"
                onClick={handleExportExcel}
                className="inline-flex items-center gap-1.5 h-8.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                title="Descargar Excel estructurado con 2 hojas: Resumen Jerárquico y Matriz Plana"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Exportar</span> Excel (.xlsx)
              </button>

              <button
                type="button"
                onClick={handleExportCSV}
                className="inline-flex items-center gap-1.5 h-8.5 px-3 bg-white hover:bg-zinc-50 text-zinc-700 border border-zinc-200/90 text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
                title="Descargar datos tabulares en CSV delimitado"
              >
                <Download className="w-3.5 h-3.5 text-zinc-500" />
                <span>CSV</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-8.5 h-8.5 rounded-lg flex items-center justify-center text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* KPI Bar & Filters Bar */}
          <div className="px-4 sm:px-5 py-3 border-b border-zinc-100 bg-white grid grid-cols-1 md:grid-cols-4 gap-3 shrink-0">
            {/* Filter: Store */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-1 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-zinc-400" />
                <span>Tienda Objetivo</span>
              </label>
              <select
                value={selectedStore}
                onChange={(e) => setSelectedStore(e.target.value)}
                className="w-full text-xs font-medium bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900 cursor-pointer"
              >
                <option value="TODAS">TODAS LAS TIENDAS (RED COMPLETA)</option>
                {stores.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter: Brand */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-1 flex items-center gap-1">
                <Tag className="w-3 h-3 text-zinc-400" />
                <span>Marca</span>
              </label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full text-xs font-medium bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900 cursor-pointer"
              >
                {availableBrands.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter: Department */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-1 flex items-center gap-1">
                <Layers className="w-3 h-3 text-zinc-400" />
                <span>División / Depto</span>
              </label>
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full text-xs font-medium bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-1 focus:ring-zinc-900 cursor-pointer"
              >
                <option value="TODOS">TODAS LAS DIVISIONES</option>
                <option value="CALZADO">CALZADO</option>
                <option value="TEXTIL">TEXTIL</option>
                <option value="ACCESORIOS">ACCESORIOS</option>
              </select>
            </div>

            {/* Fast Summary Metrics */}
            <div className="bg-zinc-50 border border-zinc-200/80 rounded-lg px-3 py-1.5 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block font-mono">
                  Sugerido Neto
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-base font-bold text-zinc-900 tabular-nums font-mono">
                    {filteredTotalUnits.toLocaleString()} <span className="text-[11px] font-normal text-zinc-500">Uds</span>
                  </span>
                  <span className="text-[10px] font-mono font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-1.5 py-0.5 rounded">
                    {filteredTotalSkus.toLocaleString()} SKUs
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block font-mono">
                  Stock Físico
                </span>
                <span className="text-xs font-semibold text-zinc-600 tabular-nums font-mono">
                  {filteredTotalStock.toLocaleString()} Uds
                </span>
              </div>
            </div>
          </div>

          {/* Sub-header Controls for Tree View */}
          <div className="px-4 sm:px-5 py-2 bg-zinc-50/70 border-b border-zinc-100 flex items-center justify-between text-xs text-zinc-600 shrink-0">
            <span className="font-semibold text-zinc-800 flex items-center gap-1.5">
              <Boxes className="w-3.5 h-3.5 text-zinc-500" />
              <span>Estructura Jerárquica de Compras (Tienda &gt; Marca &gt; Depto &gt; Género &gt; Familia)</span>
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={expandAll}
                className="text-[11px] text-zinc-600 hover:text-zinc-900 font-medium hover:underline cursor-pointer"
              >
                Expandir Todo
              </button>
              <span className="text-zinc-300">|</span>
              <button
                type="button"
                onClick={collapseAll}
                className="text-[11px] text-zinc-600 hover:text-zinc-900 font-medium hover:underline cursor-pointer"
              >
                Colapsar Todo
              </button>
            </div>
          </div>

          {/* Tree View Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 divide-y divide-zinc-100">
            {calculationResult.hierarchyTree.length === 0 ? (
              <div className="py-12 text-center text-zinc-400 text-xs">
                No se encontraron requerimientos de compra para los filtros seleccionados.
              </div>
            ) : (
              calculationResult.hierarchyTree
                .filter((storeNode) => selectedStore === 'TODAS' || storeNode.name.toUpperCase() === selectedStore.toUpperCase())
                .map((storeNode) => (
                  <div key={storeNode.id} className="pt-3 first:pt-0 space-y-2">
                    {/* Level 1: Tienda */}
                    <div
                      onClick={() => toggleNode(storeNode.id)}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-100/80 hover:bg-zinc-200/70 transition-colors cursor-pointer border border-zinc-200/90"
                    >
                      <div className="flex items-center gap-2">
                        {expandedNodes.has(storeNode.id) ? (
                          <ChevronDown className="w-4 h-4 text-zinc-700" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-zinc-500" />
                        )}
                        <Building2 className="w-4 h-4 text-zinc-700" />
                        <span className="text-xs font-bold text-zinc-900 font-mono tracking-tight uppercase">
                          TIENDA: {storeNode.name}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[11px] font-mono text-zinc-500">
                          Stock: {storeNode.stockActual.toLocaleString()} uds
                        </span>
                        <span className="text-xs font-bold font-mono px-2.5 py-0.5 rounded-full bg-zinc-900 text-white">
                          {storeNode.unidadesSugeridas.toLocaleString()} UDS A PEDIR
                        </span>
                        {storeNode.skusCount !== undefined && storeNode.skusCount > 0 && (
                          <span className="text-xs font-bold font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                            {storeNode.skusCount.toLocaleString()} {storeNode.skusCount === 1 ? 'SKU' : 'SKUs'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Level 2: Marcas */}
                    {expandedNodes.has(storeNode.id) && storeNode.children && (
                      <div className="pl-4 sm:pl-6 space-y-2 border-l-2 border-zinc-200 ml-3">
                        {storeNode.children
                          .filter((b) => selectedBrand === 'TODAS' || b.name === selectedBrand)
                          .map((brandNode) => (
                            <div key={brandNode.id} className="space-y-1.5">
                              <div
                                onClick={() => toggleNode(brandNode.id)}
                                className="flex items-center justify-between p-2 rounded-lg bg-white hover:bg-zinc-50 border border-zinc-200/80 transition-colors cursor-pointer"
                              >
                                <div className="flex items-center gap-2">
                                  {expandedNodes.has(brandNode.id) ? (
                                    <ChevronDown className="w-3.5 h-3.5 text-zinc-600" />
                                  ) : (
                                    <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
                                  )}
                                  <Tag className="w-3.5 h-3.5 text-zinc-600" />
                                  <span className="text-xs font-bold text-zinc-900 font-mono tracking-tight">
                                    {brandNode.name}
                                  </span>
                                </div>

                                <div className="flex items-center gap-3">
                                  <div className="w-20 bg-zinc-100 rounded-full h-1.5 overflow-hidden hidden sm:block">
                                    <div
                                      className="bg-emerald-500 h-1.5 rounded-full"
                                      style={{
                                        width: `${Math.min(100, (brandNode.unidadesSugeridas / (storeNode.unidadesSugeridas || 1)) * 100)}%`,
                                      }}
                                    />
                                  </div>
                                  <span className="text-xs font-bold font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.2 rounded">
                                    {brandNode.unidadesSugeridas.toLocaleString()} uds
                                  </span>
                                  {brandNode.skusCount !== undefined && brandNode.skusCount > 0 && (
                                    <span className="text-[11px] font-mono font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded">
                                      {brandNode.skusCount.toLocaleString()} {brandNode.skusCount === 1 ? 'SKU' : 'SKUs'}
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Level 3: Departamentos */}
                              {expandedNodes.has(brandNode.id) && brandNode.children && (
                                <div className="pl-4 sm:pl-6 space-y-1.5 border-l-2 border-zinc-200 ml-2">
                                  {brandNode.children
                                    .filter((d) => selectedDept === 'TODOS' || d.name === selectedDept)
                                    .map((deptNode) => (
                                      <div key={deptNode.id} className="space-y-1">
                                        <div
                                          onClick={() => toggleNode(deptNode.id)}
                                          className="flex items-center justify-between p-1.5 rounded-md bg-zinc-50/70 hover:bg-zinc-100/80 border border-zinc-200/70 cursor-pointer"
                                        >
                                          <div className="flex items-center gap-1.5 text-xs text-zinc-800 font-semibold">
                                            {expandedNodes.has(deptNode.id) ? (
                                              <ChevronDown className="w-3 h-3 text-zinc-500" />
                                            ) : (
                                              <ChevronRight className="w-3 h-3 text-zinc-400" />
                                            )}
                                            <Layers className="w-3 h-3 text-zinc-500" />
                                            <span>{deptNode.name}</span>
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <span className="text-[11px] font-mono font-semibold text-zinc-700">
                                              {deptNode.unidadesSugeridas.toLocaleString()} uds
                                            </span>
                                            {deptNode.skusCount !== undefined && deptNode.skusCount > 0 && (
                                              <span className="text-[10px] font-mono font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded">
                                                {deptNode.skusCount.toLocaleString()} {deptNode.skusCount === 1 ? 'SKU' : 'SKUs'}
                                              </span>
                                            )}
                                          </div>
                                        </div>

                                        {/* Level 4: Secciones (Género) & Level 5: Familias */}
                                        {expandedNodes.has(deptNode.id) && deptNode.children && (
                                          <div className="pl-4 sm:pl-6 space-y-1 border-l border-zinc-200 ml-2 pt-0.5">
                                            {deptNode.children.map((secNode) => (
                                              <div key={secNode.id} className="text-xs space-y-1">
                                                <div className="flex items-center justify-between text-[11px] font-bold text-zinc-600 uppercase tracking-wider py-0.5">
                                                  <span>• {secNode.name}</span>
                                                  <div className="flex items-center gap-2 font-mono">
                                                    <span className="text-zinc-800">
                                                      Subtotal: {secNode.unidadesSugeridas} uds
                                                    </span>
                                                    {secNode.skusCount !== undefined && secNode.skusCount > 0 && (
                                                      <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded">
                                                        {secNode.skusCount.toLocaleString()} {secNode.skusCount === 1 ? 'SKU' : 'SKUs'}
                                                      </span>
                                                    )}
                                                  </div>
                                                </div>

                                                {/* Familias */}
                                                {secNode.children && (
                                                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5 pl-2 pb-1">
                                                    {secNode.children.map((famNode) => (
                                                      <div
                                                        key={famNode.id}
                                                        className="flex items-center justify-between bg-white border border-zinc-200 rounded px-2 py-1 text-[11px]"
                                                      >
                                                        <span className="text-zinc-700 truncate max-w-[130px]">
                                                          {famNode.name}
                                                        </span>
                                                        <div className="flex items-center gap-1.5 shrink-0">
                                                          <span className="text-[10px] text-zinc-400 font-mono">
                                                            (Stk: {famNode.stockActual})
                                                          </span>
                                                          <span className="font-bold font-mono text-emerald-700">
                                                            +{famNode.unidadesSugeridas} uds
                                                          </span>
                                                          <span
                                                            className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-1.5 py-0.2 rounded"
                                                            title="Cantidad de SKUs sugeridos a comprar"
                                                          >
                                                            {famNode.skusCount || 1} {famNode.skusCount === 1 ? 'SKU' : 'SKUs'}
                                                          </span>
                                                        </div>
                                                      </div>
                                                    ))}
                                                  </div>
                                                )}
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    ))}
                                </div>
                              )}
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>

          {/* Footer */}
          <div className="p-3 sm:p-4 border-t border-zinc-100 bg-zinc-50 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
            <div className="text-xs text-zinc-500 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span>
                Cálculo determinista: Cobertura objetivo de 4 semanas ponderada por estacionalidad y tallas centrales.
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-white hover:bg-zinc-100 text-zinc-700 border border-zinc-200 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                Cerrar
              </button>
              <button
                type="button"
                onClick={handleExportExcel}
                className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold rounded-lg shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-zinc-300" />
                <span>Descargar Orden Completa</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
