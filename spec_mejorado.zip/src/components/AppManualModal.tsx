import React, { useState, useEffect } from 'react';
import {
  X,
  BookOpen,
  Layers,
  BarChart3,
  Grid,
  Truck,
  Building2,
  FileSpreadsheet,
  CheckCircle2,
  Download,
  AlertTriangle,
  Send,
  HelpCircle,
  Eye,
  ShoppingBag,
  Clock,
  DollarSign,
  Maximize2,
  Search,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SpecLogoIcon } from './SpecLogo';
import { downloadOfficialSpecTemplate } from '../utils/specTemplateGenerator';

interface AppManualModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab?: (tabId: string) => void;
  onOpenUpload?: () => void;
}

export const AppManualModal: React.FC<AppManualModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  onOpenUpload,
}) => {
  const [activeSection, setActiveSection] = useState<string>('intro');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const sections = [
    { id: 'intro', title: '1. Filosofía & Arquitectura SPEC', icon: BookOpen },
    { id: 'manager', title: '2. Panel Ejecutivo Manager', icon: Layers },
    { id: 'dashboard', title: '3. Cuadro de Mando & Capacidad', icon: BarChart3 },
    { id: 'curves', title: '4. Curvas de Tallas & Quiebres', icon: Grid },
    { id: 'rebalance', title: '5. Motor de Rebalanceo & Ciclo', icon: Truck },
    { id: 'store_mode', title: '6. Modo Operativo Tienda / Bodega', icon: Building2 },
    { id: 'what_if', title: '7. Simulador What-If & Compras', icon: Eye },
    { id: 'ingesta', title: '8. Ingesta de Datos & Plantilla Excel', icon: FileSpreadsheet },
  ];

  const filteredSections = searchQuery.trim()
    ? sections.filter((s) => s.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : sections;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-6 bg-zinc-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-white rounded-2xl border border-zinc-200/90 shadow-2xl w-full max-w-5xl h-[90vh] max-h-[820px] flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-zinc-200/90 bg-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white border border-zinc-200 shadow-2xs flex items-center justify-center p-1.5 shrink-0">
              <SpecLogoIcon className="w-full h-full" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black tracking-[0.2em] text-zinc-900 uppercase">SPEC</span>
                <span className="w-1.5 h-1.5 bg-[#F97316] rounded-[1px]" />
                <span className="text-xs font-bold text-zinc-600 tracking-wide uppercase">
                  Manual de Operaciones &amp; Guía de la Plataforma
                </span>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  MVP v2.4
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 mt-0.5">
                Documentación interactiva de algoritmos, reglas de rebalanceo y flujos operativos
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={downloadOfficialSpecTemplate}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              title="Descargar archivo Excel oficial con 50 referencias de ejemplo"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Descargar Plantilla Excel</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body with Lateral Nav and Content */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* Lateral Nav Index */}
          <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-zinc-200/80 bg-zinc-50/70 p-3 flex flex-col shrink-0">
            <div className="relative mb-2">
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar tema o fórmula..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-white border border-zinc-200 rounded-lg text-xs text-zinc-800 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-400"
              />
            </div>

            <div className="space-y-1 overflow-y-auto flex-1 pr-1 custom-scrollbar">
              {filteredSections.map((sec) => {
                const Icon = sec.icon;
                const isSelected = activeSection === sec.id;
                return (
                  <button
                    key={sec.id}
                    type="button"
                    onClick={() => setActiveSection(sec.id)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-zinc-900 text-white font-semibold shadow-xs'
                        : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-zinc-500'}`} />
                    <span className="truncate">{sec.title}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-zinc-200 mt-2 text-[10px] text-zinc-400 font-mono text-center">
              SPEC // ENGINE DOCUMENTATION
            </div>
          </div>

          {/* Section Content Area */}
          <div className="flex-1 p-5 sm:p-7 overflow-y-auto custom-scrollbar bg-white">
            {activeSection === 'intro' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 1
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Filosofía &amp; Arquitectura SPEC
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    <strong>SPEC (Distribution Curve &amp; Rebalance)</strong> es la plataforma de inteligencia
                    operativa diseñada para resolver el problema estructural más costoso del retail físico:
                    <strong> la asimetría de inventario entre tiendas</strong>.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div className="p-4 rounded-xl border border-rose-200/80 bg-rose-50/50 space-y-1.5">
                    <div className="flex items-center gap-2 text-rose-700 font-bold text-xs">
                      <AlertTriangle className="w-4 h-4" />
                      <span>El Problema en Retail Físico</span>
                    </div>
                    <p className="text-xs text-rose-900/80 leading-relaxed">
                      Mientras una tienda insignia pierde ventas por agotamiento de tallas centrales (8.5, 9, M, L),
                      otra sucursal tiene esas mismas piezas inmovilizadas acumulando polvo y depreciándose sin rotación.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl border border-emerald-200/80 bg-emerald-50/50 space-y-1.5">
                    <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>La Solución SPEC</span>
                    </div>
                    <p className="text-xs text-emerald-900/80 leading-relaxed">
                      SPEC cruza la curva ideal de tallas, la velocidad de venta, la matriz de capacidad de mobiliario
                      y la distancia geográfica para proponer traslados matemáticamente óptimos que aumentan la venta sin comprar stock nuevo.
                    </p>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <h4 className="text-sm font-bold text-zinc-900 uppercase tracking-wider">
                    Principios Clave del Algoritmo
                  </h4>
                  <ul className="space-y-2 text-xs text-zinc-700">
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 mt-1.5 shrink-0" />
                      <div>
                        <strong>Preservación del Stock de Seguridad:</strong> SPEC nunca desabastece a una tienda donante.
                        Solo autoriza traslados si la tienda origen conserva suficiente stock de respaldo.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 mt-1.5 shrink-0" />
                      <div>
                        <strong>Eficiencia Logística por Matriz de Distancia:</strong> Prioriza donantes cercanos
                        calculando el costo de flete estimado ($/km) para que el margen recuperado supere ampliamente el gasto de envío.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-900 mt-1.5 shrink-0" />
                      <div>
                        <strong>Tolerancia Cero a Curvas Rotas (Broken Curves):</strong> Un modelo en exhibición sin sus tallas
                        de mayor demanda genera una tasa de rechazo del cliente del 68%. SPEC prioriza recomponer esas curvas.
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {activeSection === 'manager' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 2
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">Panel Ejecutivo Manager</h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    Diseñado para Directores de Operaciones y Gerentes de Cadena de Suministro.
                    Ofrece una visión ejecutiva de toda la red de tiendas en tiempo real.
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">Indicadores y Fórmulas</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                      <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4 text-rose-500" />
                        <span>Riesgo Financiero</span>
                      </div>
                      <p className="text-zinc-600 mt-1">
                        Suma del valor de ventas perdidas por quiebres de tallas centrales más el capital congelado en Dead Stock (&gt;90 días).
                      </p>
                    </div>

                    <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                      <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-amber-500" />
                        <span>Aging del Inventario</span>
                      </div>
                      <p className="text-zinc-600 mt-1">
                        Segmentación de piezas en 4 tramos: Fresco (&lt;30d), Normal (31-60d), Alerta (61-90d) y Crítico (&gt;90d).
                      </p>
                    </div>

                    <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                      <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-blue-500" />
                        <span>Rendimiento Espacial (m²)</span>
                      </div>
                      <p className="text-zinc-600 mt-1">
                        Densidad física (piezas/m²) y valor del inventario por metro cuadrado según el formato de tienda.
                      </p>
                    </div>

                    <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                      <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                        <Send className="w-4 h-4 text-zinc-800" />
                        <span>Asignación Central &amp; Push</span>
                      </div>
                      <p className="text-zinc-600 mt-1">
                        Distribuye lotes de producto recién ingresados mediante 3 estrategias: Prioridad a Déficit, Reparto Equitativo o Mayor Peso a Flagship.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'dashboard' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 3
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Cuadro de Mando &amp; Capacidad por Departamento
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    Monitorea el balance entre la <strong>capacidad física real de mobiliario</strong> (estanterías, percheros, góndolas)
                    y el <strong>stock almacenado</strong> por cada tienda y departamento.
                  </p>
                </div>

                <div className="space-y-2 text-xs text-zinc-700">
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg">
                    <strong>1. Frentes y Variedad de SKUs:</strong> Compara cuántos modelos distintos caben en piso vs. cuántos hay activos.
                  </div>
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg">
                    <strong>2. Piezas Físicas &amp; Profundidad:</strong> Calcula si el stock promedio por SKU cumple con la profundidad objetivo (Target Depth).
                  </div>
                  <div className="p-3 bg-zinc-50 border border-zinc-200 rounded-lg">
                    <strong>3. Desglose Departamental Desplegable:</strong> Permite filtrar por Calzado, Textil y Accesorios con desglose por Género (Hombre, Mujer, Niños).
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'curves' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 4
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Curvas de Tallas &amp; Quiebres Algorítmicos
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    El motor analiza la curva de Gauss de cada referencia para clasificarla en:
                  </p>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-3 rounded-lg border border-rose-200 bg-rose-50 text-rose-900">
                    <strong>🔴 Curva Rota Crítica (Broken Core):</strong> Las tallas centrales con mayor volumen de compra histórica están en 0 o 1 unidad, impidiendo ventas.
                  </div>
                  <div className="p-3 rounded-lg border border-amber-200 bg-amber-50 text-amber-900">
                    <strong>🟡 Monotalla (Orphan SKU):</strong> Solo queda 1 o 2 unidades en tallas extremas (ej. talla 5 o 12 en calzado; XS o XXL en ropa).
                  </div>
                  <div className="p-3 rounded-lg border border-blue-200 bg-blue-50 text-blue-900">
                    <strong>🔵 Sobrestock por Concentración:</strong> Más del 40% del inventario concentrado en una sola talla o SKU.
                  </div>
                  <div className="p-3 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-900">
                    <strong>🟢 Curva Completa Óptima:</strong> Todas las tallas cubiertas uniformemente según el perfil de demanda.
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'rebalance' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 5
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Motor de Rebalanceo &amp; Ciclo de Vida del Traslado
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    Cada orden de traslado sigue un ciclo formal de 4 etapas para garantizar trazabilidad total en bodega:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 text-xs text-center font-mono">
                  <div className="p-3 bg-zinc-100 rounded-xl border border-zinc-200">
                    <span className="w-2 h-2 rounded-full bg-zinc-500 inline-block mb-1" />
                    <div className="font-bold text-zinc-900">1. SUGERIDO</div>
                    <p className="text-[10px] text-zinc-500 mt-1 font-sans">Generado automáticamente por el motor</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
                    <span className="w-2 h-2 rounded-full bg-blue-600 inline-block mb-1" />
                    <div className="font-bold text-blue-800">2. APROBADO</div>
                    <p className="text-[10px] text-blue-600 mt-1 font-sans">Validado por Planner Central</p>
                  </div>
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                    <span className="w-2 h-2 rounded-full bg-amber-500 inline-block mb-1" />
                    <div className="font-bold text-amber-800">3. EN TRÁNSITO</div>
                    <p className="text-[10px] text-amber-600 mt-1 font-sans">Recolectado y despachado por Donante</p>
                  </div>
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block mb-1" />
                    <div className="font-bold text-emerald-800">4. RECIBIDO</div>
                    <p className="text-[10px] text-emerald-600 mt-1 font-sans">Confirmado físicamente en Destino</p>
                  </div>
                </div>

                <div className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200 text-xs text-zinc-700 space-y-2">
                  <strong>Control de Discrepancias Físicas:</strong>
                  <p>
                    Si la sugerencia indica trasladar 4 unidades pero el bodeguero solo encuentra 3 en bodega,
                    SPEC permite registrar la <em>cantidad real despachada</em> y la <em>cantidad real recibida</em>,
                    evitando diferencias contables en el ERP.
                  </p>
                </div>
              </div>
            )}

            {activeSection === 'store_mode' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 6
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Modo Operativo Tienda / Bodega
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    Diseñado específicamente para el personal de tienda con tablet o teléfono móvil.
                    Al ingresar, el encargado selecciona su sucursal y la pantalla se enfoca en dos listas directas:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                    <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-amber-600" />
                      <span>Mercancía por Despachar (Salidas)</span>
                    </div>
                    <p className="text-zinc-600">
                      Muestra exactamente qué prendas deben retirarse de la bodega donante, con casillas de verificación
                      para condición física (Nuevo o Usado) y botón para marcar &quot;En Tránsito&quot;.
                    </p>
                  </div>

                  <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-200 space-y-2">
                    <div className="font-bold text-zinc-900 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Mercancía por Recibir (Entradas)</span>
                    </div>
                    <p className="text-zinc-600">
                      Avisa con antelación qué paquetes vienen en camino desde otra tienda y permite confirmar la recepción física con un solo toque.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'what_if' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 7
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Simulador What-If &amp; Compras Sugeridas
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    Antes de mover una sola caja en la vida real, el botón <strong>&quot;Simular Traslados&quot;</strong>
                    crea un entorno virtual que proyecta el stock futuro y recalcula las curvas de talla instantáneamente.
                  </p>
                </div>

                <div className="p-4 bg-purple-50/60 rounded-xl border border-purple-200 space-y-2 text-xs">
                  <div className="font-bold text-purple-900 flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-purple-700" />
                    <span>Sugerido de Compra a Proveedores</span>
                  </div>
                  <p className="text-purple-900/80 leading-relaxed">
                    Si el déficit de una tienda no puede ser cubierto por ninguna otra sucursal de la red
                    (porque todas tienen el stock justo), el módulo de Compras genera una orden de adquisición
                    con la curva exacta requerida para solicitar a fábrica.
                  </p>
                </div>
              </div>
            )}

            {activeSection === 'ingesta' && (
              <div className="space-y-5 max-w-3xl">
                <div>
                  <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    SECCIÓN 8
                  </span>
                  <h3 className="text-xl font-bold text-zinc-900 mt-1">
                    Ingesta de Datos &amp; Plantilla Oficial Excel
                  </h3>
                  <p className="text-sm text-zinc-600 mt-1.5 leading-relaxed">
                    SPEC admite cualquier archivo Excel o CSV proveniente de sistemas ERP comerciales
                    (SAP, Oracle, Dynamics, Shopify, Softland, etc.) mediante un mapeador inteligente de columnas.
                  </p>
                </div>

                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h5 className="text-xs font-bold text-emerald-950">Descarga la Plantilla Oficial SPEC</h5>
                    <p className="text-[11px] text-emerald-800 mt-0.5">
                      Incluye 50 referencias de ejemplo y la hoja de especificaciones de campos técnicos.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={downloadOfficialSpecTemplate}
                    className="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors shrink-0 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Descargar .XLSX</span>
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  <h5 className="font-bold text-zinc-900 uppercase tracking-wider text-[11px]">
                    Columnas Requeridas
                  </h5>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Tienda</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Marca</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Departamento</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Referencia</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Talla</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">Stock</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">ValorUnitario</div>
                    <div className="p-2 bg-zinc-50 border border-zinc-200 rounded">DiasAntiguedad</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-zinc-200/90 bg-zinc-50 flex items-center justify-between text-xs text-zinc-500 shrink-0">
          <span className="font-mono text-[10px]">
            SPEC // DISTRIBUTION CURVE &amp; REBALANCE ENGINE
          </span>
          <div className="flex items-center gap-2">
            {onOpenUpload && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenUpload();
                }}
                className="px-3 py-1 bg-white hover:bg-zinc-100 text-zinc-800 border border-zinc-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Subir Archivo Excel
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
            >
              Cerrar Manual
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
