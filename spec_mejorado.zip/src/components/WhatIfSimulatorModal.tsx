import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Flame,
  Info,
  Layers,
  RotateCcw,
  Sliders,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';
import {
  CapacityMatrixConfig,
  InventoryItem,
  TransferSuggestion,
  WhatIfSimulationConfig,
} from '../types';
import { ejecutarSimulacionWhatIf } from '../utils/analysisEngine';
import { CardInfoButton } from './CardInfoButton';

interface WhatIfSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: InventoryItem[];
  storeCapacities?: Record<string, CapacityMatrixConfig>;
  transfers?: TransferSuggestion[];
}

export const WhatIfSimulatorModal: React.FC<WhatIfSimulatorModalProps> = ({
  isOpen,
  onClose,
  inventory = [],
  storeCapacities = {},
  transfers = [],
}) => {
  const [config, setConfig] = useState<WhatIfSimulationConfig>({
    horizonteSemanas: 4,
    variacionSellThroughPct: 0,
    incluirTraspasosEnTransito: true,
    departamentoFiltro: 'TODAS',
  });

  const departments = useMemo(() => {
    const set = new Set<string>(['TODAS', 'CALZADO', 'TEXTIL', 'ACCESORIOS']);
    (inventory || []).forEach((it) => {
      if (it?.Departamento) set.add(it.Departamento);
    });
    return Array.from(set);
  }, [inventory]);

  const simulationResults = useMemo(() => {
    return ejecutarSimulacionWhatIf(inventory, storeCapacities, config, transfers);
  }, [inventory, storeCapacities, config, transfers]);

  const totalStockActual = useMemo(
    () => simulationResults.reduce((a, b) => a + b.stockActual, 0),
    [simulationResults]
  );
  const totalStockProyectado = useMemo(
    () => simulationResults.reduce((a, b) => a + b.stockProyectado, 0),
    [simulationResults]
  );
  const totalVentasProyectadas = useMemo(
    () => simulationResults.reduce((a, b) => a + b.ventasProyectadas, 0),
    [simulationResults]
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-5xl bg-white border border-zinc-200 rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-200 bg-[#F8F7FC]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600 border border-blue-200">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">
                  Simulador Prospectivo: Estrés de Capacidad y Rotación de Ventas
                </h2>
                <CardInfoButton
                  title="Simulador Prospectivo de Escenarios"
                  description="Modela el comportamiento dinámico del inventario y la ocupación de tiendas proyectando el ritmo de venta semanal (tasa de venta / rotación) en un horizonte de 1 a 12 semanas."
                  formula="Ventas(t) = Stock Inicial * (1 - (1 - TasaVenta)^t) | Stock(t) = Stock Inicial - Ventas(t) + Traspasos"
                  operationalImpact="Permite anticipar quiebres de tallas y desabastecimiento de bodega semanas antes de que ocurran."
                />
              </div>
              <p className="text-xs text-zinc-500">
                Proyecta el consumo de existencias, semanas de cobertura y saturación futura de la red
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Controls Bar */}
          <div className="bg-[#F8F7FC] p-5 rounded-2xl border border-zinc-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-800 uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                <span>Parámetros del Escenario de Simulación</span>
              </span>

              <button
                type="button"
                onClick={() =>
                  setConfig({
                    horizonteSemanas: 4,
                    variacionSellThroughPct: 0,
                    incluirTraspasosEnTransito: true,
                    departamentoFiltro: 'TODAS',
                  })
                }
                className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1.5 transition-colors cursor-pointer font-medium"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer Valores Base</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
              {/* Slider 1: Horizonte temporal */}
              <div>
                <div className="flex justify-between text-xs mb-1.5 font-medium">
                  <span className="text-zinc-600">Horizonte de Tiempo:</span>
                  <span className="font-bold text-blue-600">{config.horizonteSemanas} semanas</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="12"
                  step="1"
                  value={config.horizonteSemanas}
                  onChange={(e) =>
                    setConfig((prev) => ({ ...prev, horizonteSemanas: parseInt(e.target.value) || 1 }))
                  }
                  className="w-full h-2 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-[10px] text-zinc-400 mt-1 font-mono">
                  <span>1 semana</span>
                  <span>6 semanas</span>
                  <span>12 semanas</span>
                </div>
              </div>

              {/* Slider 2: Variación de Sell-Through */}
              <div>
                <div className="flex justify-between text-xs mb-1.5 font-medium">
                  <span className="text-zinc-600">Variación Rotación de Ventas:</span>
                  <span
                    className={`font-bold ${
                      config.variacionSellThroughPct > 0
                        ? 'text-emerald-600'
                        : config.variacionSellThroughPct < 0
                        ? 'text-amber-600'
                        : 'text-zinc-700'
                    }`}
                  >
                    {config.variacionSellThroughPct > 0 ? `+${config.variacionSellThroughPct}%` : `${config.variacionSellThroughPct}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  step="5"
                  value={config.variacionSellThroughPct}
                  onChange={(e) =>
                    setConfig((prev) => ({ ...prev, variacionSellThroughPct: parseInt(e.target.value) || 0 }))
                  }
                  className="w-full h-2 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-zinc-400 mt-1 font-mono">
                  <span>-50% (Baja)</span>
                  <span>0% (Base)</span>
                  <span>+50% (Alta)</span>
                </div>
              </div>

              {/* Toggle 3: Traspasos e In-transit */}
              <div className="flex flex-col justify-between">
                <span className="text-xs text-zinc-600 mb-1.5 font-medium">Opciones de Rebalanceo:</span>
                <label className="flex items-center gap-2.5 p-2 bg-white rounded-xl border border-zinc-200 cursor-pointer hover:border-zinc-300 transition-colors">
                  <input
                    type="checkbox"
                    checked={config.incluirTraspasosEnTransito}
                    onChange={(e) =>
                      setConfig((prev) => ({ ...prev, incluirTraspasosEnTransito: e.target.checked }))
                    }
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-zinc-800">
                    Incluir Traspasos en Tránsito
                  </span>
                </label>
              </div>
            </div>
          </div>

          {/* Macro KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#F8F7FC] p-4 rounded-xl border border-zinc-200">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block mb-1">
                Stock Inicial en Red
              </span>
              <div className="text-2xl font-bold text-zinc-900 tracking-tight tabular-nums">
                {totalStockActual.toLocaleString()} <span className="text-xs text-zinc-500 font-normal">uds</span>
              </div>
            </div>

            <div className="bg-[#F8F7FC] p-4 rounded-xl border border-zinc-200">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block mb-1">
                Ventas Totales Proyectadas
              </span>
              <div className="text-2xl font-bold text-emerald-600 tracking-tight tabular-nums flex items-center gap-2">
                <span>{totalVentasProyectadas.toLocaleString()}</span>
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-[#F8F7FC] p-4 rounded-xl border border-zinc-200">
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider block mb-1">
                Stock Remanente Proyectado
              </span>
              <div className="text-2xl font-bold text-blue-600 tracking-tight tabular-nums">
                {totalStockProyectado.toLocaleString()} <span className="text-xs text-zinc-500 font-normal">uds</span>
              </div>
            </div>
          </div>

          {/* Detailed Simulation Table by Store */}
          <div className="bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-2xs">
            <div className="px-4 py-3 bg-[#F8F7FC] border-b border-zinc-200 flex items-center justify-between">
              <h3 className="text-xs font-bold text-zinc-900 uppercase tracking-wider">
                Proyección por Sucursal ({simulationResults.length} Tiendas)
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-[#F4F2FD] text-zinc-500 border-b border-zinc-200 text-[10px] uppercase font-mono font-bold tracking-wider">
                    <th className="py-3 px-4">Tienda / Sucursal</th>
                    <th className="py-3 px-3 text-right">Stock Actual</th>
                    <th className="py-3 px-3 text-right">Venta Proyectada</th>
                    <th className="py-3 px-3 text-right">Stock Final</th>
                    <th className="py-3 px-3 text-center">Ocupación Inicial vs Final</th>
                    <th className="py-3 px-3 text-center">Cobertura</th>
                    <th className="py-3 px-4 text-center">Diagnóstico Prospectivo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {simulationResults.map((row) => (
                    <tr key={row.tienda} className="hover:bg-[#F8F7FC] transition-colors">
                      <td className="py-3 px-4 font-bold text-zinc-900">{row.tienda}</td>
                      <td className="py-3 px-3 text-right font-mono text-zinc-700">
                        {row.stockActual.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-emerald-600 font-semibold">
                        -{row.ventasProyectadas.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-blue-700 font-bold">
                        {row.stockProyectado.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <span className="font-mono text-zinc-500">{row.ocupacionActualPct}%</span>
                          <ArrowRight className="w-3 h-3 text-zinc-400" />
                          <span
                            className={`font-mono font-bold ${
                              row.ocupacionProyectadaPct < 50
                                ? 'text-amber-700'
                                : row.ocupacionProyectadaPct > 110
                                ? 'text-purple-700'
                                : 'text-emerald-700'
                            }`}
                          >
                            {row.ocupacionProyectadaPct}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center font-mono text-zinc-700">
                        {row.semanasCobertura > 50 ? '> 50 sem' : `${row.semanasCobertura} sem`}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.estadoRiesgo === 'QUIEBRE_PROMINENTE' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-rose-50 text-rose-800 border border-rose-200">
                            <AlertTriangle className="w-3 h-3" />
                            <span>Riesgo de Quiebre ({row.fechaQuiebreEstimada})</span>
                          </span>
                        ) : row.estadoRiesgo === 'SATURACION_ALTA' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-purple-50 text-purple-800 border border-purple-200">
                            <Flame className="w-3 h-3" />
                            <span>Saturación Alta</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-50 text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Equilibrio Saludable</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#F8F7FC] border-t border-zinc-200 flex items-center justify-between text-xs text-zinc-500">
          <span>* Basado en la velocidad teórica de rotación de la matriz de capacidad de cada formato.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white font-bold rounded-xl transition-all cursor-pointer shadow-sm"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
