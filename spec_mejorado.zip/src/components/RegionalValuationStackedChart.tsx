import React, { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
  Cell,
} from 'recharts';
import {
  Building2,
  MapPin,
  TrendingUp,
  Layers,
  Award,
  DollarSign,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { InventoryItem, StoreProfile } from '../types';
import { CardInfoButton } from './CardInfoButton';

interface RegionalValuationStackedChartProps {
  inventory: InventoryItem[];
  storeProfiles?: StoreProfile[];
  stores?: string[];
  bcvRate?: number;
  selectedStore?: string;
  onSelectStore?: (store: string) => void;
}

interface RegionAggregate {
  regionName: string;
  totalValuationUSD: number;
  totalPieces: number;
  calzadoUSD: number;
  textilUSD: number;
  accesoriosUSD: number;
  otrosUSD: number;
  calzadoPieces: number;
  textilPieces: number;
  accesoriosPieces: number;
  storesList: { name: string; valuationUSD: number; pieces: number }[];
  pctOfNetwork: number;
}

/**
 * Resolves the geographic region/zone of a store from its profile or name heuristics
 */
export function resolveStoreGeographicZone(storeName: string, profile?: StoreProfile): string {
  if (profile?.region && profile.region.trim()) {
    const r = profile.region.trim();
    return r.toLowerCase().startsWith('región') || r.toLowerCase().startsWith('zona') ? r : `Región ${r}`;
  }
  if (profile?.cluster && profile.cluster.trim()) {
    return `Zona ${profile.cluster.trim()}`;
  }
  if (profile?.ciudad && profile.ciudad.trim() && profile.ciudad !== 'Ciudad Principal') {
    return `Región ${profile.ciudad.trim()}`;
  }

  // Deduce from store name
  const nameUpper = (storeName || '').toUpperCase();
  if (nameUpper.includes('CAPITAL') || nameUpper.includes('CARACAS') || nameUpper.includes('CHACAO') || nameUpper.includes('RECREO') || nameUpper.includes('HATILLO')) {
    return 'Región Capital';
  }
  if (nameUpper.includes('CENTRO') || nameUpper.includes('CENTRAL') || nameUpper.includes('VALENCIA') || nameUpper.includes('MARACAY')) {
    return 'Región Central';
  }
  if (nameUpper.includes('OCCIDENTE') || nameUpper.includes('ZULIA') || nameUpper.includes('MARACAIBO') || nameUpper.includes('LARA') || nameUpper.includes('BARQUISIMETO') || nameUpper.includes('CABIMAS')) {
    return 'Región Occidental';
  }
  if (nameUpper.includes('ORIENTE') || nameUpper.includes('PUERTO') || nameUpper.includes('LECHERIA') || nameUpper.includes('MARGARITA') || nameUpper.includes('BARCELONA') || nameUpper.includes('MATURIN')) {
    return 'Región Oriental';
  }
  if (nameUpper.includes('ANDES') || nameUpper.includes('MERIDA') || nameUpper.includes('SAN CRISTOBAL') || nameUpper.includes('TACHIRA')) {
    return 'Región Los Andes';
  }
  if (nameUpper.includes('NORTE')) {
    return 'Zona Norte';
  }
  if (nameUpper.includes('SUR')) {
    return 'Zona Sur';
  }
  if (nameUpper.includes('ESTE')) {
    return 'Zona Este';
  }
  if (nameUpper.includes('OESTE')) {
    return 'Zona Oeste';
  }

  return profile?.ciudad ? `Región ${profile.ciudad}` : `Zona ${storeName}`;
}

const DEPT_COLORS = {
  calzado: '#0284c7', // Sky 600
  textil: '#10b981',  // Emerald 500
  accesorios: '#f59e0b', // Amber 500
  otros: '#64748b',   // Slate 500
};

export const RegionalValuationStackedChart: React.FC<RegionalValuationStackedChartProps> = ({
  inventory = [],
  storeProfiles = [],
  stores = [],
  bcvRate = 855.66,
  selectedStore = 'TODAS',
  onSelectStore,
}) => {
  const [stackMode, setStackMode] = useState<'departamento' | 'piezas'>('departamento');
  const [activeRegionHover, setActiveRegionHover] = useState<string | null>(null);

  // Group inventory by geographic zone
  const { regions, totalNetworkValuation, topRegion } = useMemo(() => {
    const profileMap = new Map<string, StoreProfile>();
    (storeProfiles || []).forEach((p) => {
      if (p && p.nombre) {
        profileMap.set(p.nombre.toLowerCase().trim(), p);
      }
    });

    const regionMap = new Map<
      string,
      {
        totalValuationUSD: number;
        totalPieces: number;
        calzadoUSD: number;
        textilUSD: number;
        accesoriosUSD: number;
        otrosUSD: number;
        calzadoPieces: number;
        textilPieces: number;
        accesoriosPieces: number;
        storeMap: Map<string, { valuationUSD: number; pieces: number }>;
      }
    >();

    // Process every item in inventory
    (inventory || []).forEach((item) => {
      if (!item) return;
      const storeName = (item.Tienda || 'TIENDA 1').trim();
      const profile = profileMap.get(storeName.toLowerCase());
      const zoneName = resolveStoreGeographicZone(storeName, profile);

      if (!regionMap.has(zoneName)) {
        regionMap.set(zoneName, {
          totalValuationUSD: 0,
          totalPieces: 0,
          calzadoUSD: 0,
          textilUSD: 0,
          accesoriosUSD: 0,
          otrosUSD: 0,
          calzadoPieces: 0,
          textilPieces: 0,
          accesoriosPieces: 0,
          storeMap: new Map(),
        });
      }

      const reg = regionMap.get(zoneName)!;
      const valUSD = Number(item.Valoracion || (item.Stock * (item.ValorUnitario || 0))) || 0;
      const stock = Math.max(0, Number(item.Stock) || 0);
      const depto = (item.Departamento || '').toUpperCase();

      reg.totalValuationUSD += valUSD;
      reg.totalPieces += stock;

      if (depto.includes('CALZADO')) {
        reg.calzadoUSD += valUSD;
        reg.calzadoPieces += stock;
      } else if (depto.includes('TEXTIL') || depto.includes('ROPA')) {
        reg.textilUSD += valUSD;
        reg.textilPieces += stock;
      } else if (depto.includes('ACCESORIO')) {
        reg.accesoriosUSD += valUSD;
        reg.accesoriosPieces += stock;
      } else {
        reg.otrosUSD += valUSD;
      }

      // Store tracking
      if (!reg.storeMap.has(storeName)) {
        reg.storeMap.set(storeName, { valuationUSD: 0, pieces: 0 });
      }
      const stData = reg.storeMap.get(storeName)!;
      stData.valuationUSD += valUSD;
      stData.pieces += stock;
    });

    // Also ensure stores with 0 inventory appear in their respective zones
    (stores || []).forEach((st) => {
      if (!st) return;
      const profile = profileMap.get(st.toLowerCase().trim());
      const zoneName = resolveStoreGeographicZone(st, profile);
      if (!regionMap.has(zoneName)) {
        regionMap.set(zoneName, {
          totalValuationUSD: 0,
          totalPieces: 0,
          calzadoUSD: 0,
          textilUSD: 0,
          accesoriosUSD: 0,
          otrosUSD: 0,
          calzadoPieces: 0,
          textilPieces: 0,
          accesoriosPieces: 0,
          storeMap: new Map([[st, { valuationUSD: 0, pieces: 0 }]]),
        });
      }
    });

    const netValuation = Array.from(regionMap.values()).reduce(
      (acc, r) => acc + r.totalValuationUSD,
      0
    );

    const result: RegionAggregate[] = Array.from(regionMap.entries()).map(
      ([regionName, data]) => {
        const pct = netValuation > 0 ? (data.totalValuationUSD / netValuation) * 100 : 0;
        const storesList = Array.from(data.storeMap.entries())
          .map(([name, s]) => ({
            name,
            valuationUSD: Math.round(s.valuationUSD * 100) / 100,
            pieces: s.pieces,
          }))
          .sort((a, b) => b.valuationUSD - a.valuationUSD);

        return {
          regionName,
          totalValuationUSD: Math.round(data.totalValuationUSD * 100) / 100,
          totalPieces: data.totalPieces,
          calzadoUSD: Math.round(data.calzadoUSD * 100) / 100,
          textilUSD: Math.round(data.textilUSD * 100) / 100,
          accesoriosUSD: Math.round(data.accesoriosUSD * 100) / 100,
          otrosUSD: Math.round(data.otrosUSD * 100) / 100,
          calzadoPieces: data.calzadoPieces,
          textilPieces: data.textilPieces,
          accesoriosPieces: data.accesoriosPieces,
          storesList,
          pctOfNetwork: Math.round(pct * 10) / 10,
        };
      }
    );

    // Sort by total valuation descending to easily identify highest capital concentration
    result.sort((a, b) => b.totalValuationUSD - a.totalValuationUSD);

    return {
      regions: result,
      totalNetworkValuation: netValuation,
      topRegion: result[0] || null,
    };
  }, [inventory, storeProfiles, stores]);

  if (regions.length === 0) {
    return (
      <div className="bg-white border border-zinc-200/90 rounded-xl p-5 shadow-xs text-center py-8">
        <MapPin className="w-8 h-8 text-zinc-300 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-zinc-700">Sin datos geográficos de inventario</h4>
        <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
          Carga un archivo de inventario en el botón superior para visualizar la distribución del capital por zonas.
        </p>
      </div>
    );
  }

  return (
    <div
      id="section-regional-valuation-chart"
      className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs space-y-4"
    >
      {/* Header with Title and Financial Concentration Leader Pill */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-100">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white shrink-0">
              <Building2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-zinc-900 tracking-tight flex items-center gap-1.5">
                  <span>Concentración de Capital por Zona // Regional Inventory Valuation</span>
                  <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-200 uppercase">
                    BARRAS APILADAS
                  </span>
                </h3>
                <CardInfoButton
                  title="Concentración Geográfica de Capital Financiero ($ USD)"
                  description="Gráfico de barras apiladas que cuantifica la valoración económica total del inventario agrupada por zona o región comercial de las tiendas. Cada barra desagrega el capital financiero inmovilizado por departamento (Calzado, Textil, Accesorios) en Dólares ($ USD)."
                  formula="Valoración Zona = Σ (Valoración Tienda en Zona), con desglose apilado por Departamento"
                  operationalImpact="Permite identificar de un vistazo qué área geográfica concentra mayor exposición de capital, facilitando la toma de decisiones para rebalancear mercancía desde zonas sobrestockeadas hacia áreas con mayor ritmo de venta."
                />
              </div>
              <p className="text-xs text-zinc-500 font-sans">
                Comparativa de capital inmovilizado en $ USD desagregado por departamento comercial entre grupos de tiendas
              </p>
            </div>
          </div>
        </div>

        {/* Controls: Stack Mode Toggle & Top Region Badge */}
        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          {topRegion && topRegion.totalValuationUSD > 0 && (
            <div
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-mono"
              title={`Área geográfica líder en capital: ${topRegion.regionName} con $${topRegion.totalValuationUSD.toLocaleString()} USD (${topRegion.pctOfNetwork}% de la red)`}
            >
              <Award className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="font-semibold text-emerald-800">Mayor Capital:</span>
              <span className="font-bold text-emerald-950 underline decoration-dotted">{topRegion.regionName}</span>
              <span className="font-bold text-emerald-700 ml-0.5">
                ${(topRegion.totalValuationUSD / 1000).toFixed(1)}k ({topRegion.pctOfNetwork}%)
              </span>
            </div>
          )}

          {/* Toggle between Valuation ($ USD) and Physical Pieces */}
          <div className="inline-flex rounded-lg border border-zinc-200 bg-zinc-50 p-0.5 text-xs font-mono">
            <button
              type="button"
              onClick={() => setStackMode('departamento')}
              className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                stackMode === 'departamento'
                  ? 'bg-zinc-900 text-white shadow-2xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              $ USD (Valor)
            </button>
            <button
              type="button"
              onClick={() => setStackMode('piezas')}
              className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                stackMode === 'piezas'
                  ? 'bg-zinc-900 text-white shadow-2xs'
                  : 'text-zinc-600 hover:text-zinc-900'
              }`}
            >
              UDS (Piezas)
            </button>
          </div>
        </div>
      </div>

      {/* Main Stacked Bar Chart with Recharts */}
      <div className="h-72 sm:h-80 w-full pt-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={regions}
            margin={{ top: 16, right: 16, left: 0, bottom: 25 }}
            onMouseMove={(state) => {
              if (state && state.activeLabel) {
                setActiveRegionHover(String(state.activeLabel));
              }
            }}
            onMouseLeave={() => setActiveRegionHover(null)}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f4" />
            <XAxis
              dataKey="regionName"
              tickLine={false}
              axisLine={{ stroke: '#e4e4e7' }}
              tick={{ fill: '#3f3f46', fontSize: 11, fontWeight: 600, fontFamily: 'monospace' }}
              interval={0}
              angle={regions.length > 5 ? -18 : 0}
              textAnchor={regions.length > 5 ? 'end' : 'middle'}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#71717a', fontSize: 11, fontFamily: 'monospace' }}
              tickFormatter={(v) =>
                stackMode === 'departamento'
                  ? `$${(v / 1000).toFixed(0)}k`
                  : `${(v / 1000).toFixed(0)}k pzs`
              }
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (!active || !payload || !payload.length) return null;
                const regData = regions.find((r) => r.regionName === label);
                if (!regData) return null;

                return (
                  <div className="bg-zinc-900 text-white p-3.5 rounded-xl shadow-xl border border-zinc-800 text-xs font-mono space-y-2 min-w-[240px] animate-fadeIn">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-1.5">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="font-bold text-white text-sm">{regData.regionName}</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-emerald-400 font-bold">
                        {regData.pctOfNetwork}% Total Red
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-sm font-bold pt-0.5">
                      <span className="text-zinc-300">Capital Concentrado:</span>
                      <span className="text-emerald-400 font-bold">
                        ${regData.totalValuationUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                      </span>
                    </div>

                    <div className="text-[11px] text-zinc-400 flex justify-between items-center">
                      <span>Volumen Físico:</span>
                      <span className="text-zinc-200 font-semibold">{regData.totalPieces.toLocaleString()} piezas</span>
                    </div>

                    {/* Breakdown by department */}
                    <div className="pt-2 border-t border-zinc-800/80 space-y-1 text-[11px]">
                      <div className="flex justify-between items-center text-sky-300">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-sky-500" />
                          <span>Calzado:</span>
                        </span>
                        <span className="font-bold font-mono">
                          ${regData.calzadoUSD.toLocaleString('en-US', { maximumFractionDigits: 0 })} USD
                          <span className="text-zinc-400 font-normal ml-1">
                            ({regData.totalValuationUSD > 0 ? ((regData.calzadoUSD / regData.totalValuationUSD) * 100).toFixed(0) : 0}%)
                          </span>
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-emerald-300">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500" />
                          <span>Textil:</span>
                        </span>
                        <span className="font-bold font-mono">
                          ${regData.textilUSD.toLocaleString('en-US', { maximumFractionDigits: 0 })} USD
                          <span className="text-zinc-400 font-normal ml-1">
                            ({regData.totalValuationUSD > 0 ? ((regData.textilUSD / regData.totalValuationUSD) * 100).toFixed(0) : 0}%)
                          </span>
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-amber-300">
                        <span className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-amber-500" />
                          <span>Accesorios:</span>
                        </span>
                        <span className="font-bold font-mono">
                          ${regData.accesoriosUSD.toLocaleString('en-US', { maximumFractionDigits: 0 })} USD
                          <span className="text-zinc-400 font-normal ml-1">
                            ({regData.totalValuationUSD > 0 ? ((regData.accesoriosUSD / regData.totalValuationUSD) * 100).toFixed(0) : 0}%)
                          </span>
                        </span>
                      </div>
                    </div>

                    {/* Stores contained in this region */}
                    <div className="pt-2 border-t border-zinc-800/80">
                      <div className="text-[10px] text-zinc-400 font-semibold mb-1">
                        Tiendas ({regData.storesList.length}):
                      </div>
                      <div className="space-y-0.5 max-h-24 overflow-y-auto pr-1">
                        {regData.storesList.map((st) => (
                          <div key={st.name} className="flex justify-between text-[10px] text-zinc-300">
                            <span className="truncate max-w-[140px]">• {st.name}</span>
                            <span className="font-bold text-zinc-400 shrink-0 ml-1">
                              ${(st.valuationUSD / 1000).toFixed(1)}k
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              }}
            />
            <Legend
              verticalAlign="top"
              align="right"
              iconSize={8}
              wrapperStyle={{ paddingBottom: 10, fontSize: 11, fontFamily: 'monospace' }}
            />

            {stackMode === 'departamento' ? (
              <>
                <Bar
                  dataKey="calzadoUSD"
                  name="Calzado ($ USD)"
                  stackId="valuation"
                  fill={DEPT_COLORS.calzado}
                  radius={[0, 0, 0, 0]}
                />
                <Bar
                  dataKey="textilUSD"
                  name="Textil ($ USD)"
                  stackId="valuation"
                  fill={DEPT_COLORS.textil}
                  radius={[0, 0, 0, 0]}
                />
                <Bar
                  dataKey="accesoriosUSD"
                  name="Accesorios ($ USD)"
                  stackId="valuation"
                  fill={DEPT_COLORS.accesorios}
                  radius={[4, 4, 0, 0]}
                />
              </>
            ) : (
              <>
                <Bar
                  dataKey="calzadoPieces"
                  name="Pzs Calzado"
                  stackId="pieces"
                  fill={DEPT_COLORS.calzado}
                  radius={[0, 0, 0, 0]}
                />
                <Bar
                  dataKey="textilPieces"
                  name="Pzs Textil"
                  stackId="pieces"
                  fill={DEPT_COLORS.textil}
                  radius={[0, 0, 0, 0]}
                />
                <Bar
                  dataKey="accesoriosPieces"
                  name="Pzs Accesorios"
                  stackId="pieces"
                  fill={DEPT_COLORS.accesorios}
                  radius={[4, 4, 0, 0]}
                />
              </>
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Ranked Geographic Zones Breakdown Cards */}
      <div className="pt-2 border-t border-zinc-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-mono font-bold text-zinc-600 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-zinc-500" />
            <span>Ranking de Zonas por Concentración Financiera</span>
          </span>
          <span className="text-[10px] text-zinc-400 font-mono">
            {regions.length} {regions.length === 1 ? 'Zona Geográfica' : 'Zonas Geográficas'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {regions.map((reg, idx) => {
            const isLeader = idx === 0 && reg.totalValuationUSD > 0;
            const isHovered = activeRegionHover === reg.regionName;

            return (
              <div
                key={reg.regionName}
                onMouseEnter={() => setActiveRegionHover(reg.regionName)}
                onMouseLeave={() => setActiveRegionHover(null)}
                className={`p-3 rounded-lg border transition-all ${
                  isLeader
                    ? 'bg-emerald-50/50 border-emerald-200/90 shadow-2xs'
                    : isHovered
                    ? 'bg-zinc-100/70 border-zinc-300'
                    : 'bg-zinc-50/80 border-zinc-200/80 hover:bg-zinc-100/50'
                }`}
              >
                <div className="flex items-start justify-between gap-1.5 mb-1.5">
                  <div className="min-w-0">
                    <span className="text-[10px] font-mono font-bold text-zinc-400 block">
                      #{idx + 1} {isLeader ? '• LÍDER EN CAPITAL' : ''}
                    </span>
                    <span className="font-bold text-zinc-900 text-xs truncate block" title={reg.regionName}>
                      {reg.regionName}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded shrink-0 ${
                      isLeader
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-zinc-200/80 text-zinc-700'
                    }`}
                  >
                    {reg.pctOfNetwork}%
                  </span>
                </div>

                {/* Valuation & Pieces */}
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-sm font-bold font-mono text-zinc-900">
                    ${(reg.totalValuationUSD / 1000).toFixed(1)}k
                    <span className="text-[10px] text-zinc-400 font-sans ml-1">USD</span>
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500">
                    {reg.totalPieces.toLocaleString()} uds
                  </span>
                </div>

                {/* Progress bar showing proportion */}
                <div className="w-full bg-zinc-200/70 h-1.5 rounded-full overflow-hidden mt-2 flex">
                  <div
                    style={{
                      width: `${reg.totalValuationUSD > 0 ? (reg.calzadoUSD / reg.totalValuationUSD) * 100 : 0}%`,
                    }}
                    className="bg-sky-600 h-full"
                    title={`Calzado: $${(reg.calzadoUSD / 1000).toFixed(1)}k`}
                  />
                  <div
                    style={{
                      width: `${reg.totalValuationUSD > 0 ? (reg.textilUSD / reg.totalValuationUSD) * 100 : 0}%`,
                    }}
                    className="bg-emerald-500 h-full"
                    title={`Textil: $${(reg.textilUSD / 1000).toFixed(1)}k`}
                  />
                  <div
                    style={{
                      width: `${reg.totalValuationUSD > 0 ? (reg.accesoriosUSD / reg.totalValuationUSD) * 100 : 0}%`,
                    }}
                    className="bg-amber-500 h-full"
                    title={`Accesorios: $${(reg.accesoriosUSD / 1000).toFixed(1)}k`}
                  />
                </div>

                {/* Stores included in this group */}
                <div className="mt-2 text-[10px] text-zinc-500 truncate flex items-center gap-1">
                  <span className="font-semibold text-zinc-700">{reg.storesList.length}</span>
                  <span>{reg.storesList.length === 1 ? 'sucursal:' : 'sucursales:'}</span>
                  <span className="truncate text-zinc-600">
                    {reg.storesList.map((s) => s.name).join(', ')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
