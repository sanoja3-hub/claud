import React, { useState, useMemo } from 'react';
import {
  AlertOctagon,
  Building2,
  CheckCircle2,
  Filter,
  RotateCcw,
  Search,
  Store,
  X,
} from 'lucide-react';
import { CardInfoButton } from './CardInfoButton';
import {
  CapacityMatrixConfig,
  InventoryAlert,
  InventoryItem,
  StoreProfile,
} from '../types';
import {
  calcularResumenCapacidad,
  detectStoreClassification,
} from '../utils/analysisEngine';

interface NetworkMatrixCardProps {
  stores: string[];
  inventory: InventoryItem[];
  storeProfiles?: StoreProfile[];
  storeCapacities?: Record<string, CapacityMatrixConfig>;
  capacityConfig: CapacityMatrixConfig;
  alerts?: InventoryAlert[];
  onSelectStore: (store: string) => void;
  onNavigateToTab?: (tabId: string) => void;
  onOpenRegisterStore?: (store?: StoreProfile | null) => void;
  onDeleteStore?: (storeName: string) => void;
  selectedStore?: string;
  selectedBrand?: string;
  onSelectBrand?: (brand: string) => void;
  selectedConcept?: string;
  searchTerm?: string;
  onResetFilters?: () => void;
}

export const NetworkMatrixCard: React.FC<NetworkMatrixCardProps> = ({
  stores = [],
  inventory = [],
  storeProfiles = [],
  storeCapacities = {},
  capacityConfig,
  alerts = [],
  onSelectStore,
  onNavigateToTab,
  onOpenRegisterStore,
  onDeleteStore,
  selectedStore = 'TODAS',
  selectedBrand = 'TODAS',
  onSelectBrand,
  selectedConcept = 'TODOS',
  searchTerm = '',
  onResetFilters,
}) => {

  // Available product brands in the inventory
  const availableProductBrands = useMemo(() => {
    const brandsSet = new Set<string>();
    (inventory || []).forEach((it) => {
      if (it?.Marca) brandsSet.add(it.Marca.trim().toUpperCase());
    });
    return Array.from(brandsSet).sort();
  }, [inventory]);

  // Available store concepts
  const availableStoreConcepts = useMemo(() => {
    const conceptsSet = new Set<string>();
    const commonConcepts = ['Nike', 'Skechers', 'Sportmarket', 'Multimarca', 'Casual', 'Running'];
    (commonConcepts || []).forEach((c) => {
      const exists = (stores || []).some((st) => {
        const p = (storeProfiles || []).find((sp) => sp.nombre === st);
        if (p?.tipo?.toLowerCase().includes(c.toLowerCase())) return true;
        if (st.toLowerCase().includes(c.toLowerCase())) return true;
        if (p?.marcasCapacidad && Object.keys(p.marcasCapacidad).some((b) => b.toLowerCase().includes(c.toLowerCase()))) return true;
        return false;
      });
      if (exists) conceptsSet.add(c);
    });
    return Array.from(conceptsSet).sort();
  }, [stores, storeProfiles]);

  // Calculate detailed store metrics with professional retail supply chain weighting
  const storeMetrics = useMemo(() => {
    return stores.map((storeName) => {
      const allStoreItems = inventory.filter((it) => it.Tienda === storeName);
      const activeStoreItems =
        selectedBrand === 'TODAS'
          ? allStoreItems
          : allStoreItems.filter(
              (it) => (it.Marca || '').toUpperCase() === (selectedBrand || '').toUpperCase()
            );

      const profile = storeProfiles.find((p) => p.nombre === storeName);
      const storeCap = storeCapacities[storeName] || capacityConfig;
      const classification = detectStoreClassification(storeName, profile, allStoreItems);

      // 1. Overall physical capacity of the store (independent of product brand filter)
      const overallSummary = calcularResumenCapacidad(allStoreItems, storeCap, storeName, storeCapacities);
      const storeTotalPieces = overallSummary.reduce((acc, r) => acc + r.PiezasActual, 0);
      const storeIdealPieces = overallSummary.reduce((acc, r) => acc + r.PiezasIdeal, 0);
      const storePhysicalOccupancy =
        storeIdealPieces > 0 ? Math.round((storeTotalPieces / storeIdealPieces) * 1000) / 10 : 0;

      // 2. Filtered summary for current brand selection
      const summary =
        selectedBrand === 'TODAS'
          ? overallSummary
          : calcularResumenCapacidad(activeStoreItems, storeCap, storeName, storeCapacities);

      const totalPiecesActual = summary.reduce((acc, r) => acc + r.PiezasActual, 0);
      const totalPiecesIdeal = summary.reduce((acc, r) => acc + r.PiezasIdeal, 0);
      const totalSkusActual = summary.reduce((acc, r) => acc + r.SKUsActual, 0);
      const totalSkusIdeal = summary.reduce((acc, r) => acc + r.SKUsIdeal, 0);
      const totalValuation = summary.reduce((acc, r) => acc + r.ValoracionTotal, 0);

      // Physical occupancy remains the true space metric of the store
      const occupancyRate = storePhysicalOccupancy;

      // 3. Store alerts from network-wide diagnostics
      const storeAlerts = alerts.filter((a) => a.Tienda === storeName);
      const criticalAlerts = storeAlerts.filter(
        (a) => a.Prioridad.includes('CRÍTICA') || a.Prioridad.includes('ALTA')
      ).length;
      const brokenCurveCount = storeAlerts.filter((a) => a.TipoDeAlerta.includes('Quiebre') || a.TipoDeAlerta.includes('Monotalla')).length;

      const distinctBrands = Array.from(new Set(allStoreItems.map((it) => it.Marca))).filter(Boolean);

      return {
        name: storeName,
        profile,
        classification,
        distinctBrands,
        totalPiecesActual,
        totalPiecesIdeal,
        totalSkusActual,
        totalSkusIdeal,
        totalValuation,
        occupancyRate: Math.round(occupancyRate * 10) / 10,
        criticalAlerts,
        brokenCurveCount,
      };
    });
  }, [stores, inventory, storeProfiles, storeCapacities, capacityConfig, alerts, selectedBrand]);

  // Filter stores based on global unified dashboard filters
  const filteredStores = useMemo(() => {
    return storeMetrics.filter((s) => {
      if (selectedStore !== 'TODAS' && s.name !== selectedStore) return false;

      if (selectedConcept !== 'TODOS') {
        const matchesConcept =
          s.classification.concept.toLowerCase() === selectedConcept.toLowerCase() ||
          s.name.toLowerCase().includes(selectedConcept.toLowerCase()) ||
          (s.profile?.tipo && s.profile.tipo.toLowerCase().includes(selectedConcept.toLowerCase())) ||
          (s.profile?.marcasCapacidad &&
            Object.keys(s.profile.marcasCapacidad).some(
              (b) => b.toLowerCase() === selectedConcept.toLowerCase()
            )) ||
          s.distinctBrands.some((b) => b.toLowerCase() === selectedConcept.toLowerCase());
        if (!matchesConcept) return false;
      }

      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const matchesText =
          s.name.toLowerCase().includes(term) ||
          (s.profile?.ciudad && s.profile.ciudad.toLowerCase().includes(term)) ||
          (s.profile?.centroComercial && s.profile.centroComercial.toLowerCase().includes(term)) ||
          (s.profile?.direccion && s.profile.direccion.toLowerCase().includes(term)) ||
          s.classification.concept.toLowerCase().includes(term) ||
          (s.profile?.tipo && s.profile.tipo.toLowerCase().includes(term)) ||
          s.distinctBrands.some((b) => b.toLowerCase() === term);
        if (!matchesText) return false;
      }

      return true;
    });
  }, [storeMetrics, selectedStore, selectedConcept, searchTerm]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (selectedConcept !== 'TODOS') count++;
    if (selectedStore !== 'TODAS') count++;
    if (selectedBrand !== 'TODAS') count++;
    if (searchTerm.trim()) count++;
    return count;
  }, [selectedConcept, selectedStore, selectedBrand, searchTerm]);

  return (
    <div className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs space-y-3.5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-sm sm:text-base font-bold text-zinc-900 tracking-tight flex items-center gap-2">
            <Store className="w-4 h-4 text-zinc-800" />
            <span>Matriz Comparativa de Rendimiento & Capacidad por Tienda</span>
            <CardInfoButton
              title="Matriz Multitienda de Rendimiento & Capacidad"
              description="Visión consolidada de toda la red comercial que evalúa el cumplimiento de capacidad física (m² y piezas), salud de curvas de tallas y valoración del stock por punto de venta."
              formula="Ocupación = (Stock Real / Capacidad Máxima) * 100"
              operationalImpact="Identifica de inmediato qué sucursales están actuando como cuello de botella o con sobrestock para orientar los traslados inter-tienda."
            />
          </h2>
          <p className="text-xs text-zinc-500">
            Evaluación en tiempo real de ocupación física, quiebres de tallas y valoración financiera por sucursal
          </p>
        </div>

        {/* Global Filter Synchronization Indicator */}
        <div className="flex items-center gap-2 flex-wrap text-xs text-zinc-500">
          <span>
            Mostrando <strong className="text-zinc-900 font-mono">{filteredStores.length}</strong> de{' '}
            <strong className="text-zinc-900 font-mono">{stores.length}</strong> tiendas
          </span>
          {activeFiltersCount > 0 && onResetFilters && (
            <button
              type="button"
              onClick={onResetFilters}
              className="inline-flex items-center gap-1 text-[11px] font-medium text-zinc-600 hover:text-zinc-900 px-2 py-0.5 rounded border border-zinc-200 bg-zinc-50 hover:bg-zinc-100 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-2.5 h-2.5 text-zinc-500" />
              <span>Restablecer Filtros</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Filters Badges Row (if any active) */}
      {activeFiltersCount > 0 && (
        <div className="flex items-center gap-1.5 flex-wrap pt-0.5 text-[11px] font-mono">
          <span className="text-zinc-400 text-[10px] uppercase font-bold tracking-wider mr-1">Filtros sincronizados:</span>
          {selectedStore !== 'TODAS' && (
            <span className="px-2 py-0.5 bg-zinc-100 text-zinc-800 rounded border border-zinc-200 font-medium">
              Tienda: {selectedStore}
            </span>
          )}
          {selectedBrand !== 'TODAS' && (
            <span className="px-2 py-0.5 bg-purple-50 text-purple-800 rounded border border-purple-200 font-medium">
              Marca: {selectedBrand}
            </span>
          )}
          {selectedConcept !== 'TODOS' && (
            <span className="px-2 py-0.5 bg-blue-50 text-blue-800 rounded border border-blue-200 font-medium">
              Concepto: {selectedConcept}
            </span>
          )}
          {searchTerm.trim() && (
            <span className="px-2 py-0.5 bg-amber-50 text-amber-800 rounded border border-amber-200 font-medium">
              Búsqueda: &quot;{searchTerm}&quot;
            </span>
          )}
        </div>
      )}

      {/* Table of Stores */}
      <div className="overflow-x-auto rounded-lg border border-zinc-200/80">
        <table className="w-full text-left text-xs">
          <thead className="bg-zinc-50 text-zinc-500 text-[10px] uppercase font-mono font-bold tracking-wider border-b border-zinc-200">
            <tr>
              <th className="px-3.5 py-2.5">Tienda / Formato & Concepto</th>
              <th className="px-3.5 py-2.5 text-center">Superficie</th>
              <th className="px-3.5 py-2.5 text-right">
                Stock Actual / Ideal {selectedBrand !== 'TODAS' && `(${selectedBrand})`}
              </th>
              <th className="px-3.5 py-2.5 text-center">Ocupación Física</th>
              <th className="px-3.5 py-2.5 text-right">Valoración ($ USD)</th>
              <th className="px-3.5 py-2.5 text-center">Alertas / Quiebres</th>
            </tr>
          </thead>
            <tbody className="divide-y divide-zinc-100 text-zinc-700">
              {filteredStores.map((sm) => {
                const badgeColor =
                  sm.profile?.tipo === 'FLAGSHIP'
                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                    : sm.profile?.tipo === 'OUTLET' || sm.profile?.tipo === 'UNITE'
                    ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                    : sm.profile?.tipo === 'EXPRESS'
                    ? 'bg-sky-50 text-sky-800 border-sky-200'
                    : sm.classification.category === 'CONCEPTUAL'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-zinc-100 text-zinc-700 border-zinc-200';

                const occupancyColor =
                  sm.occupancyRate < 70
                    ? 'text-amber-800 bg-amber-50 border-amber-200'
                    : sm.occupancyRate > 115
                    ? 'text-rose-800 bg-rose-50 border-rose-200'
                    : 'text-emerald-800 bg-emerald-50 border-emerald-200';

                const isConceptual = sm.classification.category === 'CONCEPTUAL';

                return (
                  <tr key={sm.name} className="hover:bg-zinc-50 transition-colors">
                    <td className="px-3.5 py-2.5">
                      <div className="font-bold text-zinc-900 flex items-center gap-2 flex-wrap font-sans">
                        <span>🏬 {sm.name}</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase font-mono ${badgeColor}`}>
                          {sm.profile?.tipo || (isConceptual ? 'CONCEPTUAL' : 'MULTIMARCA')}
                        </span>
                        {sm.classification.concept && sm.classification.concept !== 'Multimarca General' && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-200 uppercase font-mono">
                            {sm.classification.concept}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-zinc-500 flex items-center gap-2 mt-0.5 flex-wrap">
                        <span>📍 {sm.profile?.ciudad || 'Principal'}</span>
                        {sm.profile?.centroComercial && (
                          <span className="font-semibold text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded border border-purple-200">
                            🏢 {sm.profile.centroComercial}
                          </span>
                        )}
                        {sm.profile?.direccion && <span>• {sm.profile.direccion}</span>}
                        {typeof sm.profile?.lat === 'number' && typeof sm.profile?.lng === 'number' && (
                          <span className="text-[9px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded font-bold" title={`GPS: ${sm.profile.lat}, ${sm.profile.lng}`}>
                            MAPS GPS
                          </span>
                        )}
                        {sm.distinctBrands.length > 0 && (
                          <span className="text-[10px] text-zinc-400">
                            • {sm.distinctBrands.length} marca{sm.distinctBrands.length > 1 ? 's' : ''} ({sm.distinctBrands.slice(0, 3).join(', ')}{sm.distinctBrands.length > 3 ? '...' : ''})
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-3.5 py-2.5 text-center font-mono text-zinc-500">
                      {sm.profile?.superficieM2 ? `${sm.profile.superficieM2} m²` : '—'}
                    </td>

                    <td className="px-3.5 py-2.5 text-right font-mono">
                      <div className="font-bold text-zinc-900">
                        {sm.totalPiecesActual.toLocaleString()}{' '}
                        <span className="text-zinc-500 font-normal">/ {sm.totalPiecesIdeal.toLocaleString()} uds</span>
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        {sm.totalSkusActual} / {sm.totalSkusIdeal} SKUs
                      </div>
                    </td>

                    <td className="px-3.5 py-2.5 text-center">
                      <div className="flex flex-col items-center gap-1">
                        <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold border ${occupancyColor}`}>
                          {sm.occupancyRate}%
                        </span>
                        <div className="w-20 bg-zinc-100 border border-zinc-200/80 h-1.5 rounded-full overflow-hidden p-0.5">
                          <div
                            className={`h-full rounded-full ${
                              sm.occupancyRate < 70
                                ? 'bg-amber-500'
                                : sm.occupancyRate > 115
                                ? 'bg-rose-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, sm.occupancyRate)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="px-3.5 py-2.5 text-right font-mono font-bold text-zinc-900 whitespace-nowrap">
                      ${sm.totalValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-[10px] text-zinc-500 font-semibold">USD</span>
                    </td>

                    <td className="px-3.5 py-2.5 text-center">
                      {sm.criticalAlerts > 0 ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold font-mono">
                          <AlertOctagon className="w-3 h-3 text-rose-500" />
                          {sm.criticalAlerts} Críticas
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold font-mono">
                          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                          Sin Alertas
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
  );
};
