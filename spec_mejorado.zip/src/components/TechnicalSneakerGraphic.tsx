import React from 'react';

interface TechnicalSneakerGraphicProps {
  className?: string;
  departamento?: string;
}

export const TechnicalSneakerGraphic: React.FC<TechnicalSneakerGraphicProps> = ({
  className = 'w-full h-48',
  departamento = 'CALZADO',
}) => {
  const deptoUpper = (departamento || '').toUpperCase();
  const isTextil = deptoUpper.includes('TEXTIL') || deptoUpper.includes('ROPA');
  const isAccesorios = deptoUpper.includes('ACCESORIO') || deptoUpper.includes('COMPLEMENTO');

  if (isTextil) {
    return (
      <div className={`relative flex items-center justify-center overflow-hidden ${className}`}>
        <div className="absolute inset-0 bg-radial from-slate-700/15 via-slate-900/40 to-transparent blur-xl pointer-events-none" />
        <div className="absolute bottom-4 w-1/2 h-4 bg-black/60 rounded-full blur-md" />
        <svg
          viewBox="0 0 320 220"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full max-h-[190px] drop-shadow-2xl z-10 transition-transform duration-300 hover:scale-105"
        >
          <path
            d="M 110 35 L 140 55 C 152 60 168 60 180 55 L 210 35 L 260 65 L 235 105 L 205 92 L 205 195 L 115 195 L 115 92 L 85 105 L 60 65 Z"
            fill="#1e293b"
            stroke="#64748b"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          <path d="M 140 55 C 152 65 168 65 180 55" stroke="#64748b" strokeWidth="2.5" fill="none" />
          <path d="M 115 92 L 205 92" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
          <path d="M 160 110 L 160 170" stroke="#94a3b8" strokeWidth="1.5" strokeOpacity="0.6" strokeDasharray="4 4" />
          <text x="160" y="140" fill="#94a3b8" fontSize="8" fontFamily="monospace" fontWeight="bold" textAnchor="middle" letterSpacing="1">
            TECHNICAL APPAREL
          </text>
        </svg>
      </div>
    );
  }

  if (isAccesorios) {
    return (
      <div className={`relative flex items-center justify-center overflow-hidden ${className}`}>
        <div className="absolute inset-0 bg-radial from-slate-700/15 via-slate-900/40 to-transparent blur-xl pointer-events-none" />
        <div className="absolute bottom-4 w-1/2 h-4 bg-black/60 rounded-full blur-md" />
        <svg
          viewBox="0 0 320 220"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full max-h-[190px] drop-shadow-2xl z-10 transition-transform duration-300 hover:scale-105"
        >
          <path
            d="M 110 80 C 110 50 130 40 160 40 C 190 40 210 50 210 80 L 220 185 C 220 195 210 200 200 200 L 120 200 C 110 200 100 195 100 185 Z"
            fill="#1e293b"
            stroke="#64748b"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          <path d="M 135 40 C 135 25 185 25 185 40" stroke="#64748b" strokeWidth="2.5" fill="none" />
          <rect x="125" y="105" width="70" height="55" rx="8" fill="#0f172a" stroke="#64748b" strokeWidth="1.5" />
          <path d="M 125 125 L 195 125" stroke="#475569" strokeWidth="1.5" />
          <text x="160" y="145" fill="#94a3b8" fontSize="7.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle" letterSpacing="0.8">
            EQUIPMENT
          </text>
        </svg>
      </div>
    );
  }
  return (
    <div className={`relative flex items-center justify-center overflow-hidden ${className}`}>
      {/* Ambient background studio glow */}
      <div className="absolute inset-0 bg-radial from-slate-700/15 via-slate-900/40 to-transparent blur-xl pointer-events-none" />

      {/* Ground soft shadow */}
      <div className="absolute bottom-4 w-3/4 h-5 bg-black/60 rounded-full blur-md" />

      {/* Crisp Technical Sneaker SVG Render (NX-Terra Pro Dark Edition) */}
      <svg
        viewBox="0 0 420 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full max-h-[190px] drop-shadow-2xl z-10 transition-transform duration-300 hover:scale-105"
      >
        <defs>
          <linearGradient id="soleGradient" x1="50" y1="160" x2="380" y2="190" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="40%" stopColor="#0f172a" />
            <stop offset="70%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>

          <linearGradient id="upperGradient" x1="80" y1="70" x2="350" y2="160" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="30%" stopColor="#1e293b" />
            <stop offset="70%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>

          <linearGradient id="slateAccent" x1="120" y1="110" x2="280" y2="150" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#94a3b8" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#64748b" stopOpacity="0.3" />
          </linearGradient>

          <linearGradient id="silverHighlight" x1="180" y1="80" x2="320" y2="120" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="50%" stopColor="#cbd5e1" />
            <stop offset="100%" stopColor="#64748b" />
          </linearGradient>

          <linearGradient id="cushionCell" x1="220" y1="165" x2="290" y2="185" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#475569" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#334155" stopOpacity="0.2" />
          </linearGradient>

          <filter id="sneakerShadow" x="-10%" y="-10%" width="120%" height="130%">
            <feDropShadow dx="0" dy="12" stdDeviation="10" floodColor="#000000" floodOpacity="0.7" />
          </filter>
        </defs>

        <g filter="url(#sneakerShadow)">
          {/* Outsole Base Profile */}
          <path
            d="M 52 178 C 75 186 120 188 160 187 C 210 185 270 190 320 186 C 350 184 375 174 382 165 C 385 161 380 157 372 159 C 345 166 295 167 250 167 C 190 167 125 162 75 168 C 60 170 50 173 52 178 Z"
            fill="#0b0f17"
            stroke="#1e293b"
            strokeWidth="2"
          />

          {/* Sculpted Chunky Midsole */}
          <path
            d="M 56 174 C 70 178 115 179 160 178 C 205 176 265 181 315 178 C 342 176 368 168 376 160 C 365 152 340 154 310 155 C 265 156 220 153 175 155 C 130 157 85 159 62 166 C 54 169 53 173 56 174 Z"
            fill="url(#soleGradient)"
            stroke="#334155"
            strokeWidth="1.5"
          />

          {/* Air Cushion Windows in Midsole */}
          <rect x="230" y="165" width="22" height="7" rx="3.5" fill="url(#cushionCell)" stroke="#475569" strokeWidth="0.8" />
          <rect x="260" y="166" width="22" height="7" rx="3.5" fill="url(#cushionCell)" stroke="#475569" strokeWidth="0.8" />
          <rect x="290" y="167" width="20" height="6.5" rx="3" fill="url(#cushionCell)" stroke="#475569" strokeWidth="0.8" />

          {/* Main Upper Chassis */}
          <path
            d="M 70 165 C 80 150 95 138 120 132 C 145 126 170 125 195 122 C 220 119 240 105 260 88 C 275 75 295 72 312 80 C 322 85 328 95 330 110 C 332 125 342 135 365 145 C 374 149 375 155 368 158 C 345 164 300 162 250 162 C 190 162 120 161 70 165 Z"
            fill="url(#upperGradient)"
            stroke="#475569"
            strokeWidth="1.5"
          />

          {/* Technical Mesh Overlays */}
          <path
            d="M 115 135 C 140 130 175 129 205 126 C 215 125 225 120 235 112 C 205 120 165 124 125 132 Z"
            fill="#0f172a"
            stroke="#1e293b"
            strokeWidth="1"
          />

          {/* Aerodynamic Ribs */}
          <path
            d="M 140 148 C 170 140 210 138 250 120 C 270 111 290 100 305 85"
            stroke="url(#silverHighlight)"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          <path
            d="M 160 154 C 190 146 230 144 265 130 C 285 122 305 110 320 98"
            stroke="#64748b"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <path
            d="M 190 158 C 220 152 255 148 285 138 C 305 131 325 120 338 112"
            stroke="url(#slateAccent)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Lacing System */}
          <path d="M 235 114 L 246 118" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 250 103 L 262 108" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 266 92 L 278 98" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M 284 83 L 295 90" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />

          {/* Tongue & Collar */}
          <path
            d="M 282 82 C 290 68 305 65 318 72 C 326 77 330 88 332 98 C 320 92 305 90 290 92 Z"
            fill="#1e293b"
            stroke="#475569"
            strokeWidth="1.2"
          />

          {/* Heel Counter & Pull Tab */}
          <path
            d="M 326 102 C 330 100 336 103 338 112 C 342 126 352 136 368 144 C 360 148 350 146 342 138 C 335 128 328 116 326 102 Z"
            fill="#334155"
            stroke="#64748b"
            strokeWidth="1.2"
          />
          {/* Reflective Pull loop */}
          <path d="M 334 85 C 345 80 354 90 350 102" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" fill="none" />

          {/* Mudguard Toe Cap Shield */}
          <path
            d="M 70 165 C 62 163 56 160 55 154 C 54 148 60 144 68 142 C 76 140 85 144 92 148 C 84 154 77 160 70 165 Z"
            fill="#0f172a"
            stroke="#334155"
            strokeWidth="1.5"
          />

          {/* NX-Terra Spec Tag Print */}
          <text x="145" y="142" fill="#94a3b8" fontSize="6.5" fontFamily="monospace" fontWeight="bold" letterSpacing="0.8">
            NX-TERRA // PRO R2
          </text>
        </g>
      </svg>
    </div>
  );
};
