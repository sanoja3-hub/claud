import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  Database,
  Edit2,
  Filter,
  RefreshCw,
  Search,
  Square,
  Trash2,
  X,
} from 'lucide-react';
import { CardInfoButton } from './CardInfoButton';
import { InventoryItem } from '../types';

interface InventoryDetailTabProps {
  inventory: InventoryItem[];
  onDeleteItem?: (id: string) => void;
  onDeleteBatch?: (ids: string[]) => void;
  onClearStore?: (storeName: string) => void;
  onUpdateItem?: (updatedItem: InventoryItem) => void;
  onPurgeTextileAnomalies?: (targetItems?: InventoryItem[]) => void;
}

export const InventoryDetailTab: React.FC<InventoryDetailTabProps> = ({
  inventory = [],
  onDeleteItem,
  onDeleteBatch,
  onClearStore,
  onUpdateItem,
  onPurgeTextileAnomalies,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDept, setFilterDept] = useState('TODAS');
  const [filterStore, setFilterStore] = useState('TODAS');
  const [page, setPage] = useState(1);
  const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isConfirmingPurge, setIsConfirmingPurge] = useState(false);
  
  // State for Editing an Item in-place (e.g. correcting a Talla or Stock)
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [editTalla, setEditTalla] = useState('');
  const [editStock, setEditStock] = useState<number>(0);
  const [editValoracion, setEditValoracion] = useState<number>(0);

  const pageSize = 50;

  const departments = useMemo(() => {
    return Array.from(new Set(inventory.map((i) => i.Departamento))).sort();
  }, [inventory]);

  const stores = useMemo(() => {
    return Array.from(new Set(inventory.map((i) => i.Tienda))).sort();
  }, [inventory]);

  const hasSalesOrWos = useMemo(() => {
    return inventory.some((it) => it.VentaSemanal !== undefined || it.WOS !== undefined);
  }, [inventory]);

  const filtered = useMemo(() => {
    return inventory.filter((item) => {
      if (filterDept !== 'TODAS' && item.Departamento !== filterDept) return false;
      if (filterStore !== 'TODAS' && item.Tienda !== filterStore) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const match =
          item.Referencia.toLowerCase().includes(q) ||
          item.Marca.toLowerCase().includes(q) ||
          item.Familia.toLowerCase().includes(q) ||
          item.Talla.toLowerCase().includes(q) ||
          item.Tienda.toLowerCase().includes(q) ||
          item.SKU_Talla.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [inventory, filterDept, filterStore, searchQuery]);

  // Detect anomalies: Textile products with numeric sizes (like 4, 5, 6 instead of XS, S, M, L)
  const textileNumericAnomalies = useMemo(() => {
    return inventory.filter((it) => {
      const isTextil =
        (it.Departamento || '').toUpperCase().includes('TEXTIL') ||
        (it.Familia || '').toUpperCase().includes('APPAREL') ||
        (it.Familia || '').toUpperCase().includes('TEXTIL') ||
        (it.Familia || '').toUpperCase().includes('ROPA');
      
      if (!isTextil) return false;

      // Numeric size like "4", "5", "6", "8", "10"
      const isNumeric = /^\d+(\.0+)?$/.test(it.Talla.trim());
      return isNumeric;
    });
  }, [inventory]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pagedItems = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleToggleSelectAllPage = () => {
    const pageIds = pagedItems.map((it, idx) => it.id || `inv-${idx}`);
    const allSelected = pageIds.every((id) => selectedItemIds.has(id));

    setSelectedItemIds((prev) => {
      const next = new Set(prev);
      if (allSelected) {
        pageIds.forEach((id) => next.delete(id));
      } else {
        pageIds.forEach((id) => next.add(id));
      }
      return next;
    });
  };

  const handleToggleSelectItem = (id: string) => {
    setSelectedItemIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleDeleteSelected = () => {
    if (selectedItemIds.size === 0 || !onDeleteBatch) return;
    const count = selectedItemIds.size;
    onDeleteBatch(Array.from(selectedItemIds));
    setSelectedItemIds(new Set());
    setStatusMessage(`${count} fila(s) seleccionada(s) eliminada(s) correctamente.`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleDeleteFilteredAll = () => {
    if (filtered.length === 0 || !onDeleteBatch) return;
    const count = filtered.length;
    const ids = filtered.map((it, idx) => it.id || `inv-${idx}`);
    onDeleteBatch(ids);
    setSelectedItemIds(new Set());
    setStatusMessage(`${count} fila(s) filtrada(s) eliminada(s) correctamente.`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handlePurgeTextileAnomalies = () => {
    if (textileNumericAnomalies.length === 0) return;
    const count = textileNumericAnomalies.length;
    const anomalyItems = [...textileNumericAnomalies];

    // Trigger both direct handler and batch deletion for robustness
    if (onPurgeTextileAnomalies) {
      onPurgeTextileAnomalies(anomalyItems);
    }
    if (onDeleteBatch) {
      const ids = anomalyItems.flatMap((it, idx) => [
        it.id || '',
        `inv-${idx}`,
        `${it.Tienda}__${it.Referencia}__${it.Talla}`,
        `${it.Referencia}__${it.Talla}`,
      ]).filter(Boolean);
      onDeleteBatch(ids);
    }

    setIsConfirmingPurge(false);
    setStatusMessage(`Se depuraron y suprimieron exitosamente ${count} fila(s) con tallas numéricas erróneas.`);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleClearCurrentStore = () => {
    if (filterStore === 'TODAS' || !onClearStore) return;
    onClearStore(filterStore);
    setStatusMessage(`Inventario de "${filterStore}" vaciado.`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleStartEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setEditTalla(item.Talla);
    setEditStock(item.Stock);
    setEditValoracion(item.Valoracion);
  };

  const handleSaveEdit = () => {
    if (!editingItem || !onUpdateItem) return;
    const updated: InventoryItem = {
      ...editingItem,
      Talla: editTalla.trim().toUpperCase() || 'U',
      SKU_Talla: `${editingItem.Referencia} | ${editTalla.trim().toUpperCase() || 'U'}`,
      Stock: Math.max(0, editStock),
      Valoracion: Math.max(0, editValoracion),
    };
    onUpdateItem(updated);
    setEditingItem(null);
    setStatusMessage(`Registro de ${updated.Referencia} corregido a talla "${updated.Talla}".`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white p-4 sm:p-5 rounded-xl border border-zinc-200/90 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-zinc-700 shrink-0" />
            <h2 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight flex items-center gap-2">
              <span>Detalle Canónico y Depuración de Inventario</span>
              <CardInfoButton
                title="Detalle Canónico y Depuración de Inventario"
                description="Vista granular fila a fila de todos los registros cargados en el motor. Permite auditar SKUs, referencias, marcas, tallas y existencias."
                formula="Existencias = Unidades Físicas Registradas en Tienda"
                operationalImpact="Permite editar datos erróneos de origen, depurar registros corruptos y validar la correspondencia con el ERP."
              />
            </h2>
          </div>
          <p className="text-xs text-zinc-500 mt-1">
            Inspección granular fila por fila: puedes corregir tallas, editar existencias o eliminar registros erróneos sin afectar los productos correctos.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-7 px-2.5 rounded-lg text-xs font-medium bg-zinc-100 text-zinc-700 border border-zinc-200 font-mono inline-flex items-center">
            {inventory.length.toLocaleString()} Registros Totales
          </span>
        </div>
      </div>

      {/* Notification banner */}
      {statusMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-4 py-2.5 rounded-xl flex items-center justify-between animate-fadeIn">
          <span>{statusMessage}</span>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Anomaly Detection Banner for Textile Products with Numeric Sizes */}
      {textileNumericAnomalies.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-amber-900">
                Se detectaron {textileNumericAnomalies.length} filas textiles con tallas numéricas (ej: 4, 5, 6)
              </h4>
              <p className="text-[11px] text-amber-700 mt-0.5 max-w-2xl leading-relaxed">
                Prendas como <strong>{textileNumericAnomalies[0]?.Referencia}</strong> en <strong>{textileNumericAnomalies[0]?.Tienda}</strong> tienen filas con tallas numéricas provenientes de una carga previa. 
                <span className="font-semibold text-amber-900 ml-1">
                  La depuración NO elimina el producto: solo elimina estas filas numéricas erróneas, manteniendo intactas las tallas válidas (XS, S, M, L).
                </span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                const sampleRef = textileNumericAnomalies[0]?.Referencia || '';
                setSearchQuery(sampleRef);
                setFilterStore('TODAS');
                setPage(1);
              }}
              className="px-3 py-1.5 bg-white hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              Ver {textileNumericAnomalies[0]?.Referencia}
            </button>
            <button
              type="button"
              onClick={handlePurgeTextileAnomalies}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-lg text-xs font-bold font-mono transition-all shadow-xs hover:shadow cursor-pointer whitespace-nowrap"
              title="Suprime y elimina de inmediato estas filas textiles con tallas numéricas erróneas"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Depurar y suprimir ({textileNumericAnomalies.length}) filas
            </button>
          </div>
        </div>
      )}

      {/* Filters & Search Bar */}
      <div className="bg-white p-3 sm:p-4 rounded-xl border border-zinc-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-zinc-500 font-semibold uppercase tracking-wider mr-1">
            <Filter className="w-3.5 h-3.5" />
            <span>Filtros:</span>
          </div>

          <select
            value={filterDept}
            onChange={(e) => {
              setFilterDept(e.target.value);
              setPage(1);
            }}
            className="h-8 bg-white border border-zinc-200/90 text-xs text-zinc-800 rounded-lg px-2.5 shadow-xs focus:outline-none focus:border-zinc-400 cursor-pointer"
          >
            <option value="TODAS">Todos los Deptos</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>

          <select
            value={filterStore}
            onChange={(e) => {
              setFilterStore(e.target.value);
              setPage(1);
            }}
            className="h-8 bg-white border border-zinc-200/90 text-xs text-zinc-800 rounded-lg px-2.5 shadow-xs focus:outline-none focus:border-zinc-400 cursor-pointer"
          >
            <option value="TODAS">Todas las Tiendas</option>
            {stores.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {filterStore !== 'TODAS' && onClearStore && (
            <button
              type="button"
              onClick={handleClearCurrentStore}
              className="h-8 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              title={`Vaciar todo el inventario cargado de ${filterStore}`}
            >
              <RefreshCw className="w-3 h-3" />
              Vaciar {filterStore}
            </button>
          )}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Buscar SKU (ej: IQ3750), Marca, Talla..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPage(1);
            }}
            className="w-full h-8 bg-white border border-zinc-200/90 rounded-lg pl-8 pr-3 text-xs text-zinc-900 placeholder-zinc-400 shadow-xs focus:outline-none focus:border-zinc-400 transition-colors"
          />
        </div>
      </div>

      {/* Batch Action Bar */}
      {(selectedItemIds.size > 0 || (searchQuery.trim() !== '' && filtered.length > 0)) && (
        <div className="bg-[#F8F7FC] p-3 rounded-xl border border-zinc-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-zinc-700">
              {selectedItemIds.size > 0 ? (
                <>
                  <strong className="text-zinc-900 font-mono">{selectedItemIds.size}</strong> seleccionados de{' '}
                  <strong className="text-zinc-900 font-mono">{filtered.length}</strong> filtrados
                </>
              ) : (
                <>
                  <strong className="text-zinc-900 font-mono">{filtered.length}</strong> registros encontrados
                </>
              )}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {selectedItemIds.size > 0 && onDeleteBatch && (
              <button
                type="button"
                onClick={handleDeleteSelected}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Eliminar Seleccionados ({selectedItemIds.size})
              </button>
            )}

            {searchQuery.trim() !== '' && onDeleteBatch && (
              <button
                type="button"
                onClick={handleDeleteFilteredAll}
                className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Eliminar todos los registros que coinciden con el filtro de búsqueda actual"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                Eliminar {filtered.length} Filtrados
              </button>
            )}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl border border-zinc-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.02)] overflow-hidden">
        <div className="overflow-x-auto max-h-[600px]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F4F2FD] text-zinc-500 sticky top-0 z-10 text-[10px] uppercase font-bold font-mono tracking-wider border-b border-zinc-200">
              <tr>
                {onDeleteBatch && (
                  <th className="px-3 py-3 w-8 text-center">
                    <button
                      type="button"
                      onClick={handleToggleSelectAllPage}
                      className="cursor-pointer text-zinc-500 hover:text-zinc-900 inline-flex items-center"
                      title="Seleccionar / Deseleccionar página"
                    >
                      {pagedItems.length > 0 &&
                      pagedItems.every((it, idx) => selectedItemIds.has(it.id || `inv-${idx}`)) ? (
                        <CheckSquare className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                )}
                <th className="px-3.5 py-3 font-semibold">Tienda</th>
                <th className="px-3.5 py-3 font-semibold">Referencia / SKU</th>
                <th className="px-3.5 py-3 font-semibold">Departamento</th>
                <th className="px-3.5 py-3 font-semibold">Sección</th>
                <th className="px-3.5 py-3 font-semibold">Familia</th>
                <th className="px-3.5 py-3 font-semibold">Marca</th>
                <th className="px-3.5 py-3 text-center font-semibold">Talla</th>
                <th className="px-3.5 py-3 text-right font-semibold">Stock</th>
                <th className="px-3.5 py-3 text-right font-semibold">Valoración ($ USD)</th>
                {hasSalesOrWos && (
                  <th className="px-3.5 py-3 text-right font-semibold">Venta Sem. / WOS</th>
                )}
                <th className="px-3.5 py-3 font-mono text-zinc-500 font-semibold">SKU_Talla</th>
                {(onDeleteItem || onUpdateItem) && <th className="px-3 py-3 text-center w-16">Acción</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 text-zinc-700">
              {pagedItems.length > 0 ? (
                pagedItems.map((it, idx) => {
                  const absoluteIndex = (currentPage - 1) * pageSize + idx;
                  const itemId = it.id || `inv-${absoluteIndex}`;
                  const rowKey = `${itemId}__${absoluteIndex}`;
                  const isSelected = selectedItemIds.has(itemId);
                  const isNumericAnomaly =
                    it.Departamento === 'TEXTIL' && /^\d+(\.0+)?$/.test(it.Talla.trim());

                  return (
                    <tr
                      key={rowKey}
                      className={`hover:bg-[#F8F7FC] transition-colors ${
                        isSelected ? 'bg-blue-50/60' : isNumericAnomaly ? 'bg-amber-50/40' : ''
                      }`}
                    >
                      {onDeleteBatch && (
                        <td className="px-3 py-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleSelectItem(itemId)}
                            className="cursor-pointer text-zinc-400 hover:text-zinc-700 inline-flex items-center"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-blue-600" />
                            ) : (
                              <Square className="w-4 h-4" />
                            )}
                          </button>
                        </td>
                      )}
                      <td className="px-3.5 py-2.5 text-zinc-700 font-medium whitespace-nowrap">
                        {it.Tienda}
                      </td>
                      <td className="px-3.5 py-2.5 font-mono font-bold text-zinc-900 whitespace-nowrap">
                        {it.Referencia}
                      </td>
                      <td className="px-3.5 py-2.5 text-zinc-700 whitespace-nowrap">
                        {it.Departamento}
                      </td>
                      <td className="px-3.5 py-2.5 text-zinc-500 whitespace-nowrap">{it.Seccion}</td>
                      <td className="px-3.5 py-2.5 text-zinc-500 whitespace-nowrap">{it.Familia}</td>
                      <td className="px-3.5 py-2.5 text-zinc-900 font-semibold whitespace-nowrap">
                        {it.Marca}
                      </td>
                      <td className="px-3.5 py-2.5 text-center font-mono font-bold whitespace-nowrap">
                        <span
                          className={
                            isNumericAnomaly
                              ? 'px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300'
                              : 'text-zinc-800'
                          }
                          title={
                            isNumericAnomaly
                              ? 'Talla numérica detectada en categoría Textil'
                              : undefined
                          }
                        >
                          {it.Talla}
                        </span>
                      </td>
                      <td className="px-3.5 py-2.5 text-right font-mono font-bold text-zinc-900 whitespace-nowrap">
                        {(it.Stock ?? 0).toLocaleString()}
                      </td>
                      <td
                        className="px-3.5 py-2.5 text-right font-mono text-zinc-700 whitespace-nowrap"
                        title={it.ValoracionBs !== undefined ? `Original: Bs. ${it.ValoracionBs.toLocaleString('es-VE')}` : undefined}
                      >
                        ${(it.Valoracion ?? 0).toFixed(2)}
                      </td>
                      {hasSalesOrWos && (
                        <td className="px-3.5 py-2.5 text-right font-mono whitespace-nowrap">
                          {it.VentaSemanal !== undefined ? (
                            <span className="text-zinc-900 font-bold">{it.VentaSemanal} u/s</span>
                          ) : (
                            <span className="text-zinc-400">—</span>
                          )}
                          {it.WOS !== undefined && (
                            <span
                              className={`ml-1.5 text-[10px] px-1.5 py-0.5 rounded border font-semibold ${
                                it.WOS > 20
                                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                                  : it.WOS < 2
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              }`}
                              title={`Cobertura: ${it.WOS} semanas`}
                            >
                              {it.WOS === 999 ? '∞ WOS' : `${it.WOS}s`}
                            </span>
                          )}
                        </td>
                      )}
                      <td className="px-3.5 py-2.5 font-mono text-zinc-500 text-[11px] whitespace-nowrap">
                        {it.SKU_Talla}
                      </td>
                      {(onDeleteItem || onUpdateItem) && (
                        <td className="px-3 py-2.5 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            {onUpdateItem && (
                              <button
                                type="button"
                                onClick={() => handleStartEdit(it)}
                                className="p-1 rounded text-zinc-400 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                                title="Corregir talla o datos de esta fila"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                             {onDeleteItem && (
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteItem(itemId);
                                  setStatusMessage(`Fila de talla "${it.Talla}" para ${it.Referencia} eliminada.`);
                                  setTimeout(() => setStatusMessage(null), 3000);
                                }}
                                className="p-1 rounded text-zinc-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Eliminar solo este registro de talla"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={12} className="px-4 py-8 text-center text-zinc-500 text-xs">
                    No se encontraron registros de inventario que coincidan con los filtros.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination bar */}
        <div className="px-4 py-3 bg-[#F4F2FD] border-t border-zinc-200 flex items-center justify-between text-xs text-zinc-500">
          <div>
            Mostrando registros{' '}
            <span className="text-zinc-900 font-mono font-bold">
              {filtered.length > 0 ? (currentPage - 1) * pageSize + 1 : 0}
            </span>{' '}
            a{' '}
            <span className="text-zinc-900 font-mono font-bold">
              {Math.min(currentPage * pageSize, filtered.length)}
            </span>{' '}
            de <span className="text-zinc-900 font-mono font-bold">{filtered.length.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg bg-white hover:bg-zinc-100 text-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer border border-zinc-200 transition-colors shadow-2xs"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-zinc-700 font-mono text-xs font-semibold">
              Página {currentPage} de {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg bg-white hover:bg-zinc-100 text-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer border border-zinc-200 transition-colors shadow-2xs"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal: Edit / Correct Single Row */}
      {editingItem && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-zinc-200 shadow-xl max-w-md w-full p-5 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-zinc-200/80 pb-3">
              <div>
                <h3 className="text-sm font-bold text-zinc-900">
                  Corregir Registro de Talla
                </h3>
                <p className="text-xs text-zinc-500 font-mono">
                  {editingItem.Referencia} // {editingItem.Tienda}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="text-zinc-400 hover:text-zinc-700 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-zinc-700 mb-1">
                  Talla (Ej: XS, S, M, L, XL)
                </label>
                <input
                  type="text"
                  value={editTalla}
                  onChange={(e) => setEditTalla(e.target.value)}
                  className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 focus:outline-none focus:border-blue-500 uppercase"
                  placeholder="XS, S, M, L..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">
                    Stock (Unidades)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={editStock}
                    onChange={(e) => setEditStock(parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-zinc-700 mb-1">
                    Valoración ($ USD)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={editValoracion}
                    onChange={(e) => setEditValoracion(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#F8F7FC] border border-zinc-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-zinc-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <p className="text-[11px] text-zinc-500 leading-tight">
                Al guardar, se actualiza únicamente esta fila. El resto de las tallas y datos del producto permanecen inalterados.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-100">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-zinc-600 hover:bg-zinc-100 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" />
                Guardar Corrección
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
