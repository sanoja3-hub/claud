import React, { useRef, useState, useEffect } from 'react';
import {
  BookOpen,
  Building2,
  CheckCircle2,
  ChevronDown,
  Cloud,
  Crown,
  Download,
  FileJson,
  FileSpreadsheet,
  Layers,
  LogOut,
  MoreVertical,
  PanelLeftOpen,
  RefreshCw,
  Search,
  Settings2,
  Sliders,
  Sparkles,
  Store,
  Tag,
  Trash2,
  Upload,
  UploadCloud,
  User as UserIcon,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { User } from 'firebase/auth';
import { SpecLogoIcon } from './SpecLogo';

interface HeaderProps {
  stores: string[];
  selectedStore: string;
  onSelectStore: (store: string) => void;
  brands?: string[];
  selectedBrand?: string;
  onSelectBrand?: (brand: string) => void;
  onOpenUpload: () => void;
  onExportExcel: () => void;
  onResetToSample?: () => void;
  onClearAll?: () => void;
  onOpenRegisterStore?: () => void;
  onOpenManager?: () => void;
  isManagerActive?: boolean;
  totalItems: number;
  totalValuation: number;
  isCustomData?: boolean;
  onOpenCommandPalette?: () => void;
  onOpenWhatIf?: () => void;
  onOpenRuleEngine?: () => void;
  onOpenManual?: () => void;
  onExportJSON?: () => void;
  onImportJSON?: (jsonData: string) => void;
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: () => void;
  alertsCount?: number;
  currentUser?: User | null;
  isCloudSyncing?: boolean;
  lastCloudSync?: string | null;
  isQuotaExceeded?: boolean;
  onLoginGoogle?: () => void;
  onLogoutGoogle?: () => void;
  onManualCloudSync?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  stores,
  selectedStore,
  onSelectStore,
  brands,
  selectedBrand,
  onSelectBrand,
  onOpenUpload,
  onExportExcel,
  onResetToSample,
  onClearAll,
  onOpenRegisterStore,
  onOpenManager,
  isManagerActive,
  totalItems,
  totalValuation,
  isCustomData,
  onOpenCommandPalette,
  onOpenWhatIf,
  onOpenRuleEngine,
  onOpenManual,
  onExportJSON,
  onImportJSON,
  isSidebarCollapsed,
  onToggleSidebar,
  alertsCount,
  currentUser,
  isCloudSyncing = false,
  lastCloudSync,
  isQuotaExceeded = false,
  onLoginGoogle,
  onLogoutGoogle,
  onManualCloudSync,
}) => {
  const jsonFileInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsDropdownOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleJSONFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onImportJSON) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onImportJSON(content);
      }
    };
    reader.readAsText(file);
    if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
  };

  const hasData = totalItems > 0 || stores.length > 0;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-zinc-200/90 text-zinc-900 transition-all select-none">
      <div className="max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-2">
        <div className="flex items-center justify-between gap-2.5 sm:gap-4 min-h-[32px] w-full">
          {/* Brand & Identity Area with Native Sidebar Toggle */}
          <div className="flex items-center gap-2.5 min-w-0 shrink-0">
            {isSidebarCollapsed && onToggleSidebar && (
              <button
                type="button"
                id="btn-pestana-menu-lateral"
                onClick={onToggleSidebar}
                className="relative w-8 h-8 flex items-center justify-center bg-white border border-zinc-200/90 rounded-lg shadow-xs hover:bg-zinc-50 hover:border-zinc-300 text-zinc-700 hover:text-zinc-900 transition-all cursor-pointer shrink-0"
                title="Desplegar menú lateral"
                aria-label="Desplegar menú lateral"
              >
                <PanelLeftOpen className="w-4 h-4 text-zinc-700" />
                {alertsCount && alertsCount > 0 ? (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500" title={`${alertsCount} alertas críticas`} />
                ) : null}
              </button>
            )}

            <div className="w-8 h-8 rounded-lg bg-white border border-zinc-200/90 shadow-2xs flex items-center justify-center shrink-0 p-1 hover:border-zinc-300 transition-colors">
              <SpecLogoIcon className="w-full h-full" />
            </div>
            <div className="min-w-0">
              <h1 className="text-xs sm:text-sm font-black tracking-[0.22em] text-zinc-900 uppercase truncate leading-none flex items-center">
                <span>SPEC</span>
                <span className="w-1.5 h-1.5 bg-[#F97316] ml-1 inline-block rounded-[1px] shrink-0" />
              </h1>
              <p className="text-[10px] text-zinc-500 font-bold tracking-[0.14em] uppercase truncate mt-0.5 leading-tight">
                Distribution Curve &amp; Rebalance
              </p>
            </div>
          </div>

          {/* Symmetrical Quick Tools & Compact Selectors */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Global Search Bar Trigger */}
            {onOpenCommandPalette && (
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={onOpenCommandPalette}
                className="hidden xl:flex items-center gap-2 h-8 px-2.5 bg-white hover:bg-zinc-50 border border-zinc-200/90 rounded-lg text-xs text-zinc-500 hover:text-zinc-900 shadow-xs transition-colors cursor-pointer"
                title="Buscador Global (⌘K / Ctrl+K)"
              >
                <Search className="w-3.5 h-3.5 text-zinc-400" />
                <span className="text-zinc-600">Buscar SKU o Tienda...</span>
                <kbd className="px-1.5 py-0.5 text-[9px] bg-zinc-100 border border-zinc-300/80 rounded text-zinc-600 font-semibold leading-none">
                  ⌘K
                </kbd>
              </motion.button>
            )}

            {/* Brand Selection Dropdown (Compact Tactile Selector) */}
            {onSelectBrand && (
              <div className="flex items-center h-8 bg-white rounded-lg border border-zinc-200/90 px-2.5 shadow-xs hover:border-zinc-300 transition-colors">
                <Tag className="w-3.5 h-3.5 text-zinc-500 mr-1.5 shrink-0" />
                <label htmlFor="brand-select" className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider mr-1 shrink-0">
                  Marca:
                </label>
                <select
                  id="brand-select"
                  value={selectedBrand || 'TODAS'}
                  onChange={(e) => onSelectBrand(e.target.value)}
                  className="bg-transparent text-xs font-medium text-zinc-900 focus:outline-none cursor-pointer max-w-[120px] sm:max-w-[150px] truncate pr-1"
                >
                  <option value="TODAS" className="bg-white text-zinc-900 font-semibold">
                    Todas las Marcas
                  </option>
                  {brands && brands.length > 0 && (
                    <optgroup label="Marcas de Producto" className="bg-white text-zinc-500 font-bold">
                      {brands.map((b) => (
                        <option key={b} value={b} className="bg-white text-zinc-900">
                          {b.toUpperCase()}
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>
              </div>
            )}

            {/* Subtle Divider */}
            <div className="h-4 w-px bg-zinc-200 hidden sm:block" />

            {/* What-If Simulator Action */}
            {onOpenWhatIf && (
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={onOpenWhatIf}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
                title="Simulador de Capacidad y Rotación"
              >
                <Sliders className="w-3.5 h-3.5 text-zinc-500" />
                <span className="hidden md:inline">Simulador</span>
              </motion.button>
            )}

            {/* Export Multi-Sheet Excel */}
            {hasData && (
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                id="export-excel-btn"
                type="button"
                onClick={onExportExcel}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
                title="Descargar reporte corporativo en Excel"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Excel</span>
              </motion.button>
            )}

            {/* Dropdown Menu for Cloud Sync, Account, Backups and Maintenance */}
            <div className="relative" ref={dropdownRef}>
              {/* Trigger Button with Discreet Connection Indicator */}
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => setIsDropdownOpen((prev) => !prev)}
                className={`inline-flex items-center gap-2 h-8 px-2.5 rounded-lg text-xs font-medium border shadow-xs transition-colors cursor-pointer select-none ${
                  isDropdownOpen
                    ? 'bg-zinc-100 text-zinc-900 border-zinc-300'
                    : 'bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border-zinc-200/90'
                }`}
                title={
                  currentUser
                    ? isCloudSyncing
                      ? 'Nube: Sincronizando datos...'
                      : isQuotaExceeded
                      ? 'Nube: Modo local (Cuota diaria alcanzada)'
                      : 'Nube: Conexión activa con Firestore'
                    : 'Opciones de Cuenta, Respaldo y Sistema'
                }
                aria-expanded={isDropdownOpen}
              >
                {/* Indicador discreto de color para la conexión activa */}
                <span className="relative flex h-2 w-2 shrink-0">
                  {currentUser ? (
                    <>
                      <span
                        className={`absolute inline-flex h-full w-full rounded-full opacity-60 ${
                          isCloudSyncing
                            ? 'animate-ping bg-blue-400'
                            : isQuotaExceeded
                            ? 'bg-amber-400'
                            : 'animate-ping bg-emerald-400'
                        }`}
                      />
                      <span
                        className={`relative inline-flex rounded-full h-2 w-2 ${
                          isCloudSyncing
                            ? 'bg-blue-500'
                            : isQuotaExceeded
                            ? 'bg-amber-500'
                            : 'bg-emerald-500 ring-2 ring-emerald-100'
                        }`}
                      />
                    </>
                  ) : (
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-zinc-300" />
                  )}
                </span>

                {/* Avatar o Icono */}
                {currentUser ? (
                  currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt=""
                      className="w-4 h-4 rounded-full object-cover shrink-0"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-4 h-4 rounded-full bg-zinc-900 text-white flex items-center justify-center text-[9px] font-bold shrink-0">
                      {currentUser.displayName?.[0] || currentUser.email?.[0] || 'U'}
                    </div>
                  )
                ) : (
                  <MoreVertical className="w-3.5 h-3.5 text-zinc-500" />
                )}

                <span className="hidden sm:inline font-medium max-w-[85px] truncate">
                  {currentUser
                    ? currentUser.displayName?.split(' ')[0] || currentUser.email?.split('@')[0] || 'Cuenta'
                    : 'Opciones'}
                </span>

                <ChevronDown className={`w-3 h-3 text-zinc-400 transition-transform duration-150 ${isDropdownOpen ? 'rotate-180' : ''}`} />
              </motion.button>

              {/* Menú Desplegable Flotante */}
              <AnimatePresence>
                {isDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.96, y: -4 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96, y: -4 }}
                    transition={{ duration: 0.12 }}
                    className="absolute right-0 top-full mt-1.5 w-72 bg-white rounded-xl shadow-xl border border-zinc-200/90 py-2 z-50 text-xs select-none"
                  >
                    {/* SECCIÓN 1: CUENTA Y SINCRONIZACIÓN EN LA NUBE */}
                    <div className="px-3 py-1.5">
                      {currentUser ? (
                        <div className="space-y-2.5">
                          {/* Info Usuario */}
                          <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-100">
                            {currentUser.photoURL ? (
                              <img
                                src={currentUser.photoURL}
                                alt=""
                                className="w-8 h-8 rounded-full object-cover shrink-0 border border-zinc-200"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-zinc-900 text-white flex items-center justify-center text-xs font-bold shrink-0">
                                {currentUser.displayName?.[0] || currentUser.email?.[0] || 'U'}
                              </div>
                            )}
                            <div className="min-w-0 flex-1">
                              <p className="font-semibold text-zinc-900 truncate text-xs">
                                {currentUser.displayName || 'Usuario Google'}
                              </p>
                              <p className="text-[11px] text-zinc-500 truncate">
                                {currentUser.email}
                              </p>
                            </div>
                          </div>

                          {/* Estado de Sincronización Nube */}
                          <div className="p-2.5 rounded-lg bg-zinc-50 border border-zinc-200/80 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 font-mono">
                                Estado Nube
                              </span>
                              <div className="flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${
                                  isCloudSyncing
                                    ? 'bg-blue-500 animate-pulse'
                                    : isQuotaExceeded
                                    ? 'bg-amber-500'
                                    : 'bg-emerald-500'
                                }`} />
                                <span className={`text-[11px] font-semibold ${
                                  isCloudSyncing
                                    ? 'text-blue-700'
                                    : isQuotaExceeded
                                    ? 'text-amber-700'
                                    : 'text-emerald-700'
                                }`}>
                                  {isCloudSyncing
                                    ? 'Guardando...'
                                    : isQuotaExceeded
                                    ? 'Modo Local'
                                    : 'Sincronizado'}
                                </span>
                              </div>
                            </div>

                            {lastCloudSync && (
                              <p className="text-[10px] text-zinc-500 font-mono">
                                Última: {new Date(lastCloudSync).toLocaleTimeString()}
                              </p>
                            )}

                            {onManualCloudSync && (
                              <button
                                type="button"
                                onClick={() => {
                                  onManualCloudSync();
                                }}
                                disabled={isCloudSyncing}
                                className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 bg-white hover:bg-zinc-100 disabled:opacity-50 text-zinc-800 text-xs font-medium rounded-md border border-zinc-200 shadow-2xs transition-colors cursor-pointer"
                              >
                                <RefreshCw className={`w-3 h-3 ${isCloudSyncing ? 'animate-spin text-blue-600' : 'text-zinc-600'}`} />
                                <span>{isCloudSyncing ? 'Guardando en Firestore...' : 'Sincronizar ahora'}</span>
                              </button>
                            )}
                          </div>

                          {/* Cerrar Sesión */}
                          {onLogoutGoogle && (
                            <button
                              type="button"
                              onClick={() => {
                                setIsDropdownOpen(false);
                                onLogoutGoogle();
                              }}
                              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-zinc-600 hover:text-rose-600 hover:bg-rose-50/60 transition-colors text-xs cursor-pointer"
                            >
                              <LogOut className="w-3.5 h-3.5 shrink-0" />
                              <span>Cerrar sesión de Google</span>
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="p-2 space-y-2 text-center">
                          <div className="w-9 h-9 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                            <Cloud className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-zinc-900">Sincronización en la Nube</p>
                            <p className="text-[11px] text-zinc-500 mt-0.5">
                              Inicia sesión con Google para respaldar tus datos en Firestore automáticamente.
                            </p>
                          </div>
                          {onLoginGoogle && (
                            <button
                              type="button"
                              onClick={() => {
                                setIsDropdownOpen(false);
                                onLoginGoogle();
                              }}
                              className="w-full py-1.5 px-3 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
                            >
                              Conectar con Google
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* SECCIÓN 2: CONFIGURACIÓN DE REGLAS DE NEGOCIO */}
                    {onOpenRuleEngine && (
                      <>
                        <div className="my-1.5 border-t border-zinc-100" />
                        <div className="px-3 py-1">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 font-mono px-2 mb-1">
                            Motor de Reglas
                          </p>
                          <button
                            type="button"
                            onClick={() => {
                              setIsDropdownOpen(false);
                              onOpenRuleEngine();
                            }}
                            className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer text-xs"
                          >
                            <Settings2 className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                            <div className="text-left flex-1 min-w-0">
                              <span className="block font-medium truncate">Reglas y Umbrales</span>
                              <span className="block text-[10px] text-zinc-400 truncate">Picos, quiebres de curva y fletes</span>
                            </div>
                          </button>
                        </div>
                      </>
                    )}

                    {/* SECCIÓN MANUAL DE INSTRUCCIONES */}
                    {onOpenManual && (
                      <>
                        <div className="my-1.5 border-t border-zinc-100" />
                        <div className="px-3 py-1">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 font-mono px-2 mb-1">
                            Documentación Oficial
                          </p>
                          <button
                            type="button"
                            onClick={() => {
                              setIsDropdownOpen(false);
                              onOpenManual();
                            }}
                            className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-zinc-800 hover:text-zinc-900 bg-zinc-50 hover:bg-zinc-100 border border-zinc-200/80 transition-colors cursor-pointer text-xs"
                          >
                            <BookOpen className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                            <div className="text-left flex-1 min-w-0">
                              <span className="block font-semibold truncate">Manual de Instrucciones</span>
                              <span className="block text-[10px] text-zinc-500 truncate">Guía técnica y operativa SPEC</span>
                            </div>
                          </button>
                        </div>
                      </>
                    )}

                    {/* SECCIÓN 3: COPIAS DE SEGURIDAD (JSON) */}
                    {(onExportJSON || onImportJSON) && (
                      <>
                        <div className="my-1.5 border-t border-zinc-100" />
                        <div className="px-3 py-1">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 font-mono px-2 mb-1">
                            Respaldos Locales
                          </p>

                          {onExportJSON && (
                            <button
                              type="button"
                              onClick={() => {
                                setIsDropdownOpen(false);
                                onExportJSON();
                              }}
                              className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer text-xs"
                            >
                              <FileJson className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                              <span>Descargar Respaldo JSON</span>
                            </button>
                          )}

                          {onImportJSON && (
                            <>
                              <input
                                type="file"
                                ref={jsonFileInputRef}
                                onChange={(e) => {
                                  setIsDropdownOpen(false);
                                  handleJSONFileChange(e);
                                }}
                                accept=".json"
                                className="hidden"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  jsonFileInputRef.current?.click();
                                }}
                                className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer text-xs"
                              >
                                <Upload className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                                <span>Restaurar Respaldo JSON</span>
                              </button>
                            </>
                          )}
                        </div>
                      </>
                    )}

                    {/* SECCIÓN 3: LIMPIAR TODO EL SISTEMA */}
                    {hasData && (
                      <>
                        <div className="my-1.5 border-t border-zinc-100" />
                        <div className="px-3 py-1">
                          <button
                            type="button"
                            id="clear-all-btn"
                            onClick={() => {
                              setIsDropdownOpen(false);
                              onClearAll();
                            }}
                            className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer text-xs font-medium"
                          >
                            <Trash2 className="w-3.5 h-3.5 shrink-0" />
                            <span>Limpiar todo (Resetear)</span>
                          </button>
                        </div>
                      </>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Primary Action: Ingest Excel File */}
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              id="upload-file-btn"
              type="button"
              onClick={onOpenUpload}
              className="inline-flex items-center gap-1.5 h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer shrink-0"
              title="Cargar archivo Excel"
            >
              <UploadCloud className="w-3.5 h-3.5 text-white" />
              <span>Cargar Excel</span>
            </motion.button>
          </div>
        </div>
      </div>
    </header>
  );
};
