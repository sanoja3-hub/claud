import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Printer,
  X,
  FileText,
  SlidersHorizontal,
  ChevronDown,
} from 'lucide-react';
import { TransferManifest, TransferManifestItem, TransferSuggestion } from '../types';
import { exportarManifiestoTraspasoExcel } from '../utils/excelExporter';

interface PackingListModalProps {
  isOpen: boolean;
  onClose: () => void;
  transfers?: TransferSuggestion[];
  suggestions?: TransferSuggestion[];
  selectedOriginStore?: string;
  selectedDestStore?: string;
  distances?: any;
  conditions?: Record<string, 'NUEVO' | 'USADO' | ''>;
}

export const PackingListModal: React.FC<PackingListModalProps> = ({
  isOpen,
  onClose,
  transfers: propTransfers,
  suggestions,
  selectedOriginStore,
  selectedDestStore,
  distances: _distances,
  conditions: externalConditions = {},
}) => {
  const transfers = useMemo(
    () => propTransfers || suggestions || [],
    [propTransfers, suggestions]
  );

  // Opciones de rutas disponibles
  const availableRoutes = useMemo(() => {
    const map = new Map<string, { origin: string; dest: string }>();
    (transfers || []).forEach((t) => {
      if (!t) return;
      const key = `${t.TiendaOrigen} -> ${t.TiendaDestino}`;
      if (!map.has(key)) {
        map.set(key, { origin: t.TiendaOrigen, dest: t.TiendaDestino });
      }
    });
    return Array.from(map.entries()).map(([key, val]) => ({
      key,
      origin: val.origin,
      dest: val.dest,
    }));
  }, [transfers]);

  // Selección de ruta
  const [selectedRouteKey, setSelectedRouteKey] = useState<string>('ALL');

  // Formato de fecha oficial: DD/M/YYYY (ej: 22/9/2026)
  const todayFormatted = useMemo(() => {
    const d = new Date();
    return `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
  }, []);

  // Campos de cabecera editables (con los valores exactos de la plantilla de referencia)
  const [codigoControl, setCodigoControl] = useState<string>('DESIN-001');
  const [fechaDocumento, setFechaDocumento] = useState<string>(todayFormatted);
  const [autorizadoPor, setAutorizadoPor] = useState<string>(
    'JHONATHAN REQUENA/ EDWIN ALVAREZ'
  );

  // Estados para llenado manual de "CONDICION" y "OBSERVACIONES"
  const [condiciones, setCondiciones] = useState<Record<number, string>>({});
  const [observacionesItems, setObservacionesItems] = useState<Record<number, string>>({});

  if (!isOpen) return null;

  // Filtrado de transferencias según la ruta seleccionada
  const activeRoute = availableRoutes.find((r) => r.key === selectedRouteKey);
  const filteredTransfers = transfers.filter((t) => {
    if (activeRoute) {
      return t.TiendaOrigen === activeRoute.origin && t.TiendaDestino === activeRoute.dest;
    }
    if (selectedOriginStore && t.TiendaOrigen !== selectedOriginStore) return false;
    if (selectedDestStore && t.TiendaDestino !== selectedDestStore) return false;
    return true;
  });

  const originName =
    activeRoute?.origin ||
    selectedOriginStore ||
    filteredTransfers[0]?.TiendaOrigen ||
    'NIKE RISE';

  const destinationName =
    activeRoute?.dest ||
    selectedDestStore ||
    filteredTransfers[0]?.TiendaDestino ||
    'SPORTS MARKET BOLEITA';

  const totalCantidad = filteredTransfers.reduce(
    (acc, t) => acc + (t.UnidadesSugeridas || 0),
    0
  );

  // Mapeo a items de la guía
  const items: TransferManifestItem[] = filteredTransfers.map((t, idx) => ({
    id: `${t.Referencia}-${t.Talla}-${idx}`,
    referencia: t.Referencia,
    marca: t.Marca,
    departamento: t.Departamento,
    genero: (t as any).Genero || 'CABALLERO',
    talla: t.Talla,
    cantidad: t.UnidadesSugeridas,
    condicion: condiciones[idx] ?? (externalConditions[t.id] || ''),
    stockPrevioOrigen: t.StockOrigen,
    stockPrevioDestino: t.StockDestino,
    valorUnitario: t.ValoracionUnitario || 35,
    observaciones: observacionesItems[idx] || '',
  }));

  const manifest: TransferManifest = {
    id: `MAN-${Date.now().toString().slice(-6)}`,
    codigoManifiesto: codigoControl || 'DESIN-001',
    fechaEmision: fechaDocumento,
    tiendaOrigen: originName,
    tiendaDestino: destinationName,
    autorizadoPor: autorizadoPor || 'JHONATHAN REQUENA/ EDWIN ALVAREZ',
    distanciaKm: filteredTransfers[0]?.DistanciaKm || 15,
    costoFleteEstimado: filteredTransfers.reduce((a, b) => a + (b.CostoFleteEstimado || 0), 0),
    estado: 'EN_TRANSITO',
    totalPiezas: totalCantidad,
    totalValoracion: items.reduce((acc, it) => acc + it.cantidad * (it.valorUnitario || 35), 0),
    items,
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportExcel = () => {
    exportarManifiestoTraspasoExcel(manifest);
  };

  const handleCondicionChange = (idx: number, val: string) => {
    setCondiciones((prev) => ({ ...prev, [idx]: val }));
  };

  const handleObservacionChange = (idx: number, val: string) => {
    setObservacionesItems((prev) => ({ ...prev, [idx]: val }));
  };

  // Cantidad mínima de filas para preservar el formato físico de 25 filas
  const minRows = 25;
  const blankRowsNeeded = Math.max(0, minRows - items.length);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-5xl bg-zinc-100 border border-zinc-300 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Barra Superior de Control (Oculta al Imprimir) */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-white border-b border-zinc-200 print:hidden shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-zinc-900 text-white flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-zinc-900 tracking-tight">
                Guía de Transferencia Oficial
              </h2>
              <p className="text-[11px] text-zinc-500">
                Formato estándar operativo de traspasos (idéntico a la plantilla física)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Selector de Ruta si hay más de una */}
            {availableRoutes.length > 1 && (
              <div className="flex items-center gap-1.5 bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1 text-xs">
                <span className="text-zinc-500 font-medium">Ruta:</span>
                <select
                  value={selectedRouteKey}
                  onChange={(e) => setSelectedRouteKey(e.target.value)}
                  className="bg-transparent font-semibold text-zinc-800 outline-none cursor-pointer max-w-[200px] truncate"
                >
                  <option value="ALL">Todas las Rutas ({transfers.length} items)</option>
                  {availableRoutes.map((r) => (
                    <option key={r.key} value={r.key}>
                      {r.origin} → {r.dest}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              title="Exportar archivo Excel (.xlsx) con la estructura exacta de la plantilla"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Exportar Excel</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              title="Imprimir documento físico o guardar en PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir / PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Barra de Ajuste de Metadatos Rápidos (Oculta al Imprimir) */}
        <div className="bg-zinc-50 border-b border-zinc-200 px-5 py-2.5 flex flex-wrap items-center justify-between gap-4 text-xs print:hidden shrink-0">
          <div className="flex items-center gap-2 text-zinc-600">
            <SlidersHorizontal className="w-3.5 h-3.5 text-zinc-400" />
            <span className="font-semibold text-zinc-700">Metadatos de la Guía:</span>
          </div>

          <div className="flex items-center gap-4 flex-wrap">
            <label className="flex items-center gap-1.5">
              <span className="text-zinc-500 font-medium"># Control:</span>
              <input
                type="text"
                value={codigoControl}
                onChange={(e) => setCodigoControl(e.target.value)}
                className="w-28 bg-white border border-zinc-300 rounded px-2 py-0.5 text-xs font-mono font-bold text-zinc-900 focus:outline-none focus:border-zinc-500"
              />
            </label>

            <label className="flex items-center gap-1.5">
              <span className="text-zinc-500 font-medium">Fecha:</span>
              <input
                type="text"
                value={fechaDocumento}
                onChange={(e) => setFechaDocumento(e.target.value)}
                className="w-24 bg-white border border-zinc-300 rounded px-2 py-0.5 text-xs font-mono text-zinc-900 focus:outline-none focus:border-zinc-500"
              />
            </label>

            <label className="flex items-center gap-1.5">
              <span className="text-zinc-500 font-medium">Autorizado Por:</span>
              <input
                type="text"
                value={autorizadoPor}
                onChange={(e) => setAutorizadoPor(e.target.value)}
                className="w-64 bg-white border border-zinc-300 rounded px-2 py-0.5 text-xs font-semibold text-zinc-900 focus:outline-none focus:border-zinc-500"
              />
            </label>
          </div>
        </div>

        {/* Contenedor del Documento con Formato de Hoja Oficial */}
        <div className="overflow-y-auto p-4 sm:p-6 bg-zinc-200/70 flex-1 print:p-0 print:bg-white print:overflow-visible">
          {/* Hoja de Transferencia (Exacta a la imagen física) */}
          <div
            id="printable-transfer-sheet"
            className="bg-white mx-auto p-6 sm:p-8 rounded-none border border-zinc-300 shadow-md text-black font-sans max-w-4xl print:max-w-none print:shadow-none print:border-none print:p-0"
          >
            {/* TÍTULO: TRANSFERENCIAS (Fila 1) */}
            <h1 className="text-base sm:text-lg font-black text-center tracking-widest text-black uppercase mb-4">
              TRANSFERENCIAS
            </h1>

            {/* CABECERA: ORIGEN, DESTINO, AUTORIZADO, CONTROL, FECHA (Filas 2, 3, 4) */}
            <div className="text-xs mb-3 font-bold text-black border-collapse">
              {/* Fila 2: ORIGEN y # CONTROL */}
              <div className="flex items-center justify-between py-0.5">
                <div className="flex items-baseline gap-2">
                  <span className="w-24 uppercase">ORIGEN :</span>
                  <span className="font-bold uppercase text-zinc-900 tracking-wide">
                    {manifest.tiendaOrigen}
                  </span>
                </div>
                <div className="flex items-baseline gap-4">
                  <span className="uppercase text-right"># CONTROL</span>
                  <span className="w-24 text-right font-mono font-bold uppercase">
                    {codigoControl}
                  </span>
                </div>
              </div>

              {/* Fila 3: DESTINO y FECHA */}
              <div className="flex items-center justify-between py-0.5">
                <div className="flex items-baseline gap-2">
                  <span className="w-24 uppercase">DESTINO:</span>
                  <span className="font-bold uppercase text-zinc-900 tracking-wide">
                    {manifest.tiendaDestino}
                  </span>
                </div>
                <div className="flex items-baseline gap-4">
                  <span className="uppercase text-right">FECHA:</span>
                  <span className="w-24 text-right font-mono font-bold">
                    {fechaDocumento}
                  </span>
                </div>
              </div>

              {/* Fila 4: AUTORIZADO POR */}
              <div className="flex items-baseline gap-2 py-0.5">
                <span className="w-32 uppercase">AUTORIZADO POR:</span>
                <span className="font-bold uppercase text-zinc-900 tracking-wide">
                  {autorizadoPor}
                </span>
              </div>
            </div>

            {/* TABLA PRINCIPAL (Fila 5 en adelante) */}
            <div className="w-full overflow-x-auto print:overflow-visible">
              <table className="w-full text-xs border-collapse border border-black text-black">
                <thead>
                  {/* Encabezados con fondo gris como en la plantilla */}
                  <tr className="bg-[#D9D9D9] text-black border border-black font-black uppercase text-[10.5px] tracking-tight">
                    <th className="border border-black py-1.5 px-2 text-center w-24">
                      MARCA
                    </th>
                    <th className="border border-black py-1.5 px-2 text-left">
                      REFERENCIA
                    </th>
                    <th className="border border-black py-1.5 px-1.5 text-center w-16">
                      CANTIDAD
                    </th>
                    <th className="border border-black py-1.5 px-2 text-center w-24">
                      GENERO
                    </th>
                    <th className="border border-black py-1.5 px-2 text-center w-28">
                      DEPARTAMENTO
                    </th>
                    <th className="border border-black py-1.5 px-2 text-center w-36">
                      CONDICION (NUEVO/USADO)
                    </th>
                    <th className="border border-black py-1.5 px-1.5 text-center w-20">
                      EXISTENCIA
                    </th>
                    <th className="border border-black py-1.5 px-2 text-center w-36">
                      OBSERVACIONES
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {/* Filas con datos */}
                  {items.map((it, idx) => {
                    const refDisplay = it.talla
                      ? `${it.referencia} - T.${it.talla}`
                      : it.referencia;
                    return (
                      <tr key={it.id || idx} className="h-6.5 border-b border-black">
                        <td className="border border-black px-2 py-0.5 text-center uppercase font-medium">
                          {it.marca}
                        </td>
                        <td className="border border-black px-2 py-0.5 text-left font-mono font-bold text-[11px]">
                          {refDisplay}
                        </td>
                        <td className="border border-black px-1.5 py-0.5 text-center font-mono font-bold text-xs">
                          {it.cantidad}
                        </td>
                        <td className="border border-black px-2 py-0.5 text-center uppercase font-medium">
                          {it.genero}
                        </td>
                        <td className="border border-black px-2 py-0.5 text-center uppercase font-medium">
                          {it.departamento}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-center">
                          {/* Campo manual: el usuario puede llenar en pantalla o dejar en blanco para escribir a mano */}
                          <input
                            type="text"
                            value={condiciones[idx] ?? it.condicion ?? ''}
                            onChange={(e) => handleCondicionChange(idx, e.target.value)}
                            placeholder=""
                            className="w-full text-center bg-transparent border-none outline-none font-sans text-xs print:placeholder-transparent"
                          />
                        </td>
                        <td className="border border-black px-1.5 py-0.5 text-center font-mono font-semibold">
                          {it.stockPrevioOrigen}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-left">
                          {/* Campo manual: el usuario puede llenar en pantalla o dejar en blanco para escribir a mano */}
                          <input
                            type="text"
                            value={observacionesItems[idx] ?? it.observaciones ?? ''}
                            onChange={(e) => handleObservacionChange(idx, e.target.value)}
                            placeholder=""
                            className="w-full bg-transparent border-none outline-none font-sans text-xs print:placeholder-transparent"
                          />
                        </td>
                      </tr>
                    );
                  })}

                  {/* Filas en blanco para preservar el formato físico de 25 filas */}
                  {Array.from({ length: blankRowsNeeded }).map((_, bIdx) => (
                    <tr key={`blank-${bIdx}`} className="h-6.5 border-b border-black">
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                      <td className="border border-black px-2 py-0.5">&nbsp;</td>
                    </tr>
                  ))}

                  {/* Fila de Totalización: La suma va en la columna CANTIDAD (índice 2) */}
                  <tr className="h-7 border-b border-black font-black">
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-1.5 py-0.5 text-center font-mono font-black text-xs">
                      {totalCantidad}
                    </td>
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-2 py-0.5"></td>
                    <td className="border border-black px-2 py-0.5"></td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Espaciado y Sección de Firmas (Filas 34 a 37 en la plantilla) */}
            <div className="grid grid-cols-2 gap-16 pt-8 pb-4 text-xs font-bold text-black uppercase">
              <div className="space-y-1">
                <div>ENTREGADO POR:</div>
                <div className="text-[11px] font-semibold text-zinc-800">
                  NOMBRE Y APELLIDO
                </div>
                <div className="pt-10 border-b border-black w-4/5"></div>
              </div>

              <div className="space-y-1">
                <div>RECIBIDO POR:</div>
                <div className="text-[11px] font-semibold text-zinc-800">
                  NOMBRE Y APELLIDO
                </div>
                <div className="pt-10 border-b border-black w-4/5"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Pie del modal con instrucciones operativas */}
        <div className="px-5 py-3 bg-white border-t border-zinc-200 flex items-center justify-between text-xs text-zinc-500 print:hidden shrink-0">
          <span>
            * Los campos <b>CONDICION</b> y <b>OBSERVACIONES</b> admiten llenado manual digital o manuscrito con bolígrafo tras imprimir.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
