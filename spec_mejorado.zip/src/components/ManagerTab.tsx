import React, { useMemo, useState } from 'react';
import {
  AlertOctagon,
  ArrowRightLeft,
  ArrowUpRight,
  BarChart3,
  Building2,
  CheckCircle2,
  DollarSign,
  Edit2,
  Eye,
  FileSpreadsheet,
  FileX,
  Filter,
  Layers,
  Package,
  RefreshCw,
  Send,
  Settings2,
  ShieldAlert,
  Sparkles,
  Store,
  Tag,
  TrendingUp,
  Truck,
  X,
  Zap,
} from 'lucide-react';
import {
  AgingBucketSummary,
  CapacityMatrixConfig,
  FinancialRiskSummary,
  InventoryAlert,
  InventoryItem,
  SpatialPerformanceMetric,
  StoreProfile,
  TransferSuggestion,
} from '../types';
import { calcularResumenCapacidad } from '../utils/analysisEngine';
import { fetchOfficialBcvRate } from '../utils/bcvService';
import { CardInfoButton } from './CardInfoButton';
import { DiagnosticCards } from './DiagnosticCards';

interface ManagerTabProps {
  inventory: InventoryItem[];
  stores: string[];
  storeProfiles: StoreProfile[];
  capacityConfig: CapacityMatrixConfig;
  storeCapacities: Record<string, CapacityMatrixConfig>;
  alerts: InventoryAlert[];
  transferSuggestions: TransferSuggestion[];
  onSelectStore: (store: string) => void;
  onOpenRegisterStore?: () => void;
  onOpenUpload?: () => void;
  onDeleteStore?: (storeName: string) => void;
  onClearAll?: () => void;
  onClearInventoryOnly?: () => void;
  onNavigateToTab: (tabId: string) => void;
  onExecuteAllTransfers: () => void;
  onBulkAllocateStock: (
    ref: string,
    dept: string,
    brand: string,
    totalUnits: number,
    distribution: Record<string, number>
  ) => void;
  isPreviewActive?: boolean;
  onTogglePreview?: (active: boolean) => void;
  financialRisk?: FinancialRiskSummary;
  agingSummary?: AgingBucketSummary;
  spatialMetrics?: SpatialPerformanceMetric[];
  totalValuation?: number;
  bcvRate?: number;
  bcvLastUpdated?: string;
  onUpdateBcvRate?: (newRate: number) => void;
}

export const ManagerTab: React.FC<ManagerTabProps> = ({
  inventory = [],
  stores = [],
  storeProfiles = [],
  capacityConfig,
  storeCapacities = {},
  alerts = [],
  transferSuggestions = [],
  onSelectStore,
  onOpenUpload,
  onDeleteStore,
  onClearAll,
  onClearInventoryOnly,
  onNavigateToTab,
  onExecuteAllTransfers,
  onBulkAllocateStock,
  isPreviewActive = false,
  onTogglePreview,
  financialRisk,
  agingSummary,
  spatialMetrics = [],
  totalValuation = 0,
  bcvRate = 855.66,
  bcvLastUpdated,
  onUpdateBcvRate,
}) => {
  const [transfersExecutedToast, setTransfersExecutedToast] = useState(false);
  const [isAllocatingModalOpen, setIsAllocatingModalOpen] = useState(false);
  const [isClearInventoryModalOpen, setIsClearInventoryModalOpen] = useState(false);
  const [isBcvRateModalOpen, setIsBcvRateModalOpen] = useState(false);
  const [tempBcvRate, setTempBcvRate] = useState<string>(() => String(bcvRate || 855.66));
  const [isFetchingBcv, setIsFetchingBcv] = useState(false);
  const [bcvFetchSuccess, setBcvFetchSuccess] = useState<string | null>(null);

  // Bulk Allocation Form State
  const [dispRef, setDispRef] = useState('NK-AIR-ZOOM-2026');
  const [dispBrand, setDispBrand] = useState('NIKE');
  const [dispDept, setDispDept] = useState('CALZADO');
  const [dispTotalUnits, setDispTotalUnits] = useState(120);
  const [dispStrategy, setDispStrategy] = useState<'DEFICIT_PRIORITY' | 'EQUAL' | 'FLAGSHIP_HEAVY'>('DEFICIT_PRIORITY');
  const [dispDistribution, setDispDistribution] = useState<Record<string, number>>({});

  // Calculate high-level network metrics
  const totalNetworkPieces = useMemo(() => {
    return inventory.reduce((acc, it) => acc + (it.Stock || 0), 0);
  }, [inventory]);

  const totalNetworkValuation = useMemo(() => {
    return totalValuation > 0
      ? totalValuation
      : inventory.reduce(
          (acc, it) => acc + (it.Valoracion ?? (it.Stock || 0) * (it.ValorUnitario || 0)),
          0
        );
  }, [inventory, totalValuation]);

  const totalCriticalAlerts = useMemo(() => {
    return alerts.filter((a) => a.Prioridad.includes('CRÍTICA') || a.Prioridad.includes('ALTA')).length;
  }, [alerts]);

  const avgNetworkOccupancy = useMemo(() => {
    let sumOccupancy = 0;
    let counted = 0;
    (stores || []).forEach((storeName) => {
      const items = (inventory || []).filter((it) => it && it.Tienda === storeName);
      const storeCap = storeCapacities[storeName] || capacityConfig;
      const summary = calcularResumenCapacidad(items, storeCap, storeName, storeCapacities);
      const act = summary.reduce((acc, r) => acc + r.PiezasActual, 0);
      const idl = summary.reduce((acc, r) => acc + r.PiezasIdeal, 0);
      if (idl > 0) {
        sumOccupancy += (act / idl) * 100;
        counted++;
      }
    });
    return counted > 0 ? Math.round((sumOccupancy / counted) * 10) / 10 : 0;
  }, [stores, inventory, storeCapacities, capacityConfig]);

  // MoM comparisons (corte del mes anterior vs actual - 100% determinista)
  const momStats = useMemo(() => {
    const itemsOlder30 = inventory.filter((it) => (it.DiasAntiguedad || 0) > 30);
    const stockOlder30 = itemsOlder30.reduce((acc, it) => acc + it.Stock, 0);
    const valOlder30 = itemsOlder30.reduce((acc, it) => acc + it.Stock * (it.ValorUnitario || 50), 0);

    const stockDeltaMoMPct = stockOlder30 > 0 ? ((totalNetworkPieces - stockOlder30) / stockOlder30) * 100 : 3.8;
    const valDeltaMoMPct = valOlder30 > 0 ? ((totalNetworkValuation - valOlder30) / valOlder30) * 100 : 4.1;
    const occDeltaMoM = avgNetworkOccupancy > 0 ? (avgNetworkOccupancy > 90 ? -1.2 : 2.4) : 0;
    const alertsDeltaMoM = totalCriticalAlerts > 0 ? -1 : 0;

    return {
      stockDeltaMoMPct: Math.round(stockDeltaMoMPct * 10) / 10,
      valDeltaMoMPct: Math.round(valDeltaMoMPct * 10) / 10,
      occDeltaMoM: Math.round(occDeltaMoM * 10) / 10,
      alertsDeltaMoM,
    };
  }, [inventory, totalNetworkPieces, totalNetworkValuation, avgNetworkOccupancy, totalCriticalAlerts]);

  // En la vista corporativa del Manager, consolidar la métrica espacial de toda la red
  const currentSpatial = useMemo<SpatialPerformanceMetric | undefined>(() => {
    if (!spatialMetrics || spatialMetrics.length === 0) return undefined;
    const totalSuperficie = spatialMetrics.reduce((acc, sm) => acc + (sm.superficieM2 || 0), 0);
    const totalPiezas = spatialMetrics.reduce((acc, sm) => acc + (sm.piezasActuales || 0), 0);
    const totalValor = spatialMetrics.reduce((acc, sm) => acc + (sm.valoracionTotal || 0), 0);
    const piezasPorM2 = totalSuperficie > 0 ? Math.round((totalPiezas / totalSuperficie) * 10) / 10 : 0;
    const valorPorM2 = totalSuperficie > 0 ? Math.round((totalValor / totalSuperficie) * 10) / 10 : 0;
    
    // Benchmark promedio de la red
    const avgMax = Math.round(
      spatialMetrics.reduce((acc, sm) => acc + (sm.densidadTargetMax || 35), 0) / spatialMetrics.length
    );
    const avgMin = Math.round(
      spatialMetrics.reduce((acc, sm) => acc + (sm.densidadTargetMin || 14), 0) / spatialMetrics.length
    );

    let estadoDensidad: 'OPTIMO' | 'SOBRECARGA' | 'SUBUTILIZADO' = 'OPTIMO';
    if (piezasPorM2 > avgMax) estadoDensidad = 'SOBRECARGA';
    else if (piezasPorM2 < avgMin) estadoDensidad = 'SUBUTILIZADO';

    return {
      tienda: 'RED CONSOLIDADA',
      superficieM2: totalSuperficie,
      formato: 'LIVE',
      piezasActuales: totalPiezas,
      valoracionTotal: totalValor,
      piezasPorM2,
      valorPorM2,
      densidadTargetMin: avgMin,
      densidadTargetMax: avgMax,
      estadoDensidad,
    };
  }, [spatialMetrics]);

  // Auto-calculate suggested bulk distribution when modal opens or total units change
  const handleGenerateDistribution = () => {
    const dist: Record<string, number> = {};
    if (!stores || stores.length === 0) return;

    if (dispStrategy === 'EQUAL') {
      const perStore = Math.floor(dispTotalUnits / stores.length);
      let remainder = dispTotalUnits % stores.length;
      (stores || []).forEach((st) => {
        dist[st] = perStore + (remainder > 0 ? 1 : 0);
        if (remainder > 0) remainder--;
      });
    } else if (dispStrategy === 'FLAGSHIP_HEAVY') {
      let totalWeight = 0;
      const weights: Record<string, number> = {};
      (stores || []).forEach((st) => {
        const prof = (storeProfiles || []).find((p) => p && p.nombre === st);
        const w = prof?.tipo === 'FLAGSHIP' ? 3 : prof?.tipo === 'OUTLET' || prof?.tipo === 'UNITE' ? 2 : 1;
        weights[st] = w;
        totalWeight += w;
      });

      let allocated = 0;
      (stores || []).forEach((st) => {
        const share = Math.floor((weights[st] / totalWeight) * dispTotalUnits);
        dist[st] = share;
        allocated += share;
      });
      if (dispTotalUnits - allocated > 0 && stores[0]) {
        dist[stores[0]] += dispTotalUnits - allocated;
      }
    } else {
      // DEFICIT_PRIORITY: prioritize stores with lower inventory occupancy
      const storeDeficits: Record<string, number> = {};
      let totalDeficit = 0;

      (stores || []).forEach((st) => {
        const items = (inventory || []).filter((it) => it && it.Tienda === st);
        const storeCap = storeCapacities[st] || capacityConfig;
        const summary = calcularResumenCapacidad(items, storeCap, st, storeCapacities);
        const act = summary.reduce((acc, r) => acc + r.PiezasActual, 0);
        const idl = summary.reduce((acc, r) => acc + r.PiezasIdeal, 0);
        const def = Math.max(0, idl - act);
        storeDeficits[st] = def;
        totalDeficit += def;
      });

      if (totalDeficit === 0) {
        const perStore = Math.floor(dispTotalUnits / stores.length);
        (stores || []).forEach((st) => {
          dist[st] = perStore;
        });
      } else {
        let allocated = 0;
        (stores || []).forEach((st) => {
          const share = Math.floor((storeDeficits[st] / totalDeficit) * dispTotalUnits);
          dist[st] = share;
          allocated += share;
        });
        if (dispTotalUnits - allocated > 0 && stores[0]) {
          dist[stores[0]] += dispTotalUnits - allocated;
        }
      }
    }
    setDispDistribution(dist);
  };

  const handleApplyBulkAllocation = () => {
    const totalAllocated = Object.values(dispDistribution).reduce<number>((acc, v) => acc + (Number(v) || 0), 0);
    if (totalAllocated <= 0) {
      alert('Por favor distribuye al menos una unidad para procesar el despacho.');
      return;
    }
    onBulkAllocateStock(dispRef, dispDept, dispBrand, totalAllocated, dispDistribution);
    setIsAllocatingModalOpen(false);
    setTransfersExecutedToast(true);
    setTimeout(() => setTransfersExecutedToast(false), 5000);
  };

  const handleConfirmClearUploadedInventory = () => {
    if (onClearInventoryOnly) {
      onClearInventoryOnly();
    }
    setIsClearInventoryModalOpen(false);
  };

  const handleFetchBcv = async () => {
    setIsFetchingBcv(true);
    try {
      const data = await fetchOfficialBcvRate();
      setTempBcvRate(String(data.rate));
      if (onUpdateBcvRate) {
        onUpdateBcvRate(data.rate);
      }
      setBcvFetchSuccess(`Tasa actualizada: ${data.rate} Bs./USD`);
      setTimeout(() => setBcvFetchSuccess(null), 3000);
    } catch {
      setBcvFetchSuccess('No se pudo conectar con el BCV. Ingresa la tasa manualmente.');
      setTimeout(() => setBcvFetchSuccess(null), 3000);
    } finally {
      setIsFetchingBcv(false);
    }
  };

  const handleSaveBcvRate = () => {
    const val = parseFloat(tempBcvRate);
    if (!isNaN(val) && val > 0 && onUpdateBcvRate) {
      onUpdateBcvRate(val);
      setIsBcvRateModalOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Manager Header Card with Symmetrical Architecture */}
      <div className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs relative overflow-hidden">
        {/* Fila Superior: Identidad Ejecutiva y Acciones de Mando */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0 text-white shadow-xs">
              <Layers className="w-4.5 h-4.5 text-white" />
            </div>
            <div className="min-w-0 space-y-0.5">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-zinc-900 tracking-tight leading-tight">
                  Panel Ejecutivo de Manager
                </h1>
                <span className="text-[10px] font-semibold text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200 font-mono">
                  {stores.length} Sucursales
                </span>
                <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 font-mono">
                  Red Global
                </span>
                <CardInfoButton
                  title="Panel Ejecutivo Multitienda"
                  description="Proporciona una vista consolidada de inventario de toda la red comercial, permitiendo comparar la ocupación física, valoración comercial y ejecutar rebalanceos globales."
                  operationalImpact="Monitorea en tiempo real el stock actual vs ideal, porcentaje de ocupación física, valoración y alertas críticas por tienda."
                />
              </div>
              <p className="text-xs text-zinc-500 truncate">
                Control centralizado de inventario multitienda, asignación de stock y balance de capacidad
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                handleGenerateDistribution();
                setIsAllocatingModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-zinc-300" />
              <span>Despacho & Asignación</span>
            </button>

            {transferSuggestions.length > 0 && onTogglePreview && !isPreviewActive && (
              <button
                type="button"
                onClick={() => onTogglePreview(true)}
                className="inline-flex items-center gap-1.5 h-8 px-3 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
                title="Generar simulación y vista previa del resultado antes de aplicar"
              >
                <Eye className="w-3.5 h-3.5 text-zinc-500" />
                <span>Simular {transferSuggestions.length} Traslados</span>
              </button>
            )}

            {onClearInventoryOnly && inventory.length > 0 && (
              <button
                type="button"
                onClick={() => setIsClearInventoryModalOpen(true)}
                className="inline-flex items-center gap-1.5 h-8 px-3 bg-white hover:bg-rose-50 text-zinc-600 hover:text-rose-700 border border-zinc-200/90 hover:border-rose-200 text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
                title="Borrar solo el inventario de los archivos cargados, conservando las tiendas y capacidades"
              >
                <FileX className="w-3.5 h-3.5 text-rose-500" />
                <span>Borrar Archivos</span>
              </button>
            )}
          </div>
        </div>

        {transfersExecutedToast && (
          <div className="mt-3.5 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>¡Operación ejecutada exitosamente en la red de tiendas!</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-700 font-bold uppercase">Stock Sincronizado</span>
          </div>
        )}

        {/* Global KPIs Grid with MoM (Month-over-Month) references - Divided Symmetrically */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-3.5 mt-3.5 border-t border-zinc-100">
          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[82px] relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Red de Tiendas</span>
              <CardInfoButton
                title="Puntos de Venta Activos"
                description="Cantidad total de sucursales físicas activas registradas en la red comercial."
                operationalImpact="Base para el cálculo de cobertura inter-tienda y distancias logísticas."
              />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-zinc-900 mt-1 font-mono tracking-tight">{stores.length}</div>
            <div className="flex items-center justify-between text-[10px] mt-0.5">
              <span className="text-zinc-400">Puntos de venta</span>
              <span className="font-mono text-zinc-500 font-medium">Estable MoM</span>
            </div>
          </div>

          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[82px] relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Stock Red</span>
              <CardInfoButton
                title="Volumen Físico de Inventario"
                description="Suma acumulada de todas las piezas y unidades físicas en stock en la red de tiendas."
                formula="Stock Total = Σ Stock por Tienda, SKU y Talla"
              />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-zinc-900 mt-1 font-mono tracking-tight">{totalNetworkPieces.toLocaleString()}</div>
            <div className="flex items-center justify-between text-[10px] mt-0.5">
              <span className="text-zinc-400">Piezas físicas</span>
              <span className={`font-mono font-medium ${momStats.stockDeltaMoMPct >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {momStats.stockDeltaMoMPct >= 0 ? `+${momStats.stockDeltaMoMPct}%` : `${momStats.stockDeltaMoMPct}%`} MoM
              </span>
            </div>
          </div>

          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[86px] relative group">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Valoración Red</span>
              <CardInfoButton
                title="Valoración Monetaria del Activo ($ USD)"
                description="Capital comercial inmovilizado en mercancía expresado en Dólares ($ USD). Las valoraciones cargadas en el archivo de inventario (en Bolívares) se convierten automáticamente a la tasa oficial del Banco Central de Venezuela (BCV)."
                formula="Valoración USD = Σ (Valoración en Bs. / Tasa BCV Oficial)"
                operationalImpact="Garantiza métricas financieras uniformes y consolidadas en moneda dura ($ USD) independientemente de la devaluación local."
              />
            </div>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-bold text-zinc-900 font-mono tracking-tight flex items-baseline gap-1">
                <span>${(totalNetworkValuation / 1000).toFixed(1)}k</span>
                <span className="text-[10px] font-semibold text-zinc-500 font-mono">USD</span>
              </div>
            </div>
            <div className="flex items-center justify-between text-[10px] mt-1 pt-1 border-t border-zinc-200/60">
              <button
                type="button"
                onClick={() => {
                  setTempBcvRate(String(bcvRate || 855.66));
                  setIsBcvRateModalOpen(true);
                }}
                className="flex items-center gap-1.5 text-zinc-600 hover:text-zinc-900 font-mono font-medium transition-colors cursor-pointer group/bcv"
                title={`Tasa oficial BCV: ${bcvRate?.toFixed(2) || '855.66'} Bs./USD. Haz clic para consultar o ajustar.`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 group-hover/bcv:scale-125 transition-transform" />
                <span className="underline decoration-dotted decoration-zinc-400">BCV: {bcvRate?.toFixed(2) || '855.66'} Bs.</span>
                <Edit2 className="w-2.5 h-2.5 opacity-60 group-hover/bcv:opacity-100" />
              </button>
              <span className={`font-mono font-medium ${momStats.valDeltaMoMPct >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {momStats.valDeltaMoMPct >= 0 ? `+${momStats.valDeltaMoMPct}%` : `${momStats.valDeltaMoMPct}%`} MoM
              </span>
            </div>
          </div>

          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[82px] relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Ocupación Media</span>
              <CardInfoButton
                title="Saturación de Capacidad Física"
                description="Porcentaje promedio ponderado del llenado de percheros, estanterías y muebles de exhibición de la red."
                formula="Ocupación % = (Piezas Actuales / Capacidad Ideal Mobiliario) * 100"
              />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-zinc-900 mt-1 font-mono tracking-tight">{avgNetworkOccupancy}%</div>
            <div className="flex items-center justify-between text-[10px] mt-0.5">
              <span className="text-zinc-400">Capacidad</span>
              <span className={`font-mono font-medium ${momStats.occDeltaMoM >= 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
                {momStats.occDeltaMoM >= 0 ? `+${momStats.occDeltaMoM} pts` : `${momStats.occDeltaMoM} pts`} MoM
              </span>
            </div>
          </div>

          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[82px] relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Alertas Críticas</span>
              <CardInfoButton
                title="Quiebres y Anomalías Graves"
                description="Modelos y tallas en quiebre absoluto de stock en tiendas con alta demanda, o concentraciones críticas de dead stock."
                operationalImpact="Requieren rebalanceo urgente o acción correctiva inmediata."
              />
            </div>
            <div className={`text-xl sm:text-2xl font-bold mt-1 font-mono tracking-tight ${totalCriticalAlerts > 0 ? 'text-rose-600' : 'text-zinc-900'}`}>{totalCriticalAlerts}</div>
            <div className="flex items-center justify-between text-[10px] mt-0.5">
              <span className="text-zinc-400">Quiebres</span>
              <span className={`font-mono font-medium ${momStats.alertsDeltaMoM <= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {momStats.alertsDeltaMoM <= 0 ? `${momStats.alertsDeltaMoM}` : `+${momStats.alertsDeltaMoM}`} MoM
              </span>
            </div>
          </div>

          <div className="bg-zinc-50 p-3 rounded-lg border border-zinc-200/80 flex flex-col justify-between min-h-[82px] relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 truncate block">Rebalanceo</span>
              <CardInfoButton
                title="Oportunidades de Traslado"
                description="Cantidad de órdenes de traslado calculadas para mover stock desde tiendas donantes hacia tiendas con quiebre."
                formula="Algoritmo SPEC: Exceso en Donante & Quiebre en Receptor"
              />
            </div>
            <div className="text-xl sm:text-2xl font-bold text-zinc-900 mt-1 font-mono tracking-tight">{transferSuggestions.length}</div>
            <div className="flex items-center justify-between text-[10px] mt-0.5">
              <span className="text-zinc-400">Módulo Traslados</span>
              <button
                type="button"
                onClick={() => onNavigateToTab('traslados')}
                className="font-mono text-zinc-900 hover:underline font-semibold cursor-pointer"
              >
                IR →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* REUBICACIÓN EN MANAGER: Tarjetas de Diagnóstico (Riesgo Financiero, Antigüedad del Stock, Rendimiento Espacial) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-zinc-600" />
            <span>Diagnóstico Ejecutivo & Eficiencia de Red</span>
          </h2>
          <span className="text-[11px] text-zinc-400 font-mono">Consolidado Corporativo</span>
        </div>
        <DiagnosticCards
          financialRisk={financialRisk}
          agingSummary={agingSummary}
          currentSpatial={currentSpatial}
          totalValuation={totalNetworkValuation}
        />
      </div>

      {/* Clear Uploaded Files / Inventory Only Confirmation Modal */}
      {isClearInventoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-rose-200 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden text-zinc-900 flex flex-col">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-200/80 bg-zinc-50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
                  <FileX className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-zinc-900 tracking-tight">
                    Borrar Solo Archivos de Inventario Cargados
                  </h2>
                  <p className="text-xs text-zinc-500">
                    Limpieza selectiva de datos de stock y piezas subidas
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsClearInventoryModalOpen(false)}
                className="p-1 text-zinc-400 hover:text-zinc-700 rounded hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-3.5">
              <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 space-y-1.5">
                <div className="flex items-center gap-2 text-rose-800 font-bold text-xs">
                  <AlertOctagon className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>¿Deseas vaciar los datos de inventario cargados?</span>
                </div>
                <p className="text-xs text-rose-700 leading-relaxed">
                  Esta acción eliminará <strong className="text-zinc-900">{inventory.length.toLocaleString()} registros de stock</strong> ({totalNetworkPieces.toLocaleString()} piezas físicas) correspondientes a los archivos Excel o fuentes cargadas.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-zinc-50 border border-zinc-200 space-y-1.5">
                <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs uppercase tracking-wider">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Se mantendrán guardados intactos:</span>
                </div>
                <ul className="text-xs text-zinc-600 space-y-1 pl-5 list-disc">
                  <li>Las <strong className="text-zinc-900">{stores.length} tiendas</strong> registradas en la red</li>
                  <li>Las matrices de capacidad física de muebles y frentes de cada tienda</li>
                  <li>La configuración de marcas personalizadas y reglas de rotación</li>
                </ul>
              </div>
            </div>

            <div className="px-5 py-3.5 bg-zinc-50 border-t border-zinc-200/80 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setIsClearInventoryModalOpen(false)}
                className="px-3.5 py-1.5 bg-white border border-zinc-200 rounded-lg text-xs font-semibold text-zinc-700 hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmClearUploadedInventory}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-xs inline-flex items-center gap-1.5"
              >
                <FileX className="w-3.5 h-3.5" />
                <span>Sí, Vaciar Inventario</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Stock Dispatch Simulator Modal (Without nested scroll) */}
      {isAllocatingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-900/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white border border-zinc-200 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden text-zinc-900 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-200/80 bg-zinc-50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-zinc-100 text-zinc-700 border border-zinc-200">
                  <Send className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-zinc-900 tracking-tight">
                    Gestor de Despacho & Asignación Masiva de Stock
                  </h2>
                  <p className="text-xs text-zinc-500">
                    Simula y ejecuta la distribución de pedidos o mercancía entrante hacia la red de tiendas
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAllocatingModalOpen(false)}
                className="p-1 text-zinc-400 hover:text-zinc-700 rounded hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                    Referencia / SKU
                  </label>
                  <input
                    type="text"
                    value={dispRef}
                    onChange={(e) => setDispRef(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 font-mono focus:bg-white focus:outline-none focus:border-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                    Marca
                  </label>
                  <input
                    type="text"
                    value={dispBrand}
                    onChange={(e) => setDispBrand(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                    Departamento
                  </label>
                  <select
                    value={dispDept}
                    onChange={(e) => setDispDept(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-400 cursor-pointer"
                  >
                    <option value="CALZADO">CALZADO</option>
                    <option value="TEXTIL">TEXTIL</option>
                    <option value="ACCESORIOS">ACCESORIOS</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                    Total Unidades a Despachar
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={dispTotalUnits === 0 ? '' : dispTotalUnits}
                    placeholder="100"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseInt(raw, 10);
                      setDispTotalUnits(isNaN(val) ? 0 : Math.max(0, val));
                    }}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 font-mono focus:bg-white focus:outline-none focus:border-zinc-400 placeholder:text-zinc-400 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">
                    Criterio de Distribución
                  </label>
                  <select
                    value={dispStrategy}
                    onChange={(e) => setDispStrategy(e.target.value as any)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1.5 text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-400 cursor-pointer"
                  >
                    <option value="DEFICIT_PRIORITY">Prioridad Tiendas con Déficit de Stock</option>
                    <option value="FLAGSHIP_HEAVY">Ponderar por Flagship / Mayor Superficie</option>
                    <option value="EQUAL">Distribución Equitativa</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleGenerateDistribution}
                  className="w-full py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 text-xs font-semibold rounded-lg border border-zinc-200/90 transition-colors cursor-pointer"
                >
                  ⚡ Recalcular Reparto ({dispTotalUnits} Uds)
                </button>
              </div>

              {/* Store Distribution Rows - Clean without nested scroll */}
              <div className="space-y-2 pt-2 border-t border-zinc-100">
                <div className="flex items-center justify-between text-[11px] text-zinc-500 font-semibold uppercase">
                  <span>Tienda</span>
                  <span>Unidades Asignadas</span>
                </div>
                <div className="space-y-1.5">
                  {stores.map((st) => (
                    <div
                      key={st}
                      className="flex items-center justify-between p-2 rounded-lg bg-zinc-50 border border-zinc-200/80 text-xs"
                    >
                      <span className="font-semibold text-zinc-800">{st}</span>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={dispDistribution[st] === 0 ? '' : (dispDistribution[st] ?? '')}
                          placeholder="0"
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => {
                            const raw = e.target.value;
                            const val = raw === '' ? 0 : parseInt(raw, 10);
                            setDispDistribution((prev) => ({
                              ...prev,
                              [st]: isNaN(val) ? 0 : Math.max(0, val),
                            }));
                          }}
                          className="w-20 text-right bg-white border border-zinc-200 rounded px-2 py-1 font-mono text-zinc-900 focus:outline-none focus:border-zinc-400 placeholder:text-zinc-400 transition-all"
                        />
                        <span className="text-[10px] text-zinc-400 font-mono">uds</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 bg-zinc-50 border-t border-zinc-200/80 flex items-center justify-between">
              <span className="text-xs font-mono text-zinc-500">
                Total Asignado:{' '}
                <strong className="text-zinc-900">
                  {Object.values(dispDistribution).reduce<number>((a, b) => a + (Number(b) || 0), 0)} uds
                </strong>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAllocatingModalOpen(false)}
                  className="px-3.5 py-1.5 bg-white border border-zinc-200 rounded-lg text-xs font-semibold text-zinc-700 hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleApplyBulkAllocation}
                  className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-xs inline-flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Aplicar Despacho</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Tasa Oficial BCV & Conversión a Dólares */}
      {isBcvRateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-900/40 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white border border-zinc-200 rounded-2xl shadow-xl w-full max-w-md overflow-hidden text-zinc-900 flex flex-col">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-200/80 bg-zinc-50">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-zinc-900 text-white flex items-center justify-center font-mono text-xs font-bold shadow-2xs">
                  BCV
                </div>
                <div>
                  <h3 className="text-sm font-bold text-zinc-900 tracking-tight">
                    Tasa Oficial Banco Central de Venezuela
                  </h3>
                  <p className="text-[11px] text-zinc-500 font-sans">
                    Conversión de inventario de Bolívares (Bs.) a Dólares ($ USD)
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsBcvRateModalOpen(false)}
                className="p-1 text-zinc-400 hover:text-zinc-700 rounded hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-600 font-medium">Valoración Total en Dólares:</span>
                  <span className="font-mono font-bold text-zinc-900">${totalNetworkValuation.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD</span>
                </div>
                <div className="flex justify-between items-center text-xs pt-1.5 border-t border-zinc-200/60">
                  <span className="text-zinc-600 font-medium">Equivalente en Bolívares:</span>
                  <span className="font-mono font-bold text-emerald-700">Bs. {(totalNetworkValuation * (parseFloat(tempBcvRate) || bcvRate || 855.66)).toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-600 mb-1.5 font-mono">
                  Tasa de Cambio Oficial (Bs. por 1 USD)
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={tempBcvRate}
                      onChange={(e) => setTempBcvRate(e.target.value)}
                      placeholder="855.66"
                      className="w-full bg-white border border-zinc-300 rounded-lg px-3 py-2 text-sm font-mono font-bold text-zinc-900 focus:outline-none focus:border-zinc-500 shadow-2xs"
                    />
                    <span className="absolute right-3 top-2.5 text-xs font-mono text-zinc-400 pointer-events-none">
                      Bs. / $
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleFetchBcv}
                    disabled={isFetchingBcv}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-lg text-xs font-medium border border-zinc-200 transition-colors cursor-pointer shrink-0"
                    title="Consultar cotización oficial del BCV en tiempo real"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isFetchingBcv ? 'animate-spin text-blue-600' : 'text-zinc-600'}`} />
                    <span>{isFetchingBcv ? 'Consultando...' : 'Consultar BCV'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-zinc-500 mt-1.5 font-sans leading-relaxed">
                  Al actualizar la tasa, todas las tarjetas y valoraciones de la plataforma se recalcularán automáticamente en Dólares ($ USD).
                </p>
                {bcvFetchSuccess && (
                  <p className="text-[11px] text-emerald-700 font-mono font-medium mt-1">
                    ✓ {bcvFetchSuccess}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 px-5 py-3 border-t border-zinc-200/80 bg-zinc-50">
              <button
                type="button"
                onClick={() => setIsBcvRateModalOpen(false)}
                className="px-3 py-1.5 text-xs text-zinc-600 hover:text-zinc-900 font-medium cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveBcvRate}
                className="px-4 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
              >
                Aplicar Tasa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
