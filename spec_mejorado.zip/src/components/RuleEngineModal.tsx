import React, { useState } from 'react';
import { CheckCircle2, RotateCcw, Save, Settings2, Sliders, X } from 'lucide-react';
import { RuleEngineConfig } from '../types';
import { DEFAULT_RULE_CONFIG } from '../utils/storageService';
import { CardInfoButton } from './CardInfoButton';

interface RuleEngineModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig: RuleEngineConfig;
  onSaveConfig: (newConfig: RuleEngineConfig) => void;
}

export const RuleEngineModal: React.FC<RuleEngineModalProps> = ({
  isOpen,
  onClose,
  currentConfig,
  onSaveConfig,
}) => {
  const [config, setConfig] = useState<RuleEngineConfig>(currentConfig || DEFAULT_RULE_CONFIG);

  if (!isOpen) return null;

  const handleReset = () => {
    setConfig(DEFAULT_RULE_CONFIG);
  };

  const handleSave = () => {
    onSaveConfig(config);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-white border border-zinc-200 rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-200 bg-[#F8F7FC]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600 border border-purple-200">
              <Settings2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-zinc-900 tracking-tight">
                  Motor de Reglas y Umbrales Paramétricos
                </h2>
                <CardInfoButton
                  title="Motor de Reglas de Negocio"
                  description="Permite calibrar la sensibilidad de los diagnósticos de inventario, alertas de quiebre, envejecimiento y tarifas de flete logístico."
                  operationalImpact="Los cambios se aplican inmediatamente recalculando las alertas prioritarias y el valor en riesgo."
                />
              </div>
              <p className="text-xs text-zinc-500">
                Personaliza los criterios de sobrestock, quiebres de tallas y costos de transferencia
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Section 1: Capacity & Stock Thresholds */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-zinc-700 uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-blue-600" />
              <span>Umbrales de Ocupación y Capacidad</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Umbral de Sobrestock (%)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="100"
                    max="200"
                    value={config.umbralSobrestockPorcentaje === 0 ? '' : config.umbralSobrestockPorcentaje}
                    placeholder="115"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseInt(raw, 10);
                      setConfig((prev) => ({
                        ...prev,
                        umbralSobrestockPorcentaje: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none placeholder:text-zinc-400"
                  />
                  <span className="text-xs text-zinc-500 font-mono">%</span>
                </div>
                <p className="text-[10px] text-zinc-500">Alertar si la ocupación excede este porcentaje.</p>
              </div>

              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Umbral de Sub-ocupación (%)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="30"
                    max="95"
                    value={config.umbralSubstockPorcentaje === 0 ? '' : config.umbralSubstockPorcentaje}
                    placeholder="75"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseInt(raw, 10);
                      setConfig((prev) => ({
                        ...prev,
                        umbralSubstockPorcentaje: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none placeholder:text-zinc-400"
                  />
                  <span className="text-xs text-zinc-500 font-mono">%</span>
                </div>
                <p className="text-[10px] text-zinc-500">Alertar si la ocupación cae por debajo de este nivel.</p>
              </div>
            </div>
          </div>

          {/* Section 2: Aging & Size Curves */}
          <div className="space-y-4 pt-2">
            <h3 className="text-xs font-bold text-zinc-700 uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-amber-600" />
              <span>Antigüedad del Inventario y Monotallas</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Días para Inventario Crítico
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="30"
                    max="365"
                    value={config.umbralAgingCriticoDias === 0 ? '' : config.umbralAgingCriticoDias}
                    placeholder="90"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseInt(raw, 10);
                      setConfig((prev) => ({
                        ...prev,
                        umbralAgingCriticoDias: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none placeholder:text-zinc-400"
                  />
                  <span className="text-xs text-zinc-500 font-mono">días</span>
                </div>
                <p className="text-[10px] text-zinc-500">Stock con permanencia superior se marca como inventario inmovilizado sin rotación.</p>
              </div>

              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Límite Monotalla Huérfana
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="5"
                    value={config.umbralMonotallaPiezas === 0 ? '' : config.umbralMonotallaPiezas}
                    placeholder="2"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseInt(raw, 10);
                      setConfig((prev) => ({
                        ...prev,
                        umbralMonotallaPiezas: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-amber-500 focus:outline-none placeholder:text-zinc-400"
                  />
                  <span className="text-xs text-zinc-500 font-mono">piezas</span>
                </div>
                <p className="text-[10px] text-zinc-500">Stock aislado en 1 sola talla que genera alerta.</p>
              </div>
            </div>
          </div>

          {/* Section 3: Freight Logistics & Distance Costs */}
          <div className="space-y-4 pt-2">
            <h3 className="text-xs font-bold text-zinc-700 uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-emerald-600" />
              <span>Parámetros de Flete y Traslado Logístico</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Costo Base Fijo por Despacho ($)
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-500 font-mono">$</span>
                  <input
                    type="number"
                    step="1"
                    min="0"
                    value={config.costoFleteBaseFijo === 0 ? '' : config.costoFleteBaseFijo}
                    placeholder="15"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseFloat(raw);
                      setConfig((prev) => ({
                        ...prev,
                        costoFleteBaseFijo: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none placeholder:text-zinc-400"
                  />
                </div>
                <p className="text-[10px] text-zinc-500">Costo administrativo y de preparación de guía.</p>
              </div>

              <div className="bg-[#F8F7FC] p-3.5 rounded-xl border border-zinc-200 space-y-2">
                <label className="text-xs font-semibold text-zinc-700 block">
                  Tarifa por Kilómetro Recorrido ($/km)
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-500 font-mono">$</span>
                  <input
                    type="number"
                    step="0.05"
                    min="0.1"
                    value={config.costoFleteBasePorKm === 0 ? '' : config.costoFleteBasePorKm}
                    placeholder="0.85"
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => {
                      const raw = e.target.value;
                      const val = raw === '' ? 0 : parseFloat(raw);
                      setConfig((prev) => ({
                        ...prev,
                        costoFleteBasePorKm: isNaN(val) ? 0 : Math.max(0, val),
                      }));
                    }}
                    className="w-full bg-white border border-zinc-200 rounded-lg px-3 py-1.5 text-zinc-900 font-mono text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none placeholder:text-zinc-400"
                  />
                </div>
                <p className="text-[10px] text-zinc-500">Factor de transporte terrestre por distancia.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-[#F8F7FC] border-t border-zinc-200 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-2 px-3 py-2 text-xs text-zinc-500 hover:text-zinc-800 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer Predeterminados</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-zinc-600 hover:bg-zinc-200/60 rounded-xl transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-2 px-5 py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold rounded-xl shadow-sm transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Guardar y Aplicar Reglas</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
