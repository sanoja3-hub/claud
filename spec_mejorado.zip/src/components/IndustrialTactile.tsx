import React from 'react';

/**
 * Precision Industrial Tactile Component Suite
 * Inspired by Braun, Teenage Engineering & Leica precision instruments.
 */

// --- 1. INDUSTRIAL STATUS BADGE WITH PULSING LED ---
interface IndustrialBadgeProps {
  status: 'optimal' | 'warning' | 'critical' | 'neutral' | 'active';
  label: string;
  sublabel?: string;
  size?: 'sm' | 'md';
}

export const IndustrialBadge: React.FC<IndustrialBadgeProps> = ({
  status,
  label,
  sublabel,
  size = 'md',
}) => {
  const styles = {
    optimal: {
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-200/80',
      led: 'bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.6)]',
      pulse: 'bg-emerald-400',
    },
    active: {
      bg: 'bg-zinc-100 text-zinc-800 border-zinc-300',
      led: 'bg-zinc-900 shadow-[0_0_4px_rgba(24,24,27,0.4)]',
      pulse: 'bg-zinc-600',
    },
    warning: {
      bg: 'bg-amber-50 text-amber-800 border-amber-200/80',
      led: 'bg-amber-500 shadow-[0_0_6px_rgba(245,158,11,0.6)]',
      pulse: 'bg-amber-400',
    },
    critical: {
      bg: 'bg-rose-50 text-rose-800 border-rose-200/80',
      led: 'bg-rose-500 shadow-[0_0_6px_rgba(239,68,68,0.6)]',
      pulse: 'bg-rose-400',
    },
    neutral: {
      bg: 'bg-[#F4F2FD] text-zinc-600 border-zinc-200/80',
      led: 'bg-zinc-400',
      pulse: 'bg-zinc-300',
    },
  }[status];

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono uppercase tracking-wider rounded-full border shadow-[inset_0_1px_1px_rgba(255,255,255,0.9)] select-none ${
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px] font-semibold'
      } ${styles.bg}`}
    >
      <span className="relative flex h-2 w-2 items-center justify-center">
        <span
          className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-60 ${styles.pulse}`}
        />
        <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${styles.led}`} />
      </span>
      <span>{label}</span>
      {sublabel && (
        <>
          <span className="text-zinc-300 font-normal">//</span>
          <span className="opacity-75">{sublabel}</span>
        </>
      )}
    </span>
  );
};

// --- 2. CONCENTRIC DIAL / RADIAL CALIBRATION GAUGE ---
interface ConcentricDialProps {
  value: number; // Current value (e.g. current occupancy % or fill ratio)
  target?: number; // Standard target (default 100%)
  min?: number;
  max?: number;
  label: string;
  unit?: string;
  status?: 'optimal' | 'warning' | 'critical';
  size?: number; // default 130
}

export const ConcentricDial: React.FC<ConcentricDialProps> = ({
  value,
  target = 100,
  min = 0,
  max = 150,
  label,
  unit = '%',
  status = 'optimal',
  size = 120,
}) => {
  const radius = (size - 24) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;

  // Arc ranges: 220 degrees sweep (-200 to 20 deg)
  const sweepAngle = 220;
  const startAngle = 160; // top-left start
  const clampedVal = Math.max(min, Math.min(max, value));
  const ratio = (clampedVal - min) / (max - min);

  // Stroke Dash calculations for the arc
  const arcLength = (sweepAngle / 360) * circumference;
  const strokeDashoffset = arcLength * (1 - ratio);

  // Status colors
  const strokeColor =
    status === 'critical'
      ? '#EF4444'
      : status === 'warning'
      ? '#F59E0B'
      : '#10B981';

  // Generate radial calibration tick marks (every 10 units)
  const ticks = [];
  const tickCount = 11;
  for (let i = 0; i <= tickCount; i++) {
    const tRatio = i / tickCount;
    const angleDeg = startAngle + tRatio * sweepAngle;
    const angleRad = (angleDeg * Math.PI) / 180;
    const isMajor = i % 2 === 0;
    const tickLen = isMajor ? 6 : 3;
    const r1 = radius + 6;
    const r2 = r1 + tickLen;
    const x1 = center + r1 * Math.cos(angleRad);
    const y1 = center + r1 * Math.sin(angleRad);
    const x2 = center + r2 * Math.cos(angleRad);
    const y2 = center + r2 * Math.sin(angleRad);

    ticks.push(
      <line
        key={i}
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke={isMajor ? '#A1A1AA' : '#D4D4D8'}
        strokeWidth={isMajor ? 1.5 : 1}
      />
    );
  }

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="overflow-visible">
          {/* Bezel ring */}
          <circle
            cx={center}
            cy={center}
            r={radius + 8}
            fill="none"
            stroke="#ECEAF4"
            strokeWidth={1}
          />

          {/* Background track */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="#E4E2ED"
            strokeWidth={5}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
            transform={`rotate(${startAngle} ${center} ${center})`}
          />

          {/* Active measurement bar */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke={strokeColor}
            strokeWidth={5}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform={`rotate(${startAngle} ${center} ${center})`}
            className="transition-all duration-500 ease-out"
          />

          {/* Radial tick marks */}
          {ticks}

          {/* Target tick (100%) */}
          {target && (
            (() => {
              const targetRatio = (target - min) / (max - min);
              const angleDeg = startAngle + targetRatio * sweepAngle;
              const angleRad = (angleDeg * Math.PI) / 180;
              const r1 = radius - 7;
              const r2 = radius + 3;
              const x1 = center + r1 * Math.cos(angleRad);
              const y1 = center + r1 * Math.sin(angleRad);
              const x2 = center + r2 * Math.cos(angleRad);
              const y2 = center + r2 * Math.sin(angleRad);
              return (
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#18181B"
                  strokeWidth={2}
                  strokeLinecap="round"
                />
              );
            })()
          )}
        </svg>

        {/* Center Digital Readout */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none pt-1">
          <div className="flex items-baseline gap-0.5">
            <span className="text-xl font-bold font-mono tracking-tight text-zinc-900 leading-none">
              {Math.round(value)}
            </span>
            <span className="text-[10px] font-mono text-zinc-500">{unit}</span>
          </div>
          <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-400 mt-1">
            {target ? `TGT ${target}${unit}` : 'DIAL'}
          </span>
        </div>
      </div>
      <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-600 font-semibold mt-1">
        {label}
      </span>
    </div>
  );
};

// --- 3. EMBEDDED QUANTITY / BATCH STEPPER ---
interface StepperQuantityProps {
  value: number;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  label?: string;
  disabled?: boolean;
}

export const StepperQuantity: React.FC<StepperQuantityProps> = ({
  value,
  onChange,
  min = 0,
  max = 9999,
  step = 1,
  unit,
  label,
  disabled = false,
}) => {
  const handleDecrement = () => {
    if (value - step >= min) onChange(value - step);
  };

  const handleIncrement = () => {
    if (value + step <= max) onChange(value + step);
  };

  return (
    <div className="inline-flex flex-col gap-1 select-none">
      {label && (
        <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 font-semibold">
          {label}
        </span>
      )}
      <div className="inline-flex items-center h-8 bg-[#F4F2FD] border border-zinc-200/90 rounded-lg p-0.5 shadow-[inset_0_1.5px_3px_rgba(0,0,0,0.04)]">
        {/* Decrement Push Button */}
        <button
          type="button"
          disabled={disabled || value <= min}
          onClick={handleDecrement}
          className="w-7 h-7 flex items-center justify-center rounded-md bg-white text-zinc-700 hover:text-zinc-900 hover:bg-zinc-50 active:bg-zinc-100 disabled:opacity-40 disabled:cursor-not-allowed border border-zinc-200/80 shadow-[0_1px_1px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)] transition-all cursor-pointer text-xs font-mono font-bold"
          title="Decrementar"
        >
          -
        </button>

        {/* Central Display */}
        <div className="min-w-[48px] px-2 text-center">
          <span className="text-xs font-mono font-bold text-zinc-900 tracking-tight">
            {value}
          </span>
          {unit && <span className="text-[10px] font-mono text-zinc-500 ml-0.5">{unit}</span>}
        </div>

        {/* Increment Push Button */}
        <button
          type="button"
          disabled={disabled || value >= max}
          onClick={handleIncrement}
          className="w-7 h-7 flex items-center justify-center rounded-md bg-white text-zinc-700 hover:text-zinc-900 hover:bg-zinc-50 active:bg-zinc-100 disabled:opacity-40 disabled:cursor-not-allowed border border-zinc-200/80 shadow-[0_1px_1px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)] transition-all cursor-pointer text-xs font-mono font-bold"
          title="Incrementar"
        >
          +
        </button>
      </div>
    </div>
  );
};

// --- 4. RETICLE VIEWFINDER / CALIBRATION BOX ---
interface ReticleBoxProps {
  title?: string;
  telemetry?: string;
  children: React.ReactNode;
  className?: string;
}

export const ReticleBox: React.FC<ReticleBoxProps> = ({
  title,
  telemetry,
  children,
  className = '',
}) => {
  return (
    <div
      className={`relative bg-white border border-zinc-200/80 rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.02)] ${className}`}
    >
      {/* Precision Corner Calibration Ticks */}
      <span className="absolute top-1.5 left-1.5 w-2 h-2 border-t-2 border-l-2 border-zinc-400 pointer-events-none" />
      <span className="absolute top-1.5 right-1.5 w-2 h-2 border-t-2 border-r-2 border-zinc-400 pointer-events-none" />
      <span className="absolute bottom-1.5 left-1.5 w-2 h-2 border-b-2 border-l-2 border-zinc-400 pointer-events-none" />
      <span className="absolute bottom-1.5 right-1.5 w-2 h-2 border-b-2 border-r-2 border-zinc-400 pointer-events-none" />

      {/* Header bar with mil-spec typography */}
      {(title || telemetry) && (
        <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-zinc-100 text-[11px] font-mono">
          {title && (
            <span className="font-semibold text-zinc-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-900" />
              {title}
            </span>
          )}
          {telemetry && (
            <span className="text-zinc-400 text-[10px] uppercase tracking-widest">
              {telemetry}
            </span>
          )}
        </div>
      )}

      {children}
    </div>
  );
};
