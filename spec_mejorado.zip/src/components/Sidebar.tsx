import React, { useMemo } from 'react';
import {
  AlertOctagon,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Database,
  Grid,
  Layers,
  PanelLeftClose,
  PanelLeftOpen,
  Settings2,
  Store,
  Truck,
  UploadCloud,
  BookOpen,
} from 'lucide-react';
import { motion } from 'motion/react';
import { SpecLogoIcon } from './SpecLogo';

export interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
  badgeVariant?: 'danger' | 'info' | 'neutral';
}

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  alertsCount: number;
  transfersCount: number;
  selectedStore?: string;
  storesCount?: number;
  onOpenUpload?: () => void;
  onOpenRegisterStore?: () => void;
  onOpenManual?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
  alertsCount = 0,
  transfersCount = 0,
  selectedStore = 'TODAS',
  storesCount = 0,
  onOpenUpload,
  onOpenManual,
}) => {
  const storeDisplay = useMemo(() => {
    if (!selectedStore || selectedStore === 'TODAS') return 'RED TOTAL';
    if (typeof selectedStore === 'string') return selectedStore.toUpperCase();
    if (typeof selectedStore === 'object' && selectedStore !== null) {
      const candidate = (selectedStore as any).nombre || (selectedStore as any).name || (selectedStore as any).Tienda;
      return String(candidate || 'TIENDA').toUpperCase();
    }
    return String(selectedStore).toUpperCase();
  }, [selectedStore]);

  const navItems: NavItem[] = [
    { id: 'manager', label: 'Panel Manager', icon: Layers },
    { id: 'dashboard', label: 'Cuadro de Mando', icon: BarChart3 },
    {
      id: 'alertas',
      label: 'Curvas & Alertas',
      icon: Grid,
      badge: alertsCount,
      badgeVariant: 'danger',
    },
    {
      id: 'traslados',
      label: 'Rebalanceo Tiendas',
      icon: Truck,
      badge: transfersCount,
      badgeVariant: 'info',
    },
    { id: 'capacidad', label: 'Matriz Capacidad', icon: Settings2 },
    { id: 'detalle', label: 'Detalle Inventario', icon: Database },
  ];

  return (
    <>
      <aside
        className={`fixed top-0 left-0 h-screen z-50 flex flex-col justify-between bg-[#F8F7FC] border-r border-zinc-200/80 text-zinc-800 transition-all duration-300 ease-in-out select-none ${
          isCollapsed ? '-translate-x-full w-64 pointer-events-none' : 'translate-x-0 w-64 shadow-2xl'
        }`}
      >
      {/* Top Brand & Collapse Toggle */}
      <div>
        <div className="h-14 flex items-center justify-between px-3.5 border-b border-zinc-200/80 bg-white">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-white border border-zinc-200 shadow-2xs flex items-center justify-center shrink-0 p-1">
              <SpecLogoIcon className="w-full h-full" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center leading-none">
                <span className="text-xs font-black text-zinc-900 tracking-[0.22em] uppercase">
                  SPEC
                </span>
                <span className="w-1.5 h-1.5 bg-[#F97316] ml-1 inline-block rounded-[1px] shrink-0" />
              </div>
              <span className="text-[9px] font-bold text-zinc-400 mt-0.5 inline-block uppercase tracking-[0.14em]">
                DISTRIBUTION &amp; REBALANCE
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleCollapse}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 transition-colors cursor-pointer"
            title="Cerrar consola lateral"
            aria-label="Cerrar consola lateral"
          >
            <PanelLeftClose className="w-4 h-4" />
          </button>
        </div>

        {/* Store Context Industrial Badge */}
        <div className="px-3.5 py-2.5 border-b border-zinc-200/60 bg-[#F4F2FD]">
          <div className="text-[9px] font-mono font-bold text-zinc-500 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>ALCANCE // ACTIVO</span>
          </div>
          <div className="text-xs font-mono font-semibold text-zinc-900 truncate bg-white px-2.5 py-1.5 rounded-lg border border-zinc-200/80 shadow-[0_1px_2px_rgba(0,0,0,0.02)] flex items-center justify-between">
            <span className="truncate">
              {storeDisplay}
            </span>
            <span className="text-[10px] font-mono text-zinc-500 shrink-0 ml-1.5 bg-[#F4F2FD] px-1.5 py-0.5 rounded border border-zinc-200">
              {storesCount || 0} SUC
            </span>
          </div>
        </div>

        {/* Navigation Tabs (Tactile Hardware Switches) */}
        <nav className="p-2 space-y-1 mt-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-xs font-mono transition-all cursor-pointer relative group ${
                  isActive
                    ? 'bg-white text-zinc-900 border border-zinc-300 shadow-[0_1px_3px_rgba(0,0,0,0.03),inset_0_1px_0_rgba(255,255,255,0.9)] font-semibold'
                    : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/50 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-colors ${
                      isActive ? 'text-zinc-900' : 'text-zinc-400 group-hover:text-zinc-700'
                    }`}
                  />
                  <span className="truncate tracking-tight">{item.label}</span>
                </div>

                {/* Status Badges */}
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold shrink-0 ${
                      item.badgeVariant === 'danger'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-zinc-100 text-zinc-700 border border-zinc-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Footer Actions */}
      <div className="p-2 border-t border-zinc-200/80 bg-white space-y-1.5">
        {onOpenManual && (
          <button
            type="button"
            onClick={onOpenManual}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-zinc-100 hover:bg-zinc-200/80 text-zinc-800 border border-zinc-200/90 text-xs font-mono font-semibold transition-colors cursor-pointer"
            title="Abrir Manual de Instrucciones & Guía Completa de la Plataforma"
          >
            <BookOpen className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
            <span className="truncate">MANUAL // GUÍA SPEC</span>
          </button>
        )}

        {onOpenUpload && (
          <button
            type="button"
            onClick={onOpenUpload}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg tactile-button-dark text-xs font-mono font-semibold transition-colors cursor-pointer"
          >
            <UploadCloud className="w-3.5 h-3.5 text-white shrink-0" />
            <span className="truncate">INGESTA // EXCEL</span>
          </button>
        )}

        <div className="pt-1 px-2 text-[9px] text-zinc-400 font-mono text-center tracking-widest uppercase">
          SPEC // 400Hz PRECISION
        </div>
      </div>
    </aside>
    </>
  );
};
