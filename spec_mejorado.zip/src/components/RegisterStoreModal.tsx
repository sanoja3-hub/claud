import React, { useState, useEffect, useMemo } from 'react';
import {
  Building2,
  Check,
  CheckCircle2,
  ChevronRight,
  Crown,
  MapPin,
  Package,
  Plus,
  Ruler,
  Sliders,
  Store,
  Trash2,
  Truck,
  X,
  Tag,
  BarChart3,
  ToggleLeft,
  ToggleRight,
  Info,
  Layers,
  Globe,
  Activity,
  Maximize2,
  Minimize2,
  EyeOff,
  ChevronDown,
} from 'lucide-react';
import {
  CapacityMatrixConfig,
  DepartmentCapacity,
  StoreProfile,
  StoreType,
} from '../types';
import {
  createBaseBrandMatrix,
  createGlobalBrandMatrix,
  STORE_FORMAT_INFO,
} from '../data/defaultMatrix';
import {
  calcularTotalesMatriz,
  consolidarMatrizMarcas,
} from '../utils/analysisEngine';
import {
  IndustrialBadge,
  ConcentricDial,
  ReticleBox,
} from './IndustrialTactile';
import { GoogleMapsStoreLocator } from './GoogleMapsStoreLocator';
import { ExtractedPlaceDetails, calculateGeoDistanceKm } from '../utils/geoDistance';

function checkHasDetailedCategories(matrix?: CapacityMatrixConfig): boolean {
  if (!matrix) return false;
  for (const deptData of Object.values(matrix)) {
    if (!deptData?.secciones) continue;
    for (const secData of Object.values(deptData.secciones)) {
      const keys = Object.keys(secData || {});
      if (keys.length > 1) return true;
      if (keys.some((k) => k !== 'GLOBAL' && k !== 'UNIFICADO' && k !== 'GENERAL')) return true;
    }
  }
  return false;
}

interface RegisterStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingStores: string[];
  storeProfiles?: StoreProfile[];
  initialStoreToEdit?: StoreProfile | null;
  onRegisterStore: (
    newStore: StoreProfile,
    capacityConfig: CapacityMatrixConfig,
    distances: Record<string, number>,
    seedStock: boolean
  ) => void;
  onDeleteStore?: (storeName: string) => void;
}

export const RegisterStoreModal: React.FC<RegisterStoreModalProps> = ({
  isOpen,
  onClose,
  existingStores = [],
  storeProfiles = [],
  initialStoreToEdit,
  onRegisterStore,
  onDeleteStore,
}) => {
  const [selectedStoreToEditName, setSelectedStoreToEditName] = useState<string>(initialStoreToEdit?.nombre || '');
  const [showManualAddressEdit, setShowManualAddressEdit] = useState<boolean>(false);
  const isEditing = !!initialStoreToEdit || !!selectedStoreToEditName;

  // General Store Info
  const [nombre, setNombre] = useState('');
  const [ciudad, setCiudad] = useState('');
  const [region, setRegion] = useState('');
  const [direccion, setDireccion] = useState('');
  const [centroComercial, setCentroComercial] = useState('');
  const [lat, setLat] = useState<number | undefined>(undefined);
  const [lng, setLng] = useState<number | undefined>(undefined);
  const [placeId, setPlaceId] = useState<string | undefined>(undefined);
  const [formattedAddress, setFormattedAddress] = useState<string | undefined>(undefined);
  const [tipo, setTipo] = useState<StoreType>('LIVE');
  const [superficieM2, setSuperficieM2] = useState<number>(500);
  const [seedStock, setSeedStock] = useState<boolean>(false);
  const [showMapsLocator, setShowMapsLocator] = useState<boolean>(true);

  // Multi-brand Capacity Config State
  const [marcasCapacidad, setMarcasCapacidad] = useState<Record<string, CapacityMatrixConfig>>({});
  const [activeBrand, setActiveBrand] = useState<string>('GENERAL');
  const [newBrandInput, setNewBrandInput] = useState<string>('');
  const [showAddBrandInput, setShowAddBrandInput] = useState<boolean>(false);

  // Category toggle state per brand (true: detailed sports categories, false: global gender mode)
  const [brandCategoriesEnabled, setBrandCategoriesEnabled] = useState<Record<string, boolean>>({});
  const [newCategoryInputs, setNewCategoryInputs] = useState<Record<string, string>>({});
  const [showAddCategoryInput, setShowAddCategoryInput] = useState<Record<string, boolean>>({});

  // Global depth slider for quick adjustment of active brand
  const [globalBrandDepth, setGlobalBrandDepth] = useState<number>(16);

  // Distances to existing stores
  const [distances, setDistances] = useState<Record<string, number>>({});

  const [activeStep, setActiveStep] = useState<1 | 2 | 3>(1);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);

  // Handle switching store to geolocate / edit
  const handleSwitchStore = (storeName: string) => {
    setSelectedStoreToEditName(storeName);
    const target = storeProfiles.find((p) => p.nombre === storeName);
    if (target) {
      setNombre(target.nombre);
      setCiudad(target.ciudad || '');
      setRegion(target.region || '');
      setDireccion(target.direccion || '');
      setCentroComercial(target.centroComercial || '');
      setLat(target.lat);
      setLng(target.lng);
      setPlaceId(target.placeId);
      setFormattedAddress(target.formattedAddress);
      setTipo(target.tipo || 'LIVE');
      setSuperficieM2(target.superficieM2 || 500);
      if (target.marcasCapacidad && Object.keys(target.marcasCapacidad).length > 0) {
        setMarcasCapacidad(JSON.parse(JSON.stringify(target.marcasCapacidad)));
        setActiveBrand(Object.keys(target.marcasCapacidad)[0]);
      }
    } else {
      setNombre('');
      setCiudad('');
      setRegion('');
      setDireccion('');
      setCentroComercial('');
      setLat(undefined);
      setLng(undefined);
      setPlaceId(undefined);
      setFormattedAddress(undefined);
      setTipo('LIVE');
      setSuperficieM2(500);
      setMarcasCapacidad({ GENERAL: createBaseBrandMatrix(16) });
      setActiveBrand('GENERAL');
    }
    setErrorMsg(null);
  };

  // Initialize or reset when modal opens or store to edit changes
  useEffect(() => {
    if (!isOpen) return;

    const currentTarget = initialStoreToEdit || storeProfiles.find((p) => p.nombre === selectedStoreToEditName);

    if (currentTarget) {
      setSelectedStoreToEditName(currentTarget.nombre);
      setNombre(currentTarget.nombre);
      setCiudad(currentTarget.ciudad || '');
      setRegion(currentTarget.region || '');
      setDireccion(currentTarget.direccion || '');
      setCentroComercial(currentTarget.centroComercial || '');
      setLat(currentTarget.lat);
      setLng(currentTarget.lng);
      setPlaceId(currentTarget.placeId);
      setFormattedAddress(currentTarget.formattedAddress);
      setTipo(currentTarget.tipo || 'LIVE');
      setSuperficieM2(currentTarget.superficieM2 || 500);
      setSeedStock(false);

      if (
        currentTarget.marcasCapacidad &&
        Object.keys(currentTarget.marcasCapacidad).length > 0
      ) {
        setMarcasCapacidad(JSON.parse(JSON.stringify(currentTarget.marcasCapacidad)));
        const firstBrand = Object.keys(currentTarget.marcasCapacidad)[0];
        setActiveBrand(firstBrand);
      } else if (currentTarget.capacidadPersonalizada) {
        setMarcasCapacidad({
          GENERAL: JSON.parse(JSON.stringify(currentTarget.capacidadPersonalizada)),
        });
        setActiveBrand('GENERAL');
      } else {
        setMarcasCapacidad({
          GENERAL: createBaseBrandMatrix(16),
        });
        setActiveBrand('GENERAL');
      }
    } else {
      // New Store defaults
      setSelectedStoreToEditName('');
      setNombre('');
      setCiudad('');
      setRegion('');
      setDireccion('');
      setCentroComercial('');
      setLat(undefined);
      setLng(undefined);
      setPlaceId(undefined);
      setFormattedAddress(undefined);
      setTipo('LIVE');
      setSuperficieM2(500);
      setSeedStock(false);
      setMarcasCapacidad({
        GENERAL: createBaseBrandMatrix(16),
      });
      setActiveBrand('GENERAL');
    }

    // Initialize distances
    const initDist: Record<string, number> = {};
    (existingStores || []).forEach((st, idx) => {
      if (!st) return;
      const activeName = initialStoreToEdit?.nombre || selectedStoreToEditName;
      if (!activeName || st !== activeName) {
        const otherProfile = (storeProfiles || []).find((p) => p.nombre === st);
        const currentProfile = currentTarget;
        if (
          currentProfile?.lat !== undefined &&
          currentProfile?.lng !== undefined &&
          otherProfile?.lat !== undefined &&
          otherProfile?.lng !== undefined
        ) {
          initDist[st] = calculateGeoDistanceKm(
            currentProfile.lat,
            currentProfile.lng,
            otherProfile.lat,
            otherProfile.lng
          );
        } else {
          initDist[st] = 10 + idx * 4.5;
        }
      }
    });
    setDistances(initDist);
    setActiveStep(1);
    setErrorMsg(null);
    setShowDeleteConfirm(false);
  }, [isOpen, initialStoreToEdit, existingStores, storeProfiles]);

  const handleApplyLocationFromMap = (data: ExtractedPlaceDetails) => {
    if (data.ciudad) setCiudad(data.ciudad);
    if (data.region) setRegion(data.region);
    if (data.direccion) setDireccion(data.direccion);
    if (data.centroComercial) setCentroComercial(data.centroComercial);
    if (typeof data.lat === 'number') setLat(data.lat);
    if (typeof data.lng === 'number') setLng(data.lng);
    if (data.placeId) setPlaceId(data.placeId);
    if (data.formattedAddress) setFormattedAddress(data.formattedAddress);

    // If store name is empty, auto-fill with detected name
    if (!nombre.trim() && data.suggestedStoreName) {
      setNombre(data.suggestedStoreName);
    }

    // Auto-calculate real distances to other stores with coordinates
    if (typeof data.lat === 'number' && typeof data.lng === 'number' && (storeProfiles || []).length > 0) {
      const currentName = (selectedStoreToEditName || nombre).trim();
      setDistances((prev) => {
        const newDists: Record<string, number> = { ...prev };
        (storeProfiles || []).forEach((other) => {
          if (other && other.nombre !== currentName && typeof other.lat === 'number' && typeof other.lng === 'number') {
            const km = calculateGeoDistanceKm(data.lat, data.lng, other.lat, other.lng);
            newDists[other.nombre] = km;
          }
        });
        return newDists;
      });
    }
  };

  // Determine if categories are active for current active brand
  const isCategoriesActive = useMemo(() => {
    if (brandCategoriesEnabled[activeBrand] !== undefined) {
      return brandCategoriesEnabled[activeBrand];
    }
    return checkHasDetailedCategories(marcasCapacidad[activeBrand]);
  }, [brandCategoriesEnabled, activeBrand, marcasCapacidad]);

  // Active brand matrix
  const currentBrandMatrix = marcasCapacidad[activeBrand] || createBaseBrandMatrix(16);

  // Calculate Metrics for Current Active Brand
  const activeBrandMetrics = calcularTotalesMatriz(currentBrandMatrix);

  // Calculate Consolidated Metrics for the Entire Store across all brands
  const consolidatedMatrix = consolidarMatrizMarcas(marcasCapacidad);
  const storeConsolidatedMetrics = calcularTotalesMatriz(consolidatedMatrix);

  // Live Spatial Density Calculation (piezas / m²)
  const spatialDensity = useMemo(() => {
    const area = Number(superficieM2) || 500;
    return area > 0 ? Math.round((storeConsolidatedMetrics.totalPieces / area) * 10) / 10 : 0;
  }, [storeConsolidatedMetrics.totalPieces, superficieM2]);

  // Expected density benchmark by format
  const formatDensityTarget = useMemo(() => {
    switch (tipo) {
      case 'FLAGSHIP': return { min: 18, opt: 24, max: 32 };
      case 'LIVE': return { min: 20, opt: 28, max: 36 };
      case 'UNITE': return { min: 25, opt: 34, max: 44 };
      case 'EXPRESS': return { min: 22, opt: 30, max: 40 };
      default: return { min: 20, opt: 28, max: 36 };
    }
  }, [tipo]);

  // Density diagnosis
  const densityStatus: 'optimal' | 'warning' | 'critical' = useMemo(() => {
    if (spatialDensity < formatDensityTarget.min) return 'warning'; // Subutilizado
    if (spatialDensity > formatDensityTarget.max) return 'critical'; // Saturado
    return 'optimal';
  }, [spatialDensity, formatDensityTarget]);

  // Total floor exhibition pieces
  const totalFloorPieces = useMemo(() => {
    let pieces = 0;
    Object.values(marcasCapacidad).forEach((matrix) => {
      Object.entries(matrix).forEach(([dept, deptData]) => {
        if (deptData.activa === false) return;
        let deptSkus = 0;
        Object.values(deptData.secciones || {}).forEach((sec) => {
          Object.values(sec || {}).forEach((s) => {
            deptSkus += s || 0;
          });
        });
        const defaultExhibicion = dept === 'CALZADO' ? 1 : dept === 'TEXTIL' ? 6 : 4;
        const pz = deptData.piezas_exhibicion_sku ?? defaultExhibicion;
        pieces += deptSkus * pz;
      });
    });
    return pieces;
  }, [marcasCapacidad]);

  // Department distribution
  const departmentBreakdown = useMemo(() => {
    const res: Record<string, { skus: number; pieces: number }> = {
      CALZADO: { skus: 0, pieces: 0 },
      TEXTIL: { skus: 0, pieces: 0 },
      ACCESORIOS: { skus: 0, pieces: 0 },
    };
    Object.values(marcasCapacidad).forEach((matrix) => {
      Object.entries(matrix).forEach(([dept, deptData]) => {
        if (!res[dept]) res[dept] = { skus: 0, pieces: 0 };
        if (deptData.activa === false) return;
        let dSkus = 0;
        Object.values(deptData.secciones || {}).forEach((sec) => {
          Object.values(sec || {}).forEach((s) => {
            dSkus += s || 0;
          });
        });
        const dPieces = dSkus * (deptData.profundidad_target || 1);
        res[dept].skus += dSkus;
        res[dept].pieces += dPieces;
      });
    });
    return res;
  }, [marcasCapacidad]);

  // Gender distribution
  const genderBreakdown = useMemo(() => {
    const res: Record<string, number> = {
      Caballero: 0,
      Dama: 0,
      Niños: 0,
      Unisex: 0,
    };
    Object.values(marcasCapacidad).forEach((matrix) => {
      Object.values(matrix).forEach((deptData) => {
        if (deptData.activa === false) return;
        const depth = deptData.profundidad_target || 1;
        Object.entries(deptData.secciones || {}).forEach(([secName, secData]) => {
          const upper = (secName || '').toUpperCase();
          const totalSec = Object.values(secData || {}).reduce((a, b) => a + (b || 0), 0) * depth;
          if (upper.includes('MUJER') || upper.includes('WOMEN') || upper.includes('DAMA')) {
            res.Dama += totalSec;
          } else if (upper.includes('HOMBRE') || upper.includes('CABALLERO') || (upper.includes('MEN') && !upper.includes('WOMEN'))) {
            res.Caballero += totalSec;
          } else if (upper.includes('INFANTE') || upper.includes('NIÑOS') || upper.includes('KIDS')) {
            res.Niños += totalSec;
          } else {
            res.Unisex += totalSec;
          }
        });
      });
    });
    return res;
  }, [marcasCapacidad]);

  if (!isOpen) return null;

  // Brand Management Handlers
  const handleAddBrand = (brandNameToAdd?: string) => {
    const rawName = brandNameToAdd || newBrandInput;
    const cleanName = (rawName || '').trim().toUpperCase();
    if (!cleanName) return;

    if (marcasCapacidad[cleanName]) {
      setActiveBrand(cleanName);
      setNewBrandInput('');
      setShowAddBrandInput(false);
      return;
    }

    setMarcasCapacidad((prev) => ({
      ...prev,
      [cleanName]: createGlobalBrandMatrix(globalBrandDepth),
    }));
    setBrandCategoriesEnabled((prev) => ({
      ...prev,
      [cleanName]: false,
    }));
    setActiveBrand(cleanName);
    setNewBrandInput('');
    setShowAddBrandInput(false);
  };

  const handleRemoveBrand = (brandToRemove: string) => {
    const brandKeys = Object.keys(marcasCapacidad);
    if (brandKeys.length <= 1) {
      setErrorMsg('La tienda debe tener al menos una marca registrada.');
      return;
    }

    const next = { ...marcasCapacidad };
    delete next[brandToRemove];
    setMarcasCapacidad(next);

    const remainingKeys = Object.keys(next);
    if (activeBrand === brandToRemove) {
      setActiveBrand(remainingKeys[0]);
    }
  };

  const handleDepthChangeForBrand = (dept: string, depth: number) => {
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        profundidad_target: Math.max(1, depth),
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const handleExhibitionPiecesChangeForBrand = (dept: string, pieces: number) => {
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        piezas_exhibicion_sku: Math.max(1, pieces),
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const handleApplyGlobalDepthToBrand = (depth: number) => {
    setGlobalBrandDepth(depth);
    const nextBrandMatrix: CapacityMatrixConfig = {};
    for (const [dept, rawDeptData] of Object.entries(currentBrandMatrix)) {
      const deptData = rawDeptData as DepartmentCapacity;
      if (deptData) {
        nextBrandMatrix[dept] = {
          secciones: { ...deptData.secciones },
          profundidad_target: Math.max(1, dept === 'ACCESORIOS' ? Math.max(1, depth - 2) : depth),
        };
      }
    }

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  // Toggle between Categories Mode and Global Gender Mode
  const handleToggleBrandCategories = (enable: boolean) => {
    setBrandCategoriesEnabled((prev) => ({
      ...prev,
      [activeBrand]: enable,
    }));

    const nextBrandMatrix: CapacityMatrixConfig = JSON.parse(
      JSON.stringify(marcasCapacidad[activeBrand] || createBaseBrandMatrix(globalBrandDepth))
    );

    for (const [dept, deptData] of Object.entries(nextBrandMatrix)) {
      if (!deptData.secciones) deptData.secciones = {};

      if (!deptData.secciones['HOMBRE (MENS)']) {
        deptData.secciones['HOMBRE (MENS)'] = { GLOBAL: 0 };
      }
      if (!deptData.secciones['MUJER (WOMENS)']) {
        deptData.secciones['MUJER (WOMENS)'] = { GLOBAL: 0 };
      }
      if (!deptData.secciones['INFANTE / NIÑOS']) {
        deptData.secciones['INFANTE / NIÑOS'] = { GLOBAL: 0 };
      }

      for (const [secName, secData] of Object.entries(deptData.secciones)) {
        const totalSecSkus = Object.values(secData || {}).reduce((a, b) => a + (b || 0), 0);

        if (!enable) {
          // Switch to Global Gender Mode: condense into single GLOBAL key
          deptData.secciones[secName] = {
            GLOBAL: Math.max(0, totalSecSkus),
          };
        } else {
          // Switch to Categories Mode: distribute into sports categories
          const keys = Object.keys(secData || {});
          if (keys.length <= 1 && (keys[0] === 'GLOBAL' || keys[0] === 'UNIFICADO' || keys[0] === 'GENERAL' || keys.length === 0)) {
            const tot = totalSecSkus;
            if (tot <= 0) {
              if (dept === 'CALZADO') {
                if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                  deptData.secciones[secName] = { RUNNING: 0, 'SPORTSWEAR (CASUAL)': 0, TRAINING: 0 };
                } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                  deptData.secciones[secName] = { RUNNING: 0, 'SPORTSWEAR (CASUAL)': 0, FUTBOL: 0, TRAINING: 0 };
                } else {
                  deptData.secciones[secName] = { 'SPORTSWEAR (CASUAL)': 0, RUNNING: 0, FUTBOL: 0 };
                }
              } else if (dept === 'TEXTIL') {
                if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                  deptData.secciones[secName] = { RUNNING: 0, TRAINING: 0, 'SPORTSWEAR (CASUAL)': 0 };
                } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                  deptData.secciones[secName] = { TRAINING: 0, RUNNING: 0, 'SPORTSWEAR (CASUAL)': 0, FUTBOL: 0 };
                } else {
                  deptData.secciones[secName] = { 'SPORTSWEAR (CASUAL)': 0, TRAINING: 0, RUNNING: 0 };
                }
              } else {
                if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                  deptData.secciones[secName] = { 'GORRAS / VISERAS': 0, 'BOLSOS / MOCHILAS': 0, 'CALCETINES / MEDIAS': 0 };
                } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                  deptData.secciones[secName] = { 'GORRAS / CAPS': 0, 'MOCHILAS / MALETINES': 0, 'CALCETINES / MEDIAS': 0 };
                } else {
                  deptData.secciones[secName] = { 'MOCHILAS INFANTILES': 0, 'GORRAS INFANTILES': 0, CALCETINES: 0 };
                }
              }
            } else if (dept === 'CALZADO') {
              if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                const r = Math.round(tot * 0.40);
                const c = Math.round(tot * 0.35);
                const t = Math.max(0, tot - r - c);
                deptData.secciones[secName] = {
                  RUNNING: r,
                  'SPORTSWEAR (CASUAL)': c,
                  TRAINING: t,
                };
              } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                const r = Math.round(tot * 0.35);
                const c = Math.round(tot * 0.30);
                const f = Math.round(tot * 0.20);
                const t = Math.max(0, tot - r - c - f);
                deptData.secciones[secName] = {
                  RUNNING: r,
                  'SPORTSWEAR (CASUAL)': c,
                  FUTBOL: f,
                  TRAINING: t,
                };
              } else {
                const c = Math.round(tot * 0.50);
                const r = Math.round(tot * 0.30);
                const f = Math.max(0, tot - c - r);
                deptData.secciones[secName] = {
                  'SPORTSWEAR (CASUAL)': c,
                  RUNNING: r,
                  FUTBOL: f,
                };
              }
            } else if (dept === 'TEXTIL') {
              if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                const r = Math.round(tot * 0.35);
                const tr = Math.round(tot * 0.35);
                const s = Math.max(0, tot - r - tr);
                deptData.secciones[secName] = {
                  RUNNING: r,
                  TRAINING: tr,
                  'SPORTSWEAR (CASUAL)': s,
                };
              } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                const tr = Math.round(tot * 0.30);
                const r = Math.round(tot * 0.30);
                const s = Math.round(tot * 0.25);
                const f = Math.max(0, tot - tr - r - s);
                deptData.secciones[secName] = {
                  TRAINING: tr,
                  RUNNING: r,
                  'SPORTSWEAR (CASUAL)': s,
                  FUTBOL: f,
                };
              } else {
                const s = Math.round(tot * 0.50);
                const tr = Math.round(tot * 0.30);
                const r = Math.max(0, tot - s - tr);
                deptData.secciones[secName] = {
                  'SPORTSWEAR (CASUAL)': s,
                  TRAINING: tr,
                  RUNNING: r,
                };
              }
            } else {
              // ACCESORIOS (DAMA, CABALLERO, NIÑOS)
              if (secName.includes('MUJER') || secName.includes('WOMEN')) {
                const g = Math.round(tot * 0.35);
                const b = Math.round(tot * 0.35);
                const c = Math.max(0, tot - g - b);
                deptData.secciones[secName] = {
                  'GORRAS / VISERAS': g,
                  'BOLSOS / MOCHILAS': b,
                  'CALCETINES / MEDIAS': c,
                };
              } else if (secName.includes('HOMBRE') || secName.includes('CABALLERO') || (secName.includes('MEN') && !secName.includes('WOMEN'))) {
                const g = Math.round(tot * 0.40);
                const m = Math.round(tot * 0.30);
                const c = Math.max(0, tot - g - m);
                deptData.secciones[secName] = {
                  'GORRAS / CAPS': g,
                  'MOCHILAS / MALETINES': m,
                  'CALCETINES / MEDIAS': c,
                };
              } else {
                const m = Math.round(tot * 0.40);
                const g = Math.round(tot * 0.30);
                const c = Math.max(0, tot - m - g);
                deptData.secciones[secName] = {
                  'MOCHILAS INFANTILES': m,
                  'GORRAS INFANTILES': g,
                  'CALCETINES': c,
                };
              }
            }
          }
        }
      }
    }

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const handleToggleDepartmentActive = (dept: string, active: boolean) => {
    const currentDept = currentBrandMatrix[dept] || {
      profundidad_target: 16,
      piezas_exhibicion_sku: dept === 'CALZADO' ? 1 : dept === 'TEXTIL' ? 6 : 4,
      secciones: {},
    };
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentDept,
        activa: active,
      },
    };
    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  // Change SKUs in Global Gender Mode
  const handleGlobalSectionSkusChange = (
    dept: string,
    section: string,
    skus: number
  ) => {
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: {
          ...currentBrandMatrix[dept].secciones,
          [section]: {
            GLOBAL: Math.max(0, skus),
          },
        },
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  // Change SKUs in Category Mode
  const handleFamilySkusChangeForBrand = (
    dept: string,
    section: string,
    family: string,
    skus: number
  ) => {
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: {
          ...currentBrandMatrix[dept].secciones,
          [section]: {
            ...currentBrandMatrix[dept].secciones[section],
            [family]: Math.max(0, skus),
          },
        },
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  // Add custom category to a section
  const handleAddCategoryToSection = (dept: string, section: string, categoryName: string = '') => {
    const cleanCat = (categoryName || '').trim().toUpperCase();
    if (!cleanCat) return;

    const currentSec = currentBrandMatrix[dept]?.secciones?.[section] || {};
    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: {
          ...currentBrandMatrix[dept].secciones,
          [section]: {
            ...currentSec,
            [cleanCat]: 0,
          },
        },
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));

    setNewCategoryInputs((prev) => ({
      ...prev,
      [`${dept}__${section}`]: '',
    }));
    setShowAddCategoryInput((prev) => ({
      ...prev,
      [`${dept}__${section}`]: false,
    }));
  };

  // Remove a category from a section
  const handleRemoveCategoryFromSection = (dept: string, section: string, categoryName: string) => {
    const currentSec = { ...(currentBrandMatrix[dept]?.secciones?.[section] || {}) };
    delete currentSec[categoryName];

    if (Object.keys(currentSec).length === 0) {
      currentSec['GENERAL'] = 0;
    }

    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: {
          ...currentBrandMatrix[dept].secciones,
          [section]: currentSec,
        },
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  // Add a missing gender section to a department
  const handleAddGenderSection = (dept: string, sectionKey: string) => {
    const currentSecs = currentBrandMatrix[dept]?.secciones || {};
    if (currentSecs[sectionKey]) return;

    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: {
          ...currentSecs,
          [sectionKey]: isCategoriesActive
            ? dept === 'CALZADO'
              ? { RUNNING: 0, TRAINING: 0, 'SPORTSWEAR (CASUAL)': 0 }
              : dept === 'TEXTIL'
              ? { TRAINING: 0, RUNNING: 0, 'SPORTSWEAR (CASUAL)': 0 }
              : { 'GORRAS / CAPS': 0, 'MOCHILAS / MALETINES': 0, 'CALCETINES / MEDIAS': 0 }
            : { GLOBAL: 0 },
        },
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const handleRemoveGenderSection = (dept: string, sectionKey: string) => {
    const currentSecs = { ...(currentBrandMatrix[dept]?.secciones || {}) };
    delete currentSecs[sectionKey];

    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: currentSecs,
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const handleSwitchSectionGender = (
    dept: string,
    oldSecName: string,
    targetType: 'MENS' | 'WOMENS' | 'KIDS' | 'UNISEX'
  ) => {
    const targetKeyMap: Record<'MENS' | 'WOMENS' | 'KIDS' | 'UNISEX', string> = {
      MENS: 'HOMBRE (MENS)',
      WOMENS: 'MUJER (WOMENS)',
      KIDS: 'INFANTE / NIÑOS',
      UNISEX: 'UNISEX',
    };
    const targetKey = targetKeyMap[targetType];
    if (oldSecName === targetKey) return;

    const currentSecs = { ...(currentBrandMatrix[dept]?.secciones || {}) };
    const oldData = currentSecs[oldSecName] || {};

    if (currentSecs[targetKey]) {
      const existingData = { ...currentSecs[targetKey] };
      for (const [k, v] of Object.entries(oldData)) {
        existingData[k] = (existingData[k] || 0) + (Number(v) || 0);
      }
      currentSecs[targetKey] = existingData;
    } else {
      currentSecs[targetKey] = oldData;
    }

    delete currentSecs[oldSecName];

    const nextBrandMatrix = {
      ...currentBrandMatrix,
      [dept]: {
        ...currentBrandMatrix[dept],
        secciones: currentSecs,
      },
    };

    setMarcasCapacidad((prev) => ({
      ...prev,
      [activeBrand]: nextBrandMatrix,
    }));
  };

  const getGenderDisplayInfo = (secName: string = '') => {
    const upper = (secName || '').toUpperCase();
    // 1. Dama / Mujer (checked first to prevent 'WOMENS' from matching 'MENS')
    if (upper.includes('MUJER') || upper.includes('WOMEN') || upper.includes('DAMA') || upper.includes('FEMALE')) {
      return {
        type: 'WOMENS' as const,
        title: 'Dama (Mujer)',
        badge: 'Dama',
        icon: '👩',
        border: 'border-pink-200/90',
        bgBadge: 'bg-pink-50 text-pink-800 border-pink-200',
      };
    }
    // 2. Niños / Infantil
    if (upper.includes('INFANTE') || upper.includes('NIÑOS') || upper.includes('NIÑO') || upper.includes('KIDS') || upper.includes('JUNIOR')) {
      return {
        type: 'KIDS' as const,
        title: 'Niños (Infantil)',
        badge: 'Niños',
        icon: '🧒',
        border: 'border-amber-200/90',
        bgBadge: 'bg-amber-50 text-amber-800 border-amber-200',
      };
    }
    // 3. Caballero / Hombre (ensure it doesn't match women)
    if (upper.includes('HOMBRE') || upper.includes('CABALLERO') || (upper.includes('MEN') && !upper.includes('WOMEN'))) {
      return {
        type: 'MENS' as const,
        title: 'Caballero (Hombre)',
        badge: 'Caballero',
        icon: '👨',
        border: 'border-blue-200/90',
        bgBadge: 'bg-blue-50 text-blue-800 border-blue-200',
      };
    }
    return {
      type: 'UNISEX' as const,
      title: secName || 'Unisex / Global',
      badge: 'Unisex',
      icon: '🌐',
      border: 'border-emerald-200/90',
      bgBadge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    };
  };

  const detectGenderType = (secName: string = ''): 'MENS' | 'WOMENS' | 'KIDS' | 'UNISEX' => {
    return getGenderDisplayInfo(secName).type;
  };

  const handleSelectStoreType = (newType: StoreType) => {
    setTipo(newType);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nombre.trim()) {
      setErrorMsg('Por favor ingresa un nombre para la tienda.');
      setActiveStep(1);
      return;
    }

    const targetStore = initialStoreToEdit || storeProfiles.find((p) => p.nombre === selectedStoreToEditName);

    if (
      !targetStore &&
      existingStores.some((s) => s.toLowerCase() === nombre.trim().toLowerCase())
    ) {
      setErrorMsg('Ya existe una tienda con ese nombre. Utiliza un nombre único.');
      setActiveStep(1);
      return;
    }

    const consolidated = consolidarMatrizMarcas(marcasCapacidad);
    const totals = calcularTotalesMatriz(consolidated);

    const storeProfile: StoreProfile = {
      id: targetStore ? targetStore.id : `store-${Date.now()}`,
      nombre: nombre.trim(),
      ciudad: ciudad.trim() || 'Ciudad Principal',
      region: region.trim() || undefined,
      direccion: direccion.trim() || 'Centro Comercial',
      centroComercial: centroComercial.trim() || undefined,
      lat,
      lng,
      placeId,
      formattedAddress,
      superficieM2: Number(superficieM2) || 500,
      tipo,
      marcasCapacidad,
      capacidadPersonalizada: consolidated,
      profundidadMediaTienda: totals.avgDepth,
      totalSkusFisicos: totals.totalSkus,
      totalPiezasFisicas: totals.totalPieces,
      fechaRegistro: targetStore?.fechaRegistro || new Date().toISOString().split('T')[0],
    };

    // Recalculate distances for all stores if coordinates exist
    const finalDistances = { ...distances };
    if (typeof lat === 'number' && typeof lng === 'number' && (storeProfiles || []).length > 0) {
      (storeProfiles || []).forEach((other) => {
        if (other && other.nombre !== nombre.trim() && typeof other.lat === 'number' && typeof other.lng === 'number') {
          finalDistances[other.nombre] = calculateGeoDistanceKm(lat, lng, other.lat, other.lng);
        }
      });
    }

    onRegisterStore(storeProfile, consolidated, finalDistances, seedStock);
    onClose();
  };

  const handleDelete = () => {
    if (!initialStoreToEdit || !onDeleteStore) return;
    onDeleteStore(initialStoreToEdit.nombre);
    onClose();
  };

  const commonBrandSuggestions = [
    'ASICS',
    'CONVERSE',
    'NEW BALANCE',
    'SKECHERS',
    'HEAD',
    'ON RUNNING',
    'UNDER ARMOUR',
    'HOKA',
    'KELME',
    'NIKE',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-zinc-950/60 backdrop-blur-sm animate-fadeIn select-none">
      {/* Precision Industrial Tactical Container (Expanded Width & Information Density) */}
      <div className="bg-[#FBF8FF] text-zinc-900 border border-zinc-300/80 rounded-3xl shadow-[0_24px_50px_rgba(0,0,0,0.18)] w-full max-w-[97vw] xl:max-w-[1540px] 2xl:max-w-[1680px] h-[94vh] flex flex-col overflow-hidden">
        
        {/* TOP INDUSTRIAL HEADER BAR */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-white border-b border-zinc-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F4F2FD] border border-zinc-200/90 shadow-[inset_0_1.5px_2px_rgba(0,0,0,0.04)] flex items-center justify-center text-zinc-900 font-mono font-bold">
              <Store className="w-5 h-5 text-zinc-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-mono font-bold tracking-tight text-zinc-900">
                  {isEditing ? `CONFIGURACIÓN TIENDA: ${initialStoreToEdit?.nombre}` : 'REGISTRAR NUEVA TIENDA & MATRIZ DE CAPACIDAD'}
                </h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-200">
                  PASO {activeStep}/3
                </span>
                <span className="hidden sm:inline-block text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  {STORE_FORMAT_INFO[tipo]?.name || tipo}
                </span>
              </div>
              <p className="text-xs text-zinc-500 font-mono mt-0.5">
                Dimensionamiento de planta, visual merchandising y frentes físicos por marca
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isEditing && onDeleteStore && !showDeleteConfirm && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                title="Eliminar esta tienda de la red"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Eliminar</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700 flex items-center justify-center border border-zinc-200/80 transition-colors cursor-pointer"
              title="Cerrar ventana"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Delete Confirmation Alert if triggered */}
        {showDeleteConfirm && (
          <div className="p-3 bg-rose-50 border-b border-rose-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-mono">
            <div className="flex items-center gap-2 text-rose-800">
              <Trash2 className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>
                ¿Confirmas la eliminación permanente de la tienda <strong>"{initialStoreToEdit?.nombre}"</strong> y sus matrices?
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="px-3 py-1 bg-white hover:bg-zinc-100 text-zinc-700 border border-zinc-300 rounded-md font-semibold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDelete}
                className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-md font-bold shadow-sm cursor-pointer"
              >
                Confirmar Eliminación
              </button>
            </div>
          </div>
        )}

        {/* RECESSED STEPPER BAR */}
        <div className="bg-[#F4F2FD] border-b border-zinc-200 px-6 py-2 flex items-center justify-between shadow-[inset_0_1.5px_3px_rgba(0,0,0,0.025)]">
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              onClick={() => setActiveStep(1)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2 cursor-pointer ${
                activeStep === 1
                  ? 'bg-white font-bold text-zinc-900 border border-zinc-300 shadow-[0_1px_2px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)]'
                  : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/50 font-medium'
              }`}
            >
              <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${activeStep === 1 ? 'bg-zinc-900 text-white' : 'bg-zinc-300 text-zinc-700'}`}>1</span>
              <span>Ficha Comercial & Formato</span>
            </button>

            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />

            <button
              type="button"
              onClick={() => setActiveStep(2)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2 cursor-pointer ${
                activeStep === 2
                  ? 'bg-white font-bold text-zinc-900 border border-zinc-300 shadow-[0_1px_2px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)]'
                  : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/50 font-medium'
              }`}
            >
              <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${activeStep === 2 ? 'bg-zinc-900 text-white' : 'bg-zinc-300 text-zinc-700'}`}>2</span>
              <span>Marcas & Matriz de Capacidad</span>
            </button>

            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />

            <button
              type="button"
              onClick={() => setActiveStep(3)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2 cursor-pointer ${
                activeStep === 3
                  ? 'bg-white font-bold text-zinc-900 border border-zinc-300 shadow-[0_1px_2px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)]'
                  : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/50 font-medium'
              }`}
            >
              <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${activeStep === 3 ? 'bg-zinc-900 text-white' : 'bg-zinc-300 text-zinc-700'}`}>3</span>
              <span>Resumen Consolidado & Logística</span>
            </button>
          </div>

          <div className="hidden md:flex items-center gap-3 text-xs font-mono text-zinc-500">
            <span>Red: <strong className="text-zinc-800">{existingStores.length} tiendas</strong></span>
            <span>•</span>
            <span>Capacidad Total: <strong className="text-emerald-700 font-bold">{storeConsolidatedMetrics.totalPieces.toLocaleString()} uds</strong></span>
          </div>
        </div>

        {/* MAIN BODY: SPLIT WORKBENCH + LIVE INDUSTRIAL TELEMETRY SIDEBAR */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          
          {/* LEFT/CENTER: ACTIVE STEP CONFIGURATION (Col 1 to 8 on lg) */}
          <div className="lg:col-span-8 p-5 sm:p-6 overflow-y-auto custom-scrollbar border-r border-zinc-200 bg-[#FBF8FF] space-y-5">
            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs font-mono flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                <span>{errorMsg}</span>
              </div>
            )}

            {/* STEP 1: FICHA COMERCIAL & FORMATO */}
            {activeStep === 1 && (
              <div className="space-y-5 animate-fadeIn">
                {/* SELECTOR RÁPIDO: ASIGNAR A TIENDA EXISTENTE O CREAR NUEVA */}
                <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-700 shrink-0 font-bold text-xs">
                      🏬
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase font-bold tracking-wider text-zinc-500 block">
                        Modo de Operación de Tienda
                      </span>
                      <span className="text-xs font-bold text-zinc-900">
                        {selectedStoreToEditName
                          ? `Asignando ubicación a: ${selectedStoreToEditName}`
                          : 'Registrando Nueva Tienda'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-zinc-500 hidden sm:inline">
                      Tienda:
                    </span>
                    <select
                      value={selectedStoreToEditName}
                      onChange={(e) => handleSwitchStore(e.target.value)}
                      className="h-8.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs font-semibold px-3 text-zinc-800 focus:outline-none focus:border-zinc-500 cursor-pointer shadow-xs"
                      title="Selecciona una tienda para asignarle ubicación en el mapa o crea una nueva"
                    >
                      <option value="">➕ Registrar Nueva Tienda</option>
                      {storeProfiles.map((p) => (
                        <option key={p.id || p.nombre} value={p.nombre}>
                          🏬 Asignar a {p.nombre} ({p.ciudad}) {p.lat && p.lng ? '✅' : '⚠️ Sin GPS'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* GOOGLE MAPS STORE LOCATOR & AUTO-DETECTION WIDGET (OPEN BY DEFAULT) */}
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-emerald-700" />
                      <span className="text-xs font-mono uppercase font-bold tracking-wider text-zinc-900">
                        Geolocalización & Detección Integrada (Google Maps)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowMapsLocator((prev) => !prev)}
                      className="text-[11px] font-mono text-zinc-600 hover:text-zinc-900 underline cursor-pointer"
                    >
                      {showMapsLocator ? 'Ocultar Mapa' : 'Mostrar Mapa'}
                    </button>
                  </div>

                  {showMapsLocator && (
                    <GoogleMapsStoreLocator
                      onApplyLocation={handleApplyLocationFromMap}
                      onLocationSelected={handleApplyLocationFromMap}
                      initialRegion={region}
                      initialLocation={
                        typeof lat === 'number' && typeof lng === 'number'
                          ? {
                              lat,
                              lng,
                              ciudad,
                              region,
                              direccion,
                              centroComercial,
                              formattedAddress,
                              placeId,
                            }
                          : undefined
                      }
                      existingStores={storeProfiles}
                      selectedStoreName={selectedStoreToEditName}
                      onSelectStoreToGeolocate={handleSwitchStore}
                    />
                  )}

                  {/* Status badge when location is mapped */}
                  {typeof lat === 'number' && typeof lng === 'number' ? (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                      <div className="flex items-center gap-2 text-emerald-900">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span className="font-bold">Ubicación Asignada en Google Maps:</span>
                        <span className="text-emerald-700 font-semibold">
                          {centroComercial ? `Mall: ${centroComercial}` : formattedAddress || direccion}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-emerald-100/90 text-emerald-800 rounded font-mono text-[11px] font-bold">
                          GPS: {lat.toFixed(5)}, {lng.toFixed(5)}
                        </span>
                        <span className="text-[10px] text-emerald-600 font-medium">
                          ({ciudad})
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2 text-xs text-amber-900 font-mono">
                      <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                      <span>Busca un centro comercial o dirección en el mapa para auto-asignar ciudad, coordenadas y flete.</span>
                    </div>
                  )}
                </div>

                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                    <span className="text-xs font-mono uppercase font-bold tracking-wider text-zinc-700">
                      1. Identificación y Dimensionamiento Físico
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400">Datos Principales</span>
                  </div>

                  {/* Nombre de la tienda con sugerencia de Maps */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-mono font-bold uppercase text-zinc-700">
                        Nombre Oficial de la Tienda *
                      </label>
                      {centroComercial && nombre !== centroComercial && (
                        <button
                          type="button"
                          onClick={() => setNombre(`Tienda ${centroComercial}`)}
                          className="text-[10px] text-purple-700 hover:text-purple-900 font-semibold underline cursor-pointer"
                        >
                          ✨ Usar: "Tienda {centroComercial}"
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Store className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        required
                        placeholder="Ej. Tienda Mall Costanera, Tienda Centro..."
                        value={nombre}
                        onChange={(e) => {
                          setNombre(e.target.value);
                          setErrorMsg(null);
                        }}
                        className="w-full bg-[#F4F2FD] border border-zinc-300/80 rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-zinc-900 placeholder-zinc-400 focus:outline-none focus:bg-white focus:border-zinc-500 shadow-[inset_0_1.5px_2.5px_rgba(0,0,0,0.04)]"
                      />
                    </div>
                  </div>

                  {/* Ficha de Ubicación Extraída Automáticamente por Google Maps */}
                  <div className="bg-zinc-50/80 rounded-xl p-3.5 border border-zinc-200 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase text-zinc-500 tracking-wider">
                        Datos de Localización Integrados (Google Maps)
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowManualAddressEdit((prev) => !prev)}
                        className="text-[10px] text-zinc-600 hover:text-zinc-900 underline font-medium cursor-pointer"
                      >
                        {showManualAddressEdit ? 'Cerrar edición manual' : '✏️ Ajustar texto manualmente (opcional)'}
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
                      <div className="bg-white p-2.5 rounded-lg border border-zinc-200">
                        <span className="text-[10px] text-zinc-500 font-semibold block">Ciudad Oficial</span>
                        <span className="font-bold text-zinc-900 font-mono truncate block">
                          {ciudad || 'Detectada en el mapa'}
                        </span>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-zinc-200">
                        <span className="text-[10px] text-zinc-500 font-semibold block">Región / Estado</span>
                        <span className="font-bold text-zinc-900 font-mono truncate block">
                          {region || ciudad || 'Detectada en el mapa'}
                        </span>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-zinc-200">
                        <span className="text-[10px] text-zinc-500 font-semibold block">Centro Comercial / Mall</span>
                        <span className="font-bold text-zinc-900 truncate block">
                          {centroComercial || 'A pie de calle / Independiente'}
                        </span>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-zinc-200">
                        <span className="text-[10px] text-zinc-500 font-semibold block">Coordenadas GPS</span>
                        <span className="font-bold text-emerald-800 font-mono text-[11px] truncate block">
                          {typeof lat === 'number' && typeof lng === 'number'
                            ? `${lat.toFixed(4)}°, ${lng.toFixed(4)}°`
                            : 'Auto-detectadas'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-white p-2.5 rounded-lg border border-zinc-200 text-xs">
                      <span className="text-[10px] text-zinc-500 font-semibold block">Dirección Normalizada (Google Maps)</span>
                      <span className="text-zinc-800 leading-relaxed font-medium">
                        {direccion || formattedAddress || 'Ubicada directamente en Google Maps'}
                      </span>
                    </div>

                    {/* Optional Fine-tuning form for manual adjustments if user specifically needs to add suite/floor */}
                    {showManualAddressEdit && (
                      <div className="pt-2 border-t border-zinc-200 space-y-2.5 animate-fadeIn">
                        <p className="text-[10px] text-zinc-500">
                          Estos campos se rellenan automáticamente desde Google Maps. Solo edítalos si requieres agregar el número de local o piso:
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                          <div>
                            <label className="text-[10px] font-bold text-zinc-600 block mb-0.5">Ciudad</label>
                            <input
                              type="text"
                              value={ciudad}
                              onChange={(e) => setCiudad(e.target.value)}
                              className="w-full bg-white border border-zinc-300 rounded-lg px-2 py-1 text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-zinc-600 block mb-0.5">Región / Estado</label>
                            <input
                              type="text"
                              value={region}
                              onChange={(e) => setRegion(e.target.value)}
                              className="w-full bg-white border border-zinc-300 rounded-lg px-2 py-1 text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-zinc-600 block mb-0.5">Mall / C.C.</label>
                            <input
                              type="text"
                              value={centroComercial}
                              onChange={(e) => setCentroComercial(e.target.value)}
                              className="w-full bg-white border border-zinc-300 rounded-lg px-2 py-1 text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-zinc-600 block mb-0.5">Dirección / Local</label>
                            <input
                              type="text"
                              value={direccion}
                              onChange={(e) => setDireccion(e.target.value)}
                              className="w-full bg-white border border-zinc-300 rounded-lg px-2 py-1 text-xs font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Superficie */}
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase text-zinc-700 mb-1">
                      Superficie de Ventas (m²) *
                    </label>
                    <div className="relative">
                      <Ruler className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
                      <input
                        type="number"
                        min={30}
                        max={10000}
                        value={superficieM2 === 0 ? '' : superficieM2}
                        placeholder="350"
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => {
                          const raw = e.target.value;
                          const val = raw === '' ? 0 : parseInt(raw, 10);
                          setSuperficieM2(isNaN(val) ? 0 : Math.max(0, val));
                        }}
                        className="w-full bg-[#F4F2FD] border border-zinc-300/80 rounded-xl pl-9 pr-4 py-2 text-xs font-mono font-bold text-zinc-900 focus:outline-none focus:bg-white focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400 placeholder:text-zinc-400 shadow-[inset_0_1.5px_2.5px_rgba(0,0,0,0.04)] transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Formatos de Tienda Táctiles */}
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-3">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                    <span className="text-xs font-mono uppercase font-bold tracking-wider text-zinc-700">
                      2. Formato Comercial & Estándar de Densidad
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400">Selecciona el perfil operativo</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(['FLAGSHIP', 'LIVE', 'UNITE', 'EXPRESS'] as StoreType[]).map((fmtKey) => {
                      const info = STORE_FORMAT_INFO[fmtKey];
                      const isSelected = tipo === fmtKey;

                      return (
                        <div
                          key={fmtKey}
                          onClick={() => handleSelectStoreType(fmtKey)}
                          className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                            isSelected
                              ? 'bg-zinc-900 text-white border-zinc-900 shadow-md shadow-zinc-950/20'
                              : 'bg-[#FBF8FF] border-zinc-200/90 text-zinc-800 hover:bg-white hover:border-zinc-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-mono font-bold flex items-center gap-1.5">
                              {fmtKey === 'FLAGSHIP' && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                              {fmtKey === 'LIVE' && <Building2 className="w-3.5 h-3.5 text-blue-400" />}
                              {fmtKey === 'UNITE' && <Package className="w-3.5 h-3.5 text-purple-400" />}
                              {fmtKey === 'EXPRESS' && <Sliders className="w-3.5 h-3.5 text-sky-400" />}
                              <span>{info.name}</span>
                            </span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                          <p className={`text-[11px] leading-relaxed ${isSelected ? 'text-zinc-300' : 'text-zinc-500'}`}>
                            {info.description}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: MARCAS & MATRIZ DE CAPACIDAD CON BOTÓN DE ACTIVACIÓN DE CATEGORÍAS */}
            {activeStep === 2 && (
              <div className="space-y-4 animate-fadeIn">
                {/* Brand Navigator & Manager */}
                <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <span className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-800 flex items-center gap-2">
                        <Tag className="w-3.5 h-3.5 text-zinc-700" />
                        Marcas Asignadas ({Object.keys(marcasCapacidad).length})
                      </span>
                      <p className="text-[11px] text-zinc-500 font-mono mt-0.5">
                        Define la capacidad física para tiendas monomarca o multimarca independiente
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {!showAddBrandInput ? (
                        <button
                          type="button"
                          onClick={() => setShowAddBrandInput(true)}
                          className="h-8 px-3 tactile-button-light rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Agregar Marca</span>
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5 animate-fadeIn">
                          <input
                            type="text"
                            placeholder="Marca..."
                            value={newBrandInput}
                            onChange={(e) => setNewBrandInput(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleAddBrand();
                              }
                            }}
                            className="w-32 h-8 bg-[#F4F2FD] border border-zinc-300 rounded-lg px-2 text-xs font-mono uppercase text-zinc-900 focus:outline-none focus:bg-white"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleAddBrand()}
                            className="h-8 px-3 tactile-button-dark rounded-lg text-xs font-mono font-semibold cursor-pointer"
                          >
                            Añadir
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setShowAddBrandInput(false);
                              setNewBrandInput('');
                            }}
                            className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-zinc-800 hover:bg-zinc-100 rounded-lg cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Brand Selector Keys */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-100">
                    {Object.keys(marcasCapacidad).map((bKey) => {
                      const isBActive = activeBrand === bKey;
                      const bTotals = calcularTotalesMatriz(marcasCapacidad[bKey]);

                      return (
                        <div
                          key={bKey}
                          onClick={() => setActiveBrand(bKey)}
                          className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold cursor-pointer flex items-center gap-2 transition-all select-none ${
                            isBActive
                              ? 'bg-zinc-900 text-white border-zinc-900 shadow-sm'
                              : 'bg-[#F4F2FD] text-zinc-700 border-zinc-200/90 hover:bg-white hover:border-zinc-300'
                          }`}
                        >
                          <span>🏷️ {bKey}</span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded ${
                              isBActive ? 'bg-zinc-800 text-zinc-200' : 'bg-white text-zinc-500 border border-zinc-200'
                            }`}
                          >
                            {bTotals.totalSkus} SKUs • {bTotals.totalPieces.toLocaleString()} uds
                          </span>

                          {Object.keys(marcasCapacidad).length > 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemoveBrand(bKey);
                              }}
                              className="p-0.5 rounded opacity-60 hover:opacity-100 hover:bg-rose-500 hover:text-white"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      );
                    })}

                    {commonBrandSuggestions.some((b) => !marcasCapacidad[b]) && (
                      <div className="flex flex-wrap items-center gap-1.5 pl-2">
                        <span className="text-[10px] text-zinc-400 font-mono">Sugerencias:</span>
                        {commonBrandSuggestions
                          .filter((b) => !marcasCapacidad[b])
                          .map((s) => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => handleAddBrand(s)}
                              className="h-6 px-2 text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 rounded-md border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer whitespace-nowrap"
                              title={`Agregar marca ${s}`}
                            >
                              +{s}
                            </button>
                          ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* BOTÓN INDUSTRIAL DE ACTIVACIÓN DE CATEGORÍAS & MODO GLOBAL */}
                <div className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-3">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-zinc-900 text-white flex items-center justify-center font-mono font-bold text-sm">
                        {activeBrand.substring(0, 2)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-bold uppercase text-zinc-900">
                            Marca Activa: {activeBrand}
                          </span>
                          <IndustrialBadge
                            status={isCategoriesActive ? 'active' : 'optimal'}
                            label={isCategoriesActive ? 'Desglose Deportivo' : 'Capacidad Global'}
                            size="sm"
                          />
                        </div>
                        <p className="text-[11px] font-mono text-zinc-500 mt-0.5">
                          Total: <strong className="text-zinc-900">{activeBrandMetrics.totalSkus} SKUs</strong> • <strong className="text-emerald-700">{activeBrandMetrics.totalPieces.toLocaleString()} piezas</strong> • <strong className="text-zinc-700">{activeBrandMetrics.avgDepth} uds/SKU</strong>
                        </p>
                      </div>
                    </div>

                    {/* Dual Industrial Selector: Global vs Categorías */}
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="bg-[#F4F2FD] p-1 rounded-xl border border-zinc-200/90 flex items-center gap-1 shadow-[inset_0_1px_2px_rgba(0,0,0,0.03)]">
                        <button
                          type="button"
                          onClick={() => handleToggleBrandCategories(false)}
                          className={`h-8 px-3.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            !isCategoriesActive
                              ? 'bg-white text-zinc-900 border border-zinc-300/90 shadow-[0_1px_2px_rgba(0,0,0,0.05),inset_0_1px_0_rgba(255,255,255,0.9)]'
                              : 'text-zinc-600 hover:text-zinc-900 hover:bg-white/60 border border-transparent'
                          }`}
                          title="Cargar capacidad global por sección y género directamente"
                        >
                          <Globe className="w-3.5 h-3.5 text-zinc-700" />
                          <span>Capacidad Global por Género</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleToggleBrandCategories(true)}
                          className={`h-8 px-3.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                            isCategoriesActive
                              ? 'bg-zinc-900 text-white border border-zinc-900 shadow-sm'
                              : 'text-zinc-600 hover:text-zinc-900 hover:bg-white/60 border border-transparent'
                          }`}
                          title="Activar categorías como Running, Training, Sportswear (casual), Fútbol, etc."
                        >
                          <Tag className="w-3.5 h-3.5" />
                          <span>Activar Categorías (Running, Fútbol...)</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Informative description banner */}
                  <div className="text-[11px] font-mono text-zinc-600 bg-[#F4F2FD] p-2.5 rounded-xl border border-zinc-200 flex items-start gap-2">
                    <Info className="w-4 h-4 text-zinc-700 shrink-0 mt-0.5" />
                    <div>
                      {!isCategoriesActive ? (
                        <p>
                          <strong className="text-zinc-900 font-bold">Modo Capacidad Global por Género Activo:</strong> Carga la capacidad de frentes y SKUs directamente por sección (Calzado, Textil, Accesorios) y género (Caballero, Dama, Niños) para marcas comerciales que no requieren desglose deportivo. Si deseas desglosarla en Running, Training, Sportswear o Fútbol, pulsa el botón superior.
                        </p>
                      ) : (
                        <p>
                          <strong className="text-zinc-900 font-bold">Modo Desglose por Categorías Activo:</strong> Puedes asignar frentes y piezas a disciplinas especializadas (Running, Training, Sportswear / Casual, Fútbol, Baloncesto, etc.) para cada género y sección.
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* DEPARTMENT WORKBENCH (Calzado, Textil, Accesorios) */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {(Object.entries(currentBrandMatrix) as [string, DepartmentCapacity][]).map(
                    ([dept, deptData]) => {
                      const isDeptActive = deptData.activa !== false;
                      let deptSkus = 0;
                      if (isDeptActive) {
                        Object.values(deptData.secciones || {}).forEach((sec) => {
                          Object.values(sec || {}).forEach((fSkus: number) => {
                            deptSkus += fSkus || 0;
                          });
                        });
                      }
                      const deptPieces = isDeptActive ? deptSkus * (deptData.profundidad_target || 1) : 0;
                      const defaultExhibicion = dept === 'CALZADO' ? 1 : dept === 'TEXTIL' ? 6 : 4;
                      const piezasExhibicion = deptData.piezas_exhibicion_sku ?? defaultExhibicion;
                      const deptExhibicionPieces = isDeptActive ? deptSkus * piezasExhibicion : 0;

                      const categorySuggestions =
                        dept === 'CALZADO'
                          ? ['RUNNING', 'TRAINING', 'SPORTSWEAR (CASUAL)', 'FUTBOL', 'BASKETBALL', 'TENIS / PADEL']
                          : dept === 'TEXTIL'
                          ? ['TRAINING', 'RUNNING', 'SPORTSWEAR (CASUAL)', 'FUTBOL', 'OUTDOOR']
                          : ['GORRAS / CAPS', 'MOCHILAS / MALETINES', 'CALCETINES / MEDIAS', 'BALONES / EQUIPO'];

                      return (
                        <div
                          key={dept}
                          className={`bg-white rounded-2xl border transition-all overflow-hidden flex flex-col shadow-[0_1px_3px_rgba(0,0,0,0.02)] ${
                            !isDeptActive ? 'border-zinc-200/70 opacity-90' : 'border-zinc-200'
                          }`}
                        >
                          {/* Header of Department */}
                          <div className={`p-3 border-b border-zinc-200 space-y-2 transition-colors ${!isDeptActive ? 'bg-zinc-100/75' : 'bg-[#F4F2FD]'}`}>
                            {/* Row 1: Department Title & Active State Toggle */}
                            <div className="flex items-center justify-between gap-2 h-7">
                              <span className={`font-mono font-bold text-xs flex items-center gap-1.5 min-w-0 ${!isDeptActive ? 'text-zinc-500' : 'text-zinc-900'}`}>
                                <span className={`w-2 h-2 rounded-full shrink-0 ${!isDeptActive ? 'bg-zinc-400' : 'bg-zinc-900'}`}></span>
                                <span className={`truncate ${!isDeptActive ? 'line-through text-zinc-400' : ''}`}>{dept}</span>
                                {!isDeptActive && (
                                  <span className="text-[10px] font-sans font-semibold px-1.5 py-0.5 bg-zinc-200 text-zinc-600 rounded shrink-0">
                                    Omitida
                                  </span>
                                )}
                              </span>

                              <button
                                type="button"
                                onClick={() => handleToggleDepartmentActive(dept, !isDeptActive)}
                                className={`h-7 flex items-center gap-1.5 px-2.5 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer shadow-xs shrink-0 whitespace-nowrap ${
                                  isDeptActive
                                    ? 'bg-white text-zinc-700 border-zinc-300 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-300'
                                    : 'bg-zinc-900 text-white border-zinc-900 hover:bg-zinc-800'
                                }`}
                                title={isDeptActive ? `Omitir tarjeta de ${dept}` : `Activar tarjeta de ${dept}`}
                              >
                                {isDeptActive ? (
                                  <>
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                    <span>Activa</span>
                                  </>
                                ) : (
                                  <>
                                    <Plus className="w-3 h-3" />
                                    <span>Habilitar</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Row 2: Totals Banner */}
                            {isDeptActive && (
                              <div className="flex items-center justify-between px-2.5 py-1 rounded-lg bg-white border border-zinc-200 text-xs font-mono shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)]">
                                <span className="text-[10px] text-zinc-500">Capacidad Total:</span>
                                <span className="text-[10px] font-mono font-bold text-zinc-900 whitespace-nowrap">
                                  {deptSkus} SKUs • <strong className="text-emerald-700">{deptPieces.toLocaleString()} uds</strong>
                                </span>
                              </div>
                            )}
                          </div>

                          {!isDeptActive ? (
                            <div className="p-6 bg-zinc-50/50 flex-1 flex flex-col items-center justify-center text-center space-y-2 min-h-[220px]">
                              <div className="w-10 h-10 rounded-xl bg-zinc-200/60 flex items-center justify-center text-zinc-400">
                                <EyeOff className="w-5 h-5" />
                              </div>
                              <h5 className="text-xs font-mono font-bold text-zinc-700 uppercase">
                                Sección {dept} Omitida
                              </h5>
                              <p className="text-[11px] text-zinc-500 font-sans max-w-xs leading-relaxed">
                                Esta tienda no cuenta con {dept.toLowerCase()} para la marca <strong className="text-zinc-700">{activeBrand}</strong>. Se omite de la capacidad total.
                              </p>
                              <button
                                type="button"
                                onClick={() => handleToggleDepartmentActive(dept, true)}
                                className="h-8 px-3.5 tactile-button-dark rounded-xl text-xs font-mono font-semibold flex items-center gap-1.5 cursor-pointer mt-1"
                              >
                                <Plus className="w-3.5 h-3.5" />
                                <span>Habilitar {dept}</span>
                              </button>
                            </div>
                          ) : (
                            <>
                              {/* Depth and Floor Standards */}
                              <div className="px-3 py-2 bg-white border-b border-zinc-100 flex items-center justify-between text-xs font-mono">
                                <span className="text-[11px] text-zinc-600 font-medium">Profundidad Total:</span>
                                <div className="flex items-center gap-1">
                                  <input
                                    type="number"
                                    min={1}
                                    max={60}
                                    value={deptData.profundidad_target === 0 ? '' : deptData.profundidad_target}
                                    placeholder="1"
                                    onFocus={(e) => e.target.select()}
                                    onChange={(e) => {
                                      const raw = e.target.value;
                                      const val = raw === '' ? 0 : parseInt(raw, 10);
                                      handleDepthChangeForBrand(dept, isNaN(val) ? 0 : Math.max(0, val));
                                    }}
                                    className="w-12 bg-[#F4F2FD] border border-zinc-300 rounded px-1 text-center font-mono font-bold text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400 placeholder:text-zinc-400 transition-all shadow-xs"
                                  />
                                  <span className="text-[10px] text-zinc-400">uds/SKU</span>
                                </div>
                              </div>

                              <div className="px-3 py-2 bg-white border-b border-zinc-100 space-y-1.5 text-xs font-mono">
                                <div className="flex items-center justify-between">
                                  <span className="text-[11px] font-bold text-zinc-700 flex items-center gap-1">
                                    <Package className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                                    <span>Exhibición en Piso (VM):</span>
                                  </span>
                                  <span className="text-[10px] font-mono font-bold text-emerald-700">
                                    {(deptSkus * piezasExhibicion).toLocaleString()} uds
                                  </span>
                                </div>
                                {/* Selectores de exhibición simétricos y uniformes sin desbordamiento */}
                                <div className="grid grid-cols-4 gap-1 w-full">
                                  {dept === 'CALZADO' ? (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() => handleExhibitionPiecesChangeForBrand(dept, 1)}
                                        className={`col-span-2 h-7 px-1.5 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer flex items-center justify-center gap-1 whitespace-nowrap overflow-hidden ${
                                          piezasExhibicion === 1
                                            ? 'bg-zinc-900 text-white border-zinc-900 shadow-xs'
                                            : 'bg-white text-zinc-700 border-zinc-300 hover:bg-[#F4F2FD] hover:border-zinc-400'
                                        }`}
                                        title="1 pieza en pared de exhibición"
                                      >
                                        <span>1 pza</span>
                                        <span className="text-[9px] opacity-75 font-normal truncate">(Pared)</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleExhibitionPiecesChangeForBrand(dept, 2)}
                                        className={`col-span-2 h-7 px-1.5 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer flex items-center justify-center gap-1 whitespace-nowrap overflow-hidden ${
                                          piezasExhibicion === 2
                                            ? 'bg-zinc-900 text-white border-zinc-900 shadow-xs'
                                            : 'bg-white text-zinc-700 border-zinc-300 hover:bg-[#F4F2FD] hover:border-zinc-400'
                                        }`}
                                        title="2 piezas (par completo) en piso"
                                      >
                                        <span>2 pzas</span>
                                        <span className="text-[9px] opacity-75 font-normal truncate">(Par)</span>
                                      </button>
                                    </>
                                  ) : (
                                    [4, 6, 8, 12].map((n) => (
                                      <button
                                        key={n}
                                        type="button"
                                        onClick={() => handleExhibitionPiecesChangeForBrand(dept, n)}
                                        className={`col-span-1 h-7 px-1 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer flex items-center justify-center whitespace-nowrap overflow-hidden text-center ${
                                          piezasExhibicion === n
                                            ? 'bg-zinc-900 text-white border-zinc-900 shadow-xs'
                                            : 'bg-white text-zinc-700 border-zinc-300 hover:bg-[#F4F2FD] hover:border-zinc-400'
                                        }`}
                                        title={`${n} piezas en exhibición`}
                                      >
                                        <span>{n} pzas</span>
                                      </button>
                                    ))
                                  )}
                                </div>
                              </div>

                          {/* SECTIONS: GLOBAL GENDER MODE vs DETAILED CATEGORIES MODE */}
                          <div className="p-3 space-y-3 flex-1 min-h-[260px]">
                            {!isCategoriesActive ? (
                              /* --- MODE 1: CAPACIDAD GLOBAL POR GÉNERO Y SECCIÓN --- */
                              <div className="space-y-2.5">
                                {Object.entries(deptData.secciones || {}).map(([secName, secData]) => {
                                  const genderInfo = getGenderDisplayInfo(secName);
                                  const totalGenderSkus = Object.values(secData || {}).reduce(
                                    (a, b) => a + (b || 0),
                                    0
                                  );
                                  const totalGenderPieces = totalGenderSkus * (deptData.profundidad_target || 1);
                                  const totalGenderFloorPieces = totalGenderSkus * piezasExhibicion;

                                  return (
                                    <div
                                      key={secName}
                                      className={`p-3 rounded-xl border bg-[#FBF8FF] ${genderInfo.border} space-y-2`}
                                    >
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-1.5">
                                          <span className="text-sm select-none">{genderInfo.icon}</span>
                                          <span className="text-xs font-mono font-bold text-zinc-800">
                                            {genderInfo.title}
                                          </span>
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                          <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full border ${genderInfo.bgBadge}`}>
                                            {genderInfo.badge}
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => handleRemoveGenderSection(dept, secName)}
                                            className="text-zinc-400 hover:text-rose-600 transition-colors p-0.5 cursor-pointer"
                                            title={`Retirar tarjeta de ${genderInfo.title}`}
                                          >
                                            <Trash2 className="w-3.5 h-3.5" />
                                          </button>
                                        </div>
                                      </div>

                                      {/* SKU Input */}
                                      <div className="flex items-center justify-between pt-1 border-t border-zinc-200/80">
                                        <span className="text-[11px] font-mono text-zinc-600">
                                          Capacidad Frentes / SKUs:
                                        </span>
                                        <div className="flex items-center gap-1.5">
                                          <input
                                            type="number"
                                            min={0}
                                            max={900}
                                            value={totalGenderSkus === 0 ? '' : totalGenderSkus}
                                            placeholder="0"
                                            onFocus={(e) => e.target.select()}
                                            onChange={(e) => {
                                              const raw = e.target.value;
                                              const val = raw === '' ? 0 : parseInt(raw, 10);
                                              handleGlobalSectionSkusChange(
                                                dept,
                                                secName,
                                                isNaN(val) ? 0 : Math.max(0, val)
                                              );
                                            }}
                                            className="w-16 bg-[#F4F2FD] border border-zinc-300 rounded-lg px-2 py-1 text-right font-mono font-bold text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400 placeholder:text-zinc-400 transition-all shadow-xs"
                                          />
                                          <span className="text-xs font-mono text-zinc-500">SKUs</span>
                                        </div>
                                      </div>

                                      <div className="flex items-center justify-between text-[10px] font-mono text-zinc-600 bg-white px-2 py-1 rounded border border-zinc-200">
                                        <span>Total: <strong className="text-emerald-700 font-bold">{totalGenderPieces.toLocaleString()} uds</strong></span>
                                        <span>Exhibición: <strong className="text-zinc-800 font-bold">{totalGenderFloorPieces.toLocaleString()} uds</strong></span>
                                      </div>
                                    </div>
                                  );
                                })}

                                {/* Add Missing Gender Button */}
                                {(() => {
                                  const existingTypes = Object.keys(deptData.secciones || {}).map(detectGenderType);
                                  const hasMens = existingTypes.includes('MENS');
                                  const hasWomens = existingTypes.includes('WOMENS');
                                  const hasKids = existingTypes.includes('KIDS');
                                  const hasUnisex = existingTypes.includes('UNISEX');

                                  return (
                                    <div className="pt-2 border-t border-zinc-100 flex items-center gap-1.5 flex-wrap">
                                      {!hasMens && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'HOMBRE (MENS)')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Caballero
                                        </button>
                                      )}
                                      {!hasWomens && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'MUJER (WOMENS)')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Dama
                                        </button>
                                      )}
                                      {!hasKids && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'INFANTE / NIÑOS')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Niños
                                        </button>
                                      )}

                                    </div>
                                  );
                                })()}
                              </div>
                            ) : (
                              /* --- MODE 2: DESGLOSE POR CATEGORÍAS DEPORTIVAS --- */
                              <div className="space-y-3">
                                {Object.entries(deptData.secciones || {}).map(([secName, families]) => {
                                  const genderInfo = getGenderDisplayInfo(secName);
                                  const totalSecSkus = Object.values(families || {}).reduce(
                                    (a, b) => a + (b || 0),
                                    0
                                  );
                                  const inputKey = `${dept}__${secName}`;
                                  const isAddingCategory = showAddCategoryInput[inputKey];
                                  const currentInputVal = newCategoryInputs[inputKey] || '';

                                  return (
                                    <div
                                      key={secName}
                                      className={`space-y-2 bg-[#FBF8FF] p-2.5 rounded-xl border ${genderInfo.border}`}
                                    >
                                      <div className="text-[11px] font-mono font-bold text-zinc-800 flex items-center justify-between pb-1 border-b border-zinc-200/60">
                                        <span className="flex items-center gap-1.5">
                                          <span className="select-none">{genderInfo.icon}</span>
                                          <span>{secName}</span>
                                        </span>
                                        <div className="flex items-center gap-1.5">
                                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white text-zinc-800 font-bold border border-zinc-200">
                                            {totalSecSkus} SKUs
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => handleRemoveGenderSection(dept, secName)}
                                            className="text-zinc-400 hover:text-rose-600 transition-colors p-0.5 cursor-pointer"
                                            title={`Retirar tarjeta de ${secName}`}
                                          >
                                            <Trash2 className="w-3.5 h-3.5" />
                                          </button>
                                        </div>
                                      </div>

                                      {/* Categories list */}
                                      <div className="space-y-1 pt-1">
                                        {Object.entries(families || {}).map(([famName, skusVal]) => (
                                          <div
                                            key={famName}
                                            className="flex items-center justify-between text-xs bg-white px-2 py-1 rounded border border-zinc-200"
                                          >
                                            <span className="text-zinc-800 text-[11px] font-mono font-medium truncate max-w-[120px]">
                                              {famName}
                                            </span>
                                            <div className="flex items-center gap-1.5">
                                              <input
                                                type="number"
                                                min={0}
                                                max={400}
                                                value={skusVal === 0 ? '' : skusVal}
                                                placeholder="0"
                                                onFocus={(e) => e.target.select()}
                                                onChange={(e) => {
                                                  const raw = e.target.value;
                                                  const val = raw === '' ? 0 : parseInt(raw, 10);
                                                  handleFamilySkusChangeForBrand(
                                                    dept,
                                                    secName,
                                                    famName,
                                                    isNaN(val) ? 0 : Math.max(0, val)
                                                  );
                                                }}
                                                className="w-12 bg-[#F4F2FD] border border-zinc-300 rounded px-1 py-0.5 text-right font-mono text-xs text-zinc-900 focus:bg-white focus:outline-none focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400 placeholder:text-zinc-400 transition-all shadow-xs"
                                              />
                                              <span className="text-[9px] text-zinc-400 font-mono">SKUs</span>

                                              {Object.keys(families || {}).length > 1 && (
                                                <button
                                                  type="button"
                                                  onClick={() =>
                                                    handleRemoveCategoryFromSection(dept, secName, famName)
                                                  }
                                                  className="p-1 text-zinc-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                                                  title={`Eliminar categoría ${famName}`}
                                                >
                                                  <Trash2 className="w-3 h-3" />
                                                </button>
                                              )}
                                            </div>
                                          </div>
                                        ))}
                                      </div>

                                      {/* Quick Preset Chips */}
                                      <div className="pt-1">
                                        <div className="flex items-center gap-1 flex-wrap">
                                          {categorySuggestions
                                            .filter((cat) => !families?.[cat])
                                            .slice(0, 4)
                                            .map((cat) => (
                                              <button
                                                key={cat}
                                                type="button"
                                                onClick={() => handleAddCategoryToSection(dept, secName, cat)}
                                                className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-white hover:bg-[#F4F2FD] text-zinc-700 font-semibold cursor-pointer border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs"
                                              >
                                                +{cat}
                                              </button>
                                            ))}
                                        </div>
                                      </div>

                                      {/* Add Custom Category Input */}
                                      <div className="pt-1.5 border-t border-zinc-200/60">
                                        {!isAddingCategory ? (
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setShowAddCategoryInput((prev) => ({
                                                ...prev,
                                                [inputKey]: true,
                                              }))
                                            }
                                            className="h-6 px-2 rounded-md text-[10px] font-mono text-zinc-600 hover:text-zinc-900 font-semibold flex items-center gap-1 cursor-pointer bg-white hover:bg-[#F4F2FD] border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs"
                                          >
                                            <Plus className="w-3 h-3" />
                                            <span>+ Otra categoría</span>
                                          </button>
                                        ) : (
                                          <div className="flex items-center gap-1 pt-1 animate-fadeIn">
                                            <input
                                              type="text"
                                              placeholder="Trail, Crossfit..."
                                              value={currentInputVal}
                                              onChange={(e) =>
                                                setNewCategoryInputs((prev) => ({
                                                  ...prev,
                                                  [inputKey]: e.target.value,
                                                }))
                                              }
                                              onKeyDown={(e) => {
                                                if (e.key === 'Enter') {
                                                  e.preventDefault();
                                                  handleAddCategoryToSection(dept, secName, currentInputVal);
                                                }
                                              }}
                                              className="flex-1 h-6 bg-white border border-zinc-300 rounded px-1.5 text-xs font-mono uppercase text-zinc-900 focus:outline-none focus:border-zinc-500"
                                              autoFocus
                                            />
                                            <button
                                              type="button"
                                              onClick={() =>
                                                handleAddCategoryToSection(dept, secName, currentInputVal)
                                              }
                                              className="h-6 px-2.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded text-[10px] font-mono font-bold cursor-pointer transition-colors shadow-xs"
                                            >
                                              OK
                                            </button>
                                            <button
                                              type="button"
                                              onClick={() =>
                                                setShowAddCategoryInput((prev) => ({
                                                  ...prev,
                                                  [inputKey]: false,
                                                }))
                                              }
                                              className="w-6 h-6 flex items-center justify-center text-zinc-400 hover:text-zinc-800 rounded hover:bg-zinc-200 transition-colors cursor-pointer"
                                            >
                                              <X className="w-3.5 h-3.5" />
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}

                                {/* Add Missing Gender in Mode 2 */}
                                {(() => {
                                  const existingTypes = Object.keys(deptData.secciones || {}).map(detectGenderType);
                                  const hasMens = existingTypes.includes('MENS');
                                  const hasWomens = existingTypes.includes('WOMENS');
                                  const hasKids = existingTypes.includes('KIDS');
                                  const hasUnisex = existingTypes.includes('UNISEX');

                                  return (
                                    <div className="pt-2 border-t border-zinc-100 flex items-center gap-1.5 flex-wrap">
                                      {!hasMens && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'HOMBRE (MENS)')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Caballero
                                        </button>
                                      )}
                                      {!hasWomens && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'MUJER (WOMENS)')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Dama
                                        </button>
                                      )}
                                      {!hasKids && (
                                        <button
                                          type="button"
                                          onClick={() => handleAddGenderSection(dept, 'INFANTE / NIÑOS')}
                                          className="h-6 px-2 rounded-md text-[10px] font-mono font-semibold bg-white hover:bg-[#F4F2FD] text-zinc-700 border border-zinc-200/90 hover:border-zinc-300 transition-all shadow-xs cursor-pointer"
                                        >
                                          + Niños
                                        </button>
                                      )}

                                    </div>
                                  );
                                })()}
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  );
                    }
                  )}
                </div>
              </div>
            )}

            {/* STEP 3: RESUMEN CONSOLIDADO & DISTANCIAS */}
            {activeStep === 3 && (
              <div className="space-y-4 animate-fadeIn">
                <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                    <span className="text-xs font-mono uppercase font-bold tracking-wider text-zinc-800 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-emerald-700" />
                      Sumatoria de Red y Participación de Marcas ({Object.keys(marcasCapacidad).length})
                    </span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-800 border border-zinc-200 font-bold">
                      {STORE_FORMAT_INFO[tipo]?.name || tipo}
                    </span>
                  </div>

                  {/* Top 3 KPI Blocks */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="bg-[#F4F2FD] p-3.5 rounded-xl border border-zinc-200 shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)]">
                      <span className="text-[10px] font-mono uppercase text-zinc-500 font-bold">Total SKUs Físicos</span>
                      <div className="text-xl font-mono font-bold text-zinc-900 mt-0.5">
                        {storeConsolidatedMetrics.totalSkus.toLocaleString()} <span className="text-xs text-zinc-400 font-normal">SKUs</span>
                      </div>
                      <p className="text-[10px] font-mono text-zinc-500 mt-1">Frentes en pared y mobiliario</p>
                    </div>

                    <div className="bg-[#F4F2FD] p-3.5 rounded-xl border border-zinc-200 shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)]">
                      <span className="text-[10px] font-mono uppercase text-emerald-700 font-bold">Total Piezas Físicas</span>
                      <div className="text-xl font-mono font-bold text-emerald-700 mt-0.5">
                        {storeConsolidatedMetrics.totalPieces.toLocaleString()} <span className="text-xs text-emerald-600/70 font-normal">uds</span>
                      </div>
                      <p className="text-[10px] font-mono text-zinc-500 mt-1">Capacidad total bodega + piso</p>
                    </div>

                    <div className="bg-[#F4F2FD] p-3.5 rounded-xl border border-zinc-200 shadow-[inset_0_1px_2px_rgba(0,0,0,0.02)]">
                      <span className="text-[10px] font-mono uppercase text-purple-700 font-bold">Profundidad Ponderada</span>
                      <div className="text-xl font-mono font-bold text-purple-800 mt-0.5">
                        {storeConsolidatedMetrics.avgDepth} <span className="text-xs text-purple-600/70 font-normal">uds/SKU</span>
                      </div>
                      <p className="text-[10px] font-mono text-zinc-500 mt-1">Promedio de frentes de tienda</p>
                    </div>
                  </div>

                  {/* Brand Breakdown Table */}
                  <div className="space-y-2">
                    <span className="text-xs font-mono font-bold text-zinc-700">Desglose de Capacidad por Marca:</span>
                    <div className="overflow-x-auto border border-zinc-200 rounded-xl">
                      <table className="w-full text-left text-xs font-mono">
                        <thead className="bg-[#F4F2FD] text-zinc-600 font-bold text-[10px] uppercase border-b border-zinc-200">
                          <tr>
                            <th className="px-3 py-2">Marca</th>
                            <th className="px-3 py-2 text-right">SKUs</th>
                            <th className="px-3 py-2 text-right">Piezas</th>
                            <th className="px-3 py-2 text-right">Profundidad</th>
                            <th className="px-3 py-2 text-right">% Tienda</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-200 bg-white">
                          {Object.entries(marcasCapacidad).map(([bName, bMatrix]) => {
                            const bMetrics = calcularTotalesMatriz(bMatrix as CapacityMatrixConfig);
                            const share =
                              storeConsolidatedMetrics.totalPieces > 0
                                ? Math.round(
                                    (bMetrics.totalPieces / storeConsolidatedMetrics.totalPieces) * 1000
                                  ) / 10
                                : 0;

                            return (
                              <tr key={bName} className="hover:bg-zinc-50">
                                <td className="px-3 py-2 font-bold text-zinc-900 flex items-center gap-1.5">
                                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-900"></span>
                                  {bName}
                                </td>
                                <td className="px-3 py-2 text-right text-zinc-700">{bMetrics.totalSkus}</td>
                                <td className="px-3 py-2 text-right text-emerald-700 font-bold">{bMetrics.totalPieces.toLocaleString()}</td>
                                <td className="px-3 py-2 text-right text-zinc-700">{bMetrics.avgDepth} uds</td>
                                <td className="px-3 py-2 text-right text-zinc-500">{share}%</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Seed Stock Checkbox */}
                {!isEditing && (
                  <div className="bg-white p-4 rounded-2xl border border-zinc-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold text-zinc-900 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-zinc-700" />
                        Inicializar con Inventario Semilla Modelo
                      </span>
                      <p className="text-[11px] font-mono text-zinc-500 mt-0.5">
                        Puebla inventario modelo para simulación y análisis de curvas de talla inmediato
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={seedStock}
                      onChange={(e) => setSeedStock(e.target.checked)}
                      className="w-4 h-4 accent-zinc-900 cursor-pointer"
                    />
                  </div>
                )}

                {/* Distances Setup */}
                <div className="bg-white p-4 rounded-2xl border border-zinc-200 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                    <div>
                      <span className="text-xs font-mono uppercase font-bold text-zinc-800 flex items-center gap-1.5">
                        <Truck className="w-3.5 h-3.5 text-zinc-700" />
                        Distancias de Traslado a Otras Tiendas (Km)
                      </span>
                      {typeof lat === 'number' && typeof lng === 'number' && (
                        <span className="text-[10px] font-mono text-emerald-700 flex items-center gap-1 mt-0.5">
                          ✓ Calculado automáticamente con coordenadas GPS de Google Maps
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-zinc-400">Algoritmo de Transferencias</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {existingStores
                      .filter((st) => !initialStoreToEdit || st !== initialStoreToEdit.nombre)
                      .map((st) => {
                        const otherProfile = storeProfiles.find((p) => p.nombre === st);
                        const hasGeo =
                          typeof lat === 'number' &&
                          typeof lng === 'number' &&
                          typeof otherProfile?.lat === 'number' &&
                          typeof otherProfile?.lng === 'number';
                        const distVal = distances[st] ?? 0;
                        const fleteEst = Math.round(15 + distVal * 1.8);

                        return (
                          <div
                            key={st}
                            className="bg-[#F4F2FD] p-2.5 rounded-xl border border-zinc-200 flex flex-col gap-1.5 text-xs font-mono"
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-zinc-800 truncate max-w-[160px] font-medium flex items-center gap-1">
                                🏬 {st}
                                {hasGeo && (
                                  <span className="text-[9px] px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded font-bold">
                                    GPS
                                  </span>
                                )}
                              </span>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  min={1}
                                  max={500}
                                  value={distances[st] === 0 ? '' : (distances[st] ?? '')}
                                  placeholder="12"
                                  onFocus={(e) => e.target.select()}
                                  onChange={(e) => {
                                    const raw = e.target.value;
                                    const val = raw === '' ? 0 : parseFloat(raw);
                                    setDistances((prev) => ({ ...prev, [st]: isNaN(val) ? 0 : Math.max(0, val) }));
                                  }}
                                  className="w-14 bg-white border border-zinc-300 rounded px-1.5 py-0.5 text-center font-mono font-bold text-xs text-zinc-900 focus:outline-none focus:border-zinc-500 focus:ring-1 focus:ring-zinc-400 placeholder:text-zinc-400 transition-all shadow-xs"
                                />
                                <span className="text-[10px] text-zinc-500">km</span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-zinc-500 pt-1 border-t border-zinc-200/60">
                              <span>Flete estimado de rebalanceo:</span>
                              <span className="font-bold text-amber-800">${fleteEst} USD</span>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT SIDEBAR: LIVE INDUSTRIAL TELEMETRY & SPATIAL DIAGNOSTICS (Col 9 to 12 on lg) */}
          <div className="lg:col-span-4 p-5 overflow-y-auto custom-scrollbar bg-white space-y-4 select-none">
            {/* Reticle Viewfinder Box for Real-time Spatial Gauge */}
            <ReticleBox title="TELEMETRÍA ESPACIAL EN VIVO" telemetry="CALIBRADO">
              <div className="flex flex-col items-center justify-center pt-1 pb-3">
                <ConcentricDial
                  value={spatialDensity}
                  target={formatDensityTarget.opt}
                  max={Math.max(50, formatDensityTarget.max * 1.2)}
                  label="DENSIDAD FÍSICA"
                  unit=" pzs/m²"
                  status={densityStatus}
                  size={130}
                />

                <div className="mt-2 text-center">
                  <IndustrialBadge
                    status={densityStatus}
                    label={
                      densityStatus === 'optimal'
                        ? 'DENSIDAD ÓPTIMA'
                        : densityStatus === 'warning'
                        ? 'CAPACIDAD SUBUTILIZADA'
                        : 'SATURACIÓN ALTA'
                    }
                    size="sm"
                  />
                  <p className="text-[10px] font-mono text-zinc-500 mt-1">
                    Benchmark {tipo}: <strong>{formatDensityTarget.min}-{formatDensityTarget.max} pzs/m²</strong>
                  </p>
                </div>
              </div>

              {/* Real-time Technical Specs Grid */}
              <div className="grid grid-cols-2 gap-2 pt-3 border-t border-zinc-100 text-xs font-mono">
                <div className="bg-[#F4F2FD] p-2 rounded-lg border border-zinc-200">
                  <span className="text-[9px] uppercase text-zinc-500 block">Capacidad Tienda</span>
                  <span className="text-sm font-bold text-zinc-900">{storeConsolidatedMetrics.totalPieces.toLocaleString()} uds</span>
                </div>

                <div className="bg-[#F4F2FD] p-2 rounded-lg border border-zinc-200">
                  <span className="text-[9px] uppercase text-zinc-500 block">Exhibición Piso (VM)</span>
                  <span className="text-sm font-bold text-emerald-700">{totalFloorPieces.toLocaleString()} uds</span>
                </div>

                <div className="bg-[#F4F2FD] p-2 rounded-lg border border-zinc-200">
                  <span className="text-[9px] uppercase text-zinc-500 block">Total SKUs Físicos</span>
                  <span className="text-sm font-bold text-zinc-900">{storeConsolidatedMetrics.totalSkus} SKUs</span>
                </div>

                <div className="bg-[#F4F2FD] p-2 rounded-lg border border-zinc-200">
                  <span className="text-[9px] uppercase text-zinc-500 block">Superficie Venta</span>
                  <span className="text-sm font-bold text-zinc-900">{superficieM2 || 500} m²</span>
                </div>
              </div>
            </ReticleBox>

            {/* Department Mix Breakdown */}
            <div className="p-3.5 bg-[#FBF8FF] rounded-xl border border-zinc-200 space-y-2.5 font-mono">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-zinc-800 uppercase tracking-wider text-[11px]">
                  Mix Departamental
                </span>
                <span className="text-[10px] text-zinc-400">Ponderado en Piezas</span>
              </div>

              {['CALZADO', 'TEXTIL', 'ACCESORIOS'].map((dKey) => {
                const data = departmentBreakdown[dKey] || { skus: 0, pieces: 0 };
                const pct =
                  storeConsolidatedMetrics.totalPieces > 0
                    ? Math.round((data.pieces / storeConsolidatedMetrics.totalPieces) * 100)
                    : 0;

                return (
                  <div key={dKey} className="space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-zinc-700 font-semibold">{dKey}</span>
                      <span className="text-zinc-900 font-bold">
                        {data.pieces.toLocaleString()} uds <span className="text-zinc-400">({pct}%)</span>
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-zinc-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          dKey === 'CALZADO' ? 'bg-zinc-900' : dKey === 'TEXTIL' ? 'bg-blue-600' : 'bg-emerald-600'
                        }`}
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Gender Mix Breakdown */}
            <div className="p-3.5 bg-[#FBF8FF] rounded-xl border border-zinc-200 space-y-2 font-mono">
              <span className="font-bold text-zinc-800 uppercase tracking-wider text-[11px] block">
                Distribución por Género
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs">
                {Object.entries(genderBreakdown).map(([gen, rawPieces]) => {
                  const pieces = Number(rawPieces) || 0;
                  const pct =
                    storeConsolidatedMetrics.totalPieces > 0
                      ? Math.round((pieces / storeConsolidatedMetrics.totalPieces) * 100)
                      : 0;

                  return (
                    <div key={gen} className="bg-white p-2 rounded-lg border border-zinc-200">
                      <span className="text-[10px] text-zinc-500 uppercase block">{gen}</span>
                      <div className="font-bold text-zinc-900 mt-0.5">
                        {pieces.toLocaleString()} <span className="text-[10px] text-zinc-400 font-normal">({pct}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Active Brand Card info */}
            <div className="p-3 bg-[#F4F2FD] rounded-xl border border-zinc-200 text-xs font-mono space-y-1">
              <span className="text-[10px] uppercase font-bold text-zinc-500 block">Marca en Edición</span>
              <div className="flex items-center justify-between">
                <span className="font-bold text-zinc-900">🏷️ {activeBrand}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-white text-zinc-700 border border-zinc-200">
                  {isCategoriesActive ? 'Modo Categorías' : 'Modo Global'}
                </span>
              </div>
              <div className="text-[11px] text-zinc-600 pt-1 border-t border-zinc-200/80">
                Aporte: <strong>{activeBrandMetrics.totalPieces.toLocaleString()} uds</strong> ({storeConsolidatedMetrics.totalPieces > 0 ? Math.round((activeBrandMetrics.totalPieces / storeConsolidatedMetrics.totalPieces) * 100) : 0}% de la tienda)
              </div>
            </div>
          </div>
        </div>

        {/* MODAL INDUSTRIAL FOOTER CONTROLS */}
        <div className="px-6 py-3.5 bg-white border-t border-zinc-200 flex items-center justify-between shadow-[0_-1px_2px_rgba(0,0,0,0.02)]">
          <div>
            {activeStep > 1 && (
              <button
                type="button"
                onClick={() => setActiveStep((prev) => (prev - 1) as 1 | 2)}
                className="h-9 px-4 tactile-button-light rounded-xl text-xs font-mono font-semibold cursor-pointer"
              >
                Atrás
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="h-9 px-4 tactile-button-light rounded-xl text-xs font-mono font-semibold cursor-pointer text-zinc-600"
            >
              Cancelar
            </button>

            {activeStep < 3 ? (
              <button
                type="button"
                onClick={() => {
                  if (activeStep === 1 && !nombre.trim()) {
                    setErrorMsg('Ingresa un nombre para la tienda antes de continuar.');
                    return;
                  }
                  setErrorMsg(null);
                  setActiveStep((prev) => (prev + 1) as 2 | 3);
                }}
                className="inline-flex items-center gap-1.5 h-9 px-5 tactile-button-dark text-xs font-mono font-semibold rounded-xl cursor-pointer"
              >
                <span>Siguiente Paso</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                className="inline-flex items-center gap-1.5 h-9 px-6 bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-900 rounded-xl text-xs font-mono font-semibold shadow-xs transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isEditing ? 'Guardar Cambios de Tienda' : 'Guardar y Registrar Tienda'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
