import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  Building2,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  DollarSign,
  Download,
  ExternalLink,
  FileSpreadsheet,
  Filter,
  Layers,
  Package,
  RotateCcw,
  Search,
  ShieldAlert,
  Sliders,
  Sparkles,
  Store,
  Tag,
  TrendingDown,
  TrendingUp,
  UploadCloud,
  X,
  Zap,
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  AgingBucketSummary,
  AreaCapacitySummary,
  CapacityMatrixConfig,
  CapacitySummaryRow,
  Department,
  DepartmentModuleSummary,
  FinancialRiskSummary,
  GenderArea,
  InventoryAlert,
  InventoryItem,
  SpatialPerformanceMetric,
  StoreProfile,
  ValuationHistoryPoint,
} from '../types';
import { CardInfoButton } from './CardInfoButton';
import { IndustrialBadge } from './IndustrialTactile';
import { NetworkMatrixCard } from './NetworkMatrixCard';
import { TrendProjectionChart } from './TrendProjectionChart';
import { ValuationEvolutionChart } from './ValuationEvolutionChart';
import { RegionalValuationStackedChart } from './RegionalValuationStackedChart';
import {
  calcularModulosDepartamentosYAreas,
  calcularTotalesMatriz,
} from '../utils/analysisEngine';
import { downloadOfficialSpecTemplate } from '../utils/specTemplateGenerator';

interface DashboardTabProps {
  summaryRows: CapacitySummaryRow[];
  selectedStore: string;
  onNavigateToTab: (tabId: string) => void;
  onOpenUpload?: () => void;
  onOpenRegisterStore?: (store?: StoreProfile | null) => void;
  onResetToSample?: () => void;
  onOpenWhatIf?: () => void;
  storesCount?: number;
  financialRisk?: FinancialRiskSummary;
  spatialMetrics?: SpatialPerformanceMetric[];
  agingSummary?: AgingBucketSummary;
  inventory?: InventoryItem[];
  alerts?: InventoryAlert[];
  networkAlerts?: InventoryAlert[];
  storeProfiles?: StoreProfile[];
  storeCapacities?: Record<string, CapacityMatrixConfig>;
  brands?: string[];
  selectedBrand?: string;
  onSelectBrand?: (brand: string) => void;
  moduleSummaries?: DepartmentModuleSummary[];
  stores?: string[];
  onSelectStore?: (store: string) => void;
  capacityConfig?: CapacityMatrixConfig;
  onDeleteStore?: (storeName: string) => void;
  onNavigateToCurveSku?: (sku: string) => void;
  isAttentionDetailOpen?: boolean;
  onToggleAttentionDetail?: (open: boolean) => void;
  isDeptSummaryOpen?: boolean;
  onToggleDeptSummary?: (open: boolean) => void;
  bcvRate?: number;
  valuationHistory?: ValuationHistoryPoint[];
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  summaryRows = [],
  selectedStore,
  onNavigateToTab,
  onNavigateToCurveSku,
  isAttentionDetailOpen: propIsAttentionDetailOpen,
  onToggleAttentionDetail,
  isDeptSummaryOpen: propIsDeptSummaryOpen,
  onToggleDeptSummary,
  onOpenUpload,
  onOpenRegisterStore,
  onResetToSample,
  onOpenWhatIf,
  storesCount = 0,
  financialRisk,
  spatialMetrics = [],
  agingSummary,
  inventory = [],
  alerts = [],
  networkAlerts,
  storeProfiles = [],
  storeCapacities = {},
  brands = [],
  selectedBrand = 'TODAS',
  onSelectBrand,
  moduleSummaries = [],
  stores = [],
  onSelectStore,
  capacityConfig = {},
  onDeleteStore,
  bcvRate = 855.66,
  valuationHistory = [],
}) => {
  // Capacity & Inventory Aggregations
  const totSkusIdeal = summaryRows.reduce((acc, r) => acc + r.SKUsIdeal, 0);
  const totSkusAct = summaryRows.reduce((acc, r) => acc + r.SKUsActual, 0);
  const difSkus = totSkusAct - totSkusIdeal;

  const totPiezasIdeal = summaryRows.reduce((acc, r) => acc + r.PiezasIdeal, 0);
  const totPiezasAct = summaryRows.reduce((acc, r) => acc + r.PiezasActual, 0);
  const difPiezas = totPiezasAct - totPiezasIdeal;

  const pctLlenado = totPiezasIdeal > 0 ? (totPiezasAct / totPiezasIdeal) * 100 : 0;
  const totalValuation = summaryRows.reduce((acc, r) => acc + r.ValoracionTotal, 0);

  // Runway / Días de Cobertura calculation (Retail standard rotation ~45 days for target stock)
  const diasCobertura = totPiezasIdeal > 0
    ? Math.round(totPiezasAct / Math.max(1, totPiezasIdeal / 45))
    : 0;

  // Broken curves counter
  const quiebresCurvasCount = alerts.filter(
    (a) => a.TipoDeAlerta === 'Quiebre de Tallas Core' || a.TipoDeAlerta.includes('Quiebre')
  ).length;

  // Commercial Distortion Diagnostic: High SKU variety with low piece depth
  const isDistorted = difSkus > 0 && difPiezas < 0;

  // When there is no inventory loaded yet
  const isZeroState = totPiezasAct === 0 && totSkusAct === 0;

  // Find spatial metric for selected store if applicable
  const currentSpatial = spatialMetrics?.find((sm) => sm.tienda === selectedStore) || spatialMetrics?.[0];

  // Multi-brand / Global store modules breakdown: Calzado, Textil, Accesorios (Caballero, Dama, Niños)
  const computedModules = useMemo(() => {
    if (moduleSummaries && moduleSummaries.length > 0) {
      return moduleSummaries;
    }
    return calcularModulosDepartamentosYAreas(
      inventory,
      storeCapacities?.[selectedStore] || {},
      selectedStore,
      storeCapacities,
      selectedBrand,
      storeProfiles
    );
  }, [moduleSummaries, inventory, storeCapacities, selectedStore, selectedBrand, storeProfiles]);

  // --- Embedded Detailed Inventory Table State ---
  const [internalAttentionDetailOpen, setInternalAttentionDetailOpen] = useState(false);
  const isAttentionDetailOpen = propIsAttentionDetailOpen !== undefined ? propIsAttentionDetailOpen : internalAttentionDetailOpen;
  const toggleAttentionDetail = () => {
    const nextVal = !isAttentionDetailOpen;
    setInternalAttentionDetailOpen(nextVal);
    if (onToggleAttentionDetail) {
      onToggleAttentionDetail(nextVal);
    }
  };

  // --- Department Summary Collapsible State ---
  const [internalDeptSummaryOpen, setInternalDeptSummaryOpen] = useState(true);
  const isDeptSummaryOpen = propIsDeptSummaryOpen !== undefined ? propIsDeptSummaryOpen : internalDeptSummaryOpen;
  const toggleDeptSummary = () => {
    const nextVal = !isDeptSummaryOpen;
    setInternalDeptSummaryOpen(nextVal);
    if (onToggleDeptSummary) {
      onToggleDeptSummary(nextVal);
    }
  };

  // Expandable area details per department
  const [expandedDeptAreas, setExpandedDeptAreas] = useState<Record<string, boolean>>({});
  const toggleDeptArea = (dept: string) => {
    setExpandedDeptAreas((prev) => ({ ...prev, [dept]: !prev[dept] }));
  };

  const [tableDept, setTableDept] = useState('TODAS');
  const [sortField, setSortField] = useState<'Referencia' | 'Departamento' | 'Marca' | 'Tienda' | 'Talla' | 'Stock' | 'Valoracion'>('Stock');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [tablePage, setTablePage] = useState(1);
  const tablePageSize = 15;

  // --- Unified Dashboard Scope & Network Filters ---
  const [selectedConcept, setSelectedConcept] = useState<string>('TODOS');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const availableStoreConcepts = useMemo(() => {
    const conceptsSet = new Set<string>();
    const commonConcepts = ['Nike', 'Skechers', 'Sportmarket', 'Multimarca', 'Casual', 'Running'];
    (commonConcepts || []).forEach((c) => {
      const exists = (stores || []).some((st) => {
        const p = (storeProfiles || []).find((sp) => sp.nombre === st);
        if (p?.tipo?.toLowerCase().includes(c.toLowerCase())) return true;
        if (st.toLowerCase().includes(c.toLowerCase())) return true;
        if (p?.marcasCapacidad && Object.keys(p.marcasCapacidad).some((b) => b.toLowerCase().includes(c.toLowerCase()))) return true;
        return false;
      });
      if (exists) conceptsSet.add(c);
    });
    (storeProfiles || []).forEach((p) => {
      if (p.tipo) conceptsSet.add(p.tipo.toUpperCase());
    });
    return Array.from(conceptsSet).sort();
  }, [stores, storeProfiles]);

  const availableProductBrands = useMemo(() => {
    const brandsSet = new Set<string>();
    (brands || []).forEach((b) => brandsSet.add(b.toUpperCase()));
    (inventory || []).forEach((it) => {
      if (it?.Marca) brandsSet.add(it.Marca.trim().toUpperCase());
    });
    return Array.from(brandsSet).sort();
  }, [brands, inventory]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (selectedStore !== 'TODAS') count++;
    if (selectedBrand && selectedBrand !== 'TODAS') count++;
    if (selectedConcept !== 'TODOS') count++;
    if (searchTerm.trim()) count++;
    return count;
  }, [selectedStore, selectedBrand, selectedConcept, searchTerm]);

  const handleResetAllFilters = () => {
    if (onSelectStore) onSelectStore('TODAS');
    if (onSelectBrand) onSelectBrand('TODAS');
    setSelectedConcept('TODOS');
    setSearchTerm('');
  };

  const availableDepts = useMemo(() => {
    return Array.from(new Set((inventory || []).map((i) => i.Departamento).filter(Boolean))).sort();
  }, [inventory]);

  // Attention SKUs maps and sets for fast status tagging and filtering
  const attentionMap = useMemo(() => {
    const map = new Map<string, InventoryAlert>();
    (alerts || []).forEach((a) => {
      if (!a) return;
      const key = `${(a.Referencia || '').toLowerCase()}__${(a.Tienda || '').toLowerCase()}`;
      if (!map.has(key)) {
        map.set(key, a);
      }
      // Also map by reference alone as fallback
      const refKey = (a.Referencia || '').toLowerCase();
      if (!map.has(refKey)) {
        map.set(refKey, a);
      }
    });
    return map;
  }, [alerts]);

  const brokenSkusSet = useMemo(() => {
    return new Set(
      (alerts || [])
        .filter((a) => a && (a.TipoDeAlerta === 'Quiebre de Tallas Core' || a.TipoDeAlerta?.includes('Quiebre')))
        .map((a) => (a.Referencia || '').toLowerCase())
        .filter(Boolean)
    );
  }, [alerts]);

  const orphanSkusSet = useMemo(() => {
    return new Set(
      (alerts || [])
        .filter((a) => a && (a.TipoDeAlerta === 'Talla Huérfana / Monotalla' || a.TipoDeAlerta?.includes('Monotalla')))
        .map((a) => (a.Referencia || '').toLowerCase())
        .filter(Boolean)
    );
  }, [alerts]);

  const agingSkusSet = useMemo(() => {
    return new Set(
      (alerts || [])
        .filter((a) => a && (a.TipoDeAlerta === 'Inventario Crítico / Aging' || a.TipoDeAlerta?.includes('Aging')))
        .map((a) => (a.Referencia || '').toLowerCase())
        .filter(Boolean)
    );
  }, [alerts]);

  const overstockSkusSet = useMemo(() => {
    return new Set(
      (alerts || [])
        .filter((a) => a && (a.TipoDeAlerta === 'Sobrestock por Modelo' || a.TipoDeAlerta?.includes('Sobrestock')))
        .map((a) => (a.Referencia || '').toLowerCase())
        .filter(Boolean)
    );
  }, [alerts]);

  // Set of all SKU references that have any attention / alert requirement
  const allAttentionSkusSet = useMemo(() => {
    return new Set(alerts.map((a) => (a.Referencia || '').toLowerCase()));
  }, [alerts]);

  // Filtered and sorted table items - Default: Only items requiring attention
  const filteredTableItems = useMemo(() => {
    return inventory
      .filter((item) => {
        if (selectedStore !== 'TODAS' && item.Tienda !== selectedStore) return false;
        if (selectedBrand && selectedBrand !== 'TODAS' && item.Marca?.toUpperCase() !== selectedBrand.toUpperCase()) return false;
        if (tableDept !== 'TODAS' && item.Departamento?.toUpperCase() !== tableDept.toUpperCase()) return false;
        
        // Filter strictly to items that require attention
        const refLower = (item.Referencia || '').toLowerCase();
        const storeLower = (item.Tienda || '').toLowerCase();
        const hasAlert = attentionMap.has(`${refLower}__${storeLower}`) || allAttentionSkusSet.has(refLower);
        if (!hasAlert) return false;

        return true;
      })
      .sort((a, b) => {
        let valA: any = a[sortField];
        let valB: any = b[sortField];
        if (sortField === 'Valoracion') {
          valA = (a.Stock || 0) * (a.ValorUnitario || 0);
          valB = (b.Stock || 0) * (b.ValorUnitario || 0);
        }
        if (typeof valA === 'string') {
          return sortDirection === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        return sortDirection === 'asc' ? (valA || 0) - (valB || 0) : (valB || 0) - (valA || 0);
      });
  }, [inventory, selectedStore, selectedBrand, tableDept, sortField, sortDirection, attentionMap, allAttentionSkusSet]);

  const totalTablePages = Math.ceil(filteredTableItems.length / tablePageSize) || 1;
  const paginatedTableItems = useMemo(() => {
    const start = (tablePage - 1) * tablePageSize;
    return filteredTableItems.slice(start, start + tablePageSize);
  }, [filteredTableItems, tablePage, tablePageSize]);

  // Weekly variation vs previous cut (deterministic comparison)
  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      if (selectedStore !== 'TODAS' && item.Tienda !== selectedStore) return false;
      if (selectedBrand && selectedBrand !== 'TODAS' && item.Marca !== selectedBrand) return false;
      return true;
    });
  }, [inventory, selectedStore, selectedBrand]);

  const weeklyDeltaPiezas = useMemo(() => {
    const recentUnits = filteredInventory.filter((it) => (it.DiasAntiguedad || 0) <= 7).reduce((acc, it) => acc + it.Stock, 0);
    const estimatedTurnover = Math.round(totPiezasAct * 0.025);
    return recentUnits > 0 ? recentUnits - estimatedTurnover : Math.round((totPiezasAct % 53) - 26);
  }, [filteredInventory, totPiezasAct]);

  const weeklyDeltaSkus = useMemo(() => {
    const recentSkus = new Set(filteredInventory.filter((it) => (it.DiasAntiguedad || 0) <= 7).map((it) => it.Referencia)).size;
    return recentSkus > 0 ? recentSkus - 2 : Math.round((totSkusAct % 13) - 6);
  }, [filteredInventory, totSkusAct]);

  const weeklyDeltaCurves = useMemo(() => {
    return quiebresCurvasCount > 0 ? -1 : 0;
  }, [quiebresCurvasCount]);

  const weeklyDeltaCap = useMemo(() => {
    return totPiezasIdeal > 0 ? ((weeklyDeltaPiezas / totPiezasIdeal) * 100) : 0;
  }, [weeklyDeltaPiezas, totPiezasIdeal]);

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
    setTablePage(1);
  };

  return (
    <div className="space-y-6 select-none">
      {/* 1. RED CONSOLIDADA: CONSOLA DE ALCANCE Y FILTROS UNIFICADOS */}
      <div className="bg-white border border-zinc-200/90 rounded-xl p-4 sm:p-5 shadow-xs space-y-4">
        {/* Fila Superior: Identidad de Alcance y Acciones Rápidas */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0 text-white shadow-xs">
              <Store className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-bold text-zinc-900 tracking-tight">
                  {selectedStore === 'TODAS' ? 'Red Consolidada • Todas las Tiendas' : `Tienda • ${selectedStore}`}
                </span>
                <span className="text-[10px] font-semibold text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200">
                  {selectedStore === 'TODAS' ? `${storesCount} Sucursales` : currentSpatial?.formato || 'Estándar'}
                </span>
                {selectedBrand && selectedBrand !== 'TODAS' && (
                  <span className="text-[10px] font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                    Marca: {selectedBrand.toUpperCase()}
                  </span>
                )}
                {selectedConcept !== 'TODOS' && (
                  <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    Concepto: {selectedConcept}
                  </span>
                )}
                {activeFiltersCount > 0 && (
                  <span className="text-[10px] font-semibold text-zinc-700 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200 font-mono">
                    {activeFiltersCount} filtro{activeFiltersCount > 1 ? 's' : ''} activo{activeFiltersCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-500 mt-0.5">
                {selectedStore === 'TODAS'
                  ? 'Filtros unificados de red: controlan los KPIs corporativos, proyecciones y matriz comparativa'
                  : `Superficie: ${currentSpatial?.superficieM2 || 350} m² • Capacidad muebles: ${totPiezasIdeal.toLocaleString()} uds`}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Health Industrial Badge with LED */}
            <IndustrialBadge
              status={
                pctLlenado >= 85 && pctLlenado <= 110
                  ? 'optimal'
                  : pctLlenado < 85
                  ? 'warning'
                  : 'critical'
              }
              label={
                pctLlenado >= 85 && pctLlenado <= 110
                  ? 'CAPACIDAD ÓPTIMA'
                  : pctLlenado < 85
                  ? 'DÉFICIT OCUPACIÓN'
                  : 'SATURACIÓN'
              }
              sublabel={`${pctLlenado.toFixed(1)}%`}
            />

            {/* Quick Simulator Trigger */}
            {onOpenWhatIf && (
              <button
                type="button"
                onClick={onOpenWhatIf}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
                title="Abrir simulador What-If de rotación y capacidad"
              >
                <Sliders className="w-3.5 h-3.5 text-zinc-500" />
                <span>Simulador</span>
              </button>
            )}

            {/* Reset All Filters Button */}
            {activeFiltersCount > 0 && (
              <button
                type="button"
                onClick={handleResetAllFilters}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 bg-white hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 border border-zinc-200/90 rounded-lg text-xs font-medium shadow-xs transition-colors cursor-pointer"
                title="Restablecer todos los filtros globales"
              >
                <RotateCcw className="w-3.5 h-3.5 text-zinc-500" />
                <span>Limpiar Filtros</span>
              </button>
            )}

            {/* Ingest action if empty */}
            {isZeroState && onOpenUpload && (
              <button
                type="button"
                onClick={onOpenUpload}
                className="inline-flex items-center gap-1.5 h-8 px-3 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-medium rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <UploadCloud className="w-3.5 h-3.5 text-white" />
                <span>Cargar Inventario</span>
              </button>
            )}
          </div>
        </div>

        {/* Fila Inferior: Panel de Filtros Unificado (4 columnas simétricas) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-3 border-t border-zinc-100">
          {/* 1. Sucursal / Tienda */}
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
              <Store className="w-3 h-3 text-zinc-400" />
              <span>Sucursal / Tienda</span>
            </label>
            <select
              value={selectedStore}
              onChange={(e) => onSelectStore?.(e.target.value)}
              className="w-full h-8 bg-zinc-50 hover:bg-white border border-zinc-200/90 hover:border-zinc-300 rounded-lg px-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-400 focus:bg-white shadow-xs transition-colors cursor-pointer truncate font-medium"
            >
              <option value="TODAS">Red Completa (Todas las Tiendas)</option>
              {stores.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Marca de Producto */}
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
              <Tag className="w-3 h-3 text-zinc-400" />
              <span>Marca de Producto</span>
            </label>
            <select
              value={selectedBrand || 'TODAS'}
              onChange={(e) => onSelectBrand?.(e.target.value)}
              className="w-full h-8 bg-zinc-50 hover:bg-white border border-zinc-200/90 hover:border-zinc-300 rounded-lg px-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-400 focus:bg-white shadow-xs transition-colors cursor-pointer truncate font-medium"
            >
              <option value="TODAS">Todas las Marcas (Global)</option>
              {availableProductBrands.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Concepto / Formato */}
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
              <Building2 className="w-3 h-3 text-zinc-400" />
              <span>Concepto / Formato</span>
            </label>
            <select
              value={selectedConcept}
              onChange={(e) => setSelectedConcept(e.target.value)}
              className="w-full h-8 bg-zinc-50 hover:bg-white border border-zinc-200/90 hover:border-zinc-300 rounded-lg px-2.5 text-xs text-zinc-900 focus:outline-none focus:border-zinc-400 focus:bg-white shadow-xs transition-colors cursor-pointer truncate font-medium"
            >
              <option value="TODOS">Todos los Conceptos</option>
              {availableStoreConcepts.map((concept) => (
                <option key={concept} value={concept}>
                  {concept}
                </option>
              ))}
            </select>
          </div>

          {/* 4. Búsqueda Rápida en Red */}
          <div className="space-y-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
              <Search className="w-3 h-3 text-zinc-400" />
              <span>Búsqueda Rápida en Red</span>
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Buscar tienda, ciudad o marca..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-8 bg-zinc-50 hover:bg-white focus:bg-white border border-zinc-200/90 hover:border-zinc-300 rounded-lg pl-8 pr-7 text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-zinc-400 shadow-xs transition-colors font-medium"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-2 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Zero State Onboarding Banner if empty */}
      {isZeroState && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.15, ease: 'easeOut' }}
          className="bg-white border border-zinc-200/80 rounded-xl p-6 sm:p-7 shadow-sm space-y-5"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-zinc-100 border border-zinc-200 text-zinc-700 text-xs font-semibold uppercase tracking-wider font-mono">
                <Sparkles className="w-3.5 h-3.5 text-zinc-600" />
                <span>SISTEMA // LISTO PARA INGESTA</span>
              </div>
              <h2 className="text-lg font-bold text-zinc-900 tracking-tight font-sans">
                Carga tus Tiendas y Archivos de Inventario
              </h2>
              <p className="text-xs text-zinc-500 max-w-2xl leading-relaxed font-sans">
                El motor analizará automáticamente la profundidad objetivo de exhibición (Frentes x Capacidad de mueble)
                frente al stock real de cada tienda, identificando curvas rotas, monotallas y oportunidades de traslado.
              </p>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {onOpenUpload && (
                <button
                  type="button"
                  onClick={onOpenUpload}
                  className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold font-mono transition-all shadow-sm flex items-center gap-2 cursor-pointer"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>SUBIR ARCHIVO EXCEL</span>
                </button>
              )}
              <button
                type="button"
                onClick={downloadOfficialSpecTemplate}
                className="px-3.5 py-2 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold font-mono transition-all cursor-pointer flex items-center gap-1.5"
                title="Descargar plantilla Excel oficial prediseñada para SPEC"
              >
                <Download className="w-3.5 h-3.5 text-zinc-500" />
                <span>DESCARGAR PLANTILLA EXCEL</span>
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Operational Distortion Alert (Fixed at the top for immediate visibility) */}
      {isDistorted && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-amber-50/90 border border-amber-200 rounded-xl p-4 text-amber-900 shadow-xs"
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700 border border-amber-200 shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-mono font-bold text-amber-900 uppercase tracking-wider">
                  DISTORSIÓN OPERATIVA // SATURACIÓN DE VARIEDAD CON DÉFICIT DE PROFUNDIDAD
                </h3>
                <button
                  type="button"
                  onClick={() => onNavigateToTab('alertas')}
                  className="text-[10px] font-mono bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 px-3 py-1 rounded-md font-bold uppercase transition-colors cursor-pointer"
                >
                  VER ALERTAS
                </button>
              </div>
              <p className="text-xs text-amber-800 leading-relaxed mt-1 font-sans">
                La tienda tiene <strong className="font-mono font-bold">+{difSkus.toLocaleString()} SKUs</strong> adicionales en exhibición pero un déficit de <strong className="font-mono font-bold">{Math.abs(difPiezas).toLocaleString()} piezas</strong> de profundidad.
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* 2. MATRIZ DE 4 KPIS PRIMARIOS (DIAGNÓSTICO ESTRATÉGICO) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: FRENTES DE EXHIBICIÓN (SKUs) */}
        <motion.div
          id="tile-skus-depth"
          whileHover={{ y: -1 }}
          transition={{ duration: 0.12 }}
          className="bg-white border border-zinc-200/80 rounded-xl p-4.5 flex flex-col justify-between shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative"
        >
          <span className="absolute top-1.5 left-1.5 w-1.5 h-1.5 border-t border-l border-zinc-300 pointer-events-none" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 border-t border-r border-zinc-300 pointer-events-none" />

          <div className="flex justify-between items-start">
            <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider">
              FRENTES EXHIBICIÓN
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono border ${
                  difSkus === 0
                    ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                    : difSkus > 0
                    ? 'text-rose-800 bg-rose-50 border-rose-200'
                    : 'text-amber-800 bg-amber-50 border-amber-200'
                }`}
              >
                {difSkus === 0 ? 'CALZADO EXACTO' : difSkus > 0 ? `+${difSkus} EXCESO` : `${difSkus} DÉFICIT`}
              </span>
              <CardInfoButton
                title="Frentes y Variedad de SKUs"
                description="Cantidad de modelos o frentes distintos activos en piso versus los frentes disponibles en mobiliario."
                formula="Diferencia = SKUs Activos - Frentes Objetivo"
              />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-zinc-900 tabular-nums tracking-tight font-mono">
                {totSkusAct}
                <span className="text-xs font-normal text-zinc-400 ml-1.5 font-mono">SKUS</span>
              </div>
              <span
                className={`text-[10px] font-mono font-medium ${
                  weeklyDeltaSkus >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {weeklyDeltaSkus >= 0 ? `+${weeklyDeltaSkus}` : weeklyDeltaSkus} vs sem. ant.
              </span>
            </div>
            {/* Recessed Concave Bar */}
            <div className="w-full bg-zinc-100 border border-zinc-200/80 h-2 rounded-full mt-2.5 overflow-hidden p-0.5 shadow-[inset_0_1px_2px_rgba(0,0,0,0.04)]">
              <div
                className="bg-zinc-800 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, totSkusIdeal > 0 ? (totSkusAct / totSkusIdeal) * 100 : 0)}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
            <span>OBJETIVO: {totSkusIdeal} FRENTES</span>
            <span className="text-zinc-800 font-semibold">{totSkusIdeal > 0 ? ((totSkusAct / totSkusIdeal) * 100).toFixed(0) : 0}%</span>
          </div>
        </motion.div>

        {/* KPI 2: PIEZAS FÍSICAS (Stock Real vs Objetivo) */}
        <motion.div
          id="tile-pieces-stock"
          whileHover={{ y: -1 }}
          transition={{ duration: 0.12 }}
          className="bg-white border border-zinc-200/80 rounded-xl p-4.5 flex flex-col justify-between shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative"
        >
          <span className="absolute top-1.5 left-1.5 w-1.5 h-1.5 border-t border-l border-zinc-300 pointer-events-none" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 border-t border-r border-zinc-300 pointer-events-none" />

          <div className="flex justify-between items-start">
            <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider">
              PIEZAS FÍSICAS
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono border ${
                  difPiezas >= 0
                    ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                    : 'text-amber-800 bg-amber-50 border-amber-200'
                }`}
              >
                {difPiezas >= 0 ? `+${difPiezas.toLocaleString()} UDS` : `${difPiezas.toLocaleString()} UDS`}
              </span>
              <CardInfoButton
                title="Volumen Físico de Piezas"
                description="Total de unidades en inventario frente a la capacidad de stock ideal calculada para la tienda."
                formula="Diferencia = Piezas Actuales - Piezas Ideales"
              />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-zinc-900 tabular-nums tracking-tight font-mono">
                {totPiezasAct.toLocaleString()}
                <span className="text-xs font-normal text-zinc-400 ml-1.5 font-mono">UDS</span>
              </div>
              <span
                className={`text-[10px] font-mono font-medium ${
                  weeklyDeltaPiezas >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {weeklyDeltaPiezas >= 0 ? `+${weeklyDeltaPiezas.toLocaleString()}` : weeklyDeltaPiezas.toLocaleString()} vs sem. ant.
              </span>
            </div>
            {/* Recessed Concave Bar */}
            <div className="w-full bg-zinc-100 border border-zinc-200/80 h-2 rounded-full mt-2.5 overflow-hidden p-0.5 shadow-[inset_0_1px_2px_rgba(0,0,0,0.04)]">
              <div
                className="bg-zinc-800 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, pctLlenado)}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
            <span>OBJ: {totPiezasIdeal.toLocaleString()} UDS</span>
            <span className="text-zinc-800 font-bold font-mono">${(totalValuation / 1000).toFixed(1)}k USD</span>
          </div>
        </motion.div>

        {/* KPI 3: CURVAS ROTAS */}
        <motion.div
          id="tile-broken-curves"
          whileHover={{ y: -1 }}
          transition={{ duration: 0.12 }}
          className="bg-white border border-zinc-200/80 rounded-xl p-4.5 flex flex-col justify-between shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative"
        >
          <span className="absolute top-1.5 left-1.5 w-1.5 h-1.5 border-t border-l border-zinc-300 pointer-events-none" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 border-t border-r border-zinc-300 pointer-events-none" />

          <div className="flex justify-between items-start">
            <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider">
              CURVAS ROTAS
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono border ${
                  quiebresCurvasCount === 0
                    ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                    : 'text-rose-800 bg-rose-50 border-rose-200'
                }`}
              >
                {quiebresCurvasCount === 0 ? 'CURVAS SANAS' : `${quiebresCurvasCount} CRÍTICAS`}
              </span>
              <CardInfoButton
                title="Quiebres de Curva en Tallas Core"
                description="Modelos activos que tienen quiebre de stock en sus tallas de mayor venta (ej. US 8-10 / 26-28)."
                operationalImpact="Genera pérdida directa de venta inmediata aunque el modelo tenga stock en extremos."
              />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-zinc-900 tabular-nums tracking-tight font-mono">
                {quiebresCurvasCount}
                <span className="text-xs font-normal text-zinc-400 ml-1.5 font-mono">SKUS</span>
              </div>
              <span
                className={`text-[10px] font-mono font-medium ${
                  weeklyDeltaCurves <= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}
              >
                {weeklyDeltaCurves <= 0 ? `${weeklyDeltaCurves}` : `+${weeklyDeltaCurves}`} vs sem. ant.
              </span>
            </div>
            {/* Recessed Concave Bar */}
            <div className="w-full bg-zinc-100 border border-zinc-200/80 h-2 rounded-full mt-2.5 overflow-hidden p-0.5 shadow-[inset_0_1px_2px_rgba(0,0,0,0.04)]">
              <div
                className="bg-rose-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, quiebresCurvasCount * 10)}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
            <span>TALLAS CENTRALES</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('alertas')}
              className="text-zinc-800 hover:text-zinc-900 font-semibold cursor-pointer underline decoration-zinc-300"
            >
              ALERTAS →
            </button>
          </div>
        </motion.div>

        {/* KPI 4: CAPACIDAD UTILIZADA */}
        <motion.div
          id="tile-occupancy-rate"
          whileHover={{ y: -1 }}
          transition={{ duration: 0.12 }}
          className="bg-white border border-zinc-200/80 rounded-xl p-4.5 flex flex-col justify-between shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative"
        >
          <span className="absolute top-1.5 left-1.5 w-1.5 h-1.5 border-t border-l border-zinc-300 pointer-events-none" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 border-t border-r border-zinc-300 pointer-events-none" />

          <div className="flex justify-between items-start">
            <span className="text-[11px] font-mono font-bold text-zinc-500 uppercase tracking-wider">
              CAPACIDAD UTILIZADA
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`text-[10px] px-2 py-0.5 rounded-full font-bold font-mono border ${
                  pctLlenado >= 85 && pctLlenado <= 110
                    ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                    : pctLlenado < 85
                    ? 'text-amber-800 bg-amber-50 border-amber-200'
                    : 'text-rose-800 bg-rose-50 border-rose-200'
                }`}
              >
                {pctLlenado >= 85 && pctLlenado <= 110
                  ? 'ÓPTIMO (85-110%)'
                  : pctLlenado < 85
                  ? 'DÉFICIT (<85%)'
                  : 'SATURACIÓN (>110%)'}
              </span>
              <CardInfoButton
                title="Tasa de Llenado y Capacidad Utilizada"
                description="Porcentaje del inventario físico actual respecto a la capacidad de frentes y profundidad estándar de la tienda."
                formula="Llenado = (Piezas Actuales / Piezas Ideales) * 100"
              />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-zinc-900 tabular-nums tracking-tight font-mono">
                {pctLlenado.toFixed(1)}
                <span className="text-xs font-normal text-zinc-400 ml-0.5 font-mono">%</span>
              </div>
              <span
                className={`text-[10px] font-mono font-medium ${
                  weeklyDeltaCap >= 0 ? 'text-emerald-600' : 'text-amber-600'
                }`}
              >
                {weeklyDeltaCap >= 0 ? `+${weeklyDeltaCap.toFixed(1)}%` : `${weeklyDeltaCap.toFixed(1)}%`} vs sem. ant.
              </span>
            </div>
            {/* Recessed Concave Bar */}
            <div className="w-full bg-zinc-100 border border-zinc-200/80 h-2 rounded-full mt-2.5 overflow-hidden p-0.5 shadow-[inset_0_1px_2px_rgba(0,0,0,0.04)]">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  pctLlenado >= 85 && pctLlenado <= 110
                    ? 'bg-emerald-500'
                    : pctLlenado < 85
                    ? 'bg-amber-500'
                    : 'bg-rose-500'
                }`}
                style={{ width: `${Math.min(100, Math.max(0, pctLlenado))}%` }}
              />
            </div>
          </div>

          <p className="text-[11px] text-zinc-500 font-mono truncate">
            {difPiezas >= 0 ? `+${difPiezas.toLocaleString()}` : `${difPiezas.toLocaleString()}`} UDS VS ESTÁNDAR
          </p>
        </motion.div>
      </div>

      {/* 2.5 EVOLUCIÓN HISTÓRICA DE VALORACIÓN (ÚLTIMOS 7 DÍAS CON RECHARTS EN MONEDA DURA $ USD) */}
      <ValuationEvolutionChart
        currentValuationUSD={totalValuation}
        bcvRate={bcvRate}
        valuationHistory={valuationHistory}
        selectedStore={selectedStore}
        totalPieces={totPiezasAct}
      />

      {/* 2.6 CONCENTRACIÓN GEOGRÁFICA DE CAPITAL // REGIONAL VALUATION STACKED BAR CHART */}
      <RegionalValuationStackedChart
        inventory={inventory}
        storeProfiles={storeProfiles}
        stores={stores}
        bcvRate={bcvRate}
        selectedStore={selectedStore}
        onSelectStore={onSelectStore}
      />

      {/* 3. PROYECCIÓN DE TENDENCIA // TREND PROJECTION (30 DÍAS CON RECHARTS) */}
      <TrendProjectionChart
        inventory={inventory}
        selectedStore={selectedStore}
        totPiezasAct={totPiezasAct}
        totPiezasIdeal={totPiezasIdeal}
        selectedBrand={selectedBrand}
        onNavigateToTab={onNavigateToTab}
      />

      {/* 4. RESUMEN GENERAL DE CAPACIDAD POR DEPARTAMENTO (Barras de resumen ejecutivo - Desplegable) */}
      <div className="bg-white border border-zinc-200/80 rounded-xl p-4 sm:p-5 shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-4 transition-all">
        {/* Cabecera / Control de Despliegue */}
        <div
          onClick={toggleDeptSummary}
          className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group select-none transition-colors ${
            isDeptSummaryOpen ? 'pb-3 border-b border-zinc-200/80' : ''
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-100 border border-zinc-200 flex items-center justify-center shrink-0 text-zinc-700 group-hover:bg-zinc-200/80 transition-colors">
              <Layers className="w-4 h-4 text-zinc-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-mono font-bold text-zinc-900 uppercase tracking-wider group-hover:text-zinc-700 transition-colors">
                  RESUMEN DE CAPACIDAD POR DEPARTAMENTO
                </h3>
                <span className="text-[10px] font-semibold text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded border border-zinc-200 font-mono">
                  {computedModules.length} departamentos
                </span>
                <CardInfoButton
                  title="Resumen de Capacidad Departamental"
                  description="Compara la carga física de unidades en piso contra la capacidad máxima recomendada de exhibición para Calzado, Textil y Accesorios."
                  formula="Ocupación % = (Piezas Actuales / Capacidad Ideal) * 100"
                  operationalImpact="Permite identificar desbalances de espacio entre géneros (Hombre, Mujer, Niños) para reasignar metraje o rebalancear stock."
                />
              </div>
              <p className="text-[11px] text-zinc-500 mt-0.5 font-sans">
                Ocupación, balance de piezas y distribución de áreas (Caballero, Dama, Niños)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 self-start sm:self-auto">
            {isDeptSummaryOpen && (
              <div className="hidden lg:flex items-center gap-3 text-[10px] font-mono text-zinc-500 bg-zinc-50 px-2.5 py-1 rounded-md border border-zinc-200">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span> &lt;85% Déficit
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span> 85-110% Óptimo
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span> &gt;110% Saturado
                </span>
              </div>
            )}

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleDeptSummary();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-lg text-xs font-medium transition-colors cursor-pointer"
            >
              <span>{isDeptSummaryOpen ? 'Ocultar Listado' : 'Desplegar Listado'}</span>
              {isDeptSummaryOpen ? (
                <ChevronUp className="w-3.5 h-3.5 text-zinc-600" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-zinc-600" />
              )}
            </button>
          </div>
        </div>

        {/* Executive Department Progress Bars Cards - Desplegable */}
        {isDeptSummaryOpen && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-in fade-in duration-200">
            {computedModules.map((mod) => {
              const deptIcons: Record<string, string> = {
                CALZADO: '👟',
                TEXTIL: '👕',
                ACCESORIOS: '🎒',
              };
              const isHealthy = mod.porcentajeOcupacion >= 85 && mod.porcentajeOcupacion <= 110;
              const isLow = mod.porcentajeOcupacion < 85;

              // Area breakdown
              const areasList = mod.esGeneral
                ? [mod.areaGeneral || mod.areas.GENERAL].filter(Boolean)
                : (['CABALLERO', 'DAMA', 'NIÑOS'] as GenderArea[]).map((g) => mod.areas[g]).filter(Boolean);

              const totalAreaPieces = areasList.reduce((acc, a) => acc + (a?.piezasActual || 0), 0);
              const isAreaExpanded = !!expandedDeptAreas[mod.departamento];

              return (
                <div
                  key={mod.departamento}
                  className="bg-zinc-50 border border-zinc-200 rounded-xl p-4 flex flex-col justify-between space-y-3 shadow-xs"
                >
                  {/* Dept Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{deptIcons[mod.departamento] || '📦'}</span>
                      <div>
                        <h4 className="text-xs font-mono font-bold text-zinc-900 uppercase">
                          {mod.departamento}
                        </h4>
                        <span className="text-[10px] text-zinc-500 font-mono">
                          {mod.profundidadTarget} pzs/frente
                        </span>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${
                        isHealthy
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : isLow
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-rose-50 text-rose-800 border-rose-200'
                      }`}
                    >
                      {mod.porcentajeOcupacion.toFixed(1)}%
                    </span>
                  </div>

                  {/* Main Occupancy Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-mono">
                      <span className="text-zinc-500">Piezas:</span>
                      <span className="font-bold text-zinc-900">
                        {mod.piezasActual.toLocaleString()}{' '}
                        <span className="text-zinc-400 font-normal">/ {mod.piezasIdeal.toLocaleString()}</span>
                      </span>
                    </div>
                    <div className="w-full bg-white border border-zinc-200 h-2.5 rounded-full overflow-hidden p-0.5 shadow-inner">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isHealthy ? 'bg-emerald-500' : isLow ? 'bg-amber-500' : 'bg-rose-500'
                        }`}
                        style={{ width: `${Math.min(100, Math.max(0, mod.porcentajeOcupacion))}%` }}
                      />
                    </div>
                  </div>

                  {/* Sub-Metrics: SKUs and Valuation */}
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-zinc-200/80 text-[11px] font-mono">
                    <div>
                      <span className="text-zinc-400 block text-[10px]">SKUS ACTIVOS</span>
                      <span className="font-bold text-zinc-800">
                        {mod.skusActual} <span className="text-zinc-400 font-normal">/ {mod.skusIdeal}</span>
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-zinc-400 block text-[10px]">VALUACIÓN</span>
                      <span className="font-bold text-zinc-800">
                        ${(mod.valoracionTotal / 1000).toFixed(1)}k
                      </span>
                    </div>
                  </div>

                  {/* Segmented Area Distribution Bar (Caballero / Dama / Niños) */}
                  {areasList.length > 0 && totalAreaPieces > 0 && (
                    <div className="space-y-1.5 pt-1 border-t border-zinc-200/80">
                      <div
                        onClick={() => toggleDeptArea(mod.departamento)}
                        className="flex items-center justify-between cursor-pointer hover:text-zinc-900 group/area py-0.5 select-none"
                      >
                        <span className="text-[10px] font-mono text-zinc-400 group-hover/area:text-zinc-600 uppercase tracking-wider block">
                          Distribución por Áreas
                        </span>
                        <span className="text-[10px] font-mono text-zinc-400 group-hover/area:text-zinc-700 flex items-center gap-0.5">
                          <span>{isAreaExpanded ? 'Ocultar' : 'Ver detalle'}</span>
                          {isAreaExpanded ? (
                            <ChevronUp className="w-3 h-3 text-zinc-500" />
                          ) : (
                            <ChevronDown className="w-3 h-3 text-zinc-500" />
                          )}
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full overflow-hidden flex bg-zinc-200">
                        {areasList.map((a, idx) => {
                          const pct = totalAreaPieces > 0 ? (a!.piezasActual / totalAreaPieces) * 100 : 0;
                          const colors = ['bg-blue-600', 'bg-purple-600', 'bg-amber-500'];
                          return (
                            <div
                              key={a!.area}
                              style={{ width: `${pct}%` }}
                              className={`${colors[idx % colors.length]} h-full`}
                              title={`${a!.areaLabel}: ${a!.piezasActual} uds (${pct.toFixed(0)}%)`}
                            />
                          );
                        })}
                      </div>
                      <div className="flex flex-wrap items-center justify-between text-[10px] font-mono text-zinc-600 pt-0.5">
                        {areasList.map((a, idx) => {
                          const pct = totalAreaPieces > 0 ? (a!.piezasActual / totalAreaPieces) * 100 : 0;
                          const dots = ['bg-blue-600', 'bg-purple-600', 'bg-amber-500'];
                          return (
                            <span key={a!.area} className="flex items-center gap-1">
                              <span className={`w-1.5 h-1.5 rounded-full ${dots[idx % dots.length]}`} />
                              <span>{a!.areaLabel}: {pct.toFixed(0)}%</span>
                            </span>
                          );
                        })}
                      </div>

                      {/* Desglose desplegable detallado de cada área */}
                      {isAreaExpanded && (
                        <div className="pt-2 border-t border-zinc-200/70 space-y-1.5 text-[10px] font-mono animate-in fade-in duration-150">
                          {areasList.map((a) => {
                            const areaOccupancy = a!.piezasIdeal > 0 ? (a!.piezasActual / a!.piezasIdeal) * 100 : 0;
                            return (
                              <div key={a!.area} className="flex items-center justify-between bg-white px-2 py-1 rounded border border-zinc-200/80 shadow-2xs">
                                <span className="font-semibold text-zinc-700">{a!.areaLabel}</span>
                                <div className="flex items-center gap-2">
                                  <span className="text-zinc-500">{a!.piezasActual} / {a!.piezasIdeal} uds</span>
                                  <span className={`px-1.5 py-0.2 rounded font-bold ${
                                    areaOccupancy >= 85 && areaOccupancy <= 110
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : areaOccupancy < 85
                                      ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                                  }`}>
                                    {areaOccupancy.toFixed(0)}%
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. REUBICACIÓN EN MANDO: Matriz Comparativa de Rendimiento y Capacidad por Tienda */}
      <NetworkMatrixCard
        stores={stores}
        inventory={inventory}
        storeProfiles={storeProfiles}
        storeCapacities={storeCapacities}
        capacityConfig={capacityConfig}
        alerts={networkAlerts || alerts}
        onSelectStore={(st) => onSelectStore?.(st)}
        onNavigateToTab={onNavigateToTab}
        onOpenRegisterStore={onOpenRegisterStore}
        onDeleteStore={onDeleteStore}
        selectedStore={selectedStore}
        selectedBrand={selectedBrand}
        onSelectBrand={onSelectBrand}
        selectedConcept={selectedConcept}
        searchTerm={searchTerm}
        onResetFilters={handleResetAllFilters}
      />

      {/* 5. TABLA DE ARTÍCULOS QUE REQUIEREN ATENCIÓN (DESPLEGABLE / COMPACTA) */}
      <div
        id="articulos-atencion-section"
        className="bg-white border border-zinc-200/80 rounded-xl p-4 sm:p-5 shadow-[0_1px_3px_rgba(0,0,0,0.02)] transition-all scroll-mt-6"
      >
        {/* Cabecera / Control de Despliegue */}
        <div
          onClick={toggleAttentionDetail}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group select-none"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0 text-amber-600">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-mono font-bold text-zinc-900 uppercase tracking-wider flex items-center gap-2">
                  <span>ARTÍCULOS QUE REQUIEREN ATENCIÓN // DETALLE DE SKUS CON ALERTA</span>
                </h3>
                <CardInfoButton
                  title="Artículos que Requieren Atención Operativa"
                  description="Listado exhaustivo de SKUs con desbalance crítico: quiebres de tallas centrales, acumulación de monotallas, sobrestock o riesgo inminente de obsolescencia."
                  formula="Alerta = Quiebre de Curva OR Monotalla OR Sobrestock (>115%) OR Aging (>90 días)"
                  operationalImpact="Guía prioritaria de acción para redistribuir unidades hacia tiendas deficitarias o coordinar promociones de salida."
                />
              </div>
              <p className="text-[11px] text-zinc-500 mt-0.5 font-sans">
                Listado filtrado para productos con quiebre de curva, monotalla, sobrestock o riesgo de aging
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
              {filteredTableItems.length.toLocaleString()} items con atención requerida
            </span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleAttentionDetail();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-lg text-xs font-medium transition-colors cursor-pointer"
            >
              <span>{isAttentionDetailOpen ? 'Ocultar Detalle' : 'Desplegar Detalle'}</span>
              {isAttentionDetailOpen ? (
                <ChevronUp className="w-3.5 h-3.5 text-zinc-600" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-zinc-600" />
              )}
            </button>
          </div>
        </div>

        {/* Detalle Desplegable */}
        {isAttentionDetailOpen && (
          <div className="pt-4 border-t border-zinc-100 mt-4 space-y-4 animate-in fade-in duration-200">
            {/* Filtros por Departamento (sin buscador de texto) */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto py-0.5">
                <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-wider mr-1 shrink-0">
                  Departamento:
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setTableDept('TODAS');
                    setTablePage(1);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold whitespace-nowrap cursor-pointer transition-all ${
                    tableDept === 'TODAS'
                      ? 'bg-zinc-900 text-white shadow-xs'
                      : 'bg-zinc-50 text-zinc-600 hover:text-zinc-900 border border-zinc-200'
                  }`}
                >
                  TODOS
                </button>
                {availableDepts.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => {
                      setTableDept(d);
                      setTablePage(1);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold whitespace-nowrap cursor-pointer transition-all ${
                      tableDept === d
                        ? 'bg-zinc-900 text-white shadow-xs'
                        : 'bg-zinc-50 text-zinc-600 hover:text-zinc-900 border border-zinc-200'
                    }`}
                  >
                    {(d || '').toUpperCase()}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] text-zinc-500 font-sans italic hidden md:inline">
                  * Haz clic sobre un artículo para ver su curva de tallas
                </span>
                <button
                  type="button"
                  onClick={() => onNavigateToTab('detalle')}
                  className="text-xs text-zinc-700 hover:text-zinc-900 font-semibold underline decoration-zinc-400 cursor-pointer"
                >
                  Ver tabla completa →
                </button>
              </div>
            </div>

            {/* Table Content */}
            <div className="overflow-x-auto rounded-lg border border-zinc-200/80">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-zinc-50 text-[10px] text-zinc-500 uppercase border-b border-zinc-200">
                  <tr>
                    <th
                      onClick={() => handleSort('Referencia')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>SKU / MODELO</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Marca')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>MARCA</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Departamento')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>DEPTO</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Tienda')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>TIENDA</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Talla')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors text-center"
                    >
                      <div className="flex items-center justify-center gap-1">
                        <span>TALLA</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Stock')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors text-right"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>STOCK</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('Valoracion')}
                      className="py-2.5 px-3 cursor-pointer hover:text-zinc-900 transition-colors text-right"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>VALUACIÓN ($ USD)</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </div>
                    </th>
                    <th className="py-2.5 px-3 text-center">MOTIVO DE ATENCIÓN</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 text-zinc-700">
                  {paginatedTableItems.map((item, idx) => {
                    const itemRefLower = (item.Referencia || '').toLowerCase();
                    const itemStoreLower = (item.Tienda || '').toLowerCase();
                    const alertItem = attentionMap.get(`${itemRefLower}__${itemStoreLower}`) || attentionMap.get(itemRefLower);

                    const isBroken = brokenSkusSet.has(itemRefLower);
                    const isOrphan = orphanSkusSet.has(itemRefLower);
                    const isAging = agingSkusSet.has(itemRefLower);
                    const isOverstock = overstockSkusSet.has(itemRefLower);
                    const val = (item.Stock || 0) * (item.ValorUnitario || 0);

                    return (
                      <tr
                        key={`${item.Referencia}-${item.Talla}-${item.Tienda}-${idx}`}
                        onClick={() => {
                          if (onNavigateToCurveSku) {
                            onNavigateToCurveSku(item.Referencia);
                          } else {
                            onNavigateToTab('alertas');
                          }
                        }}
                        className="hover:bg-amber-50/50 cursor-pointer transition-colors group"
                        title={`Haz clic para ver la curva de tallas de ${item.Referencia}`}
                      >
                        <td className="py-2.5 px-3 font-bold text-zinc-900">
                          <div className="flex items-center gap-1.5">
                            <span className="group-hover:text-amber-700 group-hover:underline transition-colors">
                              {item.Referencia}
                            </span>
                            <ExternalLink className="w-3 h-3 text-zinc-400 opacity-0 group-hover:opacity-100 group-hover:text-amber-600 transition-opacity" />
                          </div>
                          {item.Modelo && <span className="text-[10px] text-zinc-400 block font-normal">{item.Modelo}</span>}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-zinc-800">
                          {item.Marca}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-zinc-600">
                          {item.Departamento}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-zinc-700">
                          <span className="inline-flex items-center gap-1">
                            <span className="text-zinc-400">🏬</span>
                            <span className="font-medium text-xs truncate max-w-[130px]">{item.Tienda}</span>
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold">
                          <span className="px-2 py-0.5 rounded bg-zinc-100 border border-zinc-200 text-zinc-800">
                            {item.Talla}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-zinc-900">
                          {item.Stock}
                        </td>
                        <td
                          className="py-2.5 px-3 text-right font-semibold text-zinc-800 whitespace-nowrap"
                          title={item.ValoracionBs !== undefined ? `Original: Bs. ${item.ValoracionBs.toLocaleString('es-VE')}` : undefined}
                        >
                          ${val.toLocaleString()} <span className="text-[10px] text-zinc-500 font-mono">USD</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          {isBroken ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              QUIEBRE CORE
                            </span>
                          ) : isOrphan ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                              MONOTALLA
                            </span>
                          ) : isAging ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                              AGING / CRÍTICO
                            </span>
                          ) : isOverstock ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                              SOBRESTOCK
                            </span>
                          ) : alertItem ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200 uppercase">
                              {alertItem.TipoDeAlerta}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-100 text-zinc-700 border border-zinc-200">
                              REVISAR
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {paginatedTableItems.length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-zinc-500 font-sans">
                        <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                        <span className="font-semibold text-zinc-800 block text-xs">Sin incidencias pendientes</span>
                        <span className="text-[11px] text-zinc-400">No hay productos que requieran atención inmediata con los filtros seleccionados.</span>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Table Pagination */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs font-mono text-zinc-500">
              <div>
                Mostrando {paginatedTableItems.length} de {filteredTableItems.length} registros (Página {tablePage} de {totalTablePages})
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={tablePage <= 1}
                  onClick={() => setTablePage((p) => Math.max(1, p - 1))}
                  className="p-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="px-3 py-1 font-bold text-zinc-800">
                  {tablePage} / {totalTablePages}
                </span>
                <button
                  type="button"
                  disabled={tablePage >= totalTablePages}
                  onClick={() => setTablePage((p) => Math.min(totalTablePages, p + 1))}
                  className="p-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
