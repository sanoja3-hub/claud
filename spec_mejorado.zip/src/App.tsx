/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  Database,
  ExternalLink,
  Eye,
  Grid,
  Layers,
  RotateCcw,
  Settings2,
  Sliders,
  Sparkles,
  Truck,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertStatus,
  CapacityMatrixConfig,
  InventoryItem,
  RuleEngineConfig,
  StoreDistance,
  StoreProfile,
  TransferStatus,
  TransferSuggestion,
  ValuationHistoryPoint,
} from './types';
import {
  fetchOfficialBcvRate,
  getStoredBcvRate,
  saveBcvRateToStorage,
} from './utils/bcvService';
import {
  DEFAULT_CAPACITY_MATRIX,
  DEFAULT_STORE_DISTANCES,
  INITIAL_STORE_CAPACITIES,
  INITIAL_STORE_PROFILES,
} from './data/defaultMatrix';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { UploadModal } from './components/UploadModal';
import { DashboardTab } from './components/DashboardTab';
import { AlertsTab } from './components/AlertsTab';
import { SizeCurveTab } from './components/SizeCurveTab';
import { TransfersTab } from './components/TransfersTab';
import { CapacityEditorTab } from './components/CapacityEditorTab';
import { InventoryDetailTab } from './components/InventoryDetailTab';
import { ManagerTab } from './components/ManagerTab';
import { RegisterStoreModal } from './components/RegisterStoreModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { WhatIfSimulatorModal } from './components/WhatIfSimulatorModal';
import { RuleEngineModal } from './components/RuleEngineModal';
import { AppManualModal } from './components/AppManualModal';
import {
  calcularAgingBuckets,
  calcularModulosDepartamentosYAreas,
  calcularRendimientoEspacial,
  calcularResumenCapacidad,
  calcularRiesgoFinanciero,
  calcularSugerenciasTraslados,
  diagnosticarAlertas,
  generarPivotCurvas,
} from './utils/analysisEngine';
import { exportarExcelEjecutivo } from './utils/excelExporter';
import { recalculateNetworkDistances } from './utils/geoDistance';
import {
  DEFAULT_RULE_CONFIG,
  exportAppBackupJSON,
  importAppBackupJSON,
  loadAppStateFromStorage,
  saveAppStateToStorage,
} from './utils/storageService';
import type { User } from 'firebase/auth';
import {
  testFirestoreConnection,
  FIRESTORE_UPGRADE_URL,
  FIRESTORE_PRICING_URL,
} from './firebase/config';
import {
  loginWithGoogle,
  logoutUser,
  subscribeToAuth,
  pushFullStateToCloud,
  pullFullStateFromCloud,
  isCloudQuotaExceeded,
  resetCloudQuotaState,
} from './firebase/cloudSyncService';
import { isQuotaExceededError } from './firebase/errors';

/** Guarantees that every item in inventory has a strictly unique `id` to prevent React key collisions */
export function ensureUniqueInventoryIds(items: InventoryItem[]): InventoryItem[] {
  const seen = new Set<string>();
  return items.map((it, idx) => {
    let id = it.id?.trim() || `${it.Tienda}-${it.Referencia}-${it.Talla}-${idx}`;
    if (seen.has(id)) {
      id = `${id}__dup${idx}_${Math.random().toString(36).slice(2, 6)}`;
    }
    seen.add(id);
    return { ...it, id };
  });
}

export default function App() {
  // 1. Initial State: Clean Slate (only officially registered stores)
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [storeProfiles, setStoreProfiles] = useState<StoreProfile[]>([]);
  const [storeCapacities, setStoreCapacities] = useState<Record<string, CapacityMatrixConfig>>({});
  const [storeDistances, setStoreDistances] = useState<StoreDistance>({});
  const [ruleConfig, setRuleConfig] = useState<RuleEngineConfig>(DEFAULT_RULE_CONFIG);
  const [customProductImageUrls, setCustomProductImageUrls] = useState<Record<string, string>>({});
  
  // Cloud & Firebase State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isCloudSyncing, setIsCloudSyncing] = useState<boolean>(false);
  const [lastCloudSync, setLastCloudSync] = useState<string | null>(null);
  const [cloudBannerMsg, setCloudBannerMsg] = useState<string | null>(null);
  const [isQuotaExceeded, setIsQuotaExceeded] = useState<boolean>(() => isCloudQuotaExceeded());
  const hasUserModifiedDataRef = useRef<boolean>(false);

  const [isCustomData, setIsCustomData] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('manager');
  const [selectedStore, setSelectedStore] = useState<string>('TODAS');
  const [selectedBrand, setSelectedBrand] = useState<string>('TODAS');
  const [selectedCurveSku, setSelectedCurveSku] = useState<string | null>(null);
  const [isAttentionDetailOpen, setIsAttentionDetailOpen] = useState<boolean>(false);
  const [hasCurveBack, setHasCurveBack] = useState<boolean>(false);
  const [isTransfersPreviewActive, setIsTransfersPreviewActive] = useState<boolean>(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  
  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isWhatIfOpen, setIsWhatIfOpen] = useState<boolean>(false);
  const [isRuleEngineOpen, setIsRuleEngineOpen] = useState<boolean>(false);
  const [isManualOpen, setIsManualOpen] = useState<boolean>(false);
  const [storeToEditInModal, setStoreToEditInModal] = useState<StoreProfile | null>(null);
  const [transfersSuccessToast, setTransfersSuccessToast] = useState<string | null>(null);

  // BCV Official Exchange Rate state (VES/USD) & 7-day Historical Valuation Evolution
  const [bcvRate, setBcvRate] = useState<number>(() => getStoredBcvRate().rate || 855.66);
  const [valuationHistory, setValuationHistory] = useState<ValuationHistoryPoint[]>([]);

  // Automatically check/update official BCV rate on mount
  useEffect(() => {
    fetchOfficialBcvRate()
      .then((data) => {
        if (data.rate > 0) {
          setBcvRate(data.rate);
        }
      })
      .catch(() => {});
  }, []);

  // Update official BCV exchange rate and re-convert inventory valuation in real-time
  const handleUpdateBcvRate = (newRate: number) => {
    if (!newRate || newRate <= 0) return;
    setBcvRate(newRate);
    saveBcvRateToStorage({
      rate: newRate,
      lastUpdated: new Date().toISOString(),
      source: 'Ajuste de Usuario / Actualización',
      isCustom: true,
    });

    // Recalculate all items in inventory with new rate
    setInventory((prev) =>
      prev.map((it) => {
        const valBs = it.ValoracionBs !== undefined ? it.ValoracionBs : it.Valoracion * bcvRate;
        const valUSD = Math.round((valBs / newRate) * 100) / 100;
        const unitValUSD = it.Stock > 0 ? Math.round((valUSD / it.Stock) * 100) / 100 : 0;
        const unitValBs = it.Stock > 0 ? Math.round((valBs / it.Stock) * 100) / 100 : 0;
        return {
          ...it,
          Valoracion: valUSD,
          ValorUnitario: unitValUSD,
          ValoracionBs: valBs,
          ValorUnitarioBs: unitValBs,
        };
      })
    );
  };

  // Workflow tracking status overrides (PENDIENTE, EN_GESTION, APLICADA, DESCARTADA)
  const [alertStatusOverrides, setAlertStatusOverrides] = useState<
    Record<string, { status: AlertStatus; note?: string; updatedAt: string }>
  >(() => {
    try {
      const saved = localStorage.getItem('cc_alert_status_overrides');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleUpdateAlertStatus = (alertId: string, status: AlertStatus, note?: string) => {
    setAlertStatusOverrides((prev) => {
      const next = {
        ...prev,
        [alertId]: {
          status,
          note,
          updatedAt: new Date().toISOString(),
        },
      };
      try {
        localStorage.setItem('cc_alert_status_overrides', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Default Global Capacity Matrix template
  const [capacityConfig, setCapacityConfig] = useState<CapacityMatrixConfig>(() =>
    JSON.parse(JSON.stringify(DEFAULT_CAPACITY_MATRIX))
  );

  // Load persisted state from IndexedDB on initial mount, purging any old demo stores
  useEffect(() => {
    async function initStorage() {
      try {
        const persisted = await loadAppStateFromStorage();
        if (persisted) {
          const demoStoreNames = new Set([
            'Tienda Centro (Flagship)',
            'Tienda Norte Mall',
            'Tienda Sur Outlet',
            'Tienda Este Plaza',
            'Tienda Oeste Hub',
            'Tienda Flagship Gran Vía',
            'Sucursal Centro Histórico',
            'Tienda Mall Los Dominicos',
          ]);

          // Filter out demo stores from profiles (keep only official user-registered stores)
          const officialProfiles = (persisted.storeProfiles || []).filter(
            (p) =>
              !demoStoreNames.has(p.nombre) &&
              !['demo-', 'sample-', 'mock-'].some((pre) => p.id?.startsWith(pre)) &&
              !['store-1', 'store-2', 'store-3', 'store-4', 'store-5'].includes(p.id)
          );
          setStoreProfiles(officialProfiles);

          // Filter out demo stores from capacities
          const cleanCapacities: Record<string, CapacityMatrixConfig> = {};
          if (persisted.storeCapacities) {
            for (const [stName, cap] of Object.entries(persisted.storeCapacities)) {
              if (!demoStoreNames.has(stName)) {
                cleanCapacities[stName] = cap;
              }
            }
          }
          setStoreCapacities(cleanCapacities);

          // Filter out demo stores from distances
          const cleanDistances: StoreDistance = {};
          if (persisted.storeDistances) {
            for (const [orig, dests] of Object.entries(persisted.storeDistances)) {
              if (!demoStoreNames.has(orig)) {
                if (dests && typeof dests === 'object') {
                  const sub: Record<string, number> = {};
                  for (const [dest, km] of Object.entries(dests as Record<string, any>)) {
                    if (!demoStoreNames.has(dest)) {
                      sub[dest] = Number(km) || 0;
                    }
                  }
                  cleanDistances[orig] = sub;
                } else if (typeof dests === 'number') {
                  cleanDistances[orig] = dests;
                }
              }
            }
          }
          setStoreDistances(cleanDistances);

          // Filter out demo stores from inventory if any and ensure unique IDs
          const cleanInventory = ensureUniqueInventoryIds(
            (persisted.inventory || []).filter((it) => !demoStoreNames.has(it.Tienda))
          );
          setInventory(cleanInventory);
          setIsCustomData(cleanInventory.length > 0);

          if (persisted.ruleConfig) setRuleConfig(persisted.ruleConfig);
          if (persisted.customProductImageUrls) setCustomProductImageUrls(persisted.customProductImageUrls);
          if (persisted.bcvRate && persisted.bcvRate > 0) setBcvRate(persisted.bcvRate);
          if (persisted.valuationHistory && Array.isArray(persisted.valuationHistory)) {
            setValuationHistory(persisted.valuationHistory);
          }

          // Force clean save to purge demo stores from IndexedDB/localStorage permanently
          saveAppStateToStorage({
            inventory: cleanInventory,
            storeProfiles: officialProfiles,
            storeCapacities: cleanCapacities,
            storeDistances: cleanDistances,
            ruleConfig: persisted.ruleConfig || DEFAULT_RULE_CONFIG,
            customProductImageUrls: persisted.customProductImageUrls || {},
            bcvRate: persisted.bcvRate || bcvRate,
            valuationHistory: persisted.valuationHistory || [],
            version: 1,
          }).catch(() => {});
        }
      } catch (err) {
        console.warn('Storage initial load notice:', err);
      }
    }
    initStorage();
  }, []);

  // Auto-save state to IndexedDB on change
  // Con debounce (800 ms): cada cambio serializaba y escribía el inventario completo en IndexedDB;
  // con ediciones seguidas eso encadenaba escrituras pesadas innecesarias.
  useEffect(() => {
    if (inventory.length === 0 && storeProfiles.length === 0 && Object.keys(customProductImageUrls).length === 0) {
      return;
    }
    const timer = setTimeout(() => {
      saveAppStateToStorage({
        inventory,
        storeProfiles,
        storeCapacities,
        storeDistances,
        ruleConfig,
        customProductImageUrls,
        bcvRate,
        valuationHistory,
        version: 1,
      }).catch((e) => console.warn('Auto-save notice:', e));
    }, 800);
    return () => clearTimeout(timer);
  }, [inventory, storeProfiles, storeCapacities, storeDistances, ruleConfig, customProductImageUrls, bcvRate, valuationHistory]);

  // Firebase Auth listener and Cloud sync probe
  useEffect(() => {
    testFirestoreConnection(() => {
      setIsQuotaExceeded(true);
    }).catch(() => {});

    const unsubscribe = subscribeToAuth(async (user) => {
      setCurrentUser(user);
      if (user && !isQuotaExceeded && !isCloudQuotaExceeded()) {
        try {
          const cloudData = await pullFullStateFromCloud();
          if (cloudData && (cloudData.inventory.length > 0 || cloudData.storeProfiles.length > 0)) {
            setInventory((prev) => (prev.length === 0 ? ensureUniqueInventoryIds(cloudData.inventory) : prev));
            setStoreProfiles((prev) => (prev.length === 0 ? cloudData.storeProfiles : prev));
            setStoreCapacities((prev) => (Object.keys(prev).length === 0 ? cloudData.storeCapacities : prev));
            setStoreDistances((prev) => (Object.keys(prev).length === 0 ? cloudData.storeDistances : prev));
            if (cloudData.ruleConfig) setRuleConfig(cloudData.ruleConfig);
            setIsCustomData(cloudData.inventory.length > 0);
            setLastCloudSync(new Date().toISOString());
            setCloudBannerMsg('Conectado a Firestore. Datos en la nube sincronizados.');
            setTimeout(() => setCloudBannerMsg(null), 4000);
          }
        } catch (e) {
          if (isQuotaExceededError(e)) {
            setIsQuotaExceeded(true);
          } else {
            console.warn('Initial cloud sync notice:', e);
          }
        }
      }
    });
    return () => unsubscribe();
  }, [isQuotaExceeded]);

  // Auto-sync to Cloud Firestore when user is authenticated and user actively made data changes
  useEffect(() => {
    if (!currentUser) return;
    if (isQuotaExceeded) return;
    if (!hasUserModifiedDataRef.current) return;
    if (inventory.length === 0 && storeProfiles.length === 0) return;

    const timer = setTimeout(async () => {
      try {
        setIsCloudSyncing(true);
        await pushFullStateToCloud({
          inventory,
          storeProfiles,
          storeCapacities,
          storeDistances,
          ruleConfig,
        });
        setLastCloudSync(new Date().toISOString());
        hasUserModifiedDataRef.current = false;
      } catch (err: any) {
        if (isQuotaExceededError(err)) {
          setIsQuotaExceeded(true);
          console.warn('Cloud auto-sync paused: Firestore quota exceeded.');
        } else {
          console.warn('Cloud auto-sync notice:', err);
        }
      } finally {
        setIsCloudSyncing(false);
      }
    }, 12000);

    return () => clearTimeout(timer);
  }, [currentUser, inventory, storeProfiles, storeCapacities, storeDistances, ruleConfig, isQuotaExceeded]);

  const handleLoginGoogle = async () => {
    try {
      setIsCloudSyncing(true);
      const user = await loginWithGoogle();
      setCurrentUser(user);
      const cloudData = await pullFullStateFromCloud();
      if (cloudData && (cloudData.inventory.length > 0 || cloudData.storeProfiles.length > 0)) {
        setInventory(ensureUniqueInventoryIds(cloudData.inventory));
        setStoreProfiles(cloudData.storeProfiles);
        setStoreCapacities(cloudData.storeCapacities);
        setStoreDistances(cloudData.storeDistances);
        if (cloudData.ruleConfig) setRuleConfig(cloudData.ruleConfig);
        setIsCustomData(cloudData.inventory.length > 0);
        setLastCloudSync(new Date().toISOString());
        setCloudBannerMsg('Sesión iniciada. Datos cargados desde Firestore.');
      } else if (!isQuotaExceeded && (inventory.length > 0 || storeProfiles.length > 0)) {
        await pushFullStateToCloud({
          inventory,
          storeProfiles,
          storeCapacities,
          storeDistances,
          ruleConfig,
        });
        setLastCloudSync(new Date().toISOString());
        setCloudBannerMsg('Sesión iniciada. Inventario actual sincronizado en la nube.');
      }
      setTimeout(() => setCloudBannerMsg(null), 4000);
    } catch (e: any) {
      if (isQuotaExceededError(e)) {
        setIsQuotaExceeded(true);
        setCloudBannerMsg('Sesión iniciada. Cuota diaria de Firestore alcanzada; operando con persistencia local.');
      } else {
        console.error('Login error:', e);
        setCloudBannerMsg('Error al conectar con Google: ' + (e?.message || 'Intenta de nuevo'));
      }
      setTimeout(() => setCloudBannerMsg(null), 5000);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const handleLogoutGoogle = async () => {
    try {
      await logoutUser();
      setCurrentUser(null);
      setCloudBannerMsg('Sesión cerrada. Tus datos continúan guardados en este dispositivo.');
      setTimeout(() => setCloudBannerMsg(null), 4000);
    } catch (e) {
      console.error('Logout error:', e);
    }
  };

  const handleManualCloudSync = async () => {
    if (!currentUser) {
      handleLoginGoogle();
      return;
    }
    await resetCloudQuotaState();
    setIsQuotaExceeded(false);
    setIsCloudSyncing(true);
    try {
      await pushFullStateToCloud({
        inventory,
        storeProfiles,
        storeCapacities,
        storeDistances,
        ruleConfig,
      });
      setLastCloudSync(new Date().toISOString());
      setCloudBannerMsg('¡Sincronizado! Los datos están guardados en Firebase Firestore.');
      setTimeout(() => setCloudBannerMsg(null), 4000);
    } catch (e: any) {
      if (isQuotaExceededError(e)) {
        setIsQuotaExceeded(true);
        setCloudBannerMsg('Límite de cuota gratuita diaria de Firestore alcanzado (20.000 operaciones/día). Tus datos están seguros en IndexedDB.');
      } else {
        console.error('Manual sync error:', e);
        setCloudBannerMsg('Error al sincronizar con la nube: ' + (e?.message || 'Revisa tu conexión'));
      }
      setTimeout(() => setCloudBannerMsg(null), 5000);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Global Keyboard Shortcut: Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Unique stores list derived from both inventory and registered profiles
  const stores = useMemo(() => {
    const invStores = inventory.map((it) => String(it.Tienda || '')).filter(Boolean);
    const profStores = storeProfiles.map((p) => String(p.nombre || '')).filter(Boolean);
    return Array.from(new Set([...invStores, ...profStores])).sort();
  }, [inventory, storeProfiles]);

  // Unique brands list derived from registered store profiles and active inventory
  const availableBrands = useMemo(() => {
    const brandSet = new Set<string>();

    (storeProfiles || []).forEach((p) => {
      if (!p) return;
      if (selectedStore === 'TODAS' || p.nombre === selectedStore) {
        if (p.marcas && Array.isArray(p.marcas)) {
          p.marcas.forEach((m) => {
            if (m && m.trim()) brandSet.add(m.trim().toUpperCase());
          });
        }
        if (p.marcasCapacidad) {
          Object.keys(p.marcasCapacidad).forEach((m) => {
            if (m && m.trim() && m !== 'GENERAL' && m !== 'GLOBAL') {
              brandSet.add(m.trim().toUpperCase());
            }
          });
        }
      }
    });

    const targetInv = selectedStore === 'TODAS'
      ? inventory
      : (inventory || []).filter((it) => it.Tienda === selectedStore);

    (targetInv || []).forEach((it) => {
      if (it?.Marca && it.Marca.trim()) {
        brandSet.add(it.Marca.trim().toUpperCase());
      }
    });

    return Array.from(brandSet).sort();
  }, [storeProfiles, selectedStore, inventory]);

  // Derived Calculations with storeCapacities support and Transfers Preview Simulation
  const transferSuggestions = useMemo(() => {
    return calcularSugerenciasTraslados(
      inventory || [],
      storeDistances,
      ruleConfig,
      storeProfiles,
      storeCapacities,
      capacityConfig
    );
  }, [inventory, storeDistances, ruleConfig, storeProfiles, storeCapacities, capacityConfig]);

  // If simulation/preview is active, effective inventory projects the transfers
  const effectiveInventory = useMemo(() => {
    if (!isTransfersPreviewActive || !transferSuggestions || transferSuggestions.length === 0) {
      return inventory || [];
    }
    const simulated = JSON.parse(JSON.stringify(inventory || [])) as InventoryItem[];
    (transferSuggestions || []).forEach((sug) => {
      // Decrease stock in origin store
      const originItem = simulated.find(
        (it) => it.Tienda === sug.TiendaOrigen && it.Referencia === sug.Referencia && it.Talla === sug.Talla
      );
      if (originItem) {
        const unitCost = originItem.Stock > 0 ? originItem.Valoracion / originItem.Stock : 50;
        originItem.Stock = Math.max(0, originItem.Stock - sug.UnidadesSugeridas);
        originItem.Valoracion = originItem.Stock * unitCost;
      }

      // Increase stock in destination store
      const destItem = simulated.find(
        (it) => it.Tienda === sug.TiendaDestino && it.Referencia === sug.Referencia && it.Talla === sug.Talla
      );
      if (destItem) {
        const unitCost = destItem.Stock > 0 ? destItem.Valoracion / destItem.Stock : 50;
        destItem.Stock += sug.UnidadesSugeridas;
        destItem.Valoracion = destItem.Stock * unitCost;
      } else if (originItem) {
        const unitCost = originItem.Stock > 0 ? originItem.Valoracion / Math.max(1, originItem.Stock) : 50;
        simulated.push({
          ...originItem,
          id: `sim-transfer-${sug.TiendaDestino}-${sug.Referencia}-${sug.Talla}`,
          Tienda: sug.TiendaDestino,
          Stock: sug.UnidadesSugeridas,
          Valoracion: sug.UnidadesSugeridas * unitCost,
          SKU_Talla: `${sug.Referencia} | ${sug.Talla}`,
        });
      }
    });

    return simulated.filter((it) => it.Stock > 0);
  }, [inventory, isTransfersPreviewActive, transferSuggestions]);

  const summaryRows = useMemo(() => {
    return calcularResumenCapacidad(
      effectiveInventory,
      capacityConfig,
      selectedStore,
      storeCapacities,
      selectedBrand,
      storeProfiles
    );
  }, [effectiveInventory, capacityConfig, selectedStore, storeCapacities, selectedBrand, storeProfiles]);

  const moduleSummaries = useMemo(() => {
    return calcularModulosDepartamentosYAreas(
      effectiveInventory,
      capacityConfig,
      selectedStore,
      storeCapacities,
      selectedBrand,
      storeProfiles
    );
  }, [effectiveInventory, capacityConfig, selectedStore, storeCapacities, selectedBrand, storeProfiles]);

  // Network-wide alerts calculated once for the entire commercial chain (stable across store selections)
  const networkAlerts = useMemo(() => {
    const rawAlerts = diagnosticarAlertas(effectiveInventory, 'TODAS', ruleConfig);
    return rawAlerts.map((a) => {
      const override = alertStatusOverrides[a.id];
      if (override) {
        return {
          ...a,
          status: override.status,
          statusNote: override.note,
          statusUpdatedAt: override.updatedAt,
        };
      }
      return a;
    });
  }, [effectiveInventory, ruleConfig, alertStatusOverrides]);

  // Contextual alerts for the currently active selected store view
  const alerts = useMemo(() => {
    if (!selectedStore || selectedStore === 'TODAS') return networkAlerts;
    return networkAlerts.filter((a) => a.Tienda === selectedStore);
  }, [networkAlerts, selectedStore]);

  const pivotGlobal = useMemo(() => {
    return generarPivotCurvas(effectiveInventory, 'TODAS', 'TODAS', selectedStore);
  }, [effectiveInventory, selectedStore]);

  const totalValuation = useMemo(() => {
    return summaryRows.reduce((acc, r) => acc + r.ValoracionTotal, 0);
  }, [summaryRows]);

  // Advanced Analysis: Financial Risk, Spatial Density, Aging
  const financialRisk = useMemo(() => {
    return calcularRiesgoFinanciero(alerts, effectiveInventory, summaryRows, ruleConfig);
  }, [alerts, effectiveInventory, summaryRows, ruleConfig]);

  const spatialMetrics = useMemo(() => {
    return calcularRendimientoEspacial(effectiveInventory, storeProfiles);
  }, [effectiveInventory, storeProfiles]);

  const agingSummary = useMemo(() => {
    const storeItems = selectedStore === 'TODAS' ? effectiveInventory : effectiveInventory.filter((it) => it.Tienda === selectedStore);
    return calcularAgingBuckets(storeItems);
  }, [effectiveInventory, selectedStore]);

  // Register or edit a store handler
  const handleRegisterStore = (
    profile: StoreProfile,
    capacityMatrix?: CapacityMatrixConfig,
    distances?: Record<string, number>
  ) => {
    hasUserModifiedDataRef.current = true;
    setStoreProfiles((prev) => {
      const idx = prev.findIndex((p) => p.nombre === profile.nombre);
      const next = idx >= 0 ? [...prev] : [...prev, profile];
      if (idx >= 0) {
        next[idx] = profile;
      }

      // Automatically recalculate network distances using GPS coordinates
      setStoreDistances((prevDist) => {
        const updated = recalculateNetworkDistances(next, prevDist);
        if (distances) {
          Object.entries(distances).forEach(([target, km]) => {
            if (!updated[profile.nombre]) updated[profile.nombre] = {};
            if (!updated[target]) updated[target] = {};
            updated[profile.nombre][target] = km;
            updated[target][profile.nombre] = km;
            (updated as any)[`${profile.nombre}-${target}`] = km;
            (updated as any)[`${target}-${profile.nombre}`] = km;
          });
        }
        return updated;
      });

      return next;
    });

    if (capacityMatrix) {
      setStoreCapacities((prev) => ({
        ...prev,
        [profile.nombre]: capacityMatrix,
      }));
    }

    if (!selectedStore || selectedStore === 'TODAS') {
      setSelectedStore(profile.nombre);
    }
  };

  // Delete a store and its inventory
  const handleDeleteStore = (storeName: string) => {
    hasUserModifiedDataRef.current = true;
    setInventory((prev) => prev.filter((it) => it.Tienda !== storeName));
    setStoreProfiles((prev) => prev.filter((p) => p.nombre !== storeName));
    setStoreCapacities((prev) => {
      const next = { ...prev };
      delete next[storeName];
      return next;
    });
    setStoreDistances((prev) => {
      const next: StoreDistance = {};
      Object.keys(prev).forEach((k) => {
        if (!k.startsWith(`${storeName}-`) && !k.endsWith(`-${storeName}`)) {
          next[k] = prev[k];
        }
      });
      return next;
    });
    if (selectedStore === storeName) {
      setSelectedStore('TODAS');
    }
  };

  // Open register modal to edit specific store
  const handleOpenRegisterModal = (storeProfile?: StoreProfile) => {
    setStoreToEditInModal(storeProfile || null);
    setIsRegisterModalOpen(true);
  };

  // Update profile from editor
  const handleUpdateStoreProfile = (updatedProfile: StoreProfile) => {
    hasUserModifiedDataRef.current = true;
    setStoreProfiles((prev) =>
      prev.map((p) => (p.nombre === updatedProfile.nombre ? updatedProfile : p))
    );
  };

  // Delete a single inventory item by ID or composite reference
  const handleDeleteInventoryItem = (itemId: string) => {
    hasUserModifiedDataRef.current = true;
    setInventory((prev) =>
      prev.filter((it, idx) => {
        const id = it.id?.trim() || `${it.Tienda}-${it.Referencia}-${it.Talla}-${idx}`;
        const fallbackId = `inv-${idx}`;
        const key1 = `${it.Tienda}__${it.Referencia}__${it.Talla}`;
        const key2 = `${it.Referencia}__${it.Talla}`;
        return (
          id !== itemId &&
          fallbackId !== itemId &&
          key1 !== itemId &&
          key2 !== itemId &&
          it.id !== itemId
        );
      })
    );
  };

  // Update a single inventory item (e.g. correct Talla or Stock)
  const handleUpdateInventoryItem = (updatedItem: InventoryItem) => {
    hasUserModifiedDataRef.current = true;
    setInventory((prev) =>
      prev.map((it, idx) => ((it.id || `inv-${idx}`) === updatedItem.id ? updatedItem : it))
    );
  };

  // Delete multiple inventory items by IDs or composite keys
  const handleDeleteInventoryBatch = (itemIds: string[]) => {
    hasUserModifiedDataRef.current = true;
    const deleteSet = new Set(itemIds);
    setInventory((prev) =>
      prev.filter((it, idx) => {
        const id = it.id?.trim() || `${it.Tienda}-${it.Referencia}-${it.Talla}-${idx}`;
        const fallbackId = `inv-${idx}`;
        const key1 = `${it.Tienda}__${it.Referencia}__${it.Talla}`;
        const key2 = `${it.Referencia}__${it.Talla}`;
        return (
          !deleteSet.has(id) &&
          !deleteSet.has(fallbackId) &&
          !deleteSet.has(key1) &&
          !deleteSet.has(key2) &&
          !deleteSet.has(it.id || '')
        );
      })
    );
  };

  // Purge all textile rows with numeric sizes directly from inventory state
  const handlePurgeTextileAnomalies = (targetItems?: InventoryItem[]) => {
    hasUserModifiedDataRef.current = true;
    setInventory((prev) => {
      let filtered = prev;

      // 1. If explicit anomalous items were passed from the view, purge by all identifiable keys
      if (targetItems && targetItems.length > 0) {
        const idSet = new Set<string>();
        targetItems.forEach((it, idx) => {
          if (it.id) idSet.add(it.id.trim());
          idSet.add(`${it.Tienda}__${it.Referencia}__${it.Talla}`);
          idSet.add(`${it.Referencia}__${it.Talla}`);
          idSet.add(`inv-${idx}`);
        });

        filtered = filtered.filter((it, idx) => {
          const id = it.id?.trim() || `${it.Tienda}-${it.Referencia}-${it.Talla}-${idx}`;
          const key1 = `${it.Tienda}__${it.Referencia}__${it.Talla}`;
          const key2 = `${it.Referencia}__${it.Talla}`;
          const fallback = `inv-${idx}`;
          if (
            (it.id && idSet.has(it.id.trim())) ||
            idSet.has(id) ||
            idSet.has(key1) ||
            idSet.has(key2) ||
            idSet.has(fallback)
          ) {
            return false;
          }
          return true;
        });
      }

      // 2. Also purge any remaining textile rows with numeric sizes
      filtered = filtered.filter((it) => {
        const isTextil =
          (it.Departamento || '').toUpperCase().includes('TEXTIL') ||
          (it.Familia || '').toUpperCase().includes('APPAREL') ||
          (it.Familia || '').toUpperCase().includes('TEXTIL') ||
          (it.Familia || '').toUpperCase().includes('ROPA') ||
          (it.Seccion || '').toUpperCase().includes('ROPA') ||
          (it.Seccion || '').toUpperCase().includes('TEXTIL');
        if (!isTextil) return true;
        const cleanTalla = String(it.Talla || '').trim();
        const isNumeric = /^\d+(\.\d+)?$/.test(cleanTalla) || (!isNaN(Number(cleanTalla)) && cleanTalla !== '');
        return !isNumeric;
      });

      // Save directly to storage for permanent effect
      saveAppStateToStorage({
        inventory: filtered,
        storeProfiles,
        storeCapacities,
        storeDistances,
        ruleConfig,
        customProductImageUrls,
        bcvRate,
        valuationHistory,
        version: 1,
      }).catch(() => {});

      return filtered;
    });
  };

  // Clear all items of a specific store
  const handleClearStoreInventory = (storeName: string) => {
    hasUserModifiedDataRef.current = true;
    setInventory((prev) => prev.filter((it) => it.Tienda.trim().toLowerCase() !== storeName.trim().toLowerCase()));
  };

  // Data loaded from Excel/CSV upload modal with full multi-file & replace support
  const handleDataLoaded = (
    newItems: InventoryItem[],
    fileNames: string[] = [],
    newStoreProfiles: StoreProfile[] = [],
    newStoreCapacities: Record<string, CapacityMatrixConfig> = {},
    replaceExisting: boolean = true,
    bcvRateUsed?: number
  ) => {
    hasUserModifiedDataRef.current = true;

    const effectiveBcv = bcvRateUsed && bcvRateUsed > 0 ? bcvRateUsed : bcvRate;
    if (bcvRateUsed && bcvRateUsed > 0) {
      setBcvRate(bcvRateUsed);
      saveBcvRateToStorage({
        rate: bcvRateUsed,
        lastUpdated: new Date().toISOString(),
        source: 'Carga de Archivo Excel',
        isCustom: false,
      });
    }

    // Identify unique stores present in the newly uploaded dataset
    const newStoresInItems = Array.from(
      new Set(newItems.map((i) => (i.Tienda || '').trim()))
    ).filter(Boolean);
    const newStoreSet = new Set(newStoresInItems.map((s) => s.toLowerCase()));

    setInventory((prev) => {
      // If replaceExisting is checked (default), purge all previous records for the stores being imported
      let combined: InventoryItem[];
      if (replaceExisting) {
        const remainingOtherStores = prev.filter(
          (it) => !newStoreSet.has((it.Tienda || '').trim().toLowerCase())
        );
        combined = [...remainingOtherStores, ...newItems];
      } else {
        // If append mode, append without purging
        combined = [...prev, ...newItems];
      }
      return ensureUniqueInventoryIds(combined);
    });

    // Record valuation history point for 7-day evolution
    const totalNewValUSD = newItems.reduce((acc, it) => acc + (it.Valoracion || 0), 0);
    const totalNewValBs = newItems.reduce(
      (acc, it) => acc + (it.ValoracionBs !== undefined ? it.ValoracionBs : (it.Valoracion || 0) * effectiveBcv),
      0
    );
    const totalNewPieces = newItems.reduce((acc, it) => acc + (it.Stock || 0), 0);
    const todayStr = new Date().toISOString().split('T')[0];
    const formattedDate = new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });

    setValuationHistory((prev) => {
      const filtered = prev.filter((p) => p.date !== todayStr);
      const newPoint: ValuationHistoryPoint = {
        date: todayStr,
        formattedDate,
        totalValuationUSD: Math.round(totalNewValUSD * 100) / 100,
        totalValuationBs: Math.round(totalNewValBs * 100) / 100,
        totalPieces: totalNewPieces,
        bcvRateUsed: effectiveBcv,
        fileName: fileNames[0] || 'Archivo Excel',
      };
      return [...filtered, newPoint].slice(-14);
    });

    // Update store profiles if any new stores were auto-registered
    if (newStoreProfiles && newStoreProfiles.length > 0) {
      setStoreProfiles((prev) => {
        const next = [...prev];
        newStoreProfiles.forEach((prof) => {
          const idx = next.findIndex((p) => p.nombre.toLowerCase() === prof.nombre.toLowerCase());
          if (idx >= 0) next[idx] = prof;
          else next.push(prof);
        });
        return next;
      });
    }

    // Update store capacities if any new stores were auto-registered
    if (newStoreCapacities && Object.keys(newStoreCapacities).length > 0) {
      setStoreCapacities((prev) => ({
        ...prev,
        ...newStoreCapacities,
      }));
    }

    setIsCustomData(true);

    // Auto-focus on the uploaded store if single store
    if (newStoresInItems.length === 1) {
      setSelectedStore(newStoresInItems[0]);
    } else {
      setSelectedStore('TODAS');
    }
  };

  // Bulk Allocation from Manager
  const handleBulkAllocateStock = (
    reference: string,
    totalUnits: number,
    distribution: Record<string, number>
  ) => {
    hasUserModifiedDataRef.current = true;
    const newItems: InventoryItem[] = [];
    Object.entries(distribution).forEach(([storeName, units]) => {
      if (units > 0) {
        newItems.push({
          id: `alloc-${storeName}-${reference}-${Date.now()}`,
          Tienda: storeName,
          Marca: 'ASIGNACIÓN CENTRAL',
          Departamento: 'CALZADO',
          Seccion: 'UNISEX',
          Familia: 'SPORTSWEAR',
          Referencia: reference,
          SKU_Talla: `${reference}-UNICA`,
          Talla: 'UNICA',
          Stock: units,
          Valoracion: units * 45.0,
        });
      }
    });
    setInventory((prev) => [...prev, ...newItems]);
  };

  // Apply a single transfer permanently to inventory (when marked RECIBIDO in field or planner)
  const handleApplySingleTransfer = (transfer: TransferSuggestion, units: number) => {
    if (!transfer || units <= 0) return;
    hasUserModifiedDataRef.current = true;

    setInventory((prev) => {
      const copy = JSON.parse(JSON.stringify(prev)) as InventoryItem[];

      // Decrease from origin store
      const originItem = copy.find(
        (it) => it.Tienda === transfer.TiendaOrigen && it.Referencia === transfer.Referencia && it.Talla === transfer.Talla
      );
      if (originItem) {
        const unitVal = originItem.Stock > 0 ? originItem.Valoracion / originItem.Stock : (originItem.ValorUnitario || 50);
        originItem.Stock = Math.max(0, originItem.Stock - units);
        originItem.Valoracion = originItem.Stock * unitVal;
      }

      // Increase in destination store
      const destItem = copy.find(
        (it) => it.Tienda === transfer.TiendaDestino && it.Referencia === transfer.Referencia && it.Talla === transfer.Talla
      );
      if (destItem) {
        const unitVal = destItem.Stock > 0 ? destItem.Valoracion / destItem.Stock : (destItem.ValorUnitario || 50);
        destItem.Stock += units;
        destItem.Valoracion = destItem.Stock * unitVal;
      } else if (originItem) {
        const unitVal = originItem.ValorUnitario || (originItem.Stock > 0 ? originItem.Valoracion / originItem.Stock : 50);
        copy.push({
          ...originItem,
          id: `transfer-rec-${transfer.TiendaDestino}-${transfer.Referencia}-${transfer.Talla}-${Date.now()}`,
          Tienda: transfer.TiendaDestino,
          Stock: units,
          Valoracion: units * unitVal,
          SKU_Talla: `${transfer.Referencia} | ${transfer.Talla}`,
        });
      }

      const updated = copy.filter((it) => it.Stock > 0);
      saveAppStateToStorage({
        inventory: updated,
        storeProfiles,
        storeCapacities,
        storeDistances,
        ruleConfig,
        customProductImageUrls,
        bcvRate,
        valuationHistory,
        version: 1,
      }).catch(() => {});
      return updated;
    });

    // Record in executed transfers localStorage history
    try {
      const savedHist = localStorage.getItem('spec_executed_transfers_v2');
      const list = savedHist ? JSON.parse(savedHist) : [];
      const newRec = {
        ...transfer,
        id: transfer.id,
        UnidadesRealesRecibidas: units,
        UnidadesRealesDespachadas: units,
        Estado: 'RECIBIDO',
        executedAt: new Date().toISOString(),
      };
      const filtered = list.filter((item: any) => item.id !== transfer.id);
      localStorage.setItem('spec_executed_transfers_v2', JSON.stringify([newRec, ...filtered]));

      // Also update workflow map in storage
      const savedWf = localStorage.getItem('spec_transfer_workflow_v2');
      const wf = savedWf ? JSON.parse(savedWf) : {};
      wf[transfer.id] = {
        status: 'RECIBIDO',
        condition: wf[transfer.id]?.condition || '',
        dispatchedUnits: units,
        receivedUnits: units,
        updatedAt: new Date().toISOString(),
      };
      localStorage.setItem('spec_transfer_workflow_v2', JSON.stringify(wf));
    } catch {}

    setTransfersSuccessToast(
      `✓ Transferencia confirmada: ${units} uds de ${transfer.Referencia} (Talla ${transfer.Talla}) transferidas de ${transfer.TiendaOrigen} a ${transfer.TiendaDestino}.`
    );
    setTimeout(() => setTransfersSuccessToast(null), 5000);
  };

  // Execute all inter-store transfer suggestions permanently
  const handleExecuteAllTransfers = () => {
    if (transferSuggestions.length === 0) return;
    hasUserModifiedDataRef.current = true;
    const totalUnits = transferSuggestions.reduce((acc, s) => acc + s.UnidadesSugeridas, 0);
    const totalOrders = transferSuggestions.length;

    // Save state permanently
    const nextInv = effectiveInventory;
    setInventory(nextInv);
    setIsTransfersPreviewActive(false);

    // Persist to IndexedDB
    saveAppStateToStorage({
      inventory: nextInv,
      storeProfiles,
      storeCapacities,
      storeDistances,
      ruleConfig,
      customProductImageUrls,
      bcvRate,
      valuationHistory,
      version: 1,
    }).catch(() => {});

    // Save all to executed transfers history in localStorage
    try {
      const savedHist = localStorage.getItem('spec_executed_transfers_v2');
      const prevList = savedHist ? JSON.parse(savedHist) : [];
      const now = new Date().toISOString();
      const newExecuted = transferSuggestions.map((sug) => ({
        ...sug,
        Estado: 'RECIBIDO' as TransferStatus,
        UnidadesRealesDespachadas: sug.UnidadesSugeridas,
        UnidadesRealesRecibidas: sug.UnidadesSugeridas,
        executedAt: now,
      }));
      const existingIds = new Set(newExecuted.map((e) => e.id));
      const mergedHist = [...newExecuted, ...prevList.filter((p: any) => !existingIds.has(p.id))];
      localStorage.setItem('spec_executed_transfers_v2', JSON.stringify(mergedHist));

      // Also mark all in workflowMap as RECIBIDO
      const savedWf = localStorage.getItem('spec_transfer_workflow_v2');
      const wf = savedWf ? JSON.parse(savedWf) : {};
      transferSuggestions.forEach((sug) => {
        wf[sug.id] = {
          status: 'RECIBIDO',
          condition: wf[sug.id]?.condition || '',
          dispatchedUnits: sug.UnidadesSugeridas,
          receivedUnits: sug.UnidadesSugeridas,
          updatedAt: now,
        };
      });
      localStorage.setItem('spec_transfer_workflow_v2', JSON.stringify(wf));
    } catch {}

    setTransfersSuccessToast(
      `¡Simulación confirmada y ejecutada! Se aplicaron ${totalOrders} traslados (${totalUnits} unidades) al inventario real. El stock entre tiendas ha sido rebalanceado y las órdenes quedaron registradas como Recibidas.`
    );
    setTimeout(() => setTransfersSuccessToast(null), 7000);
  };

  const handleToggleTransfersPreview = (active: boolean) => {
    setIsTransfersPreviewActive(active);
  };

  // Reset system to blank clean state (only official data)
  const handleResetToSample = () => {
    setInventory([]);
    setStoreProfiles([]);
    setStoreCapacities({});
    setStoreDistances({});
    setIsCustomData(false);
    setSelectedStore('TODAS');
    setIsTransfersPreviewActive(false);
    saveAppStateToStorage({
      inventory: [],
      storeProfiles: [],
      storeCapacities: {},
      storeDistances: {},
      version: 1,
    }).catch(() => {});
  };

  // Export Multi-Sheet Excel
  const handleExportExcel = () => {
    exportarExcelEjecutivo(
      summaryRows,
      alerts,
      pivotGlobal,
      effectiveInventory,
      transferSuggestions,
      financialRisk,
      spatialMetrics,
      agingSummary
    );
  };

  // Clear only uploaded inventory / stock data (preserving store configurations and capacities)
  const handleClearInventoryOnly = () => {
    setInventory([]);
    setIsTransfersPreviewActive(false);
  };

  // Reset entire system to blank slate
  const handleClearAll = () => {
    if (window.confirm('¿Estás seguro de que deseas limpiar todo el sistema? Se borrarán las tiendas e inventarios actuales.')) {
      setInventory([]);
      setStoreProfiles([]);
      setStoreCapacities({});
      setStoreDistances({});
      setSelectedStore('TODAS');
      setIsCustomData(false);
      setIsTransfersPreviewActive(false);
      try {
        localStorage.removeItem('rcc_state_backup');
        localStorage.removeItem('spec_transfer_workflow_v2');
        localStorage.removeItem('cc_alert_status_overrides');
      } catch {}
      saveAppStateToStorage({
        inventory: [],
        storeProfiles: [],
        storeCapacities: {},
        storeDistances: {},
        version: 1,
      }).catch(() => {});
    }
  };

  // Backup system state to JSON
  const handleExportJSON = () => {
    exportAppBackupJSON({
      inventory,
      storeProfiles,
      storeCapacities,
      storeDistances,
      ruleConfig,
      version: 1,
    });
  };

  // Restore system state from JSON
  const handleImportJSON = async (jsonData: string) => {
    try {
      const data = await importAppBackupJSON(jsonData);
      if (data.inventory) setInventory(data.inventory);
      if (data.storeProfiles) setStoreProfiles(data.storeProfiles);
      if (data.storeCapacities) setStoreCapacities(data.storeCapacities);
      if (data.storeDistances) setStoreDistances(data.storeDistances);
      if (data.ruleConfig) setRuleConfig(data.ruleConfig);
      setIsCustomData(true);
      setSelectedStore('TODAS');
      setIsTransfersPreviewActive(false);
      alert('Respaldo cargado correctamente con éxito.');
    } catch {
      alert('Error al leer el archivo JSON de respaldo. Verifica la estructura.');
    }
  };

  const navTabs = [
    {
      id: 'manager',
      label: 'Panel Manager',
      shortLabel: 'Manager',
      icon: Layers,
      isManager: true,
    },
    {
      id: 'dashboard',
      label: 'Cuadro de Mando',
      shortLabel: 'Mando',
      icon: BarChart3,
    },
    {
      id: 'alertas',
      label: 'Curvas & Alertas',
      shortLabel: 'Curvas & Alertas',
      icon: Grid,
      badge: alerts.length,
    },
    {
      id: 'traslados',
      label: 'Rebalanceo Tiendas',
      shortLabel: 'Rebalanceo',
      icon: Truck,
      badge: transferSuggestions.length,
    },
    {
      id: 'capacidad',
      label: 'Matriz Capacidad',
      shortLabel: 'Capacidad',
      fullTitle: 'Marcas y Matriz de Capacidad',
      icon: Settings2,
    },
    {
      id: 'detalle',
      label: 'Detalle Inventario',
      shortLabel: 'Inventario',
      icon: Database,
    },
  ];

  return (
    <div className="min-h-screen bg-[#F8F7FC] text-zinc-900 flex font-sans selection:bg-zinc-200 selection:text-zinc-900 relative">
      {/* Collapsible Clean Navigation Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={(tabId) => {
          setActiveTab(tabId);
          if (tabId === 'manager') {
            setSelectedStore('TODAS');
          }
          setIsSidebarCollapsed(true);
        }}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
        alertsCount={alerts.filter((a) => a.Prioridad.includes('CRÍTICA')).length}
        transfersCount={transferSuggestions.length}
        selectedStore={selectedStore}
        storesCount={stores.length}
        onOpenUpload={() => {
          setIsUploadModalOpen(true);
          setIsSidebarCollapsed(true);
        }}
        onOpenManual={() => {
          setIsManualOpen(true);
          setIsSidebarCollapsed(true);
        }}
      />

      {/* Dimmed backdrop when lateral drawer is open on mobile */}
      {!isSidebarCollapsed && (
        <div
          className="fixed inset-0 z-40 bg-zinc-900/30 backdrop-blur-[1px] transition-opacity lg:hidden"
          onClick={() => setIsSidebarCollapsed(true)}
          aria-hidden="true"
        />
      )}

      {/* Main Content Area (Full width when sidebar is collapsed) */}
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${isSidebarCollapsed ? 'pl-0' : 'pl-0 lg:pl-64'}`}>
        {/* Top Navbar Header */}
        <Header
          stores={stores}
          selectedStore={selectedStore}
          onSelectStore={(st) => {
            setSelectedStore(st);
            if (activeTab === 'manager') {
              setActiveTab('dashboard');
            }
          }}
          brands={availableBrands}
          selectedBrand={selectedBrand}
          onSelectBrand={setSelectedBrand}
          onOpenUpload={() => setIsUploadModalOpen(true)}
          onExportExcel={handleExportExcel}
          onResetToSample={handleResetToSample}
          onClearAll={handleClearAll}
          onOpenRegisterStore={() => setIsRegisterModalOpen(true)}
          onOpenManager={() => {
            setActiveTab('manager');
            setSelectedStore('TODAS');
          }}
          isManagerActive={activeTab === 'manager'}
          totalItems={inventory.length}
          totalValuation={totalValuation}
          isCustomData={isCustomData}
          onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
          onOpenWhatIf={() => setIsWhatIfOpen(true)}
          onOpenRuleEngine={() => setIsRuleEngineOpen(true)}
          onOpenManual={() => setIsManualOpen(true)}
          onExportJSON={handleExportJSON}
          onImportJSON={handleImportJSON}
          isSidebarCollapsed={isSidebarCollapsed}
          onToggleSidebar={() => setIsSidebarCollapsed((prev) => !prev)}
          alertsCount={alerts.filter((a) => a.Prioridad.includes('CRÍTICA')).length}
          currentUser={currentUser}
          isCloudSyncing={isCloudSyncing}
          lastCloudSync={lastCloudSync}
          isQuotaExceeded={isQuotaExceeded}
          onLoginGoogle={handleLoginGoogle}
          onLogoutGoogle={handleLogoutGoogle}
          onManualCloudSync={handleManualCloudSync}
        />

        {/* Informational banner when Firestore quota is reached */}
        {isQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200/90 text-amber-950 px-4 py-2.5 sm:px-6 shadow-2xs">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-semibold text-amber-950">
                    Límite diario de cuota gratuita alcanzado en Firebase Firestore (20.000 ops/día)
                  </p>
                  <p className="text-amber-800">
                    La aplicación continúa operando con normalidad guardando de manera segura en <strong>IndexedDB local</strong> (ningún dato se pierde). La sincronización en la nube se reanudará cuando se reinicie la cuota diaria.
                  </p>
                  <div className="flex flex-wrap items-center gap-3 pt-0.5">
                    <a
                      href={FIRESTORE_UPGRADE_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-amber-900 underline font-medium hover:text-amber-950"
                    >
                      Abrir Firebase Console <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href={FIRESTORE_PRICING_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-800 underline hover:text-amber-950"
                    >
                      Detalle de cuotas Spark
                    </a>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  type="button"
                  onClick={handleManualCloudSync}
                  className="px-2.5 py-1.5 bg-white hover:bg-zinc-50 text-amber-900 rounded font-medium border border-amber-300 shadow-2xs transition-colors cursor-pointer"
                >
                  Reintentar sincronización
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Global Feedback Banner for Cloud Notifications */}
        <AnimatePresence>
          {cloudBannerMsg && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="bg-zinc-900 text-white text-xs px-4 py-2 text-center flex items-center justify-center gap-2 border-b border-zinc-800 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{cloudBannerMsg}</span>
              <button
                type="button"
                onClick={() => setCloudBannerMsg(null)}
                className="ml-2 text-zinc-400 hover:text-white text-[11px] underline cursor-pointer"
              >
                Cerrar
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-6 space-y-6">
          
          {/* Segmented Navigation Bar (Recessed Tactile Bar - Fixed & Non-displacing) */}
          <div className="sticky top-[105px] lg:top-[57px] z-20 bg-[#F4F2FD] border border-zinc-200/90 rounded-xl p-1.5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-1 w-full overflow-hidden shadow-[0_4px_14px_rgba(0,0,0,0.06),inset_0_1.5px_3px_rgba(0,0,0,0.035)] select-none">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  id={`tab-btn-${tab.id}`}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setActiveTab(tab.id);
                    if (tab.id === 'manager') {
                      setSelectedStore('TODAS');
                    }
                  }}
                  title={tab.fullTitle || tab.label}
                  className={`relative z-10 flex items-center justify-center gap-1 sm:gap-1.5 px-1.5 sm:px-2.5 py-2 text-xs font-mono font-medium rounded-lg transition-colors cursor-pointer tracking-tight w-full min-w-0 ${
                    isActive
                      ? 'text-zinc-900 font-semibold'
                      : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/40'
                  }`}
                >
                  {/* Active Segment Indicator (White Tactile Push Key) */}
                  {isActive && (
                    <motion.div
                      layoutId="active-nav-pill"
                      transition={{ type: 'spring', stiffness: 550, damping: 35 }}
                      className="absolute inset-0 rounded-lg bg-white border border-zinc-300 shadow-[0_1px_3px_rgba(0,0,0,0.04),inset_0_1px_0_rgba(255,255,255,0.9)]"
                    />
                  )}

                  <span className="relative z-20 flex items-center justify-center gap-1 sm:gap-1.5 min-w-0 w-full">
                    {Icon && (
                      <Icon
                        className={`w-3.5 h-3.5 shrink-0 transition-transform duration-150 ${
                          isActive ? 'text-zinc-900' : 'text-zinc-400'
                        }`}
                      />
                    )}
                    <span className="truncate text-center">
                      <span className="hidden xl:inline">{tab.label}</span>
                      <span className="xl:hidden">{tab.shortLabel || tab.label}</span>
                    </span>
                    {tab.badge !== undefined && tab.badge > 0 && (
                      <span
                        className={`px-1 py-0.2 sm:px-1.5 sm:py-0.5 rounded text-[9px] sm:text-[10px] font-bold font-mono transition-transform shrink-0 ${
                          isActive
                            ? 'bg-zinc-100 text-zinc-900 border border-zinc-200'
                            : tab.id === 'alertas'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-zinc-200/70 text-zinc-700 border border-zinc-300/80'
                        }`}
                      >
                        {tab.badge}
                      </span>
                    )}
                  </span>
                </motion.button>
              );
            })}
          </div>

        {/* Global Transfer Preview Mode Banner (shown on other tabs to notify simulation is active) */}
        <AnimatePresence>
          {isTransfersPreviewActive && activeTab !== 'traslados' && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className="bg-white border border-blue-200/90 rounded-xl p-4 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3.5">
                <div className="p-2.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-200/80 shrink-0">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-800 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200 font-mono">
                      SIMULACIÓN // EN CURSO
                    </span>
                    <span className="text-xs text-zinc-600 font-mono">
                      {transferSuggestions.length} Órdenes // {transferSuggestions.reduce((acc, s) => acc + s.UnidadesSugeridas, 0)} Uds en Tránsito
                    </span>
                  </div>
                  <p className="text-xs text-zinc-600 mt-1 font-normal font-sans">
                    Visualizando el <strong>resultado simulado</strong> de los traslados en Cuadro de Mando, Curvas, Alertas y Manager.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 shrink-0 w-full md:w-auto justify-end">
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={() => handleToggleTransfersPreview(false)}
                  className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 tactile-button-light text-xs font-mono font-semibold rounded-lg cursor-pointer"
                  title="Restablecer el inventario original sin aplicar los traslados"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-zinc-500" />
                  <span>RESTABLECER ORIGINAL</span>
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={handleExecuteAllTransfers}
                  className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2 tactile-button-dark text-xs font-mono font-bold rounded-lg cursor-pointer"
                  title="Confirmar y aplicar de forma definitiva"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>CONFIRMAR Y APLICAR</span>
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab Views with Ultra-Responsive Transitions */}
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12, ease: [0.16, 1, 0.3, 1] }}
            className="w-full"
          >
            {activeTab === 'manager' && (
              <ManagerTab
                inventory={effectiveInventory}
                stores={stores}
                storeProfiles={storeProfiles}
                capacityConfig={capacityConfig}
                storeCapacities={storeCapacities}
                alerts={networkAlerts}
                transferSuggestions={transferSuggestions}
                onSelectStore={(st) => setSelectedStore(st)}
                onOpenUpload={() => setIsUploadModalOpen(true)}
                onDeleteStore={handleDeleteStore}
                onClearAll={handleClearAll}
                onClearInventoryOnly={handleClearInventoryOnly}
                onNavigateToTab={setActiveTab}
                onExecuteAllTransfers={handleExecuteAllTransfers}
                onBulkAllocateStock={handleBulkAllocateStock}
                isPreviewActive={isTransfersPreviewActive}
                onTogglePreview={handleToggleTransfersPreview}
                financialRisk={financialRisk}
                agingSummary={agingSummary}
                spatialMetrics={spatialMetrics}
                totalValuation={totalValuation}
                bcvRate={bcvRate}
                onUpdateBcvRate={handleUpdateBcvRate}
              />
            )}

            {activeTab === 'dashboard' && (
              <DashboardTab
                summaryRows={summaryRows}
                selectedStore={selectedStore}
                onNavigateToTab={setActiveTab}
                isAttentionDetailOpen={isAttentionDetailOpen}
                onToggleAttentionDetail={setIsAttentionDetailOpen}
                onNavigateToCurveSku={(sku) => {
                  setSelectedCurveSku(sku);
                  setHasCurveBack(true);
                  setIsAttentionDetailOpen(true);
                  setActiveTab('alertas');
                }}
                onOpenUpload={() => setIsUploadModalOpen(true)}
                onOpenRegisterStore={() => setIsRegisterModalOpen(true)}
                onResetToSample={handleResetToSample}
                onOpenWhatIf={() => setIsWhatIfOpen(true)}
                storesCount={stores.length}
                financialRisk={financialRisk}
                spatialMetrics={spatialMetrics}
                agingSummary={agingSummary}
                inventory={effectiveInventory}
                alerts={alerts}
                networkAlerts={networkAlerts}
                storeProfiles={storeProfiles}
                storeCapacities={storeCapacities}
                brands={availableBrands}
                selectedBrand={selectedBrand}
                onSelectBrand={setSelectedBrand}
                moduleSummaries={moduleSummaries}
                stores={stores}
                onSelectStore={(st) => setSelectedStore(st)}
                capacityConfig={capacityConfig}
                onDeleteStore={handleDeleteStore}
                bcvRate={bcvRate}
                valuationHistory={valuationHistory}
              />
            )}

            {(activeTab === 'alertas' || activeTab === 'curvas') && (
              <AlertsTab
                alerts={alerts}
                selectedStore={selectedStore}
                inventory={effectiveInventory}
                customImageUrls={customProductImageUrls}
                onUpdateProductImageUrl={(ref, url) => {
                  setCustomProductImageUrls((prev) => ({
                    ...prev,
                    [ref]: url,
                  }));
                }}
                selectedSku={selectedCurveSku}
                onSelectSku={(sku) => setSelectedCurveSku(sku)}
                onUpdateAlertStatus={handleUpdateAlertStatus}
              />
            )}

            {activeTab === 'traslados' && (
              <TransfersTab
                suggestions={transferSuggestions}
                distances={storeDistances}
                stores={stores}
                inventory={effectiveInventory}
                alerts={alerts}
                isSimulationActive={isTransfersPreviewActive}
                onToggleSimulation={handleToggleTransfersPreview}
                onConfirmExecute={handleExecuteAllTransfers}
                onApplySingleTransfer={handleApplySingleTransfer}
                executedToast={transfersSuccessToast}
              />
            )}

            {activeTab === 'capacidad' && (
              <CapacityEditorTab
                config={capacityConfig}
                onChangeConfig={setCapacityConfig}
                stores={stores}
                storeProfiles={storeProfiles}
                storeCapacities={storeCapacities}
                onUpdateStoreCapacity={(storeName, newConf) => {
                  setStoreCapacities((prev) => ({
                    ...prev,
                    [storeName]: newConf,
                  }));
                }}
                onUpdateStoreProfile={handleUpdateStoreProfile}
                onOpenRegisterModal={handleOpenRegisterModal}
                onDeleteStore={handleDeleteStore}
                selectedStore={selectedStore}
                onSelectStore={setSelectedStore}
              />
            )}

            {activeTab === 'detalle' && (
              <InventoryDetailTab
                inventory={effectiveInventory}
                onDeleteItem={handleDeleteInventoryItem}
                onDeleteBatch={handleDeleteInventoryBatch}
                onClearStore={handleClearStoreInventory}
                onUpdateItem={handleUpdateInventoryItem}
                onPurgeTextileAnomalies={handlePurgeTextileAnomalies}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Precision Industrial Tactical Footer */}
      <footer className="border-t border-zinc-200/80 bg-white py-3 text-center text-xs text-zinc-500 font-mono select-none">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]"></span>
            <span className="font-semibold text-zinc-900 tracking-wider uppercase">RETAIL PRECISION // TACTILE</span>
            <span className="text-zinc-300">//</span>
            <span className="text-zinc-500">REV 4.2 INDUSTRIAL SPEC</span>
          </span>
          <span className="text-[11px] text-zinc-400 font-mono">
            {stores.length} SUCURSALES ACTIVAS // MOTOR ANALÍTICO CALIBRADO
          </span>
        </div>
      </footer>
      </div>

      {/* File Ingestion Modal with Auto-Store Recognition */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        existingStores={stores}
        storeProfiles={storeProfiles}
        onDataLoaded={handleDataLoaded}
        bcvRate={bcvRate}
        onUpdateBcvRate={handleUpdateBcvRate}
      />

      {/* Register Store & Capacity Modal */}
      <RegisterStoreModal
        isOpen={isRegisterModalOpen}
        onClose={() => {
          setIsRegisterModalOpen(false);
          setStoreToEditInModal(null);
        }}
        existingStores={stores}
        storeProfiles={storeProfiles}
        initialStoreToEdit={storeToEditInModal}
        onRegisterStore={handleRegisterStore}
        onDeleteStore={handleDeleteStore}
      />

      {/* Global Multicriteria Command Palette Modal (Cmd+K) */}
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        inventory={inventory}
        stores={stores}
        storeProfiles={storeProfiles}
        alerts={alerts}
        onSelectStore={(st) => {
          setSelectedStore(st);
          setActiveTab('dashboard');
        }}
        onNavigateTab={(tabId) => setActiveTab(tabId)}
        onExportAudit={handleExportExcel}
        onOpenUpload={() => setIsUploadModalOpen(true)}
        onOpenRegisterStore={() => setIsRegisterModalOpen(true)}
      />

      {/* What-If Simulator Modal */}
      <WhatIfSimulatorModal
        isOpen={isWhatIfOpen}
        onClose={() => setIsWhatIfOpen(false)}
        inventory={inventory}
        storeCapacities={storeCapacities}
        transfers={transferSuggestions}
      />

      {/* Rule Engine & Alert Thresholds Modal */}
      <RuleEngineModal
        isOpen={isRuleEngineOpen}
        onClose={() => setIsRuleEngineOpen(false)}
        currentConfig={ruleConfig}
        onSaveConfig={(newConf) => setRuleConfig(newConf)}
      />

      {/* Manual de Instrucciones & Guía Integral SPEC */}
      <AppManualModal
        isOpen={isManualOpen}
        onClose={() => setIsManualOpen(false)}
        onNavigateTab={(tabId) => {
          setActiveTab(tabId);
          setIsManualOpen(false);
        }}
        onOpenUpload={() => {
          setIsManualOpen(false);
          setIsUploadModalOpen(true);
        }}
      />
    </div>
  );
}
