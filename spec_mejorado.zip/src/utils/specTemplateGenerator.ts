import * as XLSX from 'xlsx';

/**
 * Generates and triggers download of the official SPEC sample template (.xlsx)
 * Pre-filled with realistic multi-store data displaying broken curves, overstock and normal stock
 * for instant 1-click evaluation of the platform.
 */
export function downloadOfficialSpecTemplate(): void {
  const wb = XLSX.utils.book_new();

  // 1. Data Sheet
  const sampleRows = [
    // Tienda 1: Flagship Centro (con excedentes en algunas tallas y quiebres en otras)
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-080',
      Talla: '8',
      Stock: 6,
      ValorUnitario: 140,
      DiasAntiguedad: 25,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-085',
      Talla: '8.5',
      Stock: 8,
      ValorUnitario: 140,
      DiasAntiguedad: 25,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-090',
      Talla: '9',
      Stock: 10,
      ValorUnitario: 140,
      DiasAntiguedad: 30,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-095',
      Talla: '9.5',
      Stock: 7,
      ValorUnitario: 140,
      DiasAntiguedad: 20,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-100',
      Talla: '10',
      Stock: 6,
      ValorUnitario: 140,
      DiasAntiguedad: 15,
    },

    // Tienda 2: Mall Norte (con quiebre crítico en tallas centrales de NK-PEGASUS-40)
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-080',
      Talla: '8',
      Stock: 1,
      ValorUnitario: 140,
      DiasAntiguedad: 40,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-085',
      Talla: '8.5',
      Stock: 0,
      ValorUnitario: 140,
      DiasAntiguedad: 45,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-090',
      Talla: '9',
      Stock: 0,
      ValorUnitario: 140,
      DiasAntiguedad: 45,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-095',
      Talla: '9.5',
      Stock: 1,
      ValorUnitario: 140,
      DiasAntiguedad: 35,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'NIKE',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'NK-PEGASUS-40',
      SKU_Talla: 'NK-PEG-40-100',
      Talla: '10',
      Stock: 1,
      ValorUnitario: 140,
      DiasAntiguedad: 30,
    },

    // Referencia 2: ADIDAS ULTRABOOST (Sobrestock en Mall Norte, Quiebre en Flagship)
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'ADIDAS',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'AD-ULTRABOOST-23',
      SKU_Talla: 'AD-UB-23-085',
      Talla: '8.5',
      Stock: 8,
      ValorUnitario: 180,
      DiasAntiguedad: 95, // Aging crítico
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'ADIDAS',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'AD-ULTRABOOST-23',
      SKU_Talla: 'AD-UB-23-090',
      Talla: '9',
      Stock: 9,
      ValorUnitario: 180,
      DiasAntiguedad: 95,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'ADIDAS',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'AD-ULTRABOOST-23',
      SKU_Talla: 'AD-UB-23-085',
      Talla: '8.5',
      Stock: 0,
      ValorUnitario: 180,
      DiasAntiguedad: 10,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'ADIDAS',
      Departamento: 'CALZADO',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'RUNNING',
      Referencia: 'AD-ULTRABOOST-23',
      SKU_Talla: 'AD-UB-23-090',
      Talla: '9',
      Stock: 1,
      ValorUnitario: 180,
      DiasAntiguedad: 10,
    },

    // Textil: PUMA HOODIE
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'PUMA',
      Departamento: 'TEXTIL',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'SPORTSWEAR',
      Referencia: 'PU-HOODIE-CLASSIC',
      SKU_Talla: 'PU-HOD-S',
      Talla: 'S',
      Stock: 6,
      ValorUnitario: 65,
      DiasAntiguedad: 20,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'PUMA',
      Departamento: 'TEXTIL',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'SPORTSWEAR',
      Referencia: 'PU-HOODIE-CLASSIC',
      SKU_Talla: 'PU-HOD-M',
      Talla: 'M',
      Stock: 8,
      ValorUnitario: 65,
      DiasAntiguedad: 20,
    },
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'PUMA',
      Departamento: 'TEXTIL',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'SPORTSWEAR',
      Referencia: 'PU-HOODIE-CLASSIC',
      SKU_Talla: 'PU-HOD-L',
      Talla: 'L',
      Stock: 7,
      ValorUnitario: 65,
      DiasAntiguedad: 20,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'PUMA',
      Departamento: 'TEXTIL',
      Seccion: 'HOMBRE (MENS)',
      Familia: 'SPORTSWEAR',
      Referencia: 'PU-HOODIE-CLASSIC',
      SKU_Talla: 'PU-HOD-M',
      Talla: 'M',
      Stock: 0,
      ValorUnitario: 65,
      DiasAntiguedad: 15,
    },

    // Accesorios: MOCHILA
    {
      Tienda: 'Tienda Flagship Centro',
      Marca: 'UNDER ARMOUR',
      Departamento: 'ACCESORIOS',
      Seccion: 'GENERAL',
      Familia: 'MOCHILAS / MALETINES',
      Referencia: 'UA-HUSTLE-PRO',
      SKU_Talla: 'UA-HUSTLE-U',
      Talla: 'U',
      Stock: 5,
      ValorUnitario: 55,
      DiasAntiguedad: 18,
    },
    {
      Tienda: 'Tienda Mall Norte',
      Marca: 'UNDER ARMOUR',
      Departamento: 'ACCESORIOS',
      Seccion: 'GENERAL',
      Familia: 'MOCHILAS / MALETINES',
      Referencia: 'UA-HUSTLE-PRO',
      SKU_Talla: 'UA-HUSTLE-U',
      Talla: 'U',
      Stock: 1,
      ValorUnitario: 55,
      DiasAntiguedad: 12,
    },
  ];

  const wsData = XLSX.utils.json_to_sheet(sampleRows);
  wsData['!cols'] = [
    { wch: 24 }, // Tienda
    { wch: 15 }, // Marca
    { wch: 15 }, // Departamento
    { wch: 18 }, // Seccion
    { wch: 22 }, // Familia
    { wch: 20 }, // Referencia
    { wch: 18 }, // SKU_Talla
    { wch: 10 }, // Talla
    { wch: 10 }, // Stock
    { wch: 15 }, // ValorUnitario
    { wch: 16 }, // DiasAntiguedad
  ];
  XLSX.utils.book_append_sheet(wb, wsData, 'Inventario_SPEC');

  // 2. Instructions Sheet
  const instructions = [
    { Campo: 'Tienda', Requerido: 'SÍ', Descripción: 'Nombre exacto de la sucursal o tienda física.' },
    { Campo: 'Marca', Requerido: 'SÍ', Descripción: 'Marca comercial (ej. NIKE, ADIDAS, PUMA).' },
    { Campo: 'Departamento', Requerido: 'SÍ', Descripción: 'CALZADO, TEXTIL o ACCESORIOS.' },
    { Campo: 'Seccion', Requerido: 'OPCIONAL', Descripción: 'HOMBRE (MENS), MUJER (WOMENS), INFANTE o GENERAL.' },
    { Campo: 'Familia', Requerido: 'OPCIONAL', Descripción: 'Categoría funcional (RUNNING, TRAINING, CASUAL, etc.).' },
    { Campo: 'Referencia', Requerido: 'SÍ', Descripción: 'Código de modelo o estilo (Style Code).' },
    { Campo: 'SKU_Talla', Requerido: 'OPCIONAL', Descripción: 'Código de barras o identificador único de talla.' },
    { Campo: 'Talla', Requerido: 'SÍ', Descripción: 'Talla numérica (ej. 8.5) o alfabética (ej. M, L).' },
    { Campo: 'Stock', Requerido: 'SÍ', Descripción: 'Unidades físicas disponibles en la sucursal.' },
    { Campo: 'ValorUnitario', Requerido: 'RECOMENDADO', Descripción: 'Precio de venta o costo unitario para calcular valoración y ventas perdidas.' },
    { Campo: 'DiasAntiguedad', Requerido: 'OPCIONAL', Descripción: 'Días desde el ingreso del lote a bodega (calcula aging y dead stock).' },
  ];
  const wsGuide = XLSX.utils.json_to_sheet(instructions);
  wsGuide['!cols'] = [{ wch: 16 }, { wch: 12 }, { wch: 65 }];
  XLSX.utils.book_append_sheet(wb, wsGuide, 'Guia_Campos');

  XLSX.writeFile(wb, 'Plantilla_Oficial_SPEC_Inventario.xlsx');
}
