import * as XLSX from 'xlsx';
import {
  AgingBucketSummary,
  CapacitySummaryRow,
  FinancialRiskSummary,
  InventoryAlert,
  InventoryItem,
  SpatialPerformanceMetric,
  TransferManifest,
  TransferSuggestion,
} from '../types';
import { PivotRow } from './analysisEngine';

/**
 * 1. Executive Consolidated Audit Report (.XLSX)
 */
export function exportarExcelEjecutivo(
  summaryRows: CapacitySummaryRow[],
  alerts: InventoryAlert[],
  pivotData: { rows: PivotRow[]; allSizes: string[] },
  inventory: InventoryItem[],
  transfers: TransferSuggestion[],
  financialRisk?: FinancialRiskSummary,
  spatialMetrics?: SpatialPerformanceMetric[],
  agingSummary?: AgingBucketSummary
) {
  const wb = XLSX.utils.book_new();

  // 1. Hoja: Diagnóstico Ejecutivo & Riesgo Financiero
  const kpiSheetData = [
    { 'MÉTRICA ESTRATÉGICA': 'Valoración Total de Inventario', 'VALOR': `$${summaryRows.reduce((a, b) => a + b.ValoracionTotal, 0).toLocaleString()}`, 'OBSERVACIÓN': 'Activo total en red' },
    { 'MÉTRICA ESTRATÉGICA': 'Ventas Perdidas Estimadas (Lost Sales)', 'VALOR': `$${(financialRisk?.valorVentasPerdidasEstimadas || 0).toLocaleString()}`, 'OBSERVACIÓN': 'Por quiebre de tallas centrales' },
    { 'MÉTRICA ESTRATÉGICA': 'Dead Stock / Capital Atrapado (>90 días)', 'VALOR': `$${(financialRisk?.valorDeadStockCritico || 0).toLocaleString()}`, 'OBSERVACIÓN': 'Candidato a liquidación / outlet' },
    { 'MÉTRICA ESTRATÉGICA': 'Ahorro Potencial por Rebalanceo', 'VALOR': `$${(financialRisk?.ahorroPorRebalanceoEstimado || 0).toLocaleString()}`, 'OBSERVACIÓN': 'Optimizando traslados entre tiendas' },
    { 'MÉTRICA ESTRATÉGICA': 'Total de Alertas Críticas', 'VALOR': alerts.filter((a) => a.Prioridad.includes('CRÍTICA') || a.Prioridad.includes('ALTA')).length, 'OBSERVACIÓN': 'Atención prioritaria inmediata' },
  ];
  const wsKpi = XLSX.utils.json_to_sheet(kpiSheetData);
  XLSX.utils.book_append_sheet(wb, wsKpi, 'Resumen Ejecutivo & Riesgo');

  // 2. Hoja: Resumen de Capacidad por Departamento
  const summaryFormatted = summaryRows.map((r) => ({
    'Departamento': r.Departamento,
    'Profundidad Target (uds/SKU)': r.ProfundidadTarget,
    'SKUs Ideal': r.SKUsIdeal,
    'SKUs Actual': r.SKUsActual,
    'Diferencia SKUs': r.DiferenciaSKUs,
    'Piezas Ideal (Target)': r.PiezasIdeal,
    'Piezas Actual (Stock)': r.PiezasActual,
    'Diferencia Piezas': r.DiferenciaPiezas,
    '% Ocupación Piezas': `${r.PorcentajeOcupacion}%`,
    'Valoración Total ($)': r.ValoracionTotal,
  }));
  const wsSummary = XLSX.utils.json_to_sheet(summaryFormatted);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Capacidad por Departamento');

  // 3. Hoja: Rendimiento Espacial (m2)
  if (spatialMetrics && spatialMetrics.length > 0) {
    const spatialFormatted = spatialMetrics.map((sm) => ({
      'Tienda': sm.tienda,
      'Formato': sm.formato,
      'Superficie Comercial (m²)': sm.superficieM2,
      'Piezas Actuales': sm.piezasActuales,
      'Densidad Real (piezas/m²)': sm.piezasPorM2,
      'Rango Óptimo (piezas/m²)': `${sm.densidadTargetMin} - ${sm.densidadTargetMax}`,
      'Estado Densidad': sm.estadoDensidad,
      'Densidad Valor ($/m²)': `$${sm.valorPorM2}`,
      'Valoración Total ($)': sm.valoracionTotal,
    }));
    const wsSpatial = XLSX.utils.json_to_sheet(spatialFormatted);
    XLSX.utils.book_append_sheet(wb, wsSpatial, 'Rendimiento Espacial m2');
  }

  // 4. Hoja: Envejecimiento / Aging
  if (agingSummary) {
    const agingFormatted = [
      { 'Rango de Antigüedad': '0 - 30 Días (Novedad / Temporada Regular)', 'Piezas': agingSummary.rango0_30.piezas, 'Participación (%)': `${agingSummary.rango0_30.pct}%`, 'Valoración ($)': agingSummary.rango0_30.valor },
      { 'Rango de Antigüedad': '31 - 60 Días (Inventario Maduro)', 'Piezas': agingSummary.rango31_60.piezas, 'Participación (%)': `${agingSummary.rango31_60.pct}%`, 'Valoración ($)': agingSummary.rango31_60.valor },
      { 'Rango de Antigüedad': '61 - 90 Días (Inventario en Riesgo)', 'Piezas': agingSummary.rango61_90.piezas, 'Participación (%)': `${agingSummary.rango61_90.pct}%`, 'Valoración ($)': agingSummary.rango61_90.valor },
      { 'Rango de Antigüedad': '> 90 Días (Crítico / Candidato Liquidación)', 'Piezas': agingSummary.rangoMas90.piezas, 'Participación (%)': `${agingSummary.rangoMas90.pct}%`, 'Valoración ($)': agingSummary.rangoMas90.valor },
    ];
    const wsAging = XLSX.utils.json_to_sheet(agingFormatted);
    XLSX.utils.book_append_sheet(wb, wsAging, 'Aging de Inventario');
  }

  // 5. Hoja: Alertas y Acciones
  const alertsFormatted = alerts.map((a) => ({
    'Prioridad': a.Prioridad,
    'Tipo de Alerta': a.TipoDeAlerta,
    'Referencia': a.Referencia,
    'Marca': a.Marca,
    'Departamento': a.Departamento,
    'Tienda': a.Tienda,
    'Diagnóstico': a.Diagnostico,
    'Acción Correctiva': a.AccionCorrectiva,
    'Stock Total': a.Stock,
    'Impacto Monetario ($)': a.ValorRiesgoMonetario || 0,
    'Tallas Afectadas': a.TallasDisponibles.join(', '),
  }));
  const wsAlerts = XLSX.utils.json_to_sheet(alertsFormatted.length > 0 ? alertsFormatted : [{ 'Mensaje': 'Sin alertas críticas' }]);
  XLSX.utils.book_append_sheet(wb, wsAlerts, 'Alertas Prioritarias');

  // 6. Hoja: Matriz de Curvas de Talla
  const pivotFormatted = pivotData.rows.map((row) => {
    const obj: Record<string, any> = {
      'Referencia': row.Referencia,
      'Marca': row.Marca,
      'Departamento': row.Departamento,
      'Familia': row.Familia,
      'Total Stock': row.TotalStock,
    };
    pivotData.allSizes.forEach((sz) => {
      obj[`Talla ${sz}`] = row.Tallas[sz] || 0;
    });
    return obj;
  });
  const wsPivot = XLSX.utils.json_to_sheet(pivotFormatted.length > 0 ? pivotFormatted : [{ 'Mensaje': 'Sin datos de curva' }]);
  XLSX.utils.book_append_sheet(wb, wsPivot, 'Curvas de Talla');

  // 7. Hoja: Rebalanceos Inter-Tienda
  if (transfers.length > 0) {
    const transfersFormatted = transfers.map((t) => ({
      'Prioridad': t.Prioridad,
      'Referencia / SKU': t.Referencia,
      'Marca': t.Marca,
      'Departamento': t.Departamento,
      'Talla': t.Talla,
      'Tienda Origen': t.TiendaOrigen,
      'Stock en Origen': t.StockOrigen,
      'Tienda Destino': t.TiendaDestino,
      'Stock en Destino': t.StockDestino,
      'Cantidad a Trasladar': t.UnidadesSugeridas,
      'Condición (Nuevo / Usado)': '',
    }));
    const wsTransfers = XLSX.utils.json_to_sheet(transfersFormatted);
    wsTransfers['!cols'] = [
      { wch: 12 },
      { wch: 20 },
      { wch: 14 },
      { wch: 16 },
      { wch: 10 },
      { wch: 22 },
      { wch: 16 },
      { wch: 22 },
      { wch: 16 },
      { wch: 20 },
      { wch: 28 },
    ];
    XLSX.utils.book_append_sheet(wb, wsTransfers, 'Rebalanceos Sugeridos');
  }

  // 8. Hoja: Detalle de Inventario (Muestreo hasta 10,000 filas)
  const detailFormatted = inventory.slice(0, 10000).map((it) => ({
    'Tienda': it.Tienda,
    'Referencia': it.Referencia,
    'Departamento': it.Departamento,
    'Sección': it.Seccion,
    'Familia': it.Familia,
    'Marca': it.Marca,
    'Talla': it.Talla,
    'Stock': it.Stock,
    'Valoración ($)': it.Valoracion,
    'Fecha Ingreso': it.FechaIngreso || 'N/A',
    'Días Antigüedad': it.DiasAntiguedad !== undefined ? it.DiasAntiguedad : 'N/A',
    'SKU_Talla': it.SKU_Talla,
  }));
  const wsDetail = XLSX.utils.json_to_sheet(detailFormatted);
  XLSX.utils.book_append_sheet(wb, wsDetail, 'Inventario Raw');

  const dateStr = new Date().toISOString().split('T')[0];
  XLSX.writeFile(wb, `Auditoria_Consolidada_Retail_Command_Center_${dateStr}.xlsx`);
}

/**
 * 2. Export Single Transfer Manifest / Guía de Transferencia Oficial (.XLSX)
 * Formato fiel a la plantilla física oficial para evitar fricción operativa
 */
export function exportarManifiestoTraspasoExcel(manifest: TransferManifest) {
  const wb = XLSX.utils.book_new();

  const totalCantidad = manifest.items.reduce((acc, it) => acc + (it.cantidad || 0), 0);

  // Construcción celda a celda en array 2D para replicar la plantilla visual
  const rows: any[][] = [];

  // Fila 1: Título Centrado
  rows.push(['', '', '', 'TRANSFERENCIAS', '', '', '', '']);

  // Fila 2: Origen y # Control
  rows.push([
    'ORIGEN :',
    manifest.tiendaOrigen,
    '',
    '',
    '',
    '',
    '# CONTROL',
    manifest.codigoManifiesto || 'DESIN-001',
  ]);

  // Fila 3: Destino y Fecha
  rows.push([
    'DESTINO:',
    manifest.tiendaDestino,
    '',
    '',
    '',
    '',
    'FECHA:',
    manifest.fechaEmision,
  ]);

  // Fila 4: Autorizado Por
  rows.push([
    'AUTORIZADO POR:',
    manifest.autorizadoPor || 'JHONATHAN REQUENA/ EDWIN ALVAREZ',
    '',
    '',
    '',
    '',
    '',
    '',
  ]);

  // Fila 5: Encabezados Oficiales
  rows.push([
    'MARCA',
    'REFERENCIA',
    'CANTIDAD',
    'GENERO',
    'DEPARTAMENTO',
    'CONDICION (NUEVO/USADO)',
    'EXISTENCIA',
    'OBSERVACIONES',
  ]);

  // Filas de Datos (Items a transferir)
  manifest.items.forEach((it) => {
    const refDisplay = it.talla ? `${it.referencia} - T.${it.talla}` : it.referencia;
    rows.push([
      it.marca || '',
      refDisplay,
      it.cantidad || 0,
      it.genero || 'CABALLERO',
      it.departamento || '',
      it.condicion || '', // Manual para llenado físico o digital
      it.stockPrevioOrigen ?? 0,
      it.observaciones || '', // Manual para llenado físico o digital
    ]);
  });

  // Filas en blanco para preservar el formato de 25 filas de la plantilla física si hay pocos items
  const minRows = 25;
  const currentItemCount = manifest.items.length;
  if (currentItemCount < minRows) {
    const blankRowsNeeded = minRows - currentItemCount;
    for (let i = 0; i < blankRowsNeeded; i++) {
      rows.push(['', '', '', '', '', '', '', '']);
    }
  }

  // Fila de Totalización: La suma va en la columna CANTIDAD (columna C / índice 2)
  rows.push(['', '', totalCantidad, '', '', '', '', '']);

  // Espaciado previo a las firmas
  rows.push(['', '', '', '', '', '', '', '']);
  rows.push(['', '', '', '', '', '', '', '']);

  // Bloque de Firmas y Validación
  rows.push([
    'ENTREGADO POR:',
    '',
    '',
    '',
    '',
    'RECIBIDO POR:',
    '',
    '',
  ]);
  rows.push([
    'NOMBRE Y APELLIDO',
    '',
    '',
    '',
    '',
    'NOMBRE Y APELLIDO',
    '',
    '',
  ]);
  rows.push(['', '', '', '', '', '', '', '']);
  rows.push([
    '____________________________________',
    '',
    '',
    '',
    '',
    '____________________________________',
    '',
    '',
  ]);

  const ws = XLSX.utils.aoa_to_sheet(rows);

  // Configuración de anchos de columna para legibilidad y formato exacto
  ws['!cols'] = [
    { wch: 18 }, // A: MARCA
    { wch: 28 }, // B: REFERENCIA
    { wch: 12 }, // C: CANTIDAD
    { wch: 16 }, // D: GENERO
    { wch: 18 }, // E: DEPARTAMENTO
    { wch: 28 }, // F: CONDICION (NUEVO/USADO)
    { wch: 14 }, // G: EXISTENCIA
    { wch: 30 }, // H: OBSERVACIONES
  ];

  // Configuración de fusiones de celdas (merges)
  ws['!merges'] = [
    // Título Fila 1: TRANSFERENCIAS de A1 a H1
    { s: { r: 0, c: 0 }, e: { r: 0, c: 7 } },
    // Origen Fila 2: B2 a F2
    { s: { r: 1, c: 1 }, e: { r: 1, c: 5 } },
    // Destino Fila 3: B3 a F3
    { s: { r: 2, c: 1 }, e: { r: 2, c: 5 } },
    // Autorizado Por Fila 4: B4 a H4
    { s: { r: 3, c: 1 }, e: { r: 3, c: 7 } },
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'TRANSFERENCIAS');

  const safeOrigin = (manifest.tiendaOrigen || 'ORIGEN').replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeDest = (manifest.tiendaDestino || 'DESTINO').replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeCode = (manifest.codigoManifiesto || 'DESIN-001').replace(/[^a-zA-Z0-9_-]/g, '_');

  XLSX.writeFile(wb, `Guia_Transferencia_${safeCode}_${safeOrigin}_a_${safeDest}.xlsx`);
}
