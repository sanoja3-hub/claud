import * as XLSX from 'xlsx';
import { InventoryAlert, InventoryItem } from '../types';

export interface PurchaseFlatRow {
  Tienda: string;
  Temporada: string;
  Marca: string;
  Departamento: string;
  Seccion: string; // Género
  Familia: string;
  StockActual: number;
  VelocidadEstimadaSemanal: number;
  UnidadesSugeridas: number;
  SkusCount?: number;
  Justificacion: string;
}

export interface PurchaseHierarchyNode {
  id: string;
  name: string;
  level: 'tienda' | 'marca' | 'departamento' | 'seccion' | 'familia';
  unidadesSugeridas: number;
  stockActual: number;
  skusCount?: number;
  children?: PurchaseHierarchyNode[];
}

export interface PurchasePlanCalculationResult {
  flatRows: PurchaseFlatRow[];
  hierarchyTree: PurchaseHierarchyNode[];
  totalUnidades: number;
  totalStockActual: number;
  totalSkus: number;
  unidadesPorMarca: Record<string, number>;
  unidadesPorDepartamento: Record<string, number>;
  unidadesPorSeccion: Record<string, number>;
  unidadesPorTienda: Record<string, number>;
}

/**
 * Normaliza nombres de género / sección
 */
function normalizeGender(raw: string = ''): string {
  const upper = raw.toUpperCase().trim();
  if (upper.includes('CABALLER') || upper.includes('HOMBRE') || upper.includes('MASCULIN') || upper === 'MEN') return 'CABALLERO';
  if (upper.includes('DAMA') || upper.includes('MUJER') || upper.includes('FEMENIN') || upper === 'WOMEN') return 'DAMA';
  if (upper.includes('NIÑ') || upper.includes('KID') || upper.includes('INFANTIL') || upper.includes('JUNIOR')) return 'NIÑO';
  if (upper.includes('UNISEX')) return 'UNISEX';
  return upper || 'CABALLERO';
}

/**
 * Normaliza departamento
 */
function normalizeDept(raw: string = ''): string {
  const upper = raw.toUpperCase().trim();
  if (upper.includes('CALZAD') || upper === 'FOOTWEAR') return 'CALZADO';
  if (upper.includes('TEXTIL') || upper.includes('ROPA') || upper === 'APPAREL') return 'TEXTIL';
  if (upper.includes('ACCESOR') || upper === 'ACCESSORIES') return 'ACCESORIOS';
  return upper || 'CALZADO';
}

/**
 * Calcula el sugerido de compra inteligente en unidades
 * aplicando velocidad de venta por tienda, ponderador de temporada y restitución de curvas.
 */
export function generarSugeridoCompraInteligente(
  alerts: InventoryAlert[],
  inventory: InventoryItem[] = [],
  storeFilter: string = 'TODAS'
): PurchasePlanCalculationResult {
  // 1. Filtrar inventario y alertas según tienda seleccionada si aplica
  const targetInventory = storeFilter === 'TODAS'
    ? inventory
    : inventory.filter((item) => (item.Tienda || '').toUpperCase() === storeFilter.toUpperCase());

  // 2. Mapear alertas por Tienda + Referencia para detectar quiebres y severidad
  const alertMap = new Map<string, InventoryAlert>();
  (alerts || []).forEach((alt) => {
    if (!alt) return;
    const key = `${(alt.Tienda || 'TODAS').toUpperCase()}__${(alt.Referencia || '').toUpperCase()}`;
    const current = alertMap.get(key);
    if (!current || (alt.Prioridad.includes('CRÍTICA') && !current.Prioridad.includes('CRÍTICA'))) {
      alertMap.set(key, alt);
    }
  });

  // 3. Agrupar inventario por SKU + Tienda para determinar stock actual y tallas disponibles
  interface SkuStoreAggregate {
    tienda: string;
    temporada: string;
    marca: string;
    depto: string;
    seccion: string;
    familia: string;
    referencia: string;
    stock: number;
    tallas: Set<string>;
  }

  const skuStoreMap = new Map<string, SkuStoreAggregate>();

  (targetInventory || []).forEach((it) => {
    if (!it) return;
    const tienda = it.Tienda || 'TIENDA 1';
    const ref = it.Referencia || 'SKU';
    const key = `${tienda.toUpperCase()}__${ref.toUpperCase()}`;
    const depto = normalizeDept(it.Departamento);
    const seccion = normalizeGender(it.Seccion);
    const familia = (it.Familia || 'CASUAL').toUpperCase().trim();
    const marca = (it.Marca || 'GENERAL').toUpperCase().trim();
    const temporada = (it.Temporada || 'CONTINUIDAD').toUpperCase().trim();

    if (!skuStoreMap.has(key)) {
      skuStoreMap.set(key, {
        tienda,
        temporada,
        marca,
        depto,
        seccion,
        familia,
        referencia: ref,
        stock: 0,
        tallas: new Set<string>(),
      });
    }

    const rec = skuStoreMap.get(key)!;
    rec.stock += Math.max(0, it.Stock || 0);
    if (it.Stock > 0 && it.Talla) {
      rec.tallas.add(String(it.Talla).trim().toUpperCase());
    }
  });

  // 4. Determinar velocidad relativa de cada tienda basada en volumen
  const storeVolumes: Record<string, number> = {};
  skuStoreMap.forEach((rec) => {
    storeVolumes[rec.tienda] = (storeVolumes[rec.tienda] || 0) + rec.stock;
  });
  const maxStoreVol = Math.max(...Object.values(storeVolumes), 1);

  // 5. Agrupación Jerárquica: Tienda + Temporada + Marca + Depto + Seccion + Familia
  interface GroupAcc {
    tienda: string;
    temporada: string;
    marca: string;
    departamento: string;
    seccion: string;
    familia: string;
    stockActual: number;
    unidadesSugeridas: number;
    skusCount: number;
    skusSuggestedRefs: Set<string>;
    skusCriticosCount: number;
    velocidadPromedioSemanal: number;
  }

  const groupsMap = new Map<string, GroupAcc>();

  skuStoreMap.forEach((skuRec, key) => {
    const groupKey = `${skuRec.tienda}__${skuRec.temporada}__${skuRec.marca}__${skuRec.depto}__${skuRec.seccion}__${skuRec.familia}`;
    
    // Determinar multiplicador de velocidad de tienda (1.0x a 1.45x)
    const storeRelativeRatio = (storeVolumes[skuRec.tienda] || 0) / maxStoreVol;
    const storeVelocityMultiplier = 0.95 + storeRelativeRatio * 0.45;

    // Determinar factor de temporada
    let seasonMultiplier = 1.0;
    const tempUpper = skuRec.temporada.toUpperCase();
    if (tempUpper.includes('ACTUAL') || tempUpper.includes('IN-SEASON') || tempUpper.includes('ALTA') || tempUpper.includes('2026') || tempUpper.includes('VERANO') || tempUpper.includes('INVIERNO')) {
      seasonMultiplier = 1.30;
    } else if (tempUpper.includes('OUTLET') || tempUpper.includes('LIQUIDACION') || tempUpper.includes('ANTERIOR') || tempUpper.includes('PAST')) {
      seasonMultiplier = 0.20; // Frenar compras en liquidación
    } else {
      seasonMultiplier = 1.0; // Continuidad / regular
    }

    // Verificar si tiene alerta asociada
    const alertFound = alertMap.get(key);
    let skuSuggestedUnits = 0;
    let isCritico = false;

    // Identificar tallas core faltantes
    const isCalzado = skuRec.depto === 'CALZADO';
    const coreTargetSizes = isCalzado ? ['38', '39', '40', '41'] : ['M', 'L'];
    const missingCoreCount = coreTargetSizes.filter((s) => !skuRec.tallas.has(s)).length;

    if (alertFound) {
      if (alertFound.Prioridad.includes('CRÍTICA')) {
        isCritico = true;
        // Reponer al menos 4-5 piezas por cada talla central rota
        const baseNeeded = Math.max(8, missingCoreCount * 5);
        skuSuggestedUnits = Math.round(baseNeeded * storeVelocityMultiplier * seasonMultiplier);
      } else if (alertFound.Prioridad.includes('ALTA')) {
        skuSuggestedUnits = Math.round(6 * storeVelocityMultiplier * seasonMultiplier);
      } else if (alertFound.Prioridad.includes('MEDIA')) {
        skuSuggestedUnits = Math.round(4 * storeVelocityMultiplier * seasonMultiplier);
      } else {
        skuSuggestedUnits = Math.round(2 * storeVelocityMultiplier * seasonMultiplier);
      }
    } else {
      // Si el stock es muy bajo (< 4 uds) y no está en liquidación, sugerir reposición básica preventiva
      if (skuRec.stock < 4 && seasonMultiplier > 0.5) {
        skuSuggestedUnits = Math.round(4 * storeVelocityMultiplier * seasonMultiplier);
      }
    }

    // Garantizar que no se pida en productos sin rotación o liquidados
    if (seasonMultiplier <= 0.25) {
      skuSuggestedUnits = 0;
    }

    // Velocidad de venta estimada semanal para este SKU (en unidades)
    const velocidadSemanal = Math.max(1, Math.round(skuSuggestedUnits / 4));

    if (!groupsMap.has(groupKey)) {
      groupsMap.set(groupKey, {
        tienda: skuRec.tienda,
        temporada: skuRec.temporada,
        marca: skuRec.marca,
        departamento: skuRec.depto,
        seccion: skuRec.seccion,
        familia: skuRec.familia,
        stockActual: 0,
        unidadesSugeridas: 0,
        skusCount: 0,
        skusSuggestedRefs: new Set<string>(),
        skusCriticosCount: 0,
        velocidadPromedioSemanal: 0,
      });
    }

    const grp = groupsMap.get(groupKey)!;
    grp.stockActual += skuRec.stock;
    grp.unidadesSugeridas += skuSuggestedUnits;
    grp.skusCount += 1;
    if (skuSuggestedUnits > 0) {
      grp.skusSuggestedRefs.add(skuRec.referencia);
    }
    if (isCritico) grp.skusCriticosCount += 1;
    grp.velocidadPromedioSemanal += velocidadSemanal;
  });

  // 6. Construir filas planas para el reporte
  const flatRows: PurchaseFlatRow[] = [];
  const unidadesPorMarca: Record<string, number> = {};
  const unidadesPorDepartamento: Record<string, number> = {};
  const unidadesPorSeccion: Record<string, number> = {};
  const unidadesPorTienda: Record<string, number> = {};

  let totalUnidades = 0;
  let totalStockActual = 0;
  let totalSkus = 0;

  groupsMap.forEach((grp) => {
    // Si no hay unidades sugeridas y el stock es 0, no añadir filas vacías innecesarias
    if (grp.unidadesSugeridas <= 0 && grp.stockActual === 0) return;

    let justificacion = 'Continuidad de cobertura regular por velocidad de rotación.';
    if (grp.skusCriticosCount > 0) {
      justificacion = `Reposición prioritaria: ${grp.skusCriticosCount} modelo(s) con quiebre de tallas centrales.`;
    } else if (grp.temporada.includes('ACTUAL') || grp.temporada.includes('ALTA')) {
      justificacion = 'In-Season: Incremento de cobertura por temporada alta.';
    } else if (grp.unidadesSugeridas === 0) {
      justificacion = 'Stock actual suficiente / Colección en fase de liquidación.';
    }

    const skusRep = grp.skusSuggestedRefs.size > 0
      ? grp.skusSuggestedRefs.size
      : (grp.unidadesSugeridas > 0 ? 1 : 0);

    flatRows.push({
      Tienda: grp.tienda,
      Temporada: grp.temporada,
      Marca: grp.marca,
      Departamento: grp.departamento,
      Seccion: grp.seccion,
      Familia: grp.familia,
      StockActual: grp.stockActual,
      VelocidadEstimadaSemanal: grp.velocidadPromedioSemanal,
      UnidadesSugeridas: grp.unidadesSugeridas,
      SkusCount: skusRep,
      Justificacion: justificacion,
    });

    totalUnidades += grp.unidadesSugeridas;
    totalStockActual += grp.stockActual;
    totalSkus += skusRep;

    unidadesPorMarca[grp.marca] = (unidadesPorMarca[grp.marca] || 0) + grp.unidadesSugeridas;
    unidadesPorDepartamento[grp.departamento] = (unidadesPorDepartamento[grp.departamento] || 0) + grp.unidadesSugeridas;
    unidadesPorSeccion[grp.seccion] = (unidadesPorSeccion[grp.seccion] || 0) + grp.unidadesSugeridas;
    unidadesPorTienda[grp.tienda] = (unidadesPorTienda[grp.tienda] || 0) + grp.unidadesSugeridas;
  });

  // Ordenar filas alfabéticamente por Tienda, Marca, Depto, Seccion, Familia
  flatRows.sort((a, b) => {
    if (a.Tienda !== b.Tienda) return a.Tienda.localeCompare(b.Tienda);
    if (a.Marca !== b.Marca) return a.Marca.localeCompare(b.Marca);
    if (a.Departamento !== b.Departamento) return a.Departamento.localeCompare(b.Departamento);
    if (a.Seccion !== b.Seccion) return a.Seccion.localeCompare(b.Seccion);
    return a.Familia.localeCompare(b.Familia);
  });

  // 7. Construir Árbol Jerárquico (Tienda > Marca > Departamento > Sección > Familia)
  const hierarchyTree = buildHierarchyTree(flatRows);

  return {
    flatRows,
    hierarchyTree,
    totalUnidades,
    totalStockActual,
    totalSkus,
    unidadesPorMarca,
    unidadesPorDepartamento,
    unidadesPorSeccion,
    unidadesPorTienda,
  };
}

/**
 * Convierte las filas planas en un árbol anidado para visualización
 */
function buildHierarchyTree(rows: PurchaseFlatRow[]): PurchaseHierarchyNode[] {
  const storeMap = new Map<string, Map<string, Map<string, Map<string, Map<string, { stock: number; units: number; skus: number }>>>>>();

  rows.forEach((r) => {
    if (!storeMap.has(r.Tienda)) storeMap.set(r.Tienda, new Map());
    const brandMap = storeMap.get(r.Tienda)!;

    if (!brandMap.has(r.Marca)) brandMap.set(r.Marca, new Map());
    const deptMap = brandMap.get(r.Marca)!;

    if (!deptMap.has(r.Departamento)) deptMap.set(r.Departamento, new Map());
    const secMap = deptMap.get(r.Departamento)!;

    if (!secMap.has(r.Seccion)) secMap.set(r.Seccion, new Map());
    const famMap = secMap.get(r.Seccion)!;

    if (!famMap.has(r.Familia)) {
      famMap.set(r.Familia, { stock: 0, units: 0, skus: 0 });
    }
    const current = famMap.get(r.Familia)!;
    current.stock += r.StockActual;
    current.units += r.UnidadesSugeridas;
    current.skus += (r.SkusCount !== undefined ? r.SkusCount : (r.UnidadesSugeridas > 0 ? 1 : 0));
  });

  const tree: PurchaseHierarchyNode[] = [];

  storeMap.forEach((brandMap, tienda) => {
    let storeUnits = 0;
    let storeStock = 0;
    let storeSkus = 0;
    const brandNodes: PurchaseHierarchyNode[] = [];

    brandMap.forEach((deptMap, marca) => {
      let brandUnits = 0;
      let brandStock = 0;
      let brandSkus = 0;
      const deptNodes: PurchaseHierarchyNode[] = [];

      deptMap.forEach((secMap, depto) => {
        let deptUnits = 0;
        let deptStock = 0;
        let deptSkus = 0;
        const secNodes: PurchaseHierarchyNode[] = [];

        secMap.forEach((famMap, seccion) => {
          let secUnits = 0;
          let secStock = 0;
          let secSkus = 0;
          const famNodes: PurchaseHierarchyNode[] = [];

          famMap.forEach((val, familia) => {
            secUnits += val.units;
            secStock += val.stock;
            secSkus += val.skus;
            famNodes.push({
              id: `${tienda}-${marca}-${depto}-${seccion}-${familia}`,
              name: familia,
              level: 'familia',
              unidadesSugeridas: val.units,
              stockActual: val.stock,
              skusCount: val.skus,
            });
          });

          deptUnits += secUnits;
          deptStock += secStock;
          deptSkus += secSkus;
          secNodes.push({
            id: `${tienda}-${marca}-${depto}-${seccion}`,
            name: seccion,
            level: 'seccion',
            unidadesSugeridas: secUnits,
            stockActual: secStock,
            skusCount: secSkus,
            children: famNodes.sort((a, b) => b.unidadesSugeridas - a.unidadesSugeridas),
          });
        });

        brandUnits += deptUnits;
        brandStock += deptStock;
        brandSkus += deptSkus;
        deptNodes.push({
          id: `${tienda}-${marca}-${depto}`,
          name: depto,
          level: 'departamento',
          unidadesSugeridas: deptUnits,
          stockActual: deptStock,
          skusCount: deptSkus,
          children: secNodes.sort((a, b) => b.unidadesSugeridas - a.unidadesSugeridas),
        });
      });

      storeUnits += brandUnits;
      storeStock += brandStock;
      storeSkus += brandSkus;
      brandNodes.push({
        id: `${tienda}-${marca}`,
        name: marca,
        level: 'marca',
        unidadesSugeridas: brandUnits,
        stockActual: brandStock,
        skusCount: brandSkus,
        children: deptNodes.sort((a, b) => b.unidadesSugeridas - a.unidadesSugeridas),
      });
    });

    tree.push({
      id: `store-${tienda}`,
      name: tienda,
      level: 'tienda',
      unidadesSugeridas: storeUnits,
      stockActual: storeStock,
      skusCount: storeSkus,
      children: brandNodes.sort((a, b) => b.unidadesSugeridas - a.unidadesSugeridas),
    });
  });

  return tree.sort((a, b) => b.unidadesSugeridas - a.unidadesSugeridas);
}

/**
 * Exporta el archivo Excel profesional con 2 hojas:
 * Hoja 1: Resumen Jerárquico (Árbol con subtotales de unidades)
 * Hoja 2: Matriz Plana para Proveedores / ERP
 */
export function exportarSugeridoCompraExcel(
  flatRows: PurchaseFlatRow[],
  filename: string = 'Sugerido_Compra_Unidades.xlsx'
): void {
  if (flatRows.length === 0) {
    alert('No hay sugerencias de compra para exportar en la vista actual.');
    return;
  }

  const wb = XLSX.utils.book_new();
  const totalGlobal = flatRows.reduce((acc, r) => acc + r.UnidadesSugeridas, 0);

  // 1. Hoja: Resumen Jerárquico Comercial (Árbol con porcentajes de participación)
  const hierarchicalData = flatRows.map((r) => {
    const pct = totalGlobal > 0 ? ((r.UnidadesSugeridas / totalGlobal) * 100).toFixed(1) + '%' : '0%';
    return {
      'Tienda': r.Tienda,
      'Temporada': r.Temporada,
      'Marca': r.Marca,
      'Departamento (División)': r.Departamento,
      'Sección (Género)': r.Seccion,
      'Familia (Categoría)': r.Familia,
      'Stock Actual (Uds)': r.StockActual,
      'UNIDADES SUGERIDAS (A PEDIR)': r.UnidadesSugeridas,
      'SKUs Representados': r.SkusCount || 1,
      '% Cuota del Pedido': pct,
    };
  });

  const wsHierarchy = XLSX.utils.json_to_sheet(hierarchicalData);
  XLSX.utils.book_append_sheet(wb, wsHierarchy, 'Resumen_Jerarquico_Uds');

  // 2. Hoja: Matriz Plana Detallada para Proveedores / ERP
  const flatData = flatRows.map((r) => ({
    'Tienda': r.Tienda,
    'Temporada': r.Temporada,
    'Marca': r.Marca,
    'Departamento': r.Departamento,
    'Sección / Género': r.Seccion,
    'Familia / Silueta': r.Familia,
    'Stock Actual (Uds)': r.StockActual,
    'Velocidad Venta Estimada (Uds/Semana)': r.VelocidadEstimadaSemanal,
    'UNIDADES SUGERIDAS A PEDIR': r.UnidadesSugeridas,
    'SKUs Representados': r.SkusCount || 1,
    'Justificación de Negocio': r.Justificacion,
  }));

  const wsFlat = XLSX.utils.json_to_sheet(flatData);
  XLSX.utils.book_append_sheet(wb, wsFlat, 'Matriz_Plana_Proveedores');

  XLSX.writeFile(wb, filename);
}

/**
 * Exporta el reporte en formato CSV limpio con UTF-8 BOM
 */
export function exportarSugeridoCompraCSV(
  flatRows: PurchaseFlatRow[],
  filename: string = 'Sugerido_Compra_Unidades.csv'
): void {
  if (flatRows.length === 0) {
    alert('No hay sugerencias de compra para exportar en la vista actual.');
    return;
  }

  const headers = [
    'Tienda',
    'Temporada',
    'Marca',
    'Departamento',
    'Seccion',
    'Familia',
    'Stock_Actual_Uds',
    'Velocidad_Estimada_Semanal_Uds',
    'UNIDADES_SUGERIDAS_A_PEDIR',
    'Justificacion_Comercial',
  ];

  const escapeCSV = (val: string | number) => {
    const str = String(val ?? '').replace(/"/g, '""');
    return `"${str}"`;
  };

  const csvRows = [
    headers.map(escapeCSV).join(','),
    ...flatRows.map((row) =>
      [
        escapeCSV(row.Tienda),
        escapeCSV(row.Temporada),
        escapeCSV(row.Marca),
        escapeCSV(row.Departamento),
        escapeCSV(row.Seccion),
        escapeCSV(row.Familia),
        row.StockActual,
        row.VelocidadEstimadaSemanal,
        row.UnidadesSugeridas,
        escapeCSV(row.Justificacion),
      ].join(',')
    ),
  ];

  const csvContent = '\uFEFF' + csvRows.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
