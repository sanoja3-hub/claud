/**
 * Product Image Resolver & Search Utility
 * Resolves images from web/curated collections based on Referencia, Marca and Category,
 * and provides direct Google Image search queries.
 */

// Curated high-resolution images for popular retail sneaker and apparel models
const CURATED_IMAGES: Record<string, string> = {
  // Nike Footwear
  'NK-PEGASUS-40': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
  'NK-INVINCIBLE-3': 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80',
  'NK-METCON-9': 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
  'NK-MERCURIAL-VAPOR': 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=800&q=80',
  'NK-AIR-FORCE-1-07': 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
  'NK-INFINITYRN-4-W': 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80',
  'NK-SUPERREP-GO-3-W': 'https://images.unsplash.com/photo-1575537302964-96cd47c06b1b?auto=format&fit=crop&w=800&q=80',
  'NK-DUNK-LOW-W': 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80',
  
  // Adidas Footwear
  'AD-ULTRABOOST-LIGHT': 'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?auto=format&fit=crop&w=800&q=80',
  'AD-BOSTON-12': 'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&w=800&q=80',
  'AD-PREDATOR-ELITE': 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=800&q=80',
  'AD-SAMBA-OG': 'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?auto=format&fit=crop&w=800&q=80',
  'AD-ADIZERO-SL-W': 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80',
  'AD-GAZELLE-BOLD-W': 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=800&q=80',

  // Puma
  'PU-DEVIATE-NITRO-2': 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=800&q=80',
  'PU-FUTURE-MATCH': 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=800&q=80',
  'PU-SUEDE-CLASSIC': 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=800&q=80',

  // Asics & New Balance
  'AS-GEL-NIMBUS-26': 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
  'AS-GEL-KAYANO-30-W': 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80',
  'NB-FRESHFOAM-1080': 'https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=800&q=80',
  'NB-550-VINTAGE': 'https://images.unsplash.com/photo-1551107696-a4b085a6d96a?auto=format&fit=crop&w=800&q=80',

  // On Running & Reebok & Under Armour
  'ON-CLOUDMONSTER-2': 'https://images.unsplash.com/photo-1595341888016-a392ef81b7de?auto=format&fit=crop&w=800&q=80',
  'RB-NANO-X4': 'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=800&q=80',
  'UA-PROJECT-ROCK-6': 'https://images.unsplash.com/photo-1579338559194-a162d19bf842?auto=format&fit=crop&w=800&q=80',
  'UA-TRIBASE-REIGN-W': 'https://images.unsplash.com/photo-1575537302964-96cd47c06b1b?auto=format&fit=crop&w=800&q=80',

  // Stitch NX-Terra Pro SKU
  '884-JXK-92': 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80',

  // Textil H/M/Kids
  'NK-DRIFIT-TEE-M': 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
  'UA-TECH-2-TEE-M': 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?auto=format&fit=crop&w=800&q=80',
  'NK-MILER-RUN-M': 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80',
  'AD-OWNTHERUN-JKT-M': 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=800&q=80',
  'NK-CLUB-FLEECE-HD': 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80',
  'AD-ESSENTIALS-PANT': 'https://images.unsplash.com/photo-1552902865-b72c031ac5ea?auto=format&fit=crop&w=800&q=80',
  'NK-ACADEMY-SHORT': 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&w=800&q=80',
  'AD-TIRO-23-TRACK': 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=800&q=80',
  'NK-PRO-3INCH-SHORT-W': 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=800&q=80',
  'UA-HEATGEAR-LEGGING-W': 'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=800&q=80',
  'NK-SWOOSH-MED-BRA': 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
  'NK-SPORTSWEAR-TEE-W': 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',

  // Accesorios
  'NK-HERITAGE-CAP': 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=800&q=80',
  'AD-BASEBALL-CAP': 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=800&q=80',
  'NK-BRASILIA-DUFFEL-M': 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
  'UA-HUSTLE-5-BACKPACK': 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
  'PU-SPORTS-BOTTLE-750': 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=80',
  'NK-ELITE-CREW-SOCK': 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?auto=format&fit=crop&w=800&q=80',
};

// Generic Brand fallback photos
const BRAND_FALLBACKS: Record<string, string> = {
  NIKE: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
  ADIDAS: 'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?auto=format&fit=crop&w=800&q=80',
  PUMA: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=800&q=80',
  ASICS: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
  'NEW BALANCE': 'https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=800&q=80',
  'ON RUNNING': 'https://images.unsplash.com/photo-1595341888016-a392ef81b7de?auto=format&fit=crop&w=800&q=80',
  'UNDER ARMOUR': 'https://images.unsplash.com/photo-1579338559194-a162d19bf842?auto=format&fit=crop&w=800&q=80',
  REEBOK: 'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=800&q=80',
  CONVERSE: 'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?auto=format&fit=crop&w=800&q=80',
  SKECHERS: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
  HEAD: 'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?auto=format&fit=crop&w=800&q=80',
  HOKA: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80',
  KELME: 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=800&q=80',
};

// Fallbacks for apparel / textile & accessories
const APPAREL_IMAGE = 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80';
const ACCESSORIES_IMAGE = 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80';

/**
 * Returns a suitable web image URL for the given reference and brand.
 */
export function resolveProductImage(
  referencia: string,
  marca: string,
  departamento?: string
): string {
  if (!referencia) return BRAND_FALLBACKS.NIKE;

  const cleanRef = referencia.trim().toUpperCase();
  
  // 1. Check direct curated match
  if (CURATED_IMAGES[cleanRef]) {
    return CURATED_IMAGES[cleanRef];
  }

  // 2. Check if reference has known prefix or contains key terms
  for (const [key, url] of Object.entries(CURATED_IMAGES)) {
    if (cleanRef.includes(key) || key.includes(cleanRef)) {
      return url;
    }
  }

  // 3. Department specific fallbacks
  const deptoUpper = (departamento || '').toUpperCase();
  if (deptoUpper.includes('TEXTIL') || deptoUpper.includes('ROPA')) {
    return APPAREL_IMAGE;
  }
  if (deptoUpper.includes('ACCESORIO') || deptoUpper.includes('COMPLEMENTO')) {
    return ACCESSORIES_IMAGE;
  }

  // 4. Check brand fallback
  const cleanBrand = (marca || '').trim().toUpperCase();
  if (BRAND_FALLBACKS[cleanBrand]) {
    return BRAND_FALLBACKS[cleanBrand];
  }

  // 5. General footwear fallback
  return 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80';
}

/**
 * Generates a Google Image search URL to find exact product shots on the web
 */
export function getGoogleImagesSearchUrl(
  marca: string,
  referencia: string,
  departamento?: string
): string {
  const deptoUpper = (departamento || '').toUpperCase();
  let categoryKeyword = 'shoe sneaker';
  if (deptoUpper.includes('TEXTIL')) categoryKeyword = 'apparel clothing';
  else if (deptoUpper.includes('ACCESORIO')) categoryKeyword = 'accessory equipment';

  const query = `${marca || ''} ${referencia || ''} ${categoryKeyword} official`.trim();
  return `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(query)}`;
}
