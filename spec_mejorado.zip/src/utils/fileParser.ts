import * as XLSX from 'xlsx';
import { CapacityMatrixConfig, InventoryItem, StoreProfile } from '../types';

export interface DetectedStoreInfo {
  detectedStoreName: string;
  originalFilename: string;
  isMatchedToExisting: boolean;
  matchedExistingStore?: string;
  confidence: 'HIGH' | 'MEDIUM' | 'NEW';
}

export interface ColumnMappingConfig {
  Referencia?: string;
  Marca?: string;
  Departamento?: string;
  Genero?: string;
  Seccion?: string;
  Categoria?: string;
  Familia?: string;
  Talla?: string;
  Stock?: string;
  Valoracion?: string;
  Tienda?: string;
  FechaIngreso?: string;
  DiasAntiguedad?: string;
  ImagenUrl?: string;
  Temporada?: string;
  VentaSemanal?: string;
  Venta30D?: string;
}

export interface ParsedFileResult {
  items: InventoryItem[];
  filename: string;
  detectedStore: DetectedStoreInfo;
  detectedBrand?: string;
  sheetCount: number;
  rowCount: number;
  uniqueSkus: number;
  totalPieces: number;
  totalValuation: number;
  totalValuationBs?: number;
  bcvRateUsed?: number;
  deptBreakdown: Record<string, number>;
  brandBreakdown: Record<string, number>;
  genderBreakdown: Record<string, number>;
  sectionBreakdown: Record<string, number>;
  familyBreakdown: Record<string, number>;
  rawHeaders: string[];
  appliedMapping: ColumnMappingConfig;
  detectionConfidence: Record<keyof ColumnMappingConfig, { header: string; confidence: 'AUTO_HIGH' | 'AUTO_MEDIUM' | 'MANUAL'; matchedBy: string }>;
  rawRowsSample: Record<string, any>[];
}

/**
 * Intelligent Store Extractor from Excel / CSV Filenames
 */
export function extractStoreNameFromFilename(
  filename: string,
  existingStores: string[] = []
): DetectedStoreInfo {
  // 1. Remove file extension
  let clean = filename.replace(/\.(xlsx|xls|csv|tsv|txt)$/i, '');

  // 2. Normalize separators: replace underscores, dashes, dots, pluses with spaces
  clean = clean.replace(/[_\-+.]+/g, ' ').trim();

  // 3. Remove common automated prefix and suffix keywords (case insensitive)
  clean = clean
    .replace(/^(inventario|stock|reporte|datos|data|base|archivo|export|informe|listado|catalogo|control|matriz|retail)\s+/i, '')
    .replace(/\s+(inventario|stock|reporte|datos|data|base|archivo|export|informe|listado|catalogo|control|matriz|retail)$/i, '');

  // 4. Remove dates and versions
  clean = clean
    .replace(/\b(202[0-9]|203[0-9])\b/g, '')
    .replace(/\b\d{1,2}\s+(ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic|[a-z]{3,9})\b/gi, '')
    .replace(/\b(v\d+|\d+v|final|rev\d+|borrador|nuevo|copia|copy|completo|general|total|agosto|enero|febrero|marzo|abril|mayo|junio|julio|septiembre|octubre|noviembre|diciembre)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  // If cleaning made it too short, fallback to base name
  if (!clean || clean.length < 2) {
    clean = filename.replace(/\.[^/.]+$/, '').replace(/[_\-+.]+/g, ' ').trim();
  }

  // Capitalize nicely
  const formattedClean = clean
    .split(' ')
    .filter(Boolean)
    .map((w) => {
      if (w.length <= 4 && w === w.toUpperCase()) return w;
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    })
    .join(' ');

  // 5. Compare with existing registered stores
  const normClean = formattedClean.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

  for (const existing of existingStores) {
    const normExisting = existing.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

    if (normClean === normExisting) {
      return {
        detectedStoreName: existing,
        originalFilename: filename,
        isMatchedToExisting: true,
        matchedExistingStore: existing,
        confidence: 'HIGH',
      };
    }

    if (normExisting.length >= 4 && normClean.includes(normExisting)) {
      return {
        detectedStoreName: existing,
        originalFilename: filename,
        isMatchedToExisting: true,
        matchedExistingStore: existing,
        confidence: 'HIGH',
      };
    }

    if (normClean.length >= 4 && normExisting.includes(normClean)) {
      return {
        detectedStoreName: existing,
        originalFilename: filename,
        isMatchedToExisting: true,
        matchedExistingStore: existing,
        confidence: 'HIGH',
      };
    }
  }

  return {
    detectedStoreName: formattedClean || filename.replace(/\.[^/.]+$/, ''),
    originalFilename: filename,
    isMatchedToExisting: false,
    confidence: 'NEW',
  };
}

export function normalizeHeader(col: string): string {
  return String(col || '')
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z0-9]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .trim();
}

/**
 * Keyword dictionary with weights for intelligent header mapping
 */
const SCHEMA_KEYWORD_PATTERNS: Record<keyof ColumnMappingConfig, { exact: string[]; starts: string[]; contains: string[] }> = {
  Referencia: {
    exact: [
      'REFERENCIA', 'REF', 'SKU', 'CODIGO', 'CODIGO_SKU', 'COD_SKU', 'COD_ART', 'COD_ARTICULO', 
      'CODIGO_ARTICULO', 'ESTILO', 'STYLE', 'ARTICULO', 'PRODUCTO', 'MATERIAL', 'ITEM', 
      'ITEM_CODE', 'ITEM_NO', 'MODELO', 'MODEL', 'COD_PRODUCTO', 'COD_ESTILO', 'COD_REF',
      'REF_ID', 'ID_ARTICULO', 'COD_ITEM', 'REFERENCIA_PROD', 'ESTILO_SKU', 'SKU_ID'
    ],
    starts: ['REF', 'SKU', 'COD', 'ESTILO', 'STYLE', 'ART', 'PROD', 'MOD', 'ITEM', 'MAT'],
    contains: ['REFERENCIA', 'SKU', 'CODIGO', 'ESTILO', 'STYLE', 'ARTICULO', 'MODELO', 'MATERIAL'],
  },
  Marca: {
    exact: ['MARCA', 'BRAND', 'PROVEEDOR', 'FABRICANTE', 'TRADEMARK', 'LINEA_MARCA', 'LABEL', 'NOM_MARCA', 'BRAND_NAME', 'MARCA_DESC'],
    starts: ['MARCA', 'BRAND', 'PROV', 'FABR'],
    contains: ['MARCA', 'BRAND', 'PROVEEDOR', 'TRADEMARK', 'FABRICANTE'],
  },
  Genero: {
    exact: ['GENERO', 'GENDER', 'SEXO', 'PUBLICO', 'AUDIENCIA', 'SEGMENTO', 'TARGET', 'DIVISION_GENERO', 'GEN', 'SEX', 'GENERO_DESC'],
    starts: ['GEN', 'SEX', 'GEND', 'PUBL'],
    contains: ['GENERO', 'GENDER', 'SEXO', 'PUBLICO', 'TARGET'],
  },
  Seccion: {
    exact: [
      'SECCION', 'SECTION', 'SEC', 'DIVISION', 'ZONA', 'DIVISION_COMERCIAL', 'SECTOR', 'AREA_VENTA',
      'DIVISION_SECCION', 'DESC_SECCION', 'NOM_SECCION', 'SECC'
    ],
    starts: ['SECC', 'SECT', 'DIV', 'SEC_'],
    contains: ['SECCION', 'SECTION', 'DIVISION', 'SECTOR'],
  },
  Categoria: {
    exact: [
      'CATEGORIA', 'CATEGORY', 'CAT', 'TIPO_PRODUCTO', 'TIPO_ARTICULO', 'TIPO', 'TYPE', 
      'CLASE', 'RUBRO', 'MACROCATEGORIA', 'SUB_RUBRO', 'CATEGORIA_PRODUCTO', 'DESC_CAT'
    ],
    starts: ['CATEG', 'CAT', 'TIPO', 'TYPE', 'CLAS'],
    contains: ['CATEGORIA', 'CATEGORY', 'TIPO', 'RUBRO'],
  },
  Familia: {
    exact: [
      'FAMILIA', 'FAMILY', 'FAM', 'SUBCATEGORIA', 'SUB_CATEGORIA', 'SUBFAMILIA', 'SUB_FAMILIA', 
      'SILUETA', 'SILHOUETTE', 'LINEA', 'SUB_LINEA', 'SUBLINEA', 'DEPORTE', 'SPORT', 
      'ACTIVIDAD', 'DISCIPLINA', 'GRUPO', 'SUBGRUPO', 'SUB_GRUPO', 'FAMILIA_DESC', 'LINEA_PRODUCTO'
    ],
    starts: ['FAM', 'SUB', 'SILU', 'SILH', 'LINE', 'DEP', 'SPORT', 'DISC', 'ACTIV'],
    contains: ['FAMILIA', 'FAMILY', 'SUBCATEGORIA', 'SUBFAMILIA', 'SILUETA', 'SILHOUETTE', 'DEPORTE', 'SPORT', 'DISCIPLINA', 'LINEA'],
  },
  Departamento: {
    exact: [
      'DEPARTAMENTO', 'DEPTO', 'DEP', 'DEPARTMENT', 'DIVISION_PRODUCTO', 'SUPER_CATEGORIA', 
      'MACRO_RUBRO', 'AREA', 'MACRO_DEPTO', 'DEPTO_DESC', 'DEPARTAMENTO_PRODUCTO'
    ],
    starts: ['DEPART', 'DEPT', 'DEP_'],
    contains: ['DEPARTAMENTO', 'DEPARTMENT', 'DEPTO'],
  },
  Talla: {
    exact: [
      'TALLA', 'SIZE', 'SIZES', 'TAMANO', 'TALLAS', 'MEDIDA', 'DIMENSION', 'SIZE_NAME', 
      'TALLA_NUM', 'TAL', 'TALLA_DESC', 'TALLA_US', 'TALLA_EU', 'TALLA_MX', 'TAM', 'SIZE_CODE', 'TALLA_REAL'
    ],
    starts: ['TALL', 'SIZ', 'TAMAN', 'TAL_'],
    contains: ['TALLA', 'SIZE', 'TAMANO', 'MEDIDA'],
  },
  Stock: {
    exact: [
      'STOCK', 'CANTIDAD', 'CANT', 'QTY', 'QUANTITY', 'UNIDADES', 'UNID', 'UNITS', 'EXISTENCIAS', 
      'EXISTENCIA', 'INVENTARIO', 'PIEZAS', 'TOTAL_STOCK', 'SALDO', 'FISICO', 'CANT_DISPONIBLE', 
      'STK', 'TOTAL_UNIDADES', 'STOCK_ACTUAL', 'STOCK_TOTAL', 'CANTIDAD_FISICA', 'INV_ACTUAL', 'PZAS', 'PZA'
    ],
    starts: ['STOCK', 'CANT', 'QTY', 'UNID', 'EXIST', 'PIEZ', 'PZA', 'STK', 'INV_'],
    contains: ['STOCK', 'CANTIDAD', 'QUANTITY', 'UNIDADES', 'EXISTENCIA', 'PIEZAS', 'INVENTARIO', 'SALDO', 'FISICO'],
  },
  Valoracion: {
    exact: [
      'VALORACION', 'VALOR', 'PRECIO', 'COSTO', 'PVP', 'PRECIO_VENTA', 'VALOR_TOTAL', 'IMPORTE', 
      'TOTAL', 'MONTO', 'AMOUNT', 'PRICE', 'COST', 'VALOR_INVENTARIO', 'PRECIO_UNITARIO', 
      'COSTO_UNITARIO', 'VALOR_STOCK', 'IMPORTE_TOTAL', 'SUBTOTAL', 'VAL_TOTAL', 'PVP_TOTAL'
    ],
    starts: ['VALOR', 'PREC', 'COST', 'PVP', 'IMP', 'MONT', 'VAL_'],
    contains: ['VALORACION', 'VALOR', 'PRECIO', 'COSTO', 'IMPORTE', 'MONTO', 'PRICE', 'COST'],
  },
  Tienda: {
    exact: [
      'TIENDA', 'STORE', 'SUCURSAL', 'ALMACEN', 'LOCAL', 'UBICACION', 'PUNTO_VENTA', 'CENTRO', 
      'POS', 'STORE_NAME', 'NOM_TIENDA', 'ID_TIENDA', 'COD_TIENDA', 'SUCURSAL_DESC', 'ALMACEN_DESC'
    ],
    starts: ['TIEND', 'STOR', 'SUC', 'ALM', 'LOC', 'UBIC', 'PTO_'],
    contains: ['TIENDA', 'STORE', 'SUCURSAL', 'ALMACEN', 'UBICACION', 'LOCAL'],
  },
  FechaIngreso: {
    exact: ['FECHA_INGRESO', 'FECHA_RECEPCION', 'FECHA_COMPRA', 'FECHA_ENTRADA', 'FECHA', 'DATE', 'ING_FECHA', 'FECHA_ALTA', 'FECHA_ULTIMA_COMPRA'],
    starts: ['FECHA', 'DATE', 'RECEPCION'],
    contains: ['FECHA', 'DATE', 'INGRESO', 'ENTRADA', 'COMPRA'],
  },
  DiasAntiguedad: {
    exact: ['DIAS_ANTIGUEDAD', 'ANTIGUEDAD', 'AGING', 'DIAS_EN_TIENDA', 'DIAS_INVENTARIO', 'DIAS_STOCK', 'AGE_DAYS', 'DIAS'],
    starts: ['ANTIG', 'AGING', 'DIAS'],
    contains: ['ANTIGUEDAD', 'AGING', 'DIAS'],
  },
  ImagenUrl: {
    exact: ['IMAGEN_URL', 'URL_IMAGEN', 'IMAGEN', 'IMAGE_URL', 'IMAGE', 'FOTO', 'FOTO_URL', 'PHOTO', 'PHOTO_URL', 'PICTURE', 'PICTURE_URL', 'THUMBNAIL', 'URL_FOTO'],
    starts: ['IMG_', 'IMAGE_', 'FOTO_', 'URL_IMG', 'URL_FOTO'],
    contains: ['IMAGEN', 'IMAGE', 'FOTO', 'PHOTO', 'PICTURE'],
  },
  Temporada: {
    exact: ['TEMPORADA', 'SEASON', 'COLECCION', 'CAMPANA', 'TEMP', 'SEASONS', 'TEMPORADA_DESC', 'TEMPORADA_COD', 'TEMP_DESC'],
    starts: ['TEMP', 'SEAS', 'COLEC', 'CAMP'],
    contains: ['TEMPORADA', 'SEASON', 'CAMPANA', 'COLECCION'],
  },
  VentaSemanal: {
    exact: ['VENTA_SEMANAL', 'VENTAS_SEMANAL', 'WEEKLY_SALES', 'VENTA_SEM', 'VTA_SEM', 'VENTAS_SEM', 'RITMO_VENTA', 'PROMEDIO_SEMANAL', 'AVG_WEEKLY_SALES', 'RATE_OF_SALE', 'VENTA_SEMANAL_PROM', 'VENTA_POR_SEMANA', 'SALES_PW'],
    starts: ['VENTA_SEM', 'VTA_SEM', 'WEEKLY', 'SALES_W'],
    contains: ['VENTA_SEMANAL', 'WEEKLY_SALES', 'VTA_SEM', 'RITMO_VENTA'],
  },
  Venta30D: {
    exact: ['VENTA_30D', 'VENTAS_30D', 'VENTA_ULTIMOS_30_DIAS', 'VENTAS_30_DIAS', 'VTA_30D', 'SALES_30D', 'UNIDADES_VENDIDAS_30D', 'VENTA_MES', 'VENTAS_MES', 'VTA_MES', 'VENTAS_30D_UDS'],
    starts: ['VENTA_30', 'VTA_30', 'SALES_30', 'VENTA_MES', 'VTA_MES'],
    contains: ['VENTA_30', 'VENTAS_30', '30D', '30_DIAS'],
  },
};

export const WELL_KNOWN_BRANDS = [
  'NIKE',
  'JORDAN',
  'ADIDAS',
  'PUMA',
  'UNDER ARMOUR',
  'NEW BALANCE',
  'ASICS',
  'REEBOK',
  'CONVERSE',
  'VANS',
  'ON RUNNING',
  'HOKA',
  'SALOMON',
  'FILA',
  'CHAMPION',
  'THE NORTH FACE',
  'COLUMBIA',
  'OAKLEY',
  'SKECHERS',
  'TIMBERLAND',
  'UMBRO',
  'KAPPA',
  'MIZUNO',
  'LE COQ SPORTIF',
  'WILSON',
  'HEAD',
  'KELME',
  'BABOLAT',
  'ARENA',
  'SPEEDO',
];

const KNOWN_SIZE_TOKENS = new Set([
  'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', '2XL', '3XL', '4XL',
  'S/M', 'L/XL', 'M/L', 'XS/S',
  'U', 'OS', 'UNITALLA', 'UNICA', 'ONE SIZE', 'T_U', 'TU',
  '2T', '3T', '4T', '5T',
  '2C', '3C', '4C', '5C', '6C', '7C', '8C', '9C', '10C', '11C', '12C', '13C',
  '1Y', '1.5Y', '2Y', '2.5Y', '3Y', '3.5Y', '4Y', '4.5Y', '5Y', '5.5Y', '6Y', '6.5Y', '7Y',
  '2', '4', '6', '8', '10', '12', '14', '16', '18',
]);

/**
 * Checks if a sample value looks like a retail product size (Talla)
 */
function isLikelySizeValue(val: any): boolean {
  if (val === undefined || val === null || val === '') return false;
  const str = String(val).trim().toUpperCase();

  if (KNOWN_SIZE_TOKENS.has(str)) return true;

  // Numeric shoe sizes (e.g. 3.5, 4, 4.5, 5, 5.5, ... 15, 35, 36, ... 48, 22.5, 23, 29)
  const num = parseFloat(str);
  if (!isNaN(num)) {
    // US sizes 3 - 16 (including half sizes like 8.5)
    if (num >= 1 && num <= 16 && (num * 2) % 1 === 0) return true;
    // EUR / MX / CM sizes 20 - 52
    if (num >= 18 && num <= 52) return true;
  }

  // Combined size strings like "8.5 US", "42 EUR", "26 MX", "M (38-40)"
  if (/^(\d{1,2}(\.5)?|\b(XS|S|M|L|XL|2XL|3XL)\b)\s*(US|EU|EUR|MX|CM|UK)?$/i.test(str)) {
    return true;
  }

  return false;
}

/**
 * Checks if a sample value looks like Department (Calzado, Textil, Accesorios)
 */
function isLikelyDepartmentValue(val: any): boolean {
  if (!val) return false;
  const str = String(val).toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  return (
    str.includes('CALZAD') ||
    str.includes('FOOTWEAR') ||
    str.includes('ZAPAT') ||
    str.includes('SNEAKER') ||
    str.includes('SHOES') ||
    str.includes('TEXTIL') ||
    str.includes('APPAREL') ||
    str.includes('ROPA') ||
    str.includes('INDUMENTARIA') ||
    str.includes('VESTUARIO') ||
    str.includes('ACCESORI') ||
    str.includes('ACCESSOR') ||
    str.includes('EQUIPMENT') ||
    str.includes('EQUIPO') ||
    str.includes('COMPLEMENT')
  );
}

/**
 * Checks if a sample value looks like Section (Hombre, Mujer, Niños/Infante/Junior)
 */
function isLikelySectionOrGenderValue(val: any): boolean {
  if (!val) return false;
  const str = String(val).toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  return (
    str.includes('HOMBRE') ||
    str.includes('MENS') ||
    str.includes('MEN') ||
    str.includes('CABALLERO') ||
    str.includes('MUJER') ||
    str.includes('WOMENS') ||
    str.includes('WOMEN') ||
    str.includes('DAMA') ||
    str.includes('NINO') ||
    str.includes('NINA') ||
    str.includes('INFANT') ||
    str.includes('JUNIOR') ||
    str.includes('KID') ||
    str.includes('BOY') ||
    str.includes('GIRL') ||
    str.includes('BEBE') ||
    str.includes('YOUTH') ||
    str.includes('UNISEX') ||
    str.includes('GLOBAL')
  );
}

/**
 * Checks if a sample value looks like Family (Sportswear, Running, Training, Fútbol, etc.)
 */
function isLikelyFamilyValue(val: any): boolean {
  if (!val) return false;
  const str = String(val).toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  return (
    str.includes('SPORTSWEAR') ||
    str.includes('RUNNING') ||
    str.includes('TRAINING') ||
    str.includes('FUTBOL') ||
    str.includes('FOOTBALL') ||
    str.includes('SOCCER') ||
    str.includes('BASKETBALL') ||
    str.includes('JORDAN') ||
    str.includes('CASUAL') ||
    str.includes('LIFESTYLE') ||
    str.includes('OUTDOOR') ||
    str.includes('TRAIL') ||
    str.includes('TENNIS') ||
    str.includes('PADEL') ||
    str.includes('NATACION') ||
    str.includes('SWIM') ||
    str.includes('GOLF') ||
    str.includes('GYM') ||
    str.includes('FITNESS') ||
    str.includes('SKATE') ||
    str.includes('CROSSFIT') ||
    str.includes('MOTORSPORT') ||
    str.includes('ATHLETICS')
  );
}

/**
 * Checks if a sample value looks like Brand
 */
function isLikelyBrandValue(val: any): boolean {
  if (!val) return false;
  const str = String(val).toUpperCase().trim();
  return WELL_KNOWN_BRANDS.some((b) => str.includes(b));
}

/**
 * Profiles non-empty values of a column to calculate content-based affinity scores
 */
export function profileColumnContent(values: any[]): Record<keyof ColumnMappingConfig, number> {
  const sample = values.filter((v) => v !== undefined && v !== null && String(v).trim() !== '').slice(0, 80);
  const total = sample.length;

  const contentScores: Record<keyof ColumnMappingConfig, number> = {
    Referencia: 0,
    Marca: 0,
    Departamento: 0,
    Genero: 0,
    Seccion: 0,
    Categoria: 0,
    Familia: 0,
    Talla: 0,
    Stock: 0,
    Valoracion: 0,
    Tienda: 0,
    FechaIngreso: 0,
    DiasAntiguedad: 0,
    Temporada: 0,
    ImagenUrl: 0,
    VentaSemanal: 0,
    Venta30D: 0,
  };

  if (total === 0) return contentScores;

  let sizeMatches = 0;
  let deptMatches = 0;
  let sectionMatches = 0;
  let familyMatches = 0;
  let brandMatches = 0;
  let urlMatches = 0;
  let integerCount = 0;
  let currencyOrFloatCount = 0;
  let alphanumericSkuCount = 0;
  let avgLength = 0;

  for (const v of sample) {
    const str = String(v).trim();
    avgLength += str.length;

    if (isLikelySizeValue(v)) sizeMatches++;
    if (isLikelyDepartmentValue(v)) deptMatches++;
    if (isLikelySectionOrGenderValue(v)) sectionMatches++;
    if (isLikelyFamilyValue(v)) familyMatches++;
    if (isLikelyBrandValue(v)) brandMatches++;
    if (/^https?:\/\/.+/i.test(str) || /\.(jpe?g|png|webp|svg|gif)($|\?)/i.test(str)) {
      urlMatches++;
    }

    // Check if numeric
    const cleanNumStr = str.replace(/[$€£,\s]/g, '');
    const num = parseFloat(cleanNumStr);
    if (!isNaN(num)) {
      if (Number.isInteger(num) && num >= 0 && num <= 5000 && !str.includes('.') && !str.includes(',')) {
        integerCount++;
      } else if (str.includes('.') || str.includes(',') || str.includes('$') || num > 20) {
        currencyOrFloatCount++;
      }
    }

    // SKU / Reference pattern: letters + numbers or hyphen/underscore, 4 to 20 chars
    if (/^[A-Z0-9_\-\.]{4,24}$/i.test(str) && /[A-Z]/i.test(str) && /\d/.test(str)) {
      alphanumericSkuCount++;
    }
  }

  avgLength = avgLength / total;

  // Compute Content Confidence
  const sizeRatio = sizeMatches / total;
  if (sizeRatio >= 0.5 && avgLength <= 8) {
    contentScores.Talla += Math.round(sizeRatio * 160);
  }

  const deptRatio = deptMatches / total;
  if (deptRatio >= 0.4) {
    contentScores.Departamento += Math.round(deptRatio * 150);
  }

  const secRatio = sectionMatches / total;
  if (secRatio >= 0.4) {
    contentScores.Seccion += Math.round(secRatio * 140);
    contentScores.Genero += Math.round(secRatio * 120);
  }

  const famRatio = familyMatches / total;
  if (famRatio >= 0.3) {
    contentScores.Familia += Math.round(famRatio * 150);
    contentScores.Categoria += Math.round(famRatio * 90);
  }

  const brandRatio = brandMatches / total;
  if (brandRatio >= 0.4) {
    contentScores.Marca += Math.round(brandRatio * 160);
  }

  const skuRatio = alphanumericSkuCount / total;
  if (skuRatio >= 0.4) {
    contentScores.Referencia += Math.round(skuRatio * 130);
  }

  const intRatio = integerCount / total;
  if (intRatio >= 0.6 && avgLength <= 6) {
    contentScores.Stock += Math.round(intRatio * 120);
  }

  const valRatio = currencyOrFloatCount / total;
  if (valRatio >= 0.5) {
    contentScores.Valoracion += Math.round(valRatio * 130);
  }

  const urlRatio = urlMatches / total;
  if (urlRatio >= 0.3) {
    contentScores.ImagenUrl += Math.round(urlRatio * 180);
  }

  return contentScores;
}

/**
 * Multi-tier Dynamic Weighted Column Matching (Header Name + Live Cell Content Profiling)
 */
export function matchColumns(
  headers: string[],
  sampleRows: Record<string, any>[] = []
): {
  mapping: ColumnMappingConfig;
  confidences: Record<keyof ColumnMappingConfig, { header: string; confidence: 'AUTO_HIGH' | 'AUTO_MEDIUM' | 'MANUAL'; matchedBy: string }>;
} {
  const mapping: ColumnMappingConfig = {};
  const confidences: Record<keyof ColumnMappingConfig, { header: string; confidence: 'AUTO_HIGH' | 'AUTO_MEDIUM' | 'MANUAL'; matchedBy: string }> = {} as any;
  const usedHeaders = new Set<string>();

  const fieldsOrder: (keyof ColumnMappingConfig)[] = [
    'Referencia',
    'Talla',
    'Stock',
    'Marca',
    'Departamento',
    'Seccion',
    'Genero',
    'Familia',
    'Categoria',
    'Valoracion',
    'Tienda',
    'VentaSemanal',
    'Venta30D',
    'ImagenUrl',
  ];

  // Pre-profile content for each raw column
  const columnProfiles: Record<string, Record<keyof ColumnMappingConfig, number>> = {};
  for (const hdr of headers) {
    const values = sampleRows.map((r) => r[hdr]);
    columnProfiles[hdr] = profileColumnContent(values);
  }

  // Calculate scores combining Header Pattern + Content Analysis
  const candidates: {
    field: keyof ColumnMappingConfig;
    header: string;
    score: number;
    matchedBy: string;
  }[] = [];

  for (const field of fieldsOrder) {
    const patterns = SCHEMA_KEYWORD_PATTERNS[field];

    for (const rawHeader of headers) {
      const norm = normalizeHeader(rawHeader);
      let headerScore = 0;
      let matchType = '';

      if (patterns.exact.includes(norm)) {
        headerScore = 120;
        matchType = `Encabezado exacto: "${rawHeader}"`;
      } else if (patterns.starts.some((s) => norm.startsWith(s))) {
        headerScore = 80;
        matchType = `Prefijo de encabezado: "${rawHeader}"`;
      } else if (patterns.contains.some((c) => norm.includes(c))) {
        headerScore = 50;
        matchType = `Contiene término: "${rawHeader}"`;
      }

      const contentScore = columnProfiles[rawHeader]?.[field] || 0;
      if (contentScore > 0 && !matchType) {
        matchType = `Detección por contenido de celda (${contentScore} pts)`;
      } else if (contentScore > 0) {
        matchType += ` + Contenido validado`;
      }

      const totalScore = headerScore + contentScore;

      if (totalScore >= 40) {
        candidates.push({
          field,
          header: rawHeader,
          score: totalScore,
          matchedBy: matchType || 'Inferencia contextual',
        });
      }
    }
  }

  // Sort candidates descending by combined confidence score
  candidates.sort((a, b) => b.score - a.score);

  // Assign greedily
  for (const { field, header, score, matchedBy } of candidates) {
    if (!mapping[field] && !usedHeaders.has(header)) {
      mapping[field] = header;
      usedHeaders.add(header);
      confidences[field] = {
        header,
        confidence: score >= 100 ? 'AUTO_HIGH' : 'AUTO_MEDIUM',
        matchedBy,
      };
    }
  }

  return { mapping, confidences };
}

/**
 * Smart Brand Detector from text, reference or filename
 */
export function detectBrandFromTokens(text: string): string | null {
  if (!text) return null;
  const upper = text.toUpperCase();

  for (const brand of WELL_KNOWN_BRANDS) {
    if (upper.includes(brand)) return brand;
  }

  // Common acronym checks
  if (upper.startsWith('NK-') || upper.startsWith('NK_') || upper.includes('NIKE')) return 'NIKE';
  if (upper.startsWith('JD-') || upper.startsWith('AIR JORDAN') || upper.includes('JORDAN')) return 'JORDAN';
  if (upper.startsWith('AD-') || upper.startsWith('ADI-') || upper.includes('ADIDAS')) return 'ADIDAS';
  if (upper.startsWith('PM-') || upper.includes('PUMA')) return 'PUMA';
  if (upper.startsWith('NB-') || upper.includes('NEW BALANCE')) return 'NEW BALANCE';
  if (upper.startsWith('UA-') || upper.includes('ARMOUR')) return 'UNDER ARMOUR';
  if (upper.startsWith('AS-') || upper.includes('ASICS')) return 'ASICS';
  if (upper.startsWith('RB-') || upper.includes('REEBOK')) return 'REEBOK';
  if (upper.startsWith('CV-') || upper.includes('CONVERSE')) return 'CONVERSE';
  if (upper.startsWith('VN-') || upper.includes('VANS')) return 'VANS';
  if (upper.startsWith('SK-') || upper.includes('SKECHERS')) return 'SKECHERS';
  if (upper.startsWith('HK-') || upper.includes('HOKA')) return 'HOKA';
  if (upper.startsWith('KL-') || upper.includes('KELME')) return 'KELME';
  if (upper.startsWith('HD-') || upper.includes('HEAD')) return 'HEAD';
  if (upper.startsWith('ON-') || upper.includes('ON RUNNING') || upper.includes('ON RINNING')) return 'ON RUNNING';

  return null;
}

/**
 * Smart Department Resolver from Department, Category, Family, and Reference
 * Classifies strictly into: 'CALZADO' | 'TEXTIL' | 'ACCESORIOS'
 */
export function resolveDepartment(
  rawDepto: string,
  rawCat: string,
  rawFam: string,
  rawRef: string,
  rawSec: string
): string {
  const cleanDepto = (rawDepto || '').trim().toUpperCase();
  const cleanCat = (rawCat || '').trim().toUpperCase();

  // 0. Explicit Department / Category direct declaration (Strict ERP/Catalog fidelity)
  // If the user's file or ERP explicitly declares TEXTIL / ROPA / APPAREL, honor it unconditionally
  if (
    cleanDepto === 'TEXTIL' ||
    cleanDepto.includes('TEXTIL') ||
    cleanDepto.includes('APPAREL') ||
    cleanDepto.includes('ROPA') ||
    cleanDepto.includes('INDUMENTARIA') ||
    cleanDepto.includes('CONFECCION') ||
    cleanCat === 'TEXTIL' ||
    cleanCat.includes('TEXTIL') ||
    cleanCat.includes('APPAREL') ||
    cleanCat.includes('ROPA')
  ) {
    return 'TEXTIL';
  }

  if (
    cleanDepto === 'CALZADO' ||
    cleanDepto.includes('CALZAD') ||
    cleanDepto.includes('FOOTWEAR') ||
    cleanDepto.includes('ZAPAT') ||
    cleanCat === 'CALZADO' ||
    cleanCat.includes('CALZAD') ||
    cleanCat.includes('FOOTWEAR')
  ) {
    return 'CALZADO';
  }

  if (
    cleanDepto === 'ACCESORIOS' ||
    cleanDepto.includes('ACCESORI') ||
    cleanDepto.includes('ACCESSOR') ||
    cleanCat === 'ACCESORIOS' ||
    cleanCat.includes('ACCESORI')
  ) {
    return 'ACCESORIOS';
  }

  const combined = `${cleanDepto} ${cleanCat} ${rawFam || ''} ${rawSec || ''} ${rawRef || ''}`
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  // 1. Footwear checks (sneakers, boots, shoes, sandals)
  if (
    combined.includes('CALZAD') ||
    combined.includes('FOOTWEAR') ||
    combined.includes('ZAPAT') ||
    combined.includes('SNEAKER') ||
    combined.includes('TENIS') ||
    combined.includes('SHOES') ||
    combined.includes('BOTAS') ||
    combined.includes('SANDAL') ||
    combined.includes('CHIMBA') ||
    combined.includes('CLEATS') ||
    combined.includes('TACOS') ||
    combined.includes('SLIDES') ||
    combined.includes('CHANCLAS')
  ) {
    return 'CALZADO';
  }

  // 2. Apparel / Textil checks (Check BEFORE accessories to avoid false positives like "CAP" in CAPUCHA or "BAG" in BAGGY)
  if (
    combined.includes('TEXTIL') ||
    combined.includes('APPAREL') ||
    combined.includes('ROPA') ||
    combined.includes('INDUMENTARIA') ||
    combined.includes('VESTUARIO') ||
    combined.includes('CAMISETA') ||
    combined.includes('CAMISA') ||
    combined.includes('PLAYERA') ||
    combined.includes('POLERA') ||
    combined.includes('REMERA') ||
    combined.includes('T-SHIRT') ||
    combined.includes('SHIRT') ||
    combined.includes('TEE') ||
    combined.includes('JERSEY') ||
    combined.includes('POLO') ||
    combined.includes('HOODIE') ||
    combined.includes('SUDADERA') ||
    combined.includes('PANTALON') ||
    combined.includes('PANTS') ||
    combined.includes('JOGGER') ||
    combined.includes('SHORT') ||
    combined.includes('BERMUDA') ||
    combined.includes('CHAQUETA') ||
    combined.includes('JACKET') ||
    combined.includes('CAMPERA') ||
    combined.includes('ROMPEVIENTOS') ||
    combined.includes('WINDBREAKER') ||
    combined.includes('LEGGING') ||
    combined.includes('TIGHTS') ||
    combined.includes('MALLA') ||
    combined.includes('TOP') ||
    combined.includes('BRA') ||
    combined.includes('FALDA') ||
    combined.includes('SKIRT') ||
    combined.includes('BUZO') ||
    combined.includes('SWEATER') ||
    combined.includes('VESTIDO') ||
    combined.includes('DRESS') ||
    combined.includes('TRAJE DE BANO') ||
    combined.includes('SWIMSUIT') ||
    combined.includes('CAPUCHA') ||
    combined.includes('CAPRI') ||
    combined.includes('CAPITON') ||
    combined.includes('MEDIAS') ||
    combined.includes('SOCKS') ||
    combined.includes('CALCETIN') ||
    combined.includes('BOXER') ||
    combined.includes('UNDERWEAR') ||
    combined.includes('CHANDAL') ||
    combined.includes('BAGGY')
  ) {
    return 'TEXTIL';
  }

  // 3. Equipment & True Accessories checks (using safe token/substring patterns)
  const isSafeAccessoryToken =
    /\b(CAP|CAPS|HAT|HATS|BEANIE|VISOR|VISERA|GORRA|GORRO|BAG|BAGS|BACKPACK|MOCHILA|DUFFEL|TOTE|BALL|BALON|PELOTA|GLOVES|GUANTES|WALLET|BILLETERA|BELT|CINTURON|BOTTLE|BOTELLA|TERMO|SHAKER|GLASSES|GAFAS|SUNGLASSES)\b/.test(
      combined
    );

  if (
    isSafeAccessoryToken ||
    combined.includes('ACCESORI') ||
    combined.includes('ACCESSOR') ||
    combined.includes('EQUIPMENT') ||
    combined.includes('COMPLEMENT') ||
    combined.includes('MOCHILA') ||
    combined.includes('BACKPACK') ||
    combined.includes('BOLSO') ||
    combined.includes('DUFFEL') ||
    combined.includes('MALETIN') ||
    combined.includes('BALON') ||
    combined.includes('CANGURO') ||
    combined.includes('RINONERA') ||
    combined.includes('BILLETERA') ||
    combined.includes('CANILLERA') ||
    combined.includes('ESPINILLERA') ||
    combined.includes('MUNEQUERA') ||
    combined.includes('LLAVERO') ||
    combined.includes('RELOJ')
  ) {
    return 'ACCESORIOS';
  }

  return 'TEXTIL';
}

/**
 * Smart Section & Gender Resolver
 * Unifies all Kids/Infant/Junior variations into 'INFANTE / NIÑOS'
 * Unifies Men into 'HOMBRE (MENS)'
 * Unifies Women into 'MUJER (WOMENS)'
 * Unifies General/Accessories into 'UNISEX / GLOBAL'
 */
export function resolveSectionAndGender(
  rawGenero: string = '',
  rawSeccion: string = '',
  rawRef: string = '',
  rawTalla: string = ''
): { seccion: string; genero: string } {
  const gStr = (rawGenero || '').trim();
  const sStr = (rawSeccion || '').trim();
  const rStr = (rawRef || '').trim();
  const tStr = (rawTalla || '').trim();
  const gUpper = gStr.toUpperCase();
  const tUpper = tStr.toUpperCase();

  const combined = `${gStr} ${sStr} ${rStr}`
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();

  // 1. NIÑOS / INFANTE / JUNIOR UNIFICATION (Crucial rule)
  // Involves: infante niña, infante niño, infante unisex, junior niña, junior niño, junior unisex, kids, boy, girl, toddler, bebe, preescolar, youth
  if (
    combined.includes('INFANTE NINA') ||
    combined.includes('INFANTE NINO') ||
    combined.includes('INFANTE UNISEX') ||
    combined.includes('JUNIOR NINA') ||
    combined.includes('JUNIOR NINO') ||
    combined.includes('JUNIOR UNISEX') ||
    combined.includes('INFANTE') ||
    combined.includes('JUNIOR') ||
    combined.includes('NINO') ||
    combined.includes('NINA') ||
    combined.includes('NINOS') ||
    combined.includes('NINAS') ||
    combined.includes('KID') ||
    combined.includes('KIDS') ||
    combined.includes('BOY') ||
    combined.includes('BOYS') ||
    combined.includes('GIRL') ||
    combined.includes('GIRLS') ||
    combined.includes('INFANT') ||
    combined.includes('TODDLER') ||
    combined.includes('BEBE') ||
    combined.includes('BABY') ||
    combined.includes('PREESCOLAR') ||
    combined.includes('YOUTH') ||
    combined.includes('CHAVAL') ||
    combined.includes('INFANTIL') ||
    tUpper.endsWith('C') ||
    tUpper.endsWith('Y') ||
    tUpper.endsWith('T')
  ) {
    return {
      seccion: 'INFANTE / NIÑOS',
      genero: 'NIÑOS',
    };
  }

  // 2. MUJER / WOMENS
  if (
    combined.includes('MUJER') ||
    combined.includes('WOMENS') ||
    combined.includes('WOMEN') ||
    combined.includes('DAMA') ||
    combined.includes('FEMALE') ||
    combined.includes('LADIES') ||
    combined.includes('LADY') ||
    combined.includes('WOMAN') ||
    gUpper === 'F' ||
    gUpper === 'W'
  ) {
    return {
      seccion: 'MUJER (WOMENS)',
      genero: 'MUJER',
    };
  }

  // 3. HOMBRE / MENS
  if (
    combined.includes('HOMBRE') ||
    combined.includes('CABALLERO') ||
    combined.includes('MALE') ||
    combined.includes('VARON') ||
    gUpper === 'H' ||
    (gUpper === 'M' && !gUpper.includes('MUJER') && !combined.includes('WOMEN')) ||
    ((combined.includes('MEN') || combined.includes('MENS') || combined.includes('MAN')) && !combined.includes('WOMEN') && !combined.includes('WOMAN'))
  ) {
    return {
      seccion: 'HOMBRE (MENS)',
      genero: 'HOMBRE',
    };
  }

  // 4. UNISEX / GLOBAL
  if (
    combined.includes('UNISEX') ||
    combined.includes('GLOBAL') ||
    combined.includes('TODOS') ||
    combined.includes('ALL') ||
    combined.includes('NEUTRO')
  ) {
    return {
      seccion: 'UNISEX / GLOBAL',
      genero: 'UNISEX',
    };
  }

  // Fallbacks
  if (sStr.length > 1) {
    return {
      seccion: sStr.toUpperCase(),
      genero: gStr ? gStr.toUpperCase() : 'UNISEX',
    };
  }

  if (gStr.length > 1) {
    return { seccion: gUpper, genero: gUpper };
  }

  return {
    seccion: 'UNISEX / GLOBAL',
    genero: 'UNISEX',
  };
}

/**
 * Smart Family / Subcategory Resolver
 * Maps to standard retail sports/silhouettes: Sportswear, Running, Training, Fútbol, Basketball, etc.
 */
export function resolveFamily(
  rawFamilia: string,
  rawCategoria: string,
  rawSeccion: string,
  rawRef: string
): string {
  const combined = `${rawFamilia} ${rawCategoria} ${rawRef}`
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');

  if (
    combined.includes('SPORTSWEAR') ||
    combined.includes('CASUAL') ||
    combined.includes('LIFESTYLE') ||
    combined.includes('HERITAGE') ||
    combined.includes('ORIGINALS') ||
    combined.includes('CLASSIC') ||
    combined.includes('ESSENTIAL') ||
    combined.includes('AIR FORCE') ||
    combined.includes('DUNK') ||
    combined.includes('SAMBA') ||
    combined.includes('GAZELLE') ||
    combined.includes('STAN SMITH') ||
    combined.includes('SUEDE') ||
    combined.includes('BLAZER') ||
    combined.includes('CORTEZ') ||
    combined.includes('AIR MAX')
  ) {
    return 'CASUAL / SPORTSWEAR';
  }

  if (
    combined.includes('RUNNING') ||
    combined.includes('RUN') ||
    combined.includes('CORRER') ||
    combined.includes('MARATON') ||
    combined.includes('PEGASUS') ||
    combined.includes('VOMERO') ||
    combined.includes('INFINITY') ||
    combined.includes('INVINCIBLE') ||
    combined.includes('ULTRABOOST') ||
    combined.includes('ADIZERO') ||
    combined.includes('KAYANO') ||
    combined.includes('NIMBUS') ||
    combined.includes('CLOUDMONSTER')
  ) {
    return 'RUNNING';
  }

  if (
    combined.includes('TRAINING') ||
    combined.includes('TRAIN') ||
    combined.includes('FITNESS') ||
    combined.includes('GYM') ||
    combined.includes('ENTRENAMIENTO') ||
    combined.includes('CROSSFIT') ||
    combined.includes('METCON') ||
    combined.includes('SUPERREP') ||
    combined.includes('TRIBASE') ||
    combined.includes('NANO')
  ) {
    return 'TRAINING';
  }

  if (
    combined.includes('FUTBOL') ||
    combined.includes('FOOTBALL') ||
    combined.includes('SOCCER') ||
    combined.includes('MERCURIAL') ||
    combined.includes('PHANTOM') ||
    combined.includes('TIEMPO') ||
    combined.includes('PREDATOR') ||
    combined.includes('COPA') ||
    combined.includes('FUTURE') ||
    combined.includes('ULTRA')
  ) {
    return 'FUTBOL';
  }

  if (
    combined.includes('BASKETBALL') ||
    combined.includes('BASKET') ||
    combined.includes('BALONCESTO') ||
    combined.includes('JORDAN') ||
    combined.includes('LEBRON') ||
    combined.includes('KOBE') ||
    combined.includes('CURRY') ||
    combined.includes('HARDEN') ||
    combined.includes('DON ISSUE') ||
    combined.includes('LUKA') ||
    combined.includes('JA')
  ) {
    return 'BASKETBALL / JORDAN';
  }

  if (
    combined.includes('TENNIS') ||
    combined.includes('TENIS') ||
    combined.includes('PADEL') ||
    combined.includes('VAPOR PRO') ||
    combined.includes('BARICADE')
  ) {
    return 'TENNIS / PADEL';
  }

  if (
    combined.includes('OUTDOOR') ||
    combined.includes('TRAIL') ||
    combined.includes('SENDERISMO') ||
    combined.includes('TERREX') ||
    combined.includes('ACG') ||
    combined.includes('SPEEDCROSS')
  ) {
    return 'OUTDOOR / TRAIL';
  }

  if (
    combined.includes('SKATE') ||
    combined.includes('SKATEBOARDING') ||
    combined.includes('SB') ||
    combined.includes('OLD SKOOL') ||
    combined.includes('SK8')
  ) {
    return 'SKATEBOARDING';
  }

  if (
    combined.includes('NATACION') ||
    combined.includes('SWIM') ||
    combined.includes('AGUA') ||
    combined.includes('PISCINA')
  ) {
    return 'NATACION / SWIM';
  }

  if (combined.includes('GOLF')) {
    return 'GOLF';
  }

  if (combined.includes('MOTORSPORT') || combined.includes('RACING') || combined.includes('F1')) {
    return 'MOTORSPORT';
  }

  // If clean explicit family is present in rawFamilia, preserve it uppercase
  if (rawFamilia && rawFamilia.trim().length > 1 && rawFamilia.toUpperCase() !== 'GENERAL' && rawFamilia.toUpperCase() !== 'UNDEFINED') {
    return rawFamilia.trim().toUpperCase();
  }

  if (rawCategoria && rawCategoria.trim().length > 1 && rawCategoria.toUpperCase() !== 'GENERAL' && rawCategoria.toUpperCase() !== 'UNDEFINED') {
    return rawCategoria.trim().toUpperCase();
  }

  return 'UNIFICADO';
}

/**
 * Clean Talla (Size) string
 */
export function cleanSizeString(rawTalla: any): string {
  if (rawTalla === undefined || rawTalla === null || rawTalla === '') return 'U';
  let str = String(rawTalla).trim().toUpperCase();

  // If number like "8.0" or "9.00", convert to "8" or "9", but preserve "8.5"
  const num = parseFloat(str);
  if (!isNaN(num)) {
    if (String(num) === str.replace(/\.0+$/, '')) {
      return str.replace(/\.0+$/, '');
    }
  }

  // Clean trailing spaces and quote marks
  str = str.replace(/['"]/g, '').trim();

  return str || 'U';
}

/**
 * Clean numeric values like stock or price safely
 */
export function parseNumberSafely(val: any): number {
  if (val === undefined || val === null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;

  const clean = String(val)
    .replace(/[^0-9.,\-]/g, '')
    .replace(/,/g, '.');

  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}

/**
 * Core parsing function for inventory Excel/CSV files with dynamic automatic column mapping
 */
export async function parseInventoryFile(
  file: File,
  targetStoreOverride?: string,
  existingStores: string[] = [],
  customMappingOverride?: ColumnMappingConfig,
  bcvRate: number = 855.66
): Promise<ParsedFileResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        
        const detectedStore = extractStoreNameFromFilename(file.name, existingStores);
        const finalStoreName = targetStoreOverride || detectedStore.detectedStoreName;

        if (!rawRows || rawRows.length === 0) {
          resolve({
            items: [],
            filename: file.name,
            detectedStore,
            sheetCount: workbook.SheetNames.length,
            rowCount: 0,
            uniqueSkus: 0,
            totalPieces: 0,
            totalValuation: 0,
            deptBreakdown: {},
            brandBreakdown: {},
            genderBreakdown: {},
            sectionBreakdown: {},
            familyBreakdown: {},
            rawHeaders: [],
            appliedMapping: {},
            detectionConfidence: {} as any,
            rawRowsSample: [],
          });
          return;
        }

        const headers = Object.keys(rawRows[0] || {});
        const { mapping: autoMapping, confidences } = matchColumns(headers, rawRows.slice(0, 100));
        const mapping: ColumnMappingConfig = { ...autoMapping, ...customMappingOverride };

        // If custom overrides were provided, mark them in confidences
        if (customMappingOverride) {
          for (const [k, v] of Object.entries(customMappingOverride)) {
            if (v) {
              confidences[k as keyof ColumnMappingConfig] = {
                header: v,
                confidence: 'MANUAL',
                matchedBy: 'Asignación manual del usuario',
              };
            }
          }
        }

        const skuSet = new Set<string>();
        let totalPieces = 0;
        let totalValuation = 0;
        let totalValuationBs = 0;
        const effectiveBcvRate = bcvRate > 0 ? bcvRate : 855.66;
        const deptBreakdown: Record<string, number> = {};
        const brandBreakdown: Record<string, number> = {};
        const genderBreakdown: Record<string, number> = {};
        const sectionBreakdown: Record<string, number> = {};
        const familyBreakdown: Record<string, number> = {};

        // Detect potential brand from filename if not found in data
        const filenameBrand = detectBrandFromTokens(file.name);

        const items: InventoryItem[] = rawRows.map((row, idx) => {
          const rawRef = mapping.Referencia ? String(row[mapping.Referencia] || '').trim() : '';
          const ref = (rawRef && rawRef !== 'undefined' && rawRef !== 'null') ? rawRef.toUpperCase() : `SKU-${idx + 1}`;

          const rawMarca = mapping.Marca ? String(row[mapping.Marca] || '').trim() : '';
          const rawGenero = mapping.Genero ? String(row[mapping.Genero] || '').trim() : '';
          const rawSeccion = mapping.Seccion ? String(row[mapping.Seccion] || '').trim() : '';
          const rawDepto = mapping.Departamento ? String(row[mapping.Departamento] || '').trim() : '';
          const rawCat = mapping.Categoria ? String(row[mapping.Categoria] || '').trim() : '';
          const rawFam = mapping.Familia ? String(row[mapping.Familia] || '').trim() : '';
          const rawTalla = mapping.Talla ? row[mapping.Talla] : 'U';

          // 1. Resolve Size
          const talla = cleanSizeString(rawTalla);

          // 2. Resolve Brand
          let marca = rawMarca ? rawMarca.toUpperCase() : '';
          if (!marca || marca === 'GENERAL' || marca === 'UNDEFINED' || marca === 'NULL') {
            const detectedFromRef = detectBrandFromTokens(ref);
            const detectedFromCat = detectBrandFromTokens(rawCat);
            const detectedFromFam = detectBrandFromTokens(rawFam);
            marca = detectedFromRef || detectedFromCat || detectedFromFam || filenameBrand || 'GENERAL';
          }

          // 3. Resolve Department (strictly CALZADO, TEXTIL, ACCESORIOS)
          const depto = resolveDepartment(rawDepto, rawCat, rawFam, ref, rawSeccion);

          // 4. Resolve Section and Gender (Unifying Niños, Hombre, Mujer, Unisex)
          const { seccion, genero } = resolveSectionAndGender(rawGenero, rawSeccion, ref, talla);

          // 5. Resolve Family / Subcategory
          const familia = resolveFamily(rawFam, rawCat, seccion, ref);

          // 6. Resolve Stock & Valuation
          const rawStock = mapping.Stock ? row[mapping.Stock] : 1;
          const stock = Math.max(0, Math.floor(parseNumberSafely(rawStock)));

          const rawVal = mapping.Valoracion ? row[mapping.Valoracion] : 0;
          const valoracionBs = Math.round(parseNumberSafely(rawVal) * 100) / 100;
          // El archivo cuenta con valoración en Bolívares: convertimos a Dólares ($ USD) según la tasa oficial del BCV
          const valoracionUSD = Math.round((valoracionBs / effectiveBcvRate) * 100) / 100;
          const valorUnitarioBs = stock > 0 ? Math.round((valoracionBs / stock) * 100) / 100 : 0;
          const valorUnitarioUSD = stock > 0 ? Math.round((valoracionUSD / stock) * 100) / 100 : 0;

          // 7. Resolve Store
          const rawTienda = mapping.Tienda ? String(row[mapping.Tienda] || '').trim() : '';
          const tienda = String(rawTienda || finalStoreName || 'TIENDA 1').trim();

          // 8. Resolve Fecha / Antigüedad (Aging)
          let fechaIngreso: string | undefined = undefined;
          let diasAntiguedad: number | undefined = undefined;

          if (mapping.FechaIngreso && row[mapping.FechaIngreso]) {
            const rawDateVal = row[mapping.FechaIngreso];
            if (typeof rawDateVal === 'number') {
              const jsDate = new Date(Math.round((rawDateVal - 25569) * 86400 * 1000));
              if (!isNaN(jsDate.getTime())) {
                fechaIngreso = jsDate.toISOString().split('T')[0];
                diasAntiguedad = Math.max(0, Math.floor((Date.now() - jsDate.getTime()) / (1000 * 60 * 60 * 24)));
              }
            } else {
              const strDate = String(rawDateVal).trim();
              const parsedDate = new Date(strDate);
              if (!isNaN(parsedDate.getTime())) {
                fechaIngreso = parsedDate.toISOString().split('T')[0];
                diasAntiguedad = Math.max(0, Math.floor((Date.now() - parsedDate.getTime()) / (1000 * 60 * 60 * 24)));
              }
            }
          }

          if (mapping.DiasAntiguedad && row[mapping.DiasAntiguedad] !== undefined) {
            const parsedDays = parseNumberSafely(row[mapping.DiasAntiguedad]);
            if (parsedDays > 0) {
              diasAntiguedad = Math.round(parsedDays);
            }
          }

          if (diasAntiguedad === undefined) {
            const hash = (ref + talla).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
            diasAntiguedad = (hash % 100) + 10;
            const pastDate = new Date();
            pastDate.setDate(pastDate.getDate() - diasAntiguedad);
            fechaIngreso = pastDate.toISOString().split('T')[0];
          }

          // 9. Resolve ImagenUrl if present in dataset
          let imagenUrl: string | undefined = undefined;
          if (mapping.ImagenUrl && row[mapping.ImagenUrl]) {
            const rawUrl = String(row[mapping.ImagenUrl]).trim();
            if (rawUrl.startsWith('http://') || rawUrl.startsWith('https://') || rawUrl.startsWith('data:image/')) {
              imagenUrl = rawUrl;
            }
          }

          // 10. Resolve Temporada (Backward Compatibility: default to 'Sin Asignar')
          const rawTemporada = mapping.Temporada ? String(row[mapping.Temporada] || '').trim() : '';
          const temporada = (rawTemporada && rawTemporada !== 'undefined' && rawTemporada !== 'null')
            ? rawTemporada.toUpperCase()
            : 'Sin Asignar';

          // 11. Resolve VentaSemanal, Venta30D & WOS (Weeks of Supply / Cobertura)
          let ventaSemanal: number | undefined = undefined;
          let venta30D: number | undefined = undefined;
          let wos: number | undefined = undefined;

          if (mapping.VentaSemanal && row[mapping.VentaSemanal] !== undefined) {
            const parsedV = parseNumberSafely(row[mapping.VentaSemanal]);
            if (parsedV >= 0) {
              ventaSemanal = Math.round(parsedV * 10) / 10;
            }
          }

          if (mapping.Venta30D && row[mapping.Venta30D] !== undefined) {
            const parsedV30 = parseNumberSafely(row[mapping.Venta30D]);
            if (parsedV30 >= 0) {
              venta30D = Math.round(parsedV30 * 10) / 10;
              if (ventaSemanal === undefined) {
                // ~4.285 semanas por mes (30 / 7)
                ventaSemanal = Math.round((parsedV30 / 4.285) * 10) / 10;
              }
            }
          }

          if (ventaSemanal !== undefined && ventaSemanal > 0) {
            wos = Math.round((stock / ventaSemanal) * 10) / 10;
          } else if (ventaSemanal === 0 && stock > 0) {
            wos = 999; // Stock estancado sin venta
          }

          skuSet.add(ref);
          totalPieces += stock;
          totalValuation += valoracionUSD;
          totalValuationBs += valoracionBs;

          deptBreakdown[depto] = (deptBreakdown[depto] || 0) + stock;
          brandBreakdown[marca] = (brandBreakdown[marca] || 0) + stock;
          genderBreakdown[genero] = (genderBreakdown[genero] || 0) + stock;
          sectionBreakdown[seccion] = (sectionBreakdown[seccion] || 0) + stock;
          familyBreakdown[familia] = (familyBreakdown[familia] || 0) + stock;

          const itemEntropy = Math.random().toString(36).slice(2, 6);
          return {
            id: `${tienda}-${ref}-${talla}-${itemEntropy}-${idx}`,
            Referencia: ref,
            Departamento: depto,
            Seccion: seccion,
            Familia: familia,
            Marca: marca,
            Talla: talla,
            Stock: stock,
            Valoracion: valoracionUSD,
            ValorUnitario: valorUnitarioUSD,
            ValoracionBs: valoracionBs,
            ValorUnitarioBs: valorUnitarioBs,
            Tienda: tienda,
            SKU_Talla: `${ref} | ${talla}`,
            FechaIngreso: fechaIngreso,
            DiasAntiguedad: diasAntiguedad,
            ImagenUrl: imagenUrl,
            Temporada: temporada,
            VentaSemanal: ventaSemanal,
            Venta30D: venta30D,
            WOS: wos,
          };
        });

        // Top detected brand
        const topBrand = Object.entries(brandBreakdown).sort((a, b) => b[1] - a[1])[0]?.[0];

        resolve({
          items,
          filename: file.name,
          detectedStore,
          detectedBrand: topBrand,
          sheetCount: workbook.SheetNames.length,
          rowCount: items.length,
          uniqueSkus: skuSet.size,
          totalPieces,
          totalValuation,
          totalValuationBs,
          bcvRateUsed: effectiveBcvRate,
          deptBreakdown,
          brandBreakdown,
          genderBreakdown,
          sectionBreakdown,
          familyBreakdown,
          rawHeaders: headers,
          appliedMapping: mapping,
          detectionConfidence: confidences,
          rawRowsSample: rawRows.slice(0, 5),
        });
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
}

