/**
 * Banco Central de Venezuela (BCV) Exchange Rate Service for SPEC
 * Automatically retrieves the official USD/VES rate from public APIs,
 * supports manual override and persists the latest rate in storage.
 */

export interface BcvRateData {
  rate: number;
  lastUpdated: string;
  source: string;
  isCustom?: boolean;
}

const STORAGE_KEY = 'spec_bcv_rate_config';
const DEFAULT_BCV_RATE = 855.66; // Fallback rate

export async function fetchOfficialBcvRate(): Promise<BcvRateData> {
  try {
    const res = await fetch('https://ve.dolarapi.com/v1/dolares/oficial', {
      headers: { Accept: 'application/json' },
    });
    if (res.ok) {
      const data = await res.json();
      const rateVal = Number(data.promedio || data.venta || data.compra);
      if (rateVal && rateVal > 0) {
        const result: BcvRateData = {
          rate: Math.round(rateVal * 10000) / 10000,
          lastUpdated: data.fechaActualizacion || new Date().toISOString(),
          source: 'BCV Oficial (ve.dolarapi.com)',
        };
        saveBcvRateToStorage(result);
        return result;
      }
    }
  } catch (err) {
    console.warn('Could not fetch BCV rate from primary API, using stored or default rate:', err);
  }

  // Fallback to locally stored rate or default
  return getStoredBcvRate();
}

export function getStoredBcvRate(): BcvRateData {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && typeof parsed.rate === 'number' && parsed.rate > 0) {
        return parsed;
      }
    }
  } catch {}

  return {
    rate: DEFAULT_BCV_RATE,
    lastUpdated: new Date().toISOString(),
    source: 'BCV Oficial (Predeterminada)',
  };
}

export function saveBcvRateToStorage(rateData: BcvRateData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rateData));
  } catch {}
}

/**
 * Converts an amount in Bolívares (VES) to US Dollars (USD)
 */
export function convertBsToUsd(amountBs: number, rate: number): number {
  if (!rate || rate <= 0) return amountBs;
  return Math.round((amountBs / rate) * 100) / 100;
}

/**
 * Converts an amount in US Dollars (USD) to Bolívares (VES)
 */
export function convertUsdToBs(amountUsd: number, rate: number): number {
  if (!rate || rate <= 0) return amountUsd;
  return Math.round(amountUsd * rate * 100) / 100;
}

/**
 * Formats a currency value in US Dollars ($)
 */
export function formatCurrencyUSD(amount: number, compact: boolean = false): string {
  if (compact) {
    if (Math.abs(amount) >= 1_000_000) {
      return `$${(amount / 1_000_000).toFixed(2)}M`;
    }
    if (Math.abs(amount) >= 1_000) {
      return `$${(amount / 1_000).toFixed(1)}k`;
    }
    return `$${amount.toFixed(2)}`;
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Formats a currency value in Bolívares (Bs.)
 */
export function formatCurrencyBs(amount: number, compact: boolean = false): string {
  if (compact) {
    if (Math.abs(amount) >= 1_000_000) {
      return `Bs. ${(amount / 1_000_000).toFixed(2)}M`;
    }
    if (Math.abs(amount) >= 1_000) {
      return `Bs. ${(amount / 1_000).toFixed(1)}k`;
    }
    return `Bs. ${amount.toFixed(2)}`;
  }
  return `Bs. ${new Intl.NumberFormat('es-VE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)}`;
}
