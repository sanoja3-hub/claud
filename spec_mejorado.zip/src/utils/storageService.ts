/**
 * IndexedDB & Local Storage Persistence Service for Retail Command Center
 * Supports automatic background saving and complete JSON backup export/import
 */

import {
  CapacityMatrixConfig,
  CapacitySnapshot,
  InventoryItem,
  RuleEngineConfig,
  StoreDistance,
  StoreProfile,
  TransferManifest,
  ValuationHistoryPoint,
} from '../types';

export interface AppStoredState {
  inventory: InventoryItem[];
  storeProfiles: StoreProfile[];
  storeCapacities: Record<string, CapacityMatrixConfig>;
  storeDistances: StoreDistance;
  ruleConfig?: RuleEngineConfig;
  snapshots?: CapacitySnapshot[];
  manifests?: TransferManifest[];
  customProductImageUrls?: Record<string, string>;
  bcvRate?: number;
  bcvLastUpdated?: string;
  valuationHistory?: ValuationHistoryPoint[];
  lastSaved?: string;
  version: number;
}

const DB_NAME = 'RetailCommandCenterDB';
const DB_VERSION = 1;
const STORE_KEY = 'app_full_state';
const LOCAL_STORAGE_BACKUP_KEY = 'rcc_state_backup';

export const DEFAULT_RULE_CONFIG: RuleEngineConfig = {
  umbralSobrestockPorcentaje: 115,
  umbralSubstockPorcentaje: 75,
  umbralAgingCriticoDias: 90,
  umbralMonotallaPiezas: 2,
  costoFleteBasePorKm: 0.85,
  costoFleteBaseFijo: 15.0,
  diasEstimadosQuiebreParaVentasPerdidas: 14,
};

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }

    const req = window.indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e: any) => {
      const db = e.target.result as IDBDatabase;
      if (!db.objectStoreNames.contains('keyval')) {
        db.createObjectStore('keyval');
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveAppStateToStorage(state: AppStoredState): Promise<void> {
  const payload: AppStoredState = {
    ...state,
    lastSaved: new Date().toISOString(),
    version: 1,
  };

  // 1. Try IndexedDB
  try {
    const db = await openDB();
    const tx = db.transaction('keyval', 'readwrite');
    const store = tx.objectStore('keyval');
    store.put(payload, STORE_KEY);
    await new Promise((res, rej) => {
      tx.oncomplete = () => res(true);
      tx.onerror = () => rej(tx.error);
      tx.onabort = () => rej(tx.error || new Error('Transacción IndexedDB abortada'));
    });
    db.close();
  } catch (err) {
    console.warn('IndexedDB write failed, fallback to localStorage', err);
  }

  // 2. Also keep a compressed/trimmed snapshot in localStorage for instant boot
  try {
    // Only store lightweight metadata and up to 500 items if too large
    // Solo metadatos: antes se serializaba el inventario completo (`...payload`), lo que bloqueaba el hilo
    // principal en cada guardado y desbordaba la cuota de localStorage (~5 MB) en silencio.
    const lightPayload = {
      inventoryCount: payload.inventory.length,
      storeProfilesCount: payload.storeProfiles.length,
      lastSaved: payload.lastSaved,
      version: payload.version,
    };
    localStorage.setItem(LOCAL_STORAGE_BACKUP_KEY, JSON.stringify(lightPayload));
  } catch (e) {
    // quota exceeded warning ignored safely
  }
}

export async function loadAppStateFromStorage(): Promise<AppStoredState | null> {
  // 1. Try IndexedDB first
  try {
    const db = await openDB();
    const tx = db.transaction('keyval', 'readonly');
    const store = tx.objectStore('keyval');
    const req = store.get(STORE_KEY);

    const result = await new Promise<AppStoredState | null>((resolve, reject) => {
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (result && result.inventory) {
      return result;
    }
  } catch (err) {
    console.warn('IndexedDB read failed, trying localStorage fallback', err);
  }

  return null;
}

/**
 * Downloads a complete JSON backup file
 */
export function exportAppBackupJSON(state: AppStoredState): void {
  const exportData = {
    ...state,
    exportDate: new Date().toISOString(),
    system: 'Retail Command Center Enterprise',
    version: '2.0.0',
  };

  const jsonStr = JSON.stringify(exportData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().split('T')[0];
  a.download = `Backup_Retail_Command_Center_${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Imports and validates a backup JSON file or string
 */
export async function importAppBackupJSON(fileOrText: File | string): Promise<AppStoredState> {
  return new Promise((resolve, reject) => {
    const parseContent = (text: string) => {
      try {
        const parsed = JSON.parse(text);

        if (!parsed || typeof parsed !== 'object') {
          throw new Error('El archivo no tiene un formato JSON válido.');
        }

        const validState: AppStoredState = {
          inventory: Array.isArray(parsed.inventory) ? parsed.inventory : [],
          storeProfiles: Array.isArray(parsed.storeProfiles) ? parsed.storeProfiles : [],
          storeCapacities: parsed.storeCapacities || {},
          storeDistances: parsed.storeDistances || {},
          ruleConfig: parsed.ruleConfig || DEFAULT_RULE_CONFIG,
          snapshots: Array.isArray(parsed.snapshots) ? parsed.snapshots : [],
          manifests: Array.isArray(parsed.manifests) ? parsed.manifests : [],
          customProductImageUrls: parsed.customProductImageUrls && typeof parsed.customProductImageUrls === 'object' ? parsed.customProductImageUrls : {},
          lastSaved: new Date().toISOString(),
          version: 1,
        };

        resolve(validState);
      } catch (err: any) {
        reject(new Error(err.message || 'Error al procesar el archivo JSON de respaldo.'));
      }
    };

    if (typeof fileOrText === 'string') {
      parseContent(fileOrText);
    } else {
      const reader = new FileReader();
      reader.onload = (e) => parseContent(e.target?.result as string);
      reader.onerror = () => reject(new Error('Error al leer el archivo.'));
      reader.readAsText(fileOrText);
    }
  });
}
