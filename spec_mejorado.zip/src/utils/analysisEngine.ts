import {
  AgingBucketSummary,
  AreaCapacitySummary,
  CapacityMatrixConfig,
  CapacitySummaryRow,
  Department,
  DepartmentModuleSummary,
  FinancialRiskSummary,
  GenderArea,
  InventoryAlert,
  InventoryItem,
  RuleEngineConfig,
  SizeCurveClusterTarget,
  SpatialPerformanceMetric,
  StoreCluster,
  StoreDistance,
  StoreProfile,
  StoreType,
  TransferSuggestion,
  WhatIfSimulationConfig,
  WhatIfSimulationResult,
} from '../types';
import { DEFAULT_RULE_CONFIG } from './storageService';
import { calculateGeoDistanceKm } from './geoDistance';

/**
 * 1. Automatic Cluster Detection based on City / Region
 */
export function getClusterForCity(city?: string): StoreCluster {
  if (!city) return 'ESTANDAR';
  const c = city.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

  if (
    c.includes('monterrey') ||
    c.includes('tijuana') ||
    c.includes('chihuahua') ||
    c.includes('juarez') ||
    c.includes('saltillo') ||
    c.includes('hermosillo') ||
    c.includes('mexicali') ||
    c.includes('torreon') ||
    c.includes('reynosa') ||
    c.includes('norte')
  ) {
    return 'NORTE';
  }

  if (
    c.includes('cancun') ||
    c.includes('merida') ||
    c.includes('acapulco') ||
    c.includes('vallarta') ||
    c.includes('veracruz') ||
    c.includes('mazatlan') ||
    c.includes('playa') ||
    c.includes('tulum') ||
    c.includes('costa')
  ) {
    return 'COSTA';
  }

  if (
    c.includes('guadalajara') ||
    c.includes('zapopan') ||
    c.includes('leon') ||
    c.includes('aguascalientes') ||
    c.includes('morelia') ||
    c.includes('occidente') ||
    c.includes('jalisco')
  ) {
    return 'OCCIDENTE';
  }

  if (
    c.includes('oaxaca') ||
    c.includes('chiapas') ||
    c.includes('tuxtla') ||
    c.includes('tapachula') ||
    c.includes('villahermosa') ||
    c.includes('sur')
  ) {
    return 'SUR';
  }

  if (
    c.includes('cdmx') ||
    c.includes('mexico') ||
    c.includes('toluca') ||
    c.includes('puebla') ||
    c.includes('queretaro') ||
    c.includes('pachuca') ||
    c.includes('cuernavaca') ||
    c.includes('centro')
  ) {
    return 'CENTRO';
  }

  return 'ESTANDAR';
}

/**
 * Theoretical ideal size distributions per cluster (%)
 */
export const CLUSTER_SIZE_PROFILES: Record<StoreCluster, SizeCurveClusterTarget> = {
  NORTE: {
    cluster: 'NORTE',
    calzado: { '7': 2, '7.5': 4, '8': 10, '8.5': 18, '9': 24, '9.5': 20, '10': 12, '10.5': 6, '11': 4 },
    textil: { 'XS': 2, 'S': 8, 'M': 25, 'L': 35, 'XL': 22, 'XXL': 8 },
  },
  CENTRO: {
    cluster: 'CENTRO',
    calzado: { '7': 4, '7.5': 10, '8': 22, '8.5': 26, '9': 18, '9.5': 12, '10': 5, '10.5': 2, '11': 1 },
    textil: { 'XS': 6, 'S': 18, 'M': 38, 'L': 26, 'XL': 10, 'XXL': 2 },
  },
  SUR: {
    cluster: 'SUR',
    calzado: { '7': 6, '7.5': 14, '8': 28, '8.5': 24, '9': 16, '9.5': 8, '10': 3, '10.5': 1, '11': 0 },
    textil: { 'XS': 8, 'S': 24, 'M': 40, 'L': 20, 'XL': 6, 'XXL': 2 },
  },
  COSTA: {
    cluster: 'COSTA',
    calzado: { '7': 5, '7.5': 12, '8': 20, '8.5': 22, '9': 20, '9.5': 12, '10': 6, '10.5': 2, '11': 1 },
    textil: { 'XS': 10, 'S': 25, 'M': 35, 'L': 20, 'XL': 8, 'XXL': 2 },
  },
  OCCIDENTE: {
    cluster: 'OCCIDENTE',
    calzado: { '7': 3, '7.5': 8, '8': 18, '8.5': 25, '9': 22, '9.5': 14, '10': 7, '10.5': 2, '11': 1 },
    textil: { 'XS': 4, 'S': 14, 'M': 34, 'L': 30, 'XL': 14, 'XXL': 4 },
  },
  ESTANDAR: {
    cluster: 'ESTANDAR',
    calzado: { '7': 3, '7.5': 8, '8': 18, '8.5': 24, '9': 22, '9.5': 14, '10': 7, '10.5': 3, '11': 1 },
    textil: { 'XS': 5, 'S': 15, 'M': 35, 'L': 28, 'XL': 13, 'XXL': 4 },
  },
};

/**
 * Consolidated Capacity Matrix
 */
export function consolidarMatrizMarcas(
  marcasCapacidad: Record<string, CapacityMatrixConfig>
): CapacityMatrixConfig {
  const consolidated: CapacityMatrixConfig = {};
  const brandEntries = Object.entries(marcasCapacidad || {});
  if (brandEntries.length === 0) return {};

  for (const [, brandMatrix] of brandEntries) {
    for (const [dept, deptData] of Object.entries(brandMatrix || {})) {
      if (!consolidated[dept]) {
        const defaultExhibicion = (dept || '').toUpperCase() === 'CALZADO' ? 1 : (dept || '').toUpperCase() === 'TEXTIL' ? 6 : 4;
        consolidated[dept] = {
          activa: deptData.activa !== false,
          profundidad_target: deptData.profundidad_target || 16,
          piezas_exhibicion_sku: deptData.piezas_exhibicion_sku ?? defaultExhibicion,
          secciones: {},
        };
      } else {
        // If at least one brand has the department active, keep it active in consolidation
        if (deptData.activa !== false) {
          consolidated[dept].activa = true;
        }
        if (deptData.piezas_exhibicion_sku && !consolidated[dept].piezas_exhibicion_sku) {
          consolidated[dept].piezas_exhibicion_sku = deptData.piezas_exhibicion_sku;
        }
      }

      // If this brand has the department omitted, skip aggregating its SKUs
      if (deptData.activa === false) continue;

      for (const [sec, secData] of Object.entries(deptData.secciones || {})) {
        if (!consolidated[dept].secciones[sec]) {
          consolidated[dept].secciones[sec] = {};
        }
        for (const [fam, count] of Object.entries(secData || {})) {
          consolidated[dept].secciones[sec][fam] =
            (consolidated[dept].secciones[sec][fam] || 0) + (count || 0);
        }
      }
    }
  }

  for (const dept of Object.keys(consolidated)) {
    let totalPieces = 0;
    let totalSkus = 0;
    let totalExhibitionPieces = 0;
    let totalExhibitionSkus = 0;
    let fallbackExhibition = consolidated[dept].piezas_exhibicion_sku || ((dept || '').toUpperCase() === 'CALZADO' ? 1 : (dept || '').toUpperCase() === 'TEXTIL' ? 6 : 4);

    for (const [, brandMatrix] of brandEntries) {
      const deptData = brandMatrix[dept];
      if (deptData && deptData.activa !== false) {
        let deptSkus = 0;
        for (const secData of Object.values(deptData.secciones || {})) {
          for (const count of Object.values(secData || {})) {
            deptSkus += count || 0;
          }
        }
        totalSkus += deptSkus;
        totalPieces += deptSkus * (deptData.profundidad_target || 0);
        if (deptData.piezas_exhibicion_sku) {
          totalExhibitionSkus += deptSkus;
          totalExhibitionPieces += deptSkus * deptData.piezas_exhibicion_sku;
          fallbackExhibition = deptData.piezas_exhibicion_sku;
        }
      }
    }
    consolidated[dept].profundidad_target =
      totalSkus > 0 ? Math.round((totalPieces / totalSkus) * 10) / 10 : 16;
    consolidated[dept].piezas_exhibicion_sku =
      totalExhibitionSkus > 0
        ? Math.max(1, Math.round(totalExhibitionPieces / totalExhibitionSkus))
        : fallbackExhibition;
  }

  return consolidated;
}

export function calcularTotalesMatriz(config: CapacityMatrixConfig): {
  totalSkus: number;
  totalPieces: number;
  avgDepth: number;
  deptBreakdown: Record<string, { skus: number; pieces: number; depth: number }>;
} {
  let totalSkus = 0;
  let totalPieces = 0;
  const deptBreakdown: Record<string, { skus: number; pieces: number; depth: number }> = {};

  for (const [dept, deptData] of Object.entries(config || {})) {
    if (deptData.activa === false) {
      deptBreakdown[dept] = { skus: 0, pieces: 0, depth: deptData.profundidad_target || 0 };
      continue;
    }
    let deptSkus = 0;
    for (const secData of Object.values(deptData.secciones || {})) {
      for (const count of Object.values(secData || {})) {
        deptSkus += count || 0;
      }
    }
    const depth = deptData.profundidad_target || 0;
    const deptPieces = deptSkus * depth;
    totalSkus += deptSkus;
    totalPieces += deptPieces;
    deptBreakdown[dept] = { skus: deptSkus, pieces: deptPieces, depth };
  }

  const avgDepth = totalSkus > 0 ? Math.round((totalPieces / totalSkus) * 10) / 10 : 0;
  return { totalSkus, totalPieces, avgDepth, deptBreakdown };
}

export function clasificarAreaGenero(
  seccion?: string,
  departamento?: string,
  referencia?: string
): GenderArea | 'OTRO' {
  if (departamento && (departamento || '').toUpperCase() === 'ACCESORIOS') {
    return 'GENERAL';
  }
  const upper = (seccion || '').toUpperCase();
  const refUpper = (referencia || '').toUpperCase();

  if (
    upper.includes('MUJER') ||
    upper.includes('WOMENS') ||
    upper.includes('WOMEN') ||
    upper.includes('DAMA') ||
    upper.includes('FEMENINO') ||
    refUpper.endsWith('-W')
  ) {
    return 'DAMA';
  }
  if (
    upper.includes('HOMBRE') ||
    upper.includes('CABALLERO') ||
    upper.includes('MASCULINO') ||
    refUpper.endsWith('-M') ||
    ((upper.includes('MEN') || upper.includes('MENS')) && !upper.includes('WOMEN'))
  ) {
    return 'CABALLERO';
  }
  if (
    upper.includes('INFANTE') ||
    upper.includes('NIÑO') ||
    upper.includes('NIÑA') ||
    upper.includes('NINO') ||
    upper.includes('NINA') ||
    upper.includes('KID') ||
    upper.includes('JUNIOR') ||
    upper.includes('BOY') ||
    upper.includes('GIRL') ||
    refUpper.endsWith('-K')
  ) {
    return 'NIÑOS';
  }
  if (upper.includes('GENERAL') || upper.includes('UNISEX') || upper.includes('GLOBAL') || upper.includes('ACCESOR')) {
    return 'GENERAL';
  }
  return 'OTRO';
}

/**
 * Resolves the appropriate capacity matrix for a store and brand
 */
export function resolveStoreCapacityMatrix(
  storeName: string,
  selectedBrand: string | undefined,
  storeCapacities?: Record<string, CapacityMatrixConfig>,
  storeProfiles?: StoreProfile[],
  fallbackConfig?: CapacityMatrixConfig
): CapacityMatrixConfig {
  const isSingleBrand = selectedBrand && selectedBrand !== 'TODAS';
  const prof = storeProfiles?.find((p) => p.nombre === storeName || p.id === storeName);

  if (isSingleBrand && prof?.marcasCapacidad?.[selectedBrand!]) {
    return prof.marcasCapacidad[selectedBrand!];
  }
  if (prof?.marcasCapacidad && Object.keys(prof.marcasCapacidad).length > 0) {
    if (isSingleBrand) {
      return prof.marcasCapacidad[selectedBrand!] || fallbackConfig || {};
    }
    return consolidarMatrizMarcas(prof.marcasCapacidad);
  }
  if (prof?.capacidadPersonalizada) {
    return prof.capacidadPersonalizada;
  }
  if (storeCapacities?.[storeName]) {
    return storeCapacities[storeName];
  }
  return fallbackConfig || {};
}

export function calcularResumenCapacidad(
  items: InventoryItem[],
  config: CapacityMatrixConfig,
  selectedStore?: string,
  storeCapacities?: Record<string, CapacityMatrixConfig>,
  selectedBrand?: string,
  storeProfiles?: StoreProfile[]
): CapacitySummaryRow[] {
  const isSingleStore = selectedStore && selectedStore !== 'TODAS' && selectedStore !== 'MANAGER';
  const isSingleBrand = selectedBrand && selectedBrand !== 'TODAS';

  let filtered = isSingleStore
    ? items.filter((it) => it.Tienda === selectedStore)
    : items;

  if (isSingleBrand) {
    filtered = filtered.filter(
      (it) => (it.Marca || '').toUpperCase() === selectedBrand.toUpperCase()
    );
  }

  const realByDept: Record<string, { skus: Set<string>; pieces: number; val: number }> = {};

  for (const it of filtered) {
    const dept = it.Departamento || 'TEXTIL';
    if (!realByDept[dept]) {
      realByDept[dept] = { skus: new Set<string>(), pieces: 0, val: 0 };
    }
    realByDept[dept].skus.add(it.Referencia);
    realByDept[dept].pieces += it.Stock;
    realByDept[dept].val += it.Valoracion;
  }

  const deptSet = new Set<string>(['CALZADO', 'TEXTIL', 'ACCESORIOS']);
  Object.keys(realByDept).forEach((d) => deptSet.add(d));
  if (config) {
    Object.keys(config).forEach((d) => deptSet.add(d));
  }
  if (storeCapacities) {
    Object.values(storeCapacities).forEach((cap) => {
      if (cap && typeof cap === 'object') {
        Object.keys(cap).forEach((d) => deptSet.add(d));
      }
    });
  }
  const allDeptKeys = Array.from(deptSet);

  // Active stores for network aggregation
  const activeStores = storeProfiles && storeProfiles.length > 0
    ? storeProfiles.map((p) => p.nombre)
    : Object.keys(storeCapacities || {}).length > 0
    ? Object.keys(storeCapacities!)
    : Array.from(new Set(items.map((it) => it.Tienda))).filter(Boolean);

  const targetStores = isSingleStore
    ? [selectedStore!]
    : activeStores.length > 0
    ? activeStores
    : ['TIENDA_BASE'];

  const rows: CapacitySummaryRow[] = [];

  for (const dept of allDeptKeys) {
    let skusIdeal = 0;
    let piezasIdeal = 0;
    let sumDeptProf = 0;
    let storesWithDept = 0;

    for (const storeName of targetStores) {
      const storeMatrix = resolveStoreCapacityMatrix(
        storeName,
        selectedBrand,
        storeCapacities,
        storeProfiles,
        config
      );
      if (storeMatrix && storeMatrix[dept]) {
        const deptData = storeMatrix[dept];
        if (deptData.activa === false) continue;
        const depth = deptData.profundidad_target || 16;
        let storeDeptSkus = 0;
        for (const sectionData of Object.values(deptData.secciones || {})) {
          for (const famCount of Object.values(sectionData || {})) {
            storeDeptSkus += famCount || 0;
          }
        }
        skusIdeal += storeDeptSkus;
        piezasIdeal += storeDeptSkus * depth;
        sumDeptProf += depth;
        storesWithDept++;
      }
    }

    const avgTargetProf = storesWithDept > 0 ? Math.round(sumDeptProf / storesWithDept) : (config?.[dept]?.profundidad_target || 16);

    const actual = realByDept[dept] || { skus: new Set<string>(), pieces: 0, val: 0 };
    const skusActual = actual.skus.size;
    const piezasActual = actual.pieces;
    const difSkus = (skusActual === 0 && skusIdeal === 0) ? 0 : skusActual - skusIdeal;
    const difPiezas = (piezasActual === 0 && piezasIdeal === 0) ? 0 : piezasActual - piezasIdeal;
    const pctOcupacion = piezasIdeal > 0 ? Math.round((piezasActual / piezasIdeal) * 1000) / 10 : 0;

    rows.push({
      Departamento: dept,
      ProfundidadTarget: avgTargetProf,
      SKUsIdeal: skusIdeal,
      SKUsActual: skusActual,
      DiferenciaSKUs: difSkus,
      PiezasIdeal: piezasIdeal,
      PiezasActual: piezasActual,
      DiferenciaPiezas: difPiezas,
      PorcentajeOcupacion: pctOcupacion,
      ValoracionTotal: Math.round(actual.val * 100) / 100,
    });
  }

  return rows;
}

/**
 * Detailed 3-Module Breakdown: CALZADO, TEXTIL, and ACCESORIOS
 * with each respective Area: DAMA, CABALLERO, NIÑOS.
 * Analyzable globally (all brands of store) or separately (by specific brand).
 */
export function calcularModulosDepartamentosYAreas(
  items: InventoryItem[],
  config: CapacityMatrixConfig,
  selectedStore?: string,
  storeCapacities?: Record<string, CapacityMatrixConfig>,
  selectedBrand?: string,
  storeProfiles?: StoreProfile[]
): DepartmentModuleSummary[] {
  const isSingleStore = selectedStore && selectedStore !== 'TODAS' && selectedStore !== 'MANAGER';
  const isSingleBrand = selectedBrand && selectedBrand !== 'TODAS';

  let filtered = isSingleStore ? items.filter((it) => it.Tienda === selectedStore) : items;
  if (isSingleBrand) {
    filtered = filtered.filter((it) => (it.Marca || '').toUpperCase() === selectedBrand.toUpperCase());
  }

  const depts: Department[] = ['CALZADO', 'TEXTIL', 'ACCESORIOS'];
  const genderAreasList: GenderArea[] = ['CABALLERO', 'DAMA', 'NIÑOS'];

  // 1. Group real inventory by Dept and Area
  const realMatrix: Record<string, Record<GenderArea, { skus: Set<string>; pieces: number; val: number }>> = {
    CALZADO: {
      CABALLERO: { skus: new Set(), pieces: 0, val: 0 },
      DAMA: { skus: new Set(), pieces: 0, val: 0 },
      NIÑOS: { skus: new Set(), pieces: 0, val: 0 },
      GENERAL: { skus: new Set(), pieces: 0, val: 0 },
    },
    TEXTIL: {
      CABALLERO: { skus: new Set(), pieces: 0, val: 0 },
      DAMA: { skus: new Set(), pieces: 0, val: 0 },
      NIÑOS: { skus: new Set(), pieces: 0, val: 0 },
      GENERAL: { skus: new Set(), pieces: 0, val: 0 },
    },
    ACCESORIOS: {
      CABALLERO: { skus: new Set(), pieces: 0, val: 0 },
      DAMA: { skus: new Set(), pieces: 0, val: 0 },
      NIÑOS: { skus: new Set(), pieces: 0, val: 0 },
      GENERAL: { skus: new Set(), pieces: 0, val: 0 },
    },
  };

  for (const it of filtered) {
    const d = it.Departamento;
    if (!realMatrix[d]) continue;

    if (d === 'ACCESORIOS') {
      realMatrix.ACCESORIOS.GENERAL.skus.add(it.Referencia);
      realMatrix.ACCESORIOS.GENERAL.pieces += it.Stock;
      realMatrix.ACCESORIOS.GENERAL.val += it.Valoracion;
      continue;
    }

    const area = clasificarAreaGenero(it.Seccion, d, it.Referencia);
    if (area === 'OTRO' || area === 'GENERAL') {
      // If unisex or ambiguous in footwear/apparel, distribute equally between Caballero and Dama
      realMatrix[d].CABALLERO.skus.add(it.Referencia);
      realMatrix[d].CABALLERO.pieces += Math.ceil(it.Stock / 2);
      realMatrix[d].CABALLERO.val += it.Valoracion / 2;

      realMatrix[d].DAMA.skus.add(it.Referencia);
      realMatrix[d].DAMA.pieces += Math.floor(it.Stock / 2);
      realMatrix[d].DAMA.val += it.Valoracion / 2;
    } else {
      realMatrix[d][area].skus.add(it.Referencia);
      realMatrix[d][area].pieces += it.Stock;
      realMatrix[d][area].val += it.Valoracion;
    }
  }

  // 2. Active stores for network aggregation
  const activeStores = storeProfiles && storeProfiles.length > 0
    ? storeProfiles.map((p) => p.nombre)
    : Object.keys(storeCapacities || {}).length > 0
    ? Object.keys(storeCapacities!)
    : Array.from(new Set(items.map((it) => it.Tienda))).filter(Boolean);

  const targetStores = isSingleStore
    ? [selectedStore!]
    : activeStores.length > 0
    ? activeStores
    : ['TIENDA_BASE'];

  // 3. Determine Ideal Matrix for each Dept and Area across target stores
  const idealMatrix: Record<string, { sumProfundidad: number; storeCount: number; areas: Record<GenderArea, number> }> = {
    CALZADO: { sumProfundidad: 0, storeCount: 0, areas: { CABALLERO: 0, DAMA: 0, NIÑOS: 0, GENERAL: 0 } },
    TEXTIL: { sumProfundidad: 0, storeCount: 0, areas: { CABALLERO: 0, DAMA: 0, NIÑOS: 0, GENERAL: 0 } },
    ACCESORIOS: { sumProfundidad: 0, storeCount: 0, areas: { CABALLERO: 0, DAMA: 0, NIÑOS: 0, GENERAL: 0 } },
  };

  for (const storeName of targetStores) {
    const storeMatrix = resolveStoreCapacityMatrix(
      storeName,
      selectedBrand,
      storeCapacities,
      storeProfiles,
      config
    );

    for (const d of depts) {
      if (storeMatrix && storeMatrix[d]) {
        const deptData = storeMatrix[d];
        if (deptData.activa === false) continue;
        const depth = deptData.profundidad_target || (d === 'ACCESORIOS' ? 14 : 16);
        idealMatrix[d].sumProfundidad += depth;
        idealMatrix[d].storeCount++;

        if (d === 'ACCESORIOS') {
          let totalAccSkus = 0;
          for (const families of Object.values(deptData.secciones || {})) {
            for (const count of Object.values(families as Record<string, number> || {})) {
              totalAccSkus += Number(count) || 0;
            }
          }
          idealMatrix.ACCESORIOS.areas.GENERAL += totalAccSkus;
        } else {
          for (const [secName, families] of Object.entries(deptData.secciones || {})) {
            const area = clasificarAreaGenero(secName, d);
            const secSkus = Object.values(families as Record<string, number> || {}).reduce((a, b) => a + (Number(b) || 0), 0);

            if (area === 'OTRO' || area === 'GENERAL') {
              idealMatrix[d].areas.CABALLERO += Math.ceil(secSkus / 2);
              idealMatrix[d].areas.DAMA += Math.floor(secSkus / 2);
            } else {
              idealMatrix[d].areas[area] += secSkus;
            }
          }
        }
      }
    }
  }

  // 4. Build DepartmentModuleSummary outputs
  const summaries: DepartmentModuleSummary[] = [];

  for (const d of depts) {
    const deptInfo = idealMatrix[d];
    const targetProf = deptInfo.storeCount > 0
      ? Math.round(deptInfo.sumProfundidad / deptInfo.storeCount)
      : (config?.[d]?.profundidad_target || (d === 'ACCESORIOS' ? 14 : 16));

    if (d === 'ACCESORIOS') {
      const skusIdeal = deptInfo.areas.GENERAL || 0;
      const piezasIdeal = skusIdeal * targetProf;
      const actualData = realMatrix.ACCESORIOS.GENERAL;
      const skusActual = actualData.skus.size;
      const piezasActual = actualData.pieces;
      const val = Math.round(actualData.val * 100) / 100;

      const difSKUs = (skusActual === 0 && skusIdeal === 0) ? 0 : skusActual - skusIdeal;
      const difPiezas = (piezasActual === 0 && piezasIdeal === 0) ? 0 : piezasActual - piezasIdeal;
      const pctOcupacion = piezasIdeal > 0 ? Math.round((piezasActual / piezasIdeal) * 1000) / 10 : 0;

      let estado: 'OPTIMO' | 'DEFICIT' | 'SATURACION' = 'OPTIMO';
      if (pctOcupacion < 85) estado = 'DEFICIT';
      else if (pctOcupacion > 110) estado = 'SATURACION';

      const generalAreaSummary: AreaCapacitySummary = {
        area: 'GENERAL',
        areaLabel: 'Área General (Unisex / Multicategoría)',
        skusIdeal,
        skusActual,
        diferenciaSKUs: difSKUs,
        piezasIdeal,
        piezasActual,
        diferenciaPiezas: difPiezas,
        porcentajeOcupacion: pctOcupacion,
        valoracionTotal: val,
        estado,
      };

      summaries.push({
        departamento: 'ACCESORIOS',
        profundidadTarget: targetProf,
        skusIdeal,
        skusActual,
        diferenciaSKUs: difSKUs,
        piezasIdeal,
        piezasActual,
        diferenciaPiezas: difPiezas,
        porcentajeOcupacion: pctOcupacion,
        valoracionTotal: val,
        esGeneral: true,
        areaGeneral: generalAreaSummary,
        areas: {
          GENERAL: generalAreaSummary,
        },
      });
      continue;
    }

    // CALZADO and TEXTIL (Gender-based modules)
    let deptSkusIdeal = 0;
    let deptSkusActual = 0;
    let deptPiezasIdeal = 0;
    let deptPiezasActual = 0;
    let deptValoracion = 0;

    const areaSummaries: Record<GenderArea, AreaCapacitySummary> = {} as any;

    for (const a of genderAreasList) {
      const skusIdeal = deptInfo.areas[a] || 0;
      const piezasIdeal = skusIdeal * targetProf;
      const actualData = realMatrix[d][a];
      const skusActual = actualData.skus.size;
      const piezasActual = actualData.pieces;
      const val = Math.round(actualData.val * 100) / 100;

      const difSKUs = (skusActual === 0 && skusIdeal === 0) ? 0 : skusActual - skusIdeal;
      const difPiezas = (piezasActual === 0 && piezasIdeal === 0) ? 0 : piezasActual - piezasIdeal;
      const pctOcupacion = piezasIdeal > 0 ? Math.round((piezasActual / piezasIdeal) * 1000) / 10 : 0;

      let estado: 'OPTIMO' | 'DEFICIT' | 'SATURACION' = 'OPTIMO';
      if (pctOcupacion < 85) estado = 'DEFICIT';
      else if (pctOcupacion > 110) estado = 'SATURACION';

      const labelMap: Record<GenderArea, string> = {
        CABALLERO: 'Caballero (Hombre)',
        DAMA: 'Dama (Mujer)',
        NIÑOS: 'Niños / Infante',
        GENERAL: 'General',
      };

      areaSummaries[a] = {
        area: a,
        areaLabel: labelMap[a],
        skusIdeal,
        skusActual,
        diferenciaSKUs: difSKUs,
        piezasIdeal,
        piezasActual,
        diferenciaPiezas: difPiezas,
        porcentajeOcupacion: pctOcupacion,
        valoracionTotal: val,
        estado,
      };

      deptSkusIdeal += skusIdeal;
      deptSkusActual += skusActual;
      deptPiezasIdeal += piezasIdeal;
      deptPiezasActual += piezasActual;
      deptValoracion += val;
    }

    const deptPctOcupacion = deptPiezasIdeal > 0 ? Math.round((deptPiezasActual / deptPiezasIdeal) * 1000) / 10 : 0;

    summaries.push({
      departamento: d,
      profundidadTarget: targetProf,
      skusIdeal: deptSkusIdeal,
      skusActual: deptSkusActual,
      diferenciaSKUs: (deptSkusActual === 0 && deptSkusIdeal === 0) ? 0 : deptSkusActual - deptSkusIdeal,
      piezasIdeal: deptPiezasIdeal,
      piezasActual: deptPiezasActual,
      diferenciaPiezas: (deptPiezasActual === 0 && deptPiezasIdeal === 0) ? 0 : deptPiezasActual - deptPiezasIdeal,
      porcentajeOcupacion: deptPctOcupacion,
      valoracionTotal: Math.round(deptValoracion * 100) / 100,
      esGeneral: false,
      areas: areaSummaries,
    });
  }

  return summaries;
}

/**
 * 2. Aging Analysis Calculation (100% Deterministic)
 */
export function calcularAgingBuckets(items: InventoryItem[], cutoffDate?: Date): AgingBucketSummary {
  const summary: AgingBucketSummary = {
    rango0_30: { piezas: 0, valor: 0, pct: 0 },
    rango31_60: { piezas: 0, valor: 0, pct: 0 },
    rango61_90: { piezas: 0, valor: 0, pct: 0 },
    rangoMas90: { piezas: 0, valor: 0, pct: 0 },
    totalPiezas: 0,
    totalValor: 0,
  };

  // Determine fixed reference date deterministically from the max date in dataset if available
  let refMs: number;
  if (cutoffDate) {
    refMs = cutoffDate.getTime();
  } else {
    let maxDateMs = 0;
    for (const it of items) {
      if (it.FechaIngreso) {
        const t = new Date(it.FechaIngreso).getTime();
        if (!isNaN(t) && t > maxDateMs) maxDateMs = t;
      }
    }
    // Fixed static epoch if no dates present: ensures 100% deterministic reproducibility
    refMs = maxDateMs > 0 ? maxDateMs : 1774000000000;
  }

  for (const it of items) {
    let days = it.DiasAntiguedad;
    if (days === undefined || isNaN(days)) {
      if (it.FechaIngreso) {
        const itemDate = new Date(it.FechaIngreso).getTime();
        days = Math.max(0, Math.floor((refMs - itemDate) / (1000 * 60 * 60 * 24)));
      } else {
        // Fallback default: hash-based stable simulated aging between 10 and 110 days
        const hash = (it.Referencia + it.Talla).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
        days = (hash % 100) + 10;
      }
    }

    summary.totalPiezas += it.Stock;
    summary.totalValor += it.Valoracion;

    if (days <= 30) {
      summary.rango0_30.piezas += it.Stock;
      summary.rango0_30.valor += it.Valoracion;
    } else if (days <= 60) {
      summary.rango31_60.piezas += it.Stock;
      summary.rango31_60.valor += it.Valoracion;
    } else if (days <= 90) {
      summary.rango61_90.piezas += it.Stock;
      summary.rango61_90.valor += it.Valoracion;
    } else {
      summary.rangoMas90.piezas += it.Stock;
      summary.rangoMas90.valor += it.Valoracion;
    }
  }

  if (summary.totalPiezas > 0) {
    summary.rango0_30.pct = Math.round((summary.rango0_30.piezas / summary.totalPiezas) * 1000) / 10;
    summary.rango31_60.pct = Math.round((summary.rango31_60.piezas / summary.totalPiezas) * 1000) / 10;
    summary.rango61_90.pct = Math.round((summary.rango61_90.piezas / summary.totalPiezas) * 1000) / 10;
    summary.rangoMas90.pct = Math.round((summary.rangoMas90.piezas / summary.totalPiezas) * 1000) / 10;
  }

  return summary;
}

/**
 * 3. Spatial Density & Performance ($/m2 and pieces/m2)
 */
export function calcularRendimientoEspacial(
  items: InventoryItem[],
  storeProfiles: StoreProfile[]
): SpatialPerformanceMetric[] {
  const storeMap: Record<string, { piezas: number; valor: number }> = {};
  for (const it of items) {
    if (!storeMap[it.Tienda]) {
      storeMap[it.Tienda] = { piezas: 0, valor: 0 };
    }
    storeMap[it.Tienda].piezas += it.Stock;
    storeMap[it.Tienda].valor += it.Valoracion;
  }

  const FORMAT_BENCHMARKS: Record<StoreType, { min: number; max: number; defaultM2: number }> = {
    FLAGSHIP: { min: 10, max: 18, defaultM2: 450 },
    LIVE: { min: 14, max: 22, defaultM2: 280 },
    UNITE: { min: 22, max: 35, defaultM2: 320 },
    EXPRESS: { min: 16, max: 26, defaultM2: 120 },
  };

  const results: SpatialPerformanceMetric[] = [];

  const storeNames = Array.from(
    new Set([...Object.keys(storeMap), ...storeProfiles.map((p) => p.nombre)])
  ).filter((s) => s && s !== 'TODAS');

  for (const storeName of storeNames) {
    const profile = storeProfiles.find((p) => p.nombre === storeName);
    const formato = profile?.tipo || 'LIVE';
    const benchmark = FORMAT_BENCHMARKS[formato] || FORMAT_BENCHMARKS.LIVE;
    const m2 = profile?.superficieM2 && profile.superficieM2 > 0 ? profile.superficieM2 : benchmark.defaultM2;

    const data = storeMap[storeName] || { piezas: 0, valor: 0 };
    const piezasM2 = Math.round((data.piezas / m2) * 10) / 10;
    const valorM2 = Math.round((data.valor / m2) * 10) / 10;

    let estadoDensidad: 'OPTIMO' | 'SOBRECARGA' | 'SUBUTILIZADO' = 'OPTIMO';
    if (piezasM2 > benchmark.max) estadoDensidad = 'SOBRECARGA';
    else if (piezasM2 < benchmark.min) estadoDensidad = 'SUBUTILIZADO';

    results.push({
      tienda: storeName,
      superficieM2: m2,
      formato,
      piezasActuales: data.piezas,
      valoracionTotal: data.valor,
      piezasPorM2: piezasM2,
      valorPorM2: valorM2,
      densidadTargetMin: benchmark.min,
      densidadTargetMax: benchmark.max,
      estadoDensidad,
    });
  }

  return results;
}

/**
 * 4. Freight Cost Estimation based on Distance
 */
export function calcularCostoFlete(
  distanciaKm: number,
  unidades: number,
  ruleConfig: RuleEngineConfig = DEFAULT_RULE_CONFIG
): number {
  // `??` en lugar de `||`: un valor 0 configurado por el usuario es legítimo y no debe sustituirse por el default.
  const baseFija = ruleConfig.costoFleteBaseFijo ?? 15.0;
  const tarifaKm = ruleConfig.costoFleteBasePorKm ?? 0.85;
  const tarifaPieza = 0.35; // handling por prenda/caja
  const flete = baseFija + (distanciaKm * tarifaKm) + (unidades * tarifaPieza);
  return Math.round(flete * 100) / 100;
}

/**
 * 5. Diagnostic Alert Engine with Parametric Rules & Financial Risks
 */
export function diagnosticarAlertas(
  items: InventoryItem[],
  selectedStore?: string,
  ruleConfig: RuleEngineConfig = DEFAULT_RULE_CONFIG
): InventoryAlert[] {
  const filtered = selectedStore && selectedStore !== 'TODAS'
    ? items.filter((it) => it.Tienda === selectedStore)
    : items;

  if (filtered.length === 0) return [];

  const grouped: Record<string, {
    ref: string;
    marca: string;
    depto: string;
    tienda: string;
    stockTotal: number;
    valoracionTotal: number;
    tallas: Record<string, number>;
    maxDias: number;
    ventaSemanalTotal: number;
    hasSalesData: boolean;
  }> = {};

  for (const it of filtered) {
    const key = `${it.Tienda}___${it.Referencia}___${it.Marca}___${it.Departamento}`;
    if (!grouped[key]) {
      grouped[key] = {
        ref: it.Referencia,
        marca: it.Marca,
        depto: it.Departamento,
        tienda: it.Tienda,
        stockTotal: 0,
        valoracionTotal: 0,
        tallas: {},
        maxDias: it.DiasAntiguedad || 0,
        ventaSemanalTotal: 0,
        hasSalesData: false,
      };
    }
    grouped[key].stockTotal += it.Stock;
    grouped[key].valoracionTotal += it.Valoracion;
    grouped[key].tallas[it.Talla] = (grouped[key].tallas[it.Talla] || 0) + it.Stock;
    if ((it.DiasAntiguedad || 0) > grouped[key].maxDias) {
      grouped[key].maxDias = it.DiasAntiguedad || 0;
    }
    if (it.VentaSemanal !== undefined && it.VentaSemanal >= 0) {
      grouped[key].ventaSemanalTotal += it.VentaSemanal;
      grouped[key].hasSalesData = true;
    }
  }

  const alerts: InventoryAlert[] = [];
  const tallasCoreCalzado = ['8', '8.5', '9', '9.5', '10', '10.5', '11'];
  const tallasCoreTextil = ['M', 'L', 'XL'];

  Object.values(grouped).forEach((group) => {
    const { ref, marca, depto, tienda, stockTotal, valoracionTotal, tallas, maxDias, ventaSemanalTotal, hasSalesData } = group;
    const sizeKeys = Object.keys(tallas);
    const numTallas = sizeKeys.length;
    const unitVal = stockTotal > 0 ? valoracionTotal / stockTotal : 60;
    const safeTiendaId = tienda.replace(/\s+/g, '_');
    const safeRefId = ref.replace(/\s+/g, '_');

    // Regla 1: Monotalla / Huérfana
    if (stockTotal <= (ruleConfig.umbralMonotallaPiezas || 2) && numTallas === 1) {
      const riskVal = Math.round(stockTotal * unitVal * 0.7);
      alerts.push({
        id: `alert-mono-${safeTiendaId}-${safeRefId}`,
        Prioridad: 'ALTA 🔴',
        TipoDeAlerta: 'Talla Huérfana / Monotalla',
        Referencia: ref,
        Marca: marca,
        Departamento: depto,
        Tienda: tienda,
        Diagnostico: `Solo ${stockTotal} pieza(s) en talla única '${sizeKeys[0]}'. Ocupa frente de exhibición sin profundidad comercial.`,
        AccionCorrectiva: 'Retirar de exhibición principal y consolidar en rack de liquidación, outlet o solicitar traslado inter-tienda.',
        AccionSugerida: 'Retirar de exhibición principal y consolidar en rack de liquidación, outlet o solicitar traslado inter-tienda.',
        Stock: stockTotal,
        TallasDisponibles: sizeKeys,
        ValorRiesgoMonetario: riskVal,
      });
      return;
    }

    // Regla 2: Quiebre de Tallas Core (Calzado / Textil)
    if (depto === 'CALZADO' && stockTotal >= 4) {
      const coreFaltantes = tallasCoreCalzado.filter((t) => !sizeKeys.includes(t));
      const tieneCore = coreFaltantes.length < tallasCoreCalzado.length;
      if (!tieneCore && numTallas <= 2) {
        const velocidadVentasDia = 0.25;
        const ventanaReposicionDias = 14;
        const frecuenciaQuiebre = Math.max(1, Math.min(coreFaltantes.length, 4));
        const lostSalesRisk = Math.round(frecuenciaQuiebre * velocidadVentasDia * unitVal * ventanaReposicionDias);
        alerts.push({
          id: `alert-core-${safeTiendaId}-${safeRefId}`,
          Prioridad: 'CRÍTICA 🚨',
          TipoDeAlerta: 'Quiebre de Tallas Core',
          Referencia: ref,
          Marca: marca,
          Departamento: depto,
          Tienda: tienda,
          Diagnostico: `Curva rota con ${numTallas} tallas extremas (${sizeKeys.join(', ')}). Sin disponibilidad en tallas centrales de alta rotación (8 al 10.5).`,
          AccionCorrectiva: 'Solicitar reposición inmediata de tallas centrales a bodega central o ejecutar rebalanceo inter-tienda.',
          AccionSugerida: 'Solicitar reposición inmediata de tallas centrales a bodega central o ejecutar rebalanceo inter-tienda.',
          Stock: stockTotal,
          TallasDisponibles: sizeKeys,
          ValorRiesgoMonetario: lostSalesRisk,
        });
        return;
      }
    } else if (depto === 'TEXTIL' && stockTotal >= 4) {
      const coreFaltantes = tallasCoreTextil.filter((t) => !sizeKeys.includes(t));
      const tieneCore = coreFaltantes.length < tallasCoreTextil.length;
      if (!tieneCore && numTallas <= 2) {
        const velocidadVentasDia = 0.25;
        const ventanaReposicionDias = 14;
        const frecuenciaQuiebre = Math.max(1, Math.min(coreFaltantes.length, 3));
        const lostSalesRisk = Math.round(frecuenciaQuiebre * velocidadVentasDia * unitVal * ventanaReposicionDias);
        alerts.push({
          id: `alert-core-tex-${safeTiendaId}-${safeRefId}`,
          Prioridad: 'CRÍTICA 🚨',
          TipoDeAlerta: 'Quiebre de Tallas Core',
          Referencia: ref,
          Marca: marca,
          Departamento: depto,
          Tienda: tienda,
          Diagnostico: `Curva rota sin tallas centrales M/L/XL. Solo quedan extremos (${sizeKeys.join(', ')}).`,
          AccionCorrectiva: 'Reordenar tallas centrales prioritarias desde CEDI o cross-docking.',
          AccionSugerida: 'Reordenar tallas centrales prioritarias desde CEDI o cross-docking.',
          Stock: stockTotal,
          TallasDisponibles: sizeKeys,
          ValorRiesgoMonetario: lostSalesRisk,
        });
        return;
      }
    }

    // Regla 3: Aging Crítico (> 90 días o umbral configurado)
    if (maxDias >= (ruleConfig.umbralAgingCriticoDias || 90) && stockTotal >= 3) {
      alerts.push({
        id: `alert-aging-${safeTiendaId}-${safeRefId}`,
        Prioridad: 'ALTA 🔴',
        TipoDeAlerta: 'Inventario Crítico / Aging',
        Referencia: ref,
        Marca: marca,
        Departamento: depto,
        Tienda: tienda,
        Diagnostico: `Inventario con ${maxDias} días de permanencia sin rotación óptima (${stockTotal} unidades).`,
        AccionCorrectiva: 'Aplicar descuento de liquidación o trasladar a tienda formato Outlet (Unite).',
        AccionSugerida: 'Aplicar descuento de liquidación o trasladar a tienda formato Outlet (Unite).',
        Stock: stockTotal,
        TallasDisponibles: sizeKeys,
        ValorRiesgoMonetario: valoracionTotal,
      });
      return;
    }

    // Regla 4: Sobrestock por Modelo
    const limiteSobrestock = depto === 'ACCESORIOS' ? 36 : 24;
    if (stockTotal > limiteSobrestock) {
      const excess = stockTotal - limiteSobrestock;
      alerts.push({
        id: `alert-over-${safeTiendaId}-${safeRefId}`,
        Prioridad: 'MEDIA 🟡',
        TipoDeAlerta: 'Sobrestock por Modelo',
        Referencia: ref,
        Marca: marca,
        Departamento: depto,
        Tienda: tienda,
        Diagnostico: `${stockTotal} unidades en stock (Capacidad máxima sugerida: ${limiteSobrestock} uds).`,
        AccionCorrectiva: 'Activar exhibición destacada en mesa frontal, aplicar promoción de impulso o redistribuir a sucursales deficitarias.',
        AccionSugerida: 'Activar exhibición destacada en mesa frontal, aplicar promoción de impulso o redistribuir a sucursales deficitarias.',
        Stock: stockTotal,
        TallasDisponibles: sizeKeys,
        ValorRiesgoMonetario: Math.round(excess * unitVal),
      });
      return;
    }

    // Regla 5: Cobertura WOS (Weeks of Supply) y Ritmo de Venta (Si existen datos de venta en el dataset)
    if (hasSalesData) {
      const groupWos = ventaSemanalTotal > 0
        ? Math.round((stockTotal / ventaSemanalTotal) * 10) / 10
        : (stockTotal > 0 ? 999 : 0);

      if (groupWos > 24 && stockTotal >= 8) {
        alerts.push({
          id: `alert-wos-over-${safeTiendaId}-${safeRefId}`,
          Prioridad: 'ALTA 🔴',
          TipoDeAlerta: 'Sobrestock por Cobertura (WOS)',
          Referencia: ref,
          Marca: marca,
          Departamento: depto,
          Tienda: tienda,
          Diagnostico: `Cobertura excesiva de ${groupWos} semanas (${stockTotal} uds físicas para venta de ${ventaSemanalTotal} u/sem).`,
          AccionCorrectiva: 'Rebalancear stock a sucursales con mayor ritmo de venta o activar acción promocional.',
          AccionSugerida: 'Rebalancear stock a sucursales con mayor ritmo de venta o activar acción promocional.',
          Stock: stockTotal,
          TallasDisponibles: sizeKeys,
          ValorRiesgoMonetario: Math.round(Math.max(0, stockTotal - ventaSemanalTotal * 8) * unitVal),
        });
      } else if (groupWos > 0 && groupWos < 1.5 && stockTotal > 0) {
        alerts.push({
          id: `alert-wos-under-${safeTiendaId}-${safeRefId}`,
          Prioridad: 'CRÍTICA 🚨',
          TipoDeAlerta: 'Riesgo de Quiebre por Demanda',
          Referencia: ref,
          Marca: marca,
          Departamento: depto,
          Tienda: tienda,
          Diagnostico: `Cobertura crítica de solo ${groupWos} semanas (${stockTotal} uds para venta semanal de ${ventaSemanalTotal} u/sem). Riesgo inminente de agotamiento.`,
          AccionCorrectiva: 'Solicitar reposición urgente o transferencia prioritaria desde sucursales con exceso.',
          AccionSugerida: 'Solicitar reposición urgente o transferencia prioritaria desde sucursales con exceso.',
          Stock: stockTotal,
          TallasDisponibles: sizeKeys,
          ValorRiesgoMonetario: Math.round(ventaSemanalTotal * 2 * unitVal),
        });
      } else if (groupWos === 999 && stockTotal >= 6 && maxDias > 45) {
        alerts.push({
          id: `alert-wos-inactive-${safeTiendaId}-${safeRefId}`,
          Prioridad: 'MEDIA 🟡',
          TipoDeAlerta: 'Inventario Inactivo sin Venta',
          Referencia: ref,
          Marca: marca,
          Departamento: depto,
          Tienda: tienda,
          Diagnostico: `0 ventas registradas con ${stockTotal} unidades físicas y ${maxDias} días de permanencia.`,
          AccionCorrectiva: 'Revisar visibilidad en exhibición, verificar precio en POS o evaluar traslado a outlet.',
          AccionSugerida: 'Revisar visibilidad en exhibición, verificar precio en POS o evaluar traslado a outlet.',
          Stock: stockTotal,
          TallasDisponibles: sizeKeys,
          ValorRiesgoMonetario: valoracionTotal,
        });
      }
    }
  });

  return alerts;
}

/**
 * 6. Financial Risk Quantification (Lost Sales & Dead Stock in $)
 * 100% Deterministic based strictly on inventory data and theoretical formulas
 */
export function calcularRiesgoFinanciero(
  alerts: InventoryAlert[],
  items: InventoryItem[],
  summaryRows: CapacitySummaryRow[],
  ruleConfig: RuleEngineConfig = DEFAULT_RULE_CONFIG
): FinancialRiskSummary {
  let lostSales = 0;
  let deadStockFromAlerts = 0;
  let capitalInmovilizado = 0;
  let piezasEnRiesgo = 0;

  (alerts || []).forEach((a) => {
    if (!a) return;
    piezasEnRiesgo += a.Stock || 0;
    if (a.TipoDeAlerta === 'Quiebre de Tallas Core') {
      lostSales += a.ValorRiesgoMonetario || 0;
    } else if (a.TipoDeAlerta === 'Inventario Crítico / Aging' || a.TipoDeAlerta === 'Talla Huérfana / Monotalla') {
      deadStockFromAlerts += a.ValorRiesgoMonetario || 0;
    } else if (a.TipoDeAlerta === 'Sobrestock por Modelo') {
      capitalInmovilizado += a.ValorRiesgoMonetario || 0;
    }
  });

  // Dead Stock: Costo inmovilizado en tallas extremas con antigüedad > 90 días (o vinculada a temporada pasada)
  const extremeSizes = new Set(['5', '5.5', '6', '6.5', '12', '12.5', '13', '14', 'XS', 'XXL', '3XL']);
  let itemLevelDeadStock = 0;

  for (const it of items) {
    const isExtreme = extremeSizes.has(it.Talla.trim().toUpperCase());
    const isAgingGt90 = (it.DiasAntiguedad || 0) > 90;
    const isPastSeason = it.Temporada && (
      it.Temporada.toUpperCase().includes('PASADA') ||
      it.Temporada.toUpperCase().includes('ANTERIOR') ||
      it.Temporada.toUpperCase().includes('OUTLET')
    );

    if ((isExtreme && isAgingGt90) || (isAgingGt90 && isPastSeason)) {
      itemLevelDeadStock += it.Valoracion || (it.Stock * (it.ValorUnitario || 50));
    }
  }

  const aging = calcularAgingBuckets(items);
  const deadStock = Math.max(deadStockFromAlerts, Math.round(itemLevelDeadStock), Math.round(aging.rangoMas90.valor * 0.75));

  // Ahorro estimado si se ejecutan rebalanceos (evita liquidación forzada del 30%)
  const ahorroRebalanceo = Math.round((deadStock + lostSales) * 0.25);

  return {
    valorVentasPerdidasEstimadas: Math.round(lostSales),
    valorDeadStockCritico: Math.round(deadStock),
    valorCapitalInmovilizado: Math.round(capitalInmovilizado),
    ahorroPorRebalanceoEstimado: Math.round(ahorroRebalanceo),
    piezasEnRiesgo,
  };
}

/**
 * 7. Live In-Transit Simulation Engine
 * Adjusts inventory views dynamically without modifying raw data
 */
export function aplicarSimulacionTraspasos(
  baseInventory: InventoryItem[],
  transfers: TransferSuggestion[]
): InventoryItem[] {
  if (!transfers || transfers.length === 0) return baseInventory;

  const simulated = JSON.parse(JSON.stringify(baseInventory)) as InventoryItem[];

  for (const sug of transfers) {
    // 1. Subtract from source store
    const srcItem = simulated.find(
      (it) => it.Tienda === sug.TiendaOrigen && it.Referencia === sug.Referencia && it.Talla === sug.Talla
    );
    if (srcItem) {
      const unitVal = srcItem.Stock > 0 ? srcItem.Valoracion / srcItem.Stock : 50;
      srcItem.Stock = Math.max(0, srcItem.Stock - sug.UnidadesSugeridas);
      srcItem.Valoracion = srcItem.Stock * unitVal;
    }

    // 2. Add to destination store
    const dstItem = simulated.find(
      (it) => it.Tienda === sug.TiendaDestino && it.Referencia === sug.Referencia && it.Talla === sug.Talla
    );
    if (dstItem) {
      const unitVal = dstItem.Stock > 0 ? dstItem.Valoracion / dstItem.Stock : 50;
      dstItem.Stock += sug.UnidadesSugeridas;
      dstItem.Valoracion = dstItem.Stock * unitVal;
    } else if (srcItem) {
      const unitVal = srcItem.Stock > 0 ? srcItem.Valoracion / Math.max(1, srcItem.Stock) : 50;
      simulated.push({
        ...srcItem,
        id: `sim-inbound-${sug.TiendaDestino}-${sug.Referencia}-${sug.Talla}`,
        Tienda: sug.TiendaDestino,
        Stock: sug.UnidadesSugeridas,
        Valoracion: sug.UnidadesSugeridas * unitVal,
      });
    }
  }

  return simulated.filter((it) => it.Stock > 0);
}

/**
 * 8. Prospect What-If Simulation (Sell-Through & Capacity stress test)
 */
export function ejecutarSimulacionWhatIf(
  items: InventoryItem[],
  storeCapacities: Record<string, CapacityMatrixConfig>,
  config: WhatIfSimulationConfig,
  transfers: TransferSuggestion[] = []
): WhatIfSimulationResult[] {
  const workingItems = config.incluirTraspasosEnTransito
    ? aplicarSimulacionTraspasos(items, transfers)
    : items;

  const stores = Array.from(new Set(workingItems.map((it) => it.Tienda))).filter((s) => s && s !== 'TODAS');
  const results: WhatIfSimulationResult[] = [];

  const weeks = Math.max(1, config.horizonteSemanas);
  const deltaPct = config.variacionSellThroughPct / 100;

  for (const store of stores) {
    const storeItems = workingItems.filter(
      (it) => it.Tienda === store && (!config.departamentoFiltro || config.departamentoFiltro === 'TODAS' || it.Departamento === config.departamentoFiltro)
    );
    const stockActual = storeItems.reduce((acc, it) => acc + it.Stock, 0);

    // Calculate Ideal Capacity from Matrix
    let capacidadIdeal = 0;
    let targetDepth = 16;
    const matrix = storeCapacities[store];
    if (matrix) {
      Object.values(matrix).forEach((deptData) => {
        targetDepth = deptData.profundidad_target || targetDepth;
        Object.values(deptData.secciones || {}).forEach((sec) => {
          Object.values(sec || {}).forEach((cnt) => {
            capacidadIdeal += cnt * targetDepth;
          });
        });
      });
    }

    if (capacidadIdeal === 0) {
      capacidadIdeal = Math.max(100, Math.round(stockActual * 1.1));
    }

    // Base theoretical weekly sell-through rate: default 8.5% weekly (~12 weeks cycle)
    const baseWeeklySTR = 0.085;
    const simulatedWeeklySTR = Math.max(0.01, baseWeeklySTR * (1 + deltaPct));

    // Compound sales over t weeks: 1 - (1 - STR)^t
    const totalSimulatedSTR = 1 - Math.pow(1 - simulatedWeeklySTR, weeks);
    const ventasProyectadas = Math.round(stockActual * totalSimulatedSTR);
    const stockProyectado = Math.max(0, stockActual - ventasProyectadas);

    const ocupacionActualPct = Math.round((stockActual / capacidadIdeal) * 1000) / 10;
    const ocupacionProyectadaPct = Math.round((stockProyectado / capacidadIdeal) * 1000) / 10;

    const weeklyRunRate = stockActual * simulatedWeeklySTR;
    const semanasCobertura = weeklyRunRate > 0 ? Math.round((stockActual / weeklyRunRate) * 10) / 10 : 99;

    let estadoRiesgo: 'QUIEBRE_PROMINENTE' | 'OPTIMO' | 'SATURACION_ALTA' = 'OPTIMO';
    if (ocupacionProyectadaPct < 45 || semanasCobertura < 4) {
      estadoRiesgo = 'QUIEBRE_PROMINENTE';
    } else if (ocupacionProyectadaPct > 115) {
      estadoRiesgo = 'SATURACION_ALTA';
    }

    const runoutDate = new Date();
    runoutDate.setDate(runoutDate.getDate() + Math.round(semanasCobertura * 7));

    results.push({
      tienda: store,
      stockActual,
      stockProyectado,
      ventasProyectadas,
      capacidadIdeal,
      ocupacionActualPct,
      ocupacionProyectadaPct,
      semanasCobertura,
      fechaQuiebreEstimada: semanasCobertura < 12 ? runoutDate.toLocaleDateString() : 'Sin riesgo',
      estadoRiesgo,
    });
  }

  return results;
}

/**
 * 9. Pivot Table for Size Curves
 */
export interface PivotRow {
  Referencia: string;
  Marca: string;
  Departamento: string;
  Familia: string;
  Tienda?: string;
  TotalStock: number;
  Tallas: Record<string, number>;
}

export function generarPivotCurvas(
  items: InventoryItem[],
  filterDept?: string,
  filterBrand?: string,
  filterStore?: string,
  searchQuery?: string
): { rows: PivotRow[]; allSizes: string[] } {
  let filtered = items;
  if (filterDept && filterDept !== 'TODAS') {
    filtered = filtered.filter((it) => it.Departamento === filterDept);
  }
  if (filterBrand && filterBrand !== 'TODAS') {
    filtered = filtered.filter((it) => it.Marca === filterBrand);
  }
  if (filterStore && filterStore !== 'TODAS') {
    filtered = filtered.filter((it) => it.Tienda === filterStore);
  }
  if (searchQuery && searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    filtered = filtered.filter(
      (it) =>
        it.Referencia.toLowerCase().includes(q) ||
        it.Marca.toLowerCase().includes(q) ||
        it.Familia.toLowerCase().includes(q)
    );
  }

  const grouped: Record<string, PivotRow> = {};
  const sizeSet = new Set<string>();

  for (const it of filtered) {
    const key = `${it.Referencia}___${it.Marca}___${it.Departamento}___${it.Familia}`;
    if (!grouped[key]) {
      grouped[key] = {
        Referencia: it.Referencia,
        Marca: it.Marca,
        Departamento: it.Departamento,
        Familia: it.Familia,
        TotalStock: 0,
        Tallas: {},
      };
    }
    grouped[key].Tallas[it.Talla] = (grouped[key].Tallas[it.Talla] || 0) + it.Stock;
    grouped[key].TotalStock += it.Stock;
    sizeSet.add(it.Talla);
  }

  const sizeOrderRank: Record<string, number> = {
    'XS': 1, 'S': 2, 'M': 3, 'L': 4, 'XL': 5, 'XXL': 6, '2XL': 7, '3XL': 8, 'U': 99,
  };

  const allSizes = Array.from(sizeSet).sort((a, b) => {
    const numA = parseFloat(a);
    const numB = parseFloat(b);
    if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
    if (!isNaN(numA)) return -1;
    if (!isNaN(numB)) return 1;
    const rankA = sizeOrderRank[a] || 50;
    const rankB = sizeOrderRank[b] || 50;
    return rankA - rankB || a.localeCompare(b);
  });

  return {
    rows: Object.values(grouped).sort((a, b) => b.TotalStock - a.TotalStock),
    allSizes,
  };
}

/**
 * 10. Inter-Store Transfer Calculation with Freight Costs & Warehouse Review Status
 */
export function calcularSugerenciasTraslados(
  items: InventoryItem[],
  distances: StoreDistance = {},
  ruleConfig: RuleEngineConfig = DEFAULT_RULE_CONFIG,
  storeProfiles: StoreProfile[] = [],
  storeCapacities?: Record<string, CapacityMatrixConfig>,
  capacityConfig?: CapacityMatrixConfig
): TransferSuggestion[] {
  const stores = Array.from(new Set(items.map((it) => it.Tienda)));
  if (stores.length < 2) return [];

  // Helper to detect Outlet / Liquidación stores
  const isOutletStore = (storeName: string): boolean => {
    const s = storeName.toLowerCase().trim();
    const prof = storeProfiles.find((p) => p.nombre.toLowerCase().trim() === s);
    if (prof && prof.tipo === 'UNITE') return true;
    return s.includes('outlet') || s.includes('unite') || s.includes('liquidacion') || s.includes('remate') || s.includes('rebaja');
  };

  // Distance lookup helper (GPS Haversine, then matrix, then fallback)
  const getDistBetweenStores = (s1: string, s2: string, fallback: number = 15): { dist: number; isGps: boolean } => {
    if (storeProfiles && storeProfiles.length > 0) {
      const p1 = storeProfiles.find((p) => p.nombre.toLowerCase().trim() === s1.toLowerCase().trim());
      const p2 = storeProfiles.find((p) => p.nombre.toLowerCase().trim() === s2.toLowerCase().trim());
      if (
        p1 && p2 &&
        typeof p1.lat === 'number' && typeof p1.lng === 'number' &&
        typeof p2.lat === 'number' && typeof p2.lng === 'number'
      ) {
        const geoKm = calculateGeoDistanceKm(p1.lat, p1.lng, p2.lat, p2.lng);
        if (geoKm > 0) {
          return { dist: geoKm, isGps: true };
        }
      }
    }

    const d = distances as any;
    if (typeof d?.[s1]?.[s2] === 'number') return { dist: d[s1][s2], isGps: false };
    if (typeof d?.[s2]?.[s1] === 'number') return { dist: d[s2][s1], isGps: false };
    if (typeof d?.[`${s1}-${s2}`] === 'number') return { dist: d[`${s1}-${s2}`], isGps: false };
    if (typeof d?.[`${s2}-${s1}`] === 'number') return { dist: d[`${s2}-${s1}`], isGps: false };
    return { dist: fallback, isGps: false };
  };

  // Group inventory by Store and Reference
  interface StoreRefSummary {
    ref: string;
    marca: string;
    depto: string;
    seccion: string;
    tienda: string;
    tallas: Record<string, number>;
    itemsMap: Record<string, InventoryItem>;
    maxDias: number;
  }

  const storeMap: Record<string, Record<string, StoreRefSummary>> = {};

  for (const it of items) {
    if (!storeMap[it.Tienda]) storeMap[it.Tienda] = {};
    if (!storeMap[it.Tienda][it.Referencia]) {
      storeMap[it.Tienda][it.Referencia] = {
        ref: it.Referencia,
        marca: it.Marca,
        depto: it.Departamento,
        seccion: it.Seccion,
        tienda: it.Tienda,
        tallas: {},
        itemsMap: {},
        maxDias: it.DiasAntiguedad || 0,
      };
    }
    const refData = storeMap[it.Tienda][it.Referencia];
    refData.tallas[it.Talla] = (refData.tallas[it.Talla] || 0) + it.Stock;
    if (!refData.itemsMap[it.Talla] || it.Stock > (refData.itemsMap[it.Talla]?.Stock || 0)) {
      refData.itemsMap[it.Talla] = it;
    }
    if ((it.DiasAntiguedad || 0) > refData.maxDias) {
      refData.maxDias = it.DiasAntiguedad || 0;
    }
  }

  // Live simulation ledger to track changes in real time and enforce invariant:
  // Transfers MUST strictly decrease or maintain total alerts across the network!
  const simStock: Record<string, Record<string, Record<string, number>>> = {};
  for (const st of stores) {
    simStock[st] = {};
    if (storeMap[st]) {
      for (const [ref, data] of Object.entries(storeMap[st])) {
        simStock[st][ref] = { ...data.tallas };
      }
    }
  }

  const getSimTotal = (tienda: string, ref: string): number => {
    const tMap = simStock[tienda]?.[ref];
    if (!tMap) return 0;
    return Object.values(tMap).reduce((a, b) => a + b, 0);
  };

  const getSimNumTallas = (tienda: string, ref: string): number => {
    const tMap = simStock[tienda]?.[ref];
    if (!tMap) return 0;
    return Object.values(tMap).filter((v) => v > 0).length;
  };

  const getSimSizeStock = (tienda: string, ref: string, talla: string): number => {
    return simStock[tienda]?.[ref]?.[talla] || 0;
  };

  // Helper to calculate total simulated pieces in a store for a department
  const getDestDeptCurrentPieces = (store: string, dept: string): number => {
    let sum = 0;
    const storeRefs = simStock[store];
    if (!storeRefs) return 0;
    for (const [r, tallasMap] of Object.entries(storeRefs)) {
      const rDepto = storeMap[store]?.[r]?.depto;
      if (rDepto === dept) {
        sum += Object.values(tallasMap).reduce((a, b) => a + b, 0);
      }
    }
    return sum;
  };

  // Helper to check if destination store has physical capacity allowed (Ponderación de Capacidad)
  const checkDestCapacityAllowed = (destStore: string, depto: string, incomingUnits: number): boolean => {
    if (isOutletStore(destStore)) return true; // Outlets have clearance capacity tolerance

    const storeMatrix = resolveStoreCapacityMatrix(
      destStore,
      undefined,
      storeCapacities,
      storeProfiles,
      capacityConfig
    );

    if (storeMatrix && storeMatrix[depto] && storeMatrix[depto].activa !== false) {
      const deptCap = storeMatrix[depto];
      const targetDepth = deptCap.profundidad_target || 16;
      let deptSkusIdeal = 0;
      for (const secData of Object.values(deptCap.secciones || {})) {
        for (const qty of Object.values(secData || {})) {
          deptSkusIdeal += qty || 0;
        }
      }
      const deptPiezasIdeal = deptSkusIdeal * targetDepth;

      // Restricción de Capacidad: Si la tienda ya está al 100% de ocupación en este módulo o si el envío excede el 100%, BLOQUEAR
      if (deptPiezasIdeal > 0) {
        const currentDeptPieces = getDestDeptCurrentPieces(destStore, depto);
        if (currentDeptPieces + incomingUnits > deptPiezasIdeal) {
          return false; // BLOQUEADO: Módulo de departamento saturado (> 100% capacidad)
        }
      }
    }

    // Comprobación adicional de superficie / capacidad física total si el perfil de tienda define totalPiezasFisicas
    const prof = storeProfiles.find((p) => p.nombre.toLowerCase().trim() === destStore.toLowerCase().trim());
    if (prof?.totalPiezasFisicas && prof.totalPiezasFisicas > 0) {
      let storeTotalPieces = 0;
      const storeRefs = simStock[destStore];
      if (storeRefs) {
        for (const tallasMap of Object.values(storeRefs)) {
          storeTotalPieces += Object.values(tallasMap).reduce((a, b) => a + b, 0);
        }
      }
      if (storeTotalPieces + incomingUnits > prof.totalPiezasFisicas) {
        return false; // BLOQUEADO: Tienda ha superado su aforo físico global
      }
    }

    return true;
  };

  const tallasCoreCalzado = ['8', '8.5', '9', '9.5', '10', '10.5', '11'];
  const tallasCoreTextil = ['M', 'L', 'XL'];
  const umbralMono = ruleConfig.umbralMonotallaPiezas || 2;

  const suggestions: TransferSuggestion[] = [];

  // Helper to add a verified transfer suggestion
  const tryAddSuggestion = (
    srcStore: string,
    destStore: string,
    ref: string,
    talla: string,
    units: number,
    motivo: string,
    prioridad: 'ALTA' | 'MEDIA' | 'NORMAL'
  ): boolean => {
    if (srcStore === destStore || units <= 0) return false;
    const srcSizeStock = getSimSizeStock(srcStore, ref, talla);
    if (srcSizeStock < units) return false;

    const srcData = storeMap[srcStore]?.[ref];
    const repItem = srcData?.itemsMap[talla] || Object.values(srcData?.itemsMap || {})[0];
    if (!repItem) return false;

    // Simulation projected check:
    const srcTotalBefore = getSimTotal(srcStore, ref);
    const srcTallasBefore = getSimNumTallas(srcStore, ref);
    const destTotalBefore = getSimTotal(destStore, ref);
    const destTallasBefore = getSimNumTallas(destStore, ref);

    const srcTotalAfter = srcTotalBefore - units;
    const srcSizeAfter = srcSizeStock - units;
    const srcTallasAfter = srcSizeAfter === 0 ? srcTallasBefore - 1 : srcTallasBefore;

    const destTotalAfter = destTotalBefore + units;
    const destSizeBefore = getSimSizeStock(destStore, ref, talla);
    const destTallasAfter = destSizeBefore === 0 ? destTallasBefore + 1 : destTallasBefore;

    // GOLDEN RULE 1: In destination store:
    // If destStore is NOT an outlet, it must NEVER end up as an isolated Monotalla alert
    // (stockTotal <= umbralMono && numTallas === 1)
    if (!isOutletStore(destStore)) {
      if (destTotalAfter <= umbralMono && destTallasAfter === 1) {
        return false; // REJECT: creates a new Monotalla in destination!
      }
    }

    // GOLDEN RULE 2: In origin store:
    // If origin store was healthy (not an active monotalla), it must NOT become a new Monotalla alert!
    const wasSrcMonotalla = srcTotalBefore <= umbralMono && srcTallasBefore === 1;
    if (!wasSrcMonotalla) {
      if (srcTotalAfter > 0 && srcTotalAfter <= umbralMono && srcTallasAfter === 1) {
        return false; // REJECT: leaves behind a new Monotalla in origin!
      }
    }

    // GOLDEN RULE 3: CAPACITY WEIGHTING (Ponderación de Capacidad)
    // No saturar tiendas cuyo módulo ya se encuentre en el 100% de capacidad
    if (!checkDestCapacityAllowed(destStore, repItem.Departamento, units)) {
      return false; // REJECT: Destination store capacity reached/exceeded!
    }

    // Apply to live ledger
    simStock[srcStore][ref][talla] -= units;
    if (!simStock[destStore]) simStock[destStore] = {};
    if (!simStock[destStore][ref]) simStock[destStore][ref] = {};
    simStock[destStore][ref][talla] = (simStock[destStore][ref][talla] || 0) + units;

    const distInfo = getDistBetweenStores(srcStore, destStore, 15);
    const dist = distInfo.dist;
    const costoFlete = calcularCostoFlete(dist, units, ruleConfig);
    const unitVal = repItem.ValorUnitario || (repItem.Stock > 0 ? Math.round(repItem.Valoracion / repItem.Stock) : 45);
    const genero = (repItem as any).Genero || clasificarAreaGenero(repItem.Seccion, repItem.Departamento, ref) || 'CABALLERO';

    const safeSrc = srcStore.trim().replace(/\s+/g, '_');
    const safeDest = destStore.trim().replace(/\s+/g, '_');
    const safeRef = ref.trim().replace(/\s+/g, '_');
    const safeTalla = talla.trim().replace(/\s+/g, '_');

    suggestions.push({
      id: `trans-${safeSrc}-${safeDest}-${safeRef}-${safeTalla}`,
      Referencia: ref,
      Marca: repItem.Marca,
      Departamento: repItem.Departamento,
      Genero: genero,
      Seccion: repItem.Seccion,
      Talla: talla,
      TiendaOrigen: srcStore,
      StockOrigen: srcSizeStock,
      TiendaDestino: destStore,
      StockDestino: destSizeBefore,
      UnidadesSugeridas: units,
      DistanciaKm: dist,
      CostoFleteEstimado: costoFlete,
      ValoracionUnitario: unitVal,
      Motivo: motivo,
      Prioridad: prioridad,
      Estado: 'SUGERIDO',
      FechaCreacion: new Date().toISOString(),
      RevisadoPorAlmacen: false,
      isGpsCalculated: distInfo.isGps,
    });

    return true;
  };

  // STRATEGY 1: REPARACIÓN DE QUIEBRES EN TALLAS CORE (PRIORIDAD CRÍTICA / ALTA)
  // Destino tiene una curva activa rota por falta de tallas centrales (ej. 8 al 10.5 en calzado, M/L en textil)
  for (const destStore of stores) {
    if (!storeMap[destStore]) continue;
    for (const [ref, destData] of Object.entries(storeMap[destStore])) {
      const { depto } = destData;
      if (depto !== 'CALZADO' && depto !== 'TEXTIL') continue;

      const destTotal = getSimTotal(destStore, ref);
      if (destTotal < 3) continue; // Destino debe tener surtido activo de la referencia

      const coreList = depto === 'CALZADO' ? tallasCoreCalzado : tallasCoreTextil;
      const missingCores = coreList.filter((c) => getSimSizeStock(destStore, ref, c) === 0);
      if (missingCores.length === 0) continue;

      for (const coreSize of missingCores) {
        // Buscar tienda origen con excedente en esa talla (mínimo 3 unidades)
        const candidates = stores
          .filter((st) => st !== destStore && getSimSizeStock(st, ref, coreSize) >= 3)
          .map((st) => ({
            store: st,
            stock: getSimSizeStock(st, ref, coreSize),
            dist: getDistBetweenStores(st, destStore, 15).dist,
          }))
          .sort((a, b) => a.dist - b.dist);

        for (const cand of candidates) {
          const srcStore = cand.store;
          const srcSizeStock = getSimSizeStock(srcStore, ref, coreSize);
          const unitsToMove = Math.min(2, Math.floor(srcSizeStock / 2));
          if (unitsToMove >= 1) {
            const added = tryAddSuggestion(
              srcStore,
              destStore,
              ref,
              coreSize,
              unitsToMove,
              `Reconstrucción de Curva: Reparación de quiebre en talla core '${coreSize}'. Destino tenía 0 uds y Origen dispone de ${srcSizeStock} uds con stock balanceado.`,
              cand.dist < 20 ? 'ALTA' : 'MEDIA'
            );
            if (added) break;
          }
        }
      }
    }
  }

  // STRATEGY 2: CONSOLIDACIÓN DE TALLAS HUÉRFANAS / MONOTALLAS (ELIMINACIÓN DE ALERTAS)
  // Origen tiene 1 o 2 unidades en talla solitaria que generan una alerta activa
  for (const srcStore of stores) {
    if (!storeMap[srcStore]) continue;
    for (const [ref] of Object.entries(storeMap[srcStore])) {
      const srcTotal = getSimTotal(srcStore, ref);
      const srcTallas = getSimNumTallas(srcStore, ref);

      // Si origen tiene una Monotalla activa
      if (srcTotal > 0 && srcTotal <= umbralMono && srcTallas === 1) {
        const orphanSize = Object.entries(simStock[srcStore]?.[ref] || {}).find(([, qty]) => qty > 0)?.[0];
        if (!orphanSize) continue;
        const orphanUnits = getSimSizeStock(srcStore, ref, orphanSize);
        if (orphanUnits <= 0) continue;

        // Destino preferido: Tienda que YA tiene la referencia con volumen comercial (>= 4 uds y varias tallas), o Tienda Outlet
        const candidateDestinations = stores
          .filter((st) => st !== srcStore)
          .map((st) => {
            const destTotal = getSimTotal(st, ref);
            const destTallas = getSimNumTallas(st, ref);
            const isOutlet = isOutletStore(st);
            const dist = getDistBetweenStores(srcStore, st, 15).dist;
            let score = 0;
            if (destTotal >= 4 && destTallas >= 2) {
              score = 100 - dist;
            } else if (isOutlet) {
              score = 50 - dist;
            }
            return { store: st, score, dist, destTotal, isOutlet };
          })
          .filter((c) => c.score > 0)
          .sort((a, b) => b.score - a.score);

        for (const cand of candidateDestinations) {
          const destStore = cand.store;
          // Se transfieren TODAS las piezas restantes para que en Origen el stock quede en 0 y la alerta DESAPAREZCA
          const added = tryAddSuggestion(
            srcStore,
            destStore,
            ref,
            orphanSize,
            orphanUnits,
            `Consolidación de Monotalla: Retiro de ${orphanUnits} ud(s) huérfana(s) en '${orphanSize}' para liberar exhibición y consolidar en tienda con curva activa (${cand.destTotal} uds).`,
            cand.dist < 25 ? 'ALTA' : 'MEDIA'
          );
          if (added) break;
        }
      }
    }
  }

  // STRATEGY 3: ALIVIO DE SOBRESTOCK POR MODELO
  // Origen tiene stock > 24 (o > 36 en accesorios)
  for (const srcStore of stores) {
    if (!storeMap[srcStore]) continue;
    for (const [ref, srcData] of Object.entries(storeMap[srcStore])) {
      const { depto } = srcData;
      const limiteSobrestock = depto === 'ACCESORIOS' ? 36 : 24;
      const srcTotal = getSimTotal(srcStore, ref);

      if (srcTotal > limiteSobrestock) {
        const heavySizes = Object.entries(simStock[srcStore]?.[ref] || {})
          .filter(([, qty]) => qty >= 4)
          .sort((a, b) => b[1] - a[1]);

        for (const [size, sizeQty] of heavySizes) {
          if (getSimTotal(srcStore, ref) <= limiteSobrestock) break;

          const candidateDestinations = stores
            .filter((st) => {
              if (st === srcStore) return false;
              const dTotal = getSimTotal(st, ref);
              return dTotal >= 2 && dTotal <= 12 && getSimSizeStock(st, ref, size) <= 2;
            })
            .map((st) => ({
              store: st,
              dist: getDistBetweenStores(srcStore, st, 15).dist,
            }))
            .sort((a, b) => a.dist - b.dist);

          for (const cand of candidateDestinations) {
            const destStore = cand.store;
            const unitsToMove = Math.min(3, Math.max(1, Math.floor(sizeQty / 3)));
            const added = tryAddSuggestion(
              srcStore,
              destStore,
              ref,
              size,
              unitsToMove,
              `Alivio de Sobrestock: Despresurización de modelo con ${srcTotal} uds en Origen. Se transfieren ${unitsToMove} uds de talla '${size}' a tienda con baja profundidad.`,
              'MEDIA'
            );
            if (added) break;
          }
        }
      }
    }
  }

  // Sort by priority and proximity
  return suggestions.sort((a, b) => {
    if (a.Prioridad === 'ALTA' && b.Prioridad !== 'ALTA') return -1;
    if (b.Prioridad === 'ALTA' && a.Prioridad !== 'ALTA') return 1;
    if (a.Prioridad === 'MEDIA' && b.Prioridad === 'NORMAL') return -1;
    if (b.Prioridad === 'MEDIA' && a.Prioridad === 'NORMAL') return 1;
    return a.DistanciaKm - b.DistanciaKm;
  }).slice(0, 60);
}

// Helper function to detect store classification (Multimarca vs Conceptual) and brand concept
export function detectStoreClassification(
  storeName: string,
  profile?: StoreProfile,
  storeItems: InventoryItem[] = []
): {
  category: 'MULTIMARCA' | 'CONCEPTUAL';
  concept: string;
  typeLabel: string;
} {
  const lowerName = (storeName || '').toLowerCase();
  const marcasConfig = profile?.marcasCapacidad ? Object.keys(profile.marcasCapacidad) : [];

  let concept = 'Multimarca General';

  if (lowerName.includes('nike')) concept = 'Nike';
  else if (lowerName.includes('skechers') || lowerName.includes('skecheers')) concept = 'Skechers';
  else if (lowerName.includes('sportmarket') || lowerName.includes('sport market')) concept = 'Sportmarket';
  else if (lowerName.includes('adidas')) concept = 'Adidas';
  else if (lowerName.includes('puma')) concept = 'Puma';
  else if (lowerName.includes('under armour') || lowerName.includes('underarmour')) concept = 'Under Armour';
  else if (lowerName.includes('new balance')) concept = 'New Balance';
  else if (lowerName.includes('asics')) concept = 'Asics';
  else if (marcasConfig.length === 1 && marcasConfig[0] !== 'GENERAL') {
    concept = marcasConfig[0];
  } else if (storeItems.length > 0) {
    const brandCounts: Record<string, number> = {};
    let totalStk = 0;
    (storeItems || []).forEach((it) => {
      if (!it) return;
      brandCounts[it.Marca] = (brandCounts[it.Marca] || 0) + it.Stock;
      totalStk += it.Stock;
    });
    const sortedBrands = Object.entries(brandCounts).sort((a, b) => b[1] - a[1]);
    if (sortedBrands.length > 0 && totalStk > 0 && sortedBrands[0][1] / totalStk >= 0.7) {
      concept = sortedBrands[0][0];
    }
  }

  const isMonoBrand =
    concept !== 'Multimarca General' &&
    concept !== 'Sportmarket';

  const category: 'MULTIMARCA' | 'CONCEPTUAL' = isMonoBrand ? 'CONCEPTUAL' : 'MULTIMARCA';
  const typeLabel = isMonoBrand ? `Tienda Conceptual ${concept}` : 'Tienda Multimarca';

  return { category, concept, typeLabel };
}

