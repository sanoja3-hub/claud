import { StoreDistance, StoreProfile } from '../types';

/**
 * Calculates the great-circle distance between two points on the Earth's surface
 * using the Haversine formula, and applies an average road tortuosity factor (1.25x)
 * to estimate real driving distance.
 */
export function calculateGeoDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  roadTortuosityFactor: number = 1.25
): number {
  if (lat1 === lat2 && lon1 === lon2) return 0;

  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const straightLineDistance = R * c;

  // Road distance estimation: road distance is typically 20-30% longer than straight line
  const roadDistance = straightLineDistance * roadTortuosityFactor;

  return Math.round(roadDistance * 10) / 10;
}

/**
 * Calculates distance between two StoreProfile objects.
 * Returns calculated km if coordinates are available, or fallback value.
 */
export function calculateDistanceBetweenStores(
  storeA: Pick<StoreProfile, 'lat' | 'lng' | 'nombre'>,
  storeB: Pick<StoreProfile, 'lat' | 'lng' | 'nombre'>,
  fallbackKm: number = 15
): number {
  if (storeA.nombre === storeB.nombre) return 0;

  if (
    typeof storeA.lat === 'number' &&
    typeof storeA.lng === 'number' &&
    typeof storeB.lat === 'number' &&
    typeof storeB.lng === 'number'
  ) {
    const km = calculateGeoDistanceKm(storeA.lat, storeA.lng, storeB.lat, storeB.lng);
    return Math.max(1, km);
  }

  return fallbackKm;
}

/**
 * Recalculates the full network distance matrix for an array of stores.
 */
export function recalculateNetworkDistances(
  stores: StoreProfile[],
  existingDistances: StoreDistance = {}
): StoreDistance {
  const updated: StoreDistance = JSON.parse(JSON.stringify(existingDistances || {}));

  for (let i = 0; i < stores.length; i++) {
    const stA = stores[i];
    if (!stA?.nombre) continue;
    if (!updated[stA.nombre]) updated[stA.nombre] = {};

    for (let j = 0; j < stores.length; j++) {
      const stB = stores[j];
      if (!stB?.nombre) continue;
      if (stA.nombre === stB.nombre) {
        updated[stA.nombre][stB.nombre] = 0;
        continue;
      }

      // Check if both have coordinates to compute accurate geo-distance
      if (
        typeof stA.lat === 'number' &&
        typeof stA.lng === 'number' &&
        typeof stB.lat === 'number' &&
        typeof stB.lng === 'number'
      ) {
        const km = calculateDistanceBetweenStores(stA, stB);
        updated[stA.nombre][stB.nombre] = km;
        if (!updated[stB.nombre]) updated[stB.nombre] = {};
        updated[stB.nombre][stA.nombre] = km;
        // Also set flat composite keys for fast dual lookup
        (updated as any)[`${stA.nombre}-${stB.nombre}`] = km;
        (updated as any)[`${stB.nombre}-${stA.nombre}`] = km;
      } else if (updated[stA.nombre]?.[stB.nombre] === undefined) {
        // Keep existing or default to 15km
        const existing = updated[stB.nombre]?.[stA.nombre] || (updated as any)[`${stA.nombre}-${stB.nombre}`] || 15;
        updated[stA.nombre][stB.nombre] = existing;
        (updated as any)[`${stA.nombre}-${stB.nombre}`] = existing;
      }
    }
  }

  return updated;
}

/**
 * Extracts shopping mall, city, and normalized address components from a Google Place object.
 */
export interface ExtractedPlaceDetails {
  centroComercial?: string;
  ciudad: string;
  region?: string;
  direccion: string;
  formattedAddress: string;
  lat: number;
  lng: number;
  placeId: string;
  suggestedStoreName?: string;
}

export function parseGooglePlaceDetails(
  place: any // Supports google.maps.places.Place or Places API results
): ExtractedPlaceDetails | null {
  if (!place) return null;

  // Extract lat/lng
  let lat = 0;
  let lng = 0;
  if (place.location) {
    if (typeof place.location.lat === 'function') {
      lat = place.location.lat();
      lng = place.location.lng();
    } else {
      lat = place.location.lat || 0;
      lng = place.location.lng || 0;
    }
  } else if (place.geometry?.location) {
    if (typeof place.geometry.location.lat === 'function') {
      lat = place.geometry.location.lat();
      lng = place.geometry.location.lng();
    } else {
      lat = place.geometry.location.lat || 0;
      lng = place.geometry.location.lng || 0;
    }
  }

  const formattedAddress = place.formattedAddress || place.formatted_address || '';
  const displayName =
    typeof place.displayName === 'string'
      ? place.displayName
      : place.displayName?.text || place.name || '';

  let ciudad = '';
  let region = '';
  let centroComercial = '';
  let direccion = formattedAddress;

  const addressComponents: any[] = place.addressComponents || place.address_components || [];

  // Parse components
  for (const comp of addressComponents) {
    const types: string[] = comp.types || [];
    if (types.includes('locality')) {
      ciudad = comp.longText || comp.long_name || ciudad;
    } else if (!ciudad && types.includes('sublocality_level_1')) {
      ciudad = comp.longText || comp.long_name || ciudad;
    } else if (!ciudad && types.includes('administrative_area_level_2')) {
      ciudad = comp.longText || comp.long_name || ciudad;
    }

    if (types.includes('administrative_area_level_1')) {
      region = comp.longText || comp.long_name || region;
    } else if (!region && types.includes('country')) {
      region = comp.longText || comp.long_name || region;
    }
  }

  if (!ciudad && region) {
    ciudad = region;
  }

  // Detect shopping center / mall
  const placeTypes: string[] = place.types || [];
  const isMallType =
    placeTypes.includes('shopping_mall') ||
    placeTypes.includes('department_store') ||
    placeTypes.includes('shopping_center');

  const mallKeywords = [
    'mall',
    'centro comercial',
    'c.c.',
    'cc ',
    'plaza',
    'galerias',
    'galerías',
    'paseo',
    'outlet',
    'shopping',
    'parque',
  ];

  const nameLower = displayName.toLowerCase();
  const addressLower = formattedAddress.toLowerCase();

  if (isMallType || mallKeywords.some((k) => nameLower.includes(k))) {
    centroComercial = displayName;
  } else {
    // Check if address mentions a mall
    for (const kw of mallKeywords) {
      const idx = addressLower.indexOf(kw);
      if (idx !== -1) {
        // Extract surrounding phrase
        const chunk = formattedAddress.slice(idx, idx + 40).split(',')[0].trim();
        if (chunk) {
          centroComercial = chunk;
          break;
        }
      }
    }
  }

  // If displayName is a store inside a mall, suggested store name
  let suggestedStoreName = displayName;
  if (centroComercial && displayName && !displayName.toLowerCase().includes(centroComercial.toLowerCase())) {
    suggestedStoreName = `${displayName} - ${centroComercial}`;
  }

  return {
    centroComercial: centroComercial || undefined,
    ciudad: ciudad || 'Ciudad Principal',
    region: region || undefined,
    direccion: direccion || formattedAddress,
    formattedAddress: formattedAddress || displayName,
    lat,
    lng,
    placeId: place.id || place.place_id || '',
    suggestedStoreName,
  };
}
