import {
  collection,
  deleteDoc,
  disableNetwork,
  doc,
  enableNetwork,
  getDoc,
  getDocs,
  setDoc,
  writeBatch,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { auth, db, googleProvider, QUOTA_STORAGE_KEY } from './config';
import { handleFirestoreError, isQuotaExceededError, OperationType } from './errors';
import {
  CapacityMatrixConfig,
  InventoryItem,
  RuleEngineConfig,
  StoreDistance,
  StoreProfile,
} from '../types';

export interface CloudSyncStatus {
  isOnline: boolean;
  user: User | null;
  lastSyncedAt: string | null;
  isSyncing: boolean;
  error: string | null;
}

function checkPersistedQuotaExceeded(): boolean {
  try {
    const stored = localStorage.getItem(QUOTA_STORAGE_KEY);
    if (!stored) return false;
    const recordedTime = parseInt(stored, 10);
    if (isNaN(recordedTime)) return false;
    // Firestore daily quota resets every 24h
    const elapsed = Date.now() - recordedTime;
    if (elapsed < 24 * 60 * 60 * 1000) {
      return true;
    }
    localStorage.removeItem(QUOTA_STORAGE_KEY);
    return false;
  } catch {
    return false;
  }
}

// Module-level quota state initialized with persistence
let quotaExceededState = checkPersistedQuotaExceeded();
let quotaErrorMessage = quotaExceededState
  ? 'Cuota diaria de Firebase Firestore superada (20.000 operaciones/día). Operando en modo Local Seguro con IndexedDB.'
  : '';

// Immediately silence Firestore SDK network retry loop if quota was previously exceeded
if (quotaExceededState) {
  try {
    disableNetwork(db).catch(() => {});
  } catch {}
}

export function isCloudQuotaExceeded(): boolean {
  return quotaExceededState;
}

export function getCloudQuotaMessage(): string {
  return quotaErrorMessage;
}

export async function resetCloudQuotaState(): Promise<void> {
  quotaExceededState = false;
  quotaErrorMessage = '';
  try {
    localStorage.removeItem(QUOTA_STORAGE_KEY);
    await enableNetwork(db);
  } catch (e) {
    console.warn('Notice re-enabling Firestore network:', e);
  }
}

export function markQuotaExceeded(msg?: string): void {
  quotaExceededState = true;
  quotaErrorMessage =
    msg ||
    'Cuota diaria de Firebase Firestore superada (20.000 operaciones/día). La aplicación opera en modo Local Seguro con IndexedDB.';
  try {
    localStorage.setItem(QUOTA_STORAGE_KEY, String(Date.now()));
  } catch {}
  try {
    disableNetwork(db).catch((e) => console.warn('Notice disabling Firestore network:', e));
  } catch {}
}

// Cached signatures to skip writes if data has not changed
let lastProfilesHash = '';
let lastCapacitiesHash = '';
let lastInventoryHash = '';
let lastSettingsHash = '';

function computeHash(obj: any): string {
  try {
    return JSON.stringify(obj);
  } catch {
    return String(Math.random());
  }
}

// Convert any store name to safe Firestore document ID
export function sanitizeDocId(name: string): string {
  return encodeURIComponent((name || '').trim().replace(/[\/\\]/g, '-')) || 'unknown';
}

export function desanitizeDocId(id: string): string {
  try {
    return decodeURIComponent(id);
  } catch {
    return id;
  }
}

/**
 * Recursively remove all `undefined` fields from an object or array.
 * Firestore strictly forbids `undefined` values and throws:
 * "Function setDoc() called with invalid data. Unsupported field value: undefined"
 */
export function removeUndefined<T>(val: T): T {
  if (val === null || val === undefined) {
    return null as any;
  }
  if (Array.isArray(val)) {
    return val.map((item) => removeUndefined(item)) as any;
  }
  if (typeof val === 'object') {
    const res: Record<string, any> = {};
    for (const [k, v] of Object.entries(val as Record<string, any>)) {
      if (v !== undefined) {
        res[k] = removeUndefined(v);
      }
    }
    return res as any;
  }
  return val;
}

/**
 * Clean and normalize an InventoryItem for Firestore
 */
function sanitizeInventoryItem(item: InventoryItem, fallbackStore: string): Record<string, any> {
  const clean: Record<string, any> = {
    Referencia: String(item.Referencia || ''),
    Departamento: String(item.Departamento || 'CALZADO'),
    Seccion: String(item.Seccion || ''),
    Familia: String(item.Familia || ''),
    Marca: String(item.Marca || ''),
    Talla: String(item.Talla || ''),
    Stock: typeof item.Stock === 'number' && !isNaN(item.Stock) ? item.Stock : Number(item.Stock) || 0,
    Valoracion: typeof item.Valoracion === 'number' && !isNaN(item.Valoracion) ? item.Valoracion : Number(item.Valoracion) || 0,
    Tienda: String(item.Tienda || fallbackStore || ''),
    SKU_Talla: String(item.SKU_Talla || `${item.Referencia || ''}_${item.Talla || ''}`),
  };

  if (item.id !== undefined && item.id !== null) {
    clean.id = String(item.id);
  }
  if (item.FechaIngreso !== undefined && item.FechaIngreso !== null && item.FechaIngreso !== '') {
    clean.FechaIngreso = String(item.FechaIngreso);
  }
  if (item.DiasAntiguedad !== undefined && item.DiasAntiguedad !== null && !isNaN(Number(item.DiasAntiguedad))) {
    clean.DiasAntiguedad = Number(item.DiasAntiguedad);
  }
  if (item.ImagenUrl !== undefined && item.ImagenUrl !== null && item.ImagenUrl !== '') {
    clean.ImagenUrl = String(item.ImagenUrl);
  }

  // Campos que usa el motor de análisis (cobertura WOS, alertas por demanda, valoración en Bs).
  // Antes se descartaban al sincronizar y, tras restaurar desde la nube, esas alertas dejaban de funcionar.
  if (item.Temporada !== undefined && item.Temporada !== null && item.Temporada !== '') {
    clean.Temporada = String(item.Temporada);
  }
  const numericOptionals: Array<keyof InventoryItem> = [
    'ValorUnitario',
    'ValoracionBs',
    'ValorUnitarioBs',
    'VentaSemanal',
    'Venta30D',
    'WOS',
  ];
  for (const key of numericOptionals) {
    const raw = item[key];
    if (raw !== undefined && raw !== null && !isNaN(Number(raw))) {
      clean[key as string] = Number(raw);
    }
  }

  return clean;
}

/**
 * Authentication with Google
 */
export async function loginWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;

    // Record user profile in Firestore
    try {
      const userRef = doc(db, 'users', user.uid);
      const userPayload = removeUndefined({
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'Usuario Retail',
        photoURL: user.photoURL || '',
        // Ya no se escribe `role` desde el cliente: cualquier usuario podía autoasignarse ADMINISTRADOR_RETAIL.
        // Los roles deben asignarse a mano en la consola de Firebase (ver firestore.rules.hardened).
        lastLogin: new Date().toISOString(),
      });
      await setDoc(userRef, userPayload, { merge: true });
    } catch (e) {
      console.warn('User profile sync notice:', e);
    }

    return user;
  } catch (error) {
    console.error('Google login error:', error);
    throw error;
  }
}

export async function logoutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Logout error:', error);
    throw error;
  }
}

export function subscribeToAuth(callback: (user: User | null) => void): Unsubscribe {
  return onAuthStateChanged(auth, callback);
}

/**
 * Upload Store Profiles to Cloud Firestore
 */
export async function syncStoreProfilesToCloud(profiles: StoreProfile[]): Promise<void> {
  if (!auth.currentUser) return;
  if (quotaExceededState) return;

  const currentHash = computeHash(profiles);
  if (currentHash === lastProfilesHash) return;

  const path = 'stores';
  try {
    const batch = writeBatch(db);
    const now = new Date().toISOString();
    const uid = auth.currentUser.uid;

    profiles.forEach((profile) => {
      const docId = sanitizeDocId(profile.nombre || profile.id || 'tienda');
      const ref = doc(db, path, docId);
      const payload = removeUndefined({
        id: profile.id || profile.nombre || docId,
        nombre: profile.nombre || docId,
        ciudad: profile.ciudad || '',
        direccion: profile.direccion || '',
        superficieM2: profile.superficieM2 || 0,
        tipo: profile.tipo || 'FLAGSHIP',
        marcas: profile.marcas || [],
        cluster: profile.cluster || 'CENTRO',
        marcasCapacidad: profile.marcasCapacidad || null,
        capacidadPersonalizada: profile.capacidadPersonalizada || null,
        // Geolocalización y metadatos: sin ellos las distancias GPS (Haversine) se perdían al restaurar.
        region: profile.region ?? null,
        centroComercial: profile.centroComercial ?? null,
        lat: typeof profile.lat === 'number' ? profile.lat : null,
        lng: typeof profile.lng === 'number' ? profile.lng : null,
        placeId: profile.placeId ?? null,
        formattedAddress: profile.formattedAddress ?? null,
        mapsUrl: profile.mapsUrl ?? null,
        profundidadMediaTienda: profile.profundidadMediaTienda ?? null,
        totalSkusFisicos: profile.totalSkusFisicos ?? null,
        totalPiezasFisicas: profile.totalPiezasFisicas ?? null,
        fechaRegistro: profile.fechaRegistro ?? null,
        updatedAt: now,
        updatedBy: uid,
      });
      batch.set(ref, payload, { merge: true });
    });

    await batch.commit();
    lastProfilesHash = currentHash;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Upload Store Capacity Matrix to Cloud Firestore
 */
export async function syncStoreCapacitiesToCloud(
  capacities: Record<string, CapacityMatrixConfig>
): Promise<void> {
  if (!auth.currentUser) return;
  if (quotaExceededState) return;

  const currentHash = computeHash(capacities);
  if (currentHash === lastCapacitiesHash) return;

  const path = 'capacities';
  try {
    const batch = writeBatch(db);
    const now = new Date().toISOString();
    const uid = auth.currentUser.uid;

    Object.entries(capacities).forEach(([storeName, cap]) => {
      const docId = sanitizeDocId(storeName);
      const ref = doc(db, path, docId);
      const payload = removeUndefined({
        storeName,
        matrix: cap || {},
        updatedAt: now,
        updatedBy: uid,
      });
      batch.set(ref, payload, { merge: true });
    });

    await batch.commit();
    lastCapacitiesHash = currentHash;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

const INVENTORY_CHUNK_SIZE = 750;

/**
 * Upload Inventories to Cloud Firestore (Partitioned by Store and Chunks of 750 items max to respect Firestore 1MB document limit)
 */
export async function syncInventoriesToCloud(inventory: InventoryItem[]): Promise<void> {
  if (!auth.currentUser) return;
  if (quotaExceededState) return;

  // Huella con checksum sobre stock, valoración y claves: la versión anterior (longitud + primera/última
  // referencia + suma de stock) no detectaba, p. ej., un traslado que mueve unidades entre tiendas.
  let checksum = 0;
  for (let i = 0; i < inventory.length; i++) {
    const it = inventory[i];
    const key = `${it.Tienda}|${it.Referencia}|${it.Talla}`;
    let h = 0;
    for (let c = 0; c < key.length; c++) h = (h * 31 + key.charCodeAt(c)) | 0;
    checksum = (checksum + h * (1 + (it.Stock || 0)) + Math.round((it.Valoracion || 0) * 100)) | 0;
  }
  const invFingerprint = `${inventory.length}_${checksum}`;
  if (invFingerprint === lastInventoryHash) return;

  const path = 'inventories';
  try {
    // 1. Group inventory items by store
    const storeGroups: Record<string, InventoryItem[]> = {};
    inventory.forEach((item) => {
      const storeName = item.Tienda || 'SIN_TIENDA';
      if (!storeGroups[storeName]) storeGroups[storeName] = [];
      storeGroups[storeName].push(item);
    });

    const now = new Date().toISOString();
    const uid = auth.currentUser.uid;

    // 2. Query existing documents in inventories collection to know what to overwrite or clean up
    let existingDocIds: string[] = [];
    try {
      const existingSnap = await getDocs(collection(db, path));
      existingDocIds = existingSnap.docs.map((d) => d.id);
    } catch (e) {
      if (isQuotaExceededError(e)) {
        markQuotaExceeded();
        throw e;
      }
      console.warn('Notice reading existing inventory docs before sync:', e);
    }

    const newlyWrittenDocIds = new Set<string>();

    // 3. For each store, write documents (chunking if count > INVENTORY_CHUNK_SIZE)
    const entries = Object.entries(storeGroups);
    for (const [storeName, items] of entries) {
      const baseDocId = sanitizeDocId(storeName);
      const cleanItems = items.map((it) => sanitizeInventoryItem(it, storeName));
      const totalItems = cleanItems.length;

      if (totalItems <= INVENTORY_CHUNK_SIZE) {
        // Single document is small (< 150 KB), well within 1MB limit
        const docRef = doc(db, path, baseDocId);
        const payload = removeUndefined({
          storeName,
          itemCount: totalItems,
          partIndex: 0,
          totalParts: 1,
          items: cleanItems,
          updatedAt: now,
          updatedBy: uid,
        });
        await setDoc(docRef, payload, { merge: true });
        newlyWrittenDocIds.add(baseDocId);
      } else {
        // Partition into chunks of 750 items to ensure document size never exceeds 1MB limit
        const totalParts = Math.ceil(totalItems / INVENTORY_CHUNK_SIZE);
        for (let part = 0; part < totalParts; part++) {
          const chunkDocId = `${baseDocId}__part_${part}`;
          const chunkItems = cleanItems.slice(part * INVENTORY_CHUNK_SIZE, (part + 1) * INVENTORY_CHUNK_SIZE);
          const docRef = doc(db, path, chunkDocId);
          const payload = removeUndefined({
            storeName,
            itemCount: chunkItems.length,
            partIndex: part,
            totalParts,
            totalStoreItems: totalItems,
            items: chunkItems,
            updatedAt: now,
            updatedBy: uid,
          });
          await setDoc(docRef, payload, { merge: true });
          newlyWrittenDocIds.add(chunkDocId);
        }
      }

      // If this store had old parts or a single doc that are not in newlyWrittenDocIds, clean them up
      const oldStoreDocIds = existingDocIds.filter(
        (id) => (id === baseDocId || id.startsWith(`${baseDocId}__part_`)) && !newlyWrittenDocIds.has(id)
      );
      for (const oldId of oldStoreDocIds) {
        try {
          await deleteDoc(doc(db, path, oldId));
        } catch (delErr) {
          if (isQuotaExceededError(delErr)) {
            markQuotaExceeded();
            throw delErr;
          }
          console.warn('Notice removing old inventory chunk:', oldId, delErr);
        }
      }
    }
    lastInventoryHash = invFingerprint;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Upload Global Settings (Rule Config & Store Distances)
 */
export async function syncSettingsToCloud(
  ruleConfig: RuleEngineConfig,
  storeDistances: StoreDistance
): Promise<void> {
  if (!auth.currentUser) return;
  if (quotaExceededState) return;

  const currentHash = computeHash({ ruleConfig, storeDistances });
  if (currentHash === lastSettingsHash) return;

  const path = 'settings';
  try {
    const ref = doc(db, path, 'global');
    const payload = removeUndefined({
      ruleConfig: ruleConfig || {},
      storeDistances: storeDistances || {},
      updatedAt: new Date().toISOString(),
      updatedBy: auth.currentUser.uid,
    });
    await setDoc(ref, payload, { merge: true });
    lastSettingsHash = currentHash;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `${path}/global`);
  }
}

/**
 * Complete push to Cloud Firestore
 */
export async function pushFullStateToCloud(params: {
  inventory: InventoryItem[];
  storeProfiles: StoreProfile[];
  storeCapacities: Record<string, CapacityMatrixConfig>;
  storeDistances: StoreDistance;
  ruleConfig: RuleEngineConfig;
}): Promise<void> {
  if (!auth.currentUser) {
    throw new Error('Debes iniciar sesión con Google para sincronizar tus datos en la nube.');
  }

  if (quotaExceededState) {
    console.info('[CloudSync] Sincronización en la nube pausada: la cuota diaria de Firestore está agotada. Los datos se guardan de forma segura en almacenamiento local (IndexedDB).');
    return;
  }

  try {
    await syncStoreProfilesToCloud(params.storeProfiles);
    await syncStoreCapacitiesToCloud(params.storeCapacities);
    await syncInventoriesToCloud(params.inventory);
    await syncSettingsToCloud(params.ruleConfig, params.storeDistances);
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      console.warn('[CloudSync] Límite de cuota detectado en Firestore. Pausando auto-sincronización con la nube.');
    }
    throw error;
  }
}

/**
 * Pull all data from Cloud Firestore
 */
export async function pullFullStateFromCloud(): Promise<{
  inventory: InventoryItem[];
  storeProfiles: StoreProfile[];
  storeCapacities: Record<string, CapacityMatrixConfig>;
  storeDistances: StoreDistance;
  ruleConfig?: RuleEngineConfig;
} | null> {
  if (!auth.currentUser) return null;

  try {
    // 1. Fetch Store Profiles
    const DEMO_STORE_NAMES = new Set([
      'Tienda Centro (Flagship)',
      'Tienda Norte Mall',
      'Tienda Sur Outlet',
      'Tienda Este Plaza',
      'Tienda Oeste Hub',
      'Tienda Flagship Gran Vía',
      'Sucursal Centro Histórico',
      'Tienda Mall Los Dominicos',
      'Tienda Centro',
      'Tienda Norte',
      'Tienda Sur',
      'Tienda Este',
      'Tienda Oeste',
    ]);

    const storesSnap = await getDocs(collection(db, 'stores'));
    const storeProfiles: StoreProfile[] = [];
    storesSnap.forEach((d) => {
      const data = d.data();
      const storeName = data.nombre || d.id;
      if (DEMO_STORE_NAMES.has(storeName) || d.id.startsWith('demo-')) {
        return; // Skip obsolete demo stores
      }
      storeProfiles.push({
        id: data.id || d.id,
        nombre: storeName,
        ciudad: data.ciudad || '',
        direccion: data.direccion || '',
        superficieM2: data.superficieM2 || 500,
        tipo: data.tipo || 'FLAGSHIP',
        marcas: data.marcas || [],
        cluster: data.cluster || 'CENTRO',
        region: data.region ?? undefined,
        centroComercial: data.centroComercial ?? undefined,
        lat: typeof data.lat === 'number' ? data.lat : undefined,
        lng: typeof data.lng === 'number' ? data.lng : undefined,
        placeId: data.placeId ?? undefined,
        formattedAddress: data.formattedAddress ?? undefined,
        mapsUrl: data.mapsUrl ?? undefined,
        marcasCapacidad: data.marcasCapacidad ?? undefined,
        capacidadPersonalizada: data.capacidadPersonalizada ?? undefined,
        profundidadMediaTienda: data.profundidadMediaTienda ?? undefined,
        totalSkusFisicos: data.totalSkusFisicos ?? undefined,
        totalPiezasFisicas: data.totalPiezasFisicas ?? undefined,
        fechaRegistro: data.fechaRegistro ?? undefined,
      });
    });

    // 2. Fetch Store Capacities
    const capacitiesSnap = await getDocs(collection(db, 'capacities'));
    const storeCapacities: Record<string, CapacityMatrixConfig> = {};
    capacitiesSnap.forEach((d) => {
      const data = d.data();
      if (data.storeName && data.matrix) {
        storeCapacities[data.storeName] = data.matrix;
      }
    });

    // 3. Fetch Inventories
    const inventoriesSnap = await getDocs(collection(db, 'inventories'));
    const allItems: InventoryItem[] = [];
    inventoriesSnap.forEach((d) => {
      const data = d.data();
      if (Array.isArray(data.items)) {
        const storeFallback = data.storeName || desanitizeDocId(d.id.split('__part_')[0]);
        data.items.forEach((item: any) => {
          if (!item.Tienda && storeFallback) {
            item.Tienda = storeFallback;
          }
          allItems.push(item);
        });
      }
    });

    // 4. Fetch Settings
    let ruleConfig: RuleEngineConfig | undefined;
    let storeDistances: StoreDistance = {};
    const settingsDoc = await getDoc(doc(db, 'settings', 'global'));
    if (settingsDoc.exists()) {
      const data = settingsDoc.data();
      if (data.ruleConfig) ruleConfig = data.ruleConfig;
      if (data.storeDistances) storeDistances = data.storeDistances;
    }

    return {
      inventory: allItems,
      storeProfiles,
      storeCapacities,
      storeDistances,
      ruleConfig,
    };
  } catch (error) {
    if (isQuotaExceededError(error)) {
      markQuotaExceeded();
      console.warn('[CloudSync] Cuota excedida al consultar Firestore. Utilizando datos locales de IndexedDB.');
      return null;
    }
    handleFirestoreError(error, OperationType.GET, 'all');
  }
}
