import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, disableNetwork, setLogLevel } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { isQuotaExceededError } from './errors';

// Suppress repetitive internal backoff retry logs when quotas are exceeded
setLogLevel('silent');

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId); /* CRITICAL: The app will break without this line */
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const QUOTA_STORAGE_KEY = 'retail_firestore_quota_exceeded_timestamp';
export const FIRESTORE_UPGRADE_URL =
  'https://console.firebase.google.com/project/pivotal-vault-7f38q/firestore/databases/ai-studio-retailcommandcen-26707c9f-dfa7-4276-95f8-879b211b5cc3/data?openUpgradeDialog=true';
export const FIRESTORE_PRICING_URL = 'https://firebase.google.com/pricing#cloud-firestore';

// Immediately check if quota was exceeded in previous turns/sessions
try {
  const stored = typeof window !== 'undefined' ? localStorage.getItem(QUOTA_STORAGE_KEY) : null;
  if (stored) {
    const elapsed = Date.now() - parseInt(stored, 10);
    if (elapsed < 24 * 60 * 60 * 1000) {
      disableNetwork(db).catch(() => {});
    } else {
      localStorage.removeItem(QUOTA_STORAGE_KEY);
    }
  }
} catch {}

export async function testFirestoreConnection(
  onQuotaExceeded?: () => void
): Promise<boolean> {
  try {
    const stored = typeof window !== 'undefined' ? localStorage.getItem(QUOTA_STORAGE_KEY) : null;
    if (stored) {
      const elapsed = Date.now() - parseInt(stored, 10);
      if (elapsed < 24 * 60 * 60 * 1000) {
        if (onQuotaExceeded) onQuotaExceeded();
        return false;
      }
    }
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      try {
        localStorage.setItem(QUOTA_STORAGE_KEY, String(Date.now()));
        disableNetwork(db).catch(() => {});
      } catch {}
      if (onQuotaExceeded) onQuotaExceeded();
      console.warn('Firebase Firestore: Límite de cuota gratuita diaria alcanzado. Modo seguro local activado.');
      return false;
    }
    return false;
  }
}
