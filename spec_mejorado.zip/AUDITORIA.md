# Auditoría de SPEC / Retail Command Center

Alcance: lectura completa de configuración, reglas de Firestore, capa de persistencia/sync y arranque de `App.tsx`;
lectura parcial de `analysisEngine.ts`. No se pudo ejecutar `npm install` ni `vite build` (sin red), así que los
cambios se verificaron solo por sintaxis (`tsc`, errores TS1xxx), **no** con build ni pruebas en runtime.

## Cambios ya aplicados en el código

| Archivo | Problema | Cambio |
|---|---|---|
| `GoogleMapsStoreLocator.tsx` | Clave de Google Maps hardcodeada como fallback (línea 34-35) | Se lee solo de `VITE_GOOGLE_MAPS_API_KEY`; si falta, se muestra aviso en vez del mapa |
| `cloudSyncService.ts` | `sanitizeInventoryItem` descartaba `VentaSemanal`, `Venta30D`, `WOS`, `Temporada`, `ValorUnitario`, `ValoracionBs`, `ValorUnitarioBs`: al restaurar desde la nube se rompían las alertas por demanda/cobertura | Ahora se conservan |
| `cloudSyncService.ts` | Perfiles de tienda sin `lat/lng/placeId/region/...` ni al subir ni al bajar: se perdían las distancias GPS | Se suben y se leen de vuelta (incluye `marcasCapacidad` y `capacidadPersonalizada` en el pull) |
| `cloudSyncService.ts` | Huella del inventario (longitud + primera/última ref + suma de stock) no detectaba traslados entre tiendas | Checksum sobre tienda/ref/talla/stock/valoración |
| `cloudSyncService.ts` | El cliente escribía `role: 'ADMINISTRADOR_RETAIL'` a todo usuario que iniciara sesión | Se dejó de escribir `role` |
| `storageService.ts` | El respaldo "ligero" en localStorage serializaba el inventario completo en cada guardado | Solo metadatos; además `onabort` y cierre de la conexión IndexedDB |
| `App.tsx` | Autoguardado sin debounce (escritura completa de IndexedDB en cada cambio) | Debounce de 800 ms |
| `analysisEngine.ts` | `costoFleteBaseFijo \|\| 15` y `costoFleteBasePorKm \|\| 0.85` ignoraban un 0 configurado; distancia 0 en la matriz caía al fallback de 15 km | `??` y comprobación por tipo |

## Requiere tu acción (no lo puedo hacer yo)

1. **Rota la clave de Google Maps** que estaba en el código (`AIzaSyAx...`): ya viajó en el zip y en el historial.
   Créala de nuevo y restríngela por HTTP referrer y por API en Google Cloud Console.
2. **Reglas de Firestore.** `firestore.rules` permite que *cualquier* cuenta de Google con sesión lea y escriba
   todas las tiendas, inventarios y ajustes, y ahora mismo todos son "administradores". Dejé una propuesta en
   `firestore.rules.hardened` (roles asignados a mano, verificación de email, `role` inmutable desde el cliente,
   límite de 750 ítems por fragmento). Antes de activarla, asígnate `role: "ADMINISTRADOR_RETAIL"` en tu doc de
   `/users/{uid}` desde la consola, o te quedarás sin escritura.
3. **`xlsx@0.18.5` de npm** tiene vulnerabilidades conocidas (prototype pollution y ReDoS) y no recibe parches en
   npm; la app parsea archivos subidos por el usuario. SheetJS distribuye las versiones nuevas desde su propio CDN
   (cdn.sheetjs.com). Revisa allí la versión vigente antes de actualizar.

## Recomendaciones pendientes (no aplicadas)

- **Sincronización sin resolución de conflictos:** gana el último que escribe. Un dispositivo con datos viejos puede
  pisar la nube y borrar fragmentos. Además, si la lectura de la nube termina antes que la de IndexedDB, los datos
  locales (posiblemente viejos) sobrescriben a los de la nube. Conviene añadir un `updatedAt` global y comparar.
- **`syncInventoriesToCloud` lee toda la colección `inventories` en cada sincronización** y escribe documento a
  documento sin batch: consume la cuota gratuita (20.000 ops/día) muy rápido. Mejor escribir solo las tiendas
  cuyo contenido cambió y usar `writeBatch`.
- **Rendimiento:** no hay `React.lazy`. `RegisterStoreModal` (132 KB), `SizeCurveTab` (83 KB), `DashboardTab` (73 KB)
  y `xlsx` se cargan de entrada. Carga diferida de modales/pestañas e `import('xlsx')` dinámico reducirían el bundle.
- **`getDistBetweenStores`** hace `find` lineal con `toLowerCase()` en cada llamada dentro de bucles; construir
  antes un `Map` nombre→perfil.
- **Dependencias sin uso en `src/`:** `express`, `dotenv`, `@google/genai`, `esbuild`, `autoprefixer`, `tsx`;
  `vite` está duplicado en dependencies y devDependencies; el paquete se llama `react-example`. Al tocarlo,
  regenera `bun.lock`.
- **Deuda de tipos:** 54 usos de `any`/`as any`. `App.tsx` (1.790 líneas) concentra demasiado estado; conviene
  extraer hooks (`useCloudSync`, `useInventoryStore`).
- **El autoguardado con debounce** puede perder el último cambio si se cierra la pestaña en menos de 800 ms;
  si te preocupa, añade un flush en `beforeunload`.
